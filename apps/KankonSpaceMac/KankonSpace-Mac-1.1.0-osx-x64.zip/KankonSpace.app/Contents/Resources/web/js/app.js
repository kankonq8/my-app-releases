/* Kankon Space - app glue: views, info panel, time controls, tonight's sky, compare, quiz, help. */
(function () {
  const D = window.KS_DATA, A = window.KS_ASTRO, I = window.KS_I18N, S = window.KS_SOLAR;
  const t = I.t, L = I.L, $ = (s) => document.querySelector(s), $$ = (s) => document.querySelectorAll(s);
  const VERSION = (window.KS_HELP && KS_HELP.version) || '1.0.0';
  const AU_KM = 149597870.7, GM_SUN = 1.32712440018e11, C_KMS = 299792.458;
  const all = [D.sun, ...D.planets, ...D.dwarfs, ...D.comets, ...D.craft, ...D.moons];
  const byId = {}; all.forEach((b) => { byId[b.id] = b; });
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const nf = (x, d) => Number(x).toLocaleString('en-US', { maximumFractionDigits: d === undefined ? 1 : d, minimumFractionDigits: 0 });
  const ar = () => I.lang === 'ar';

  // ---------------- state ----------------
  const SPEEDS = [1 / 86400, 1 / 1440, 1 / 24, 1, 7, 30.4375, 365.25], SPK = ['spReal', 'spMin', 'spHour', 'spDay', 'spWeek', 'spMonth', 'spYear'];
  const st = { view: 'solar', simMs: Date.now(), playing: true, dir: 1, sp: 3, sel: null, live: false };

  // ---------------- formatting ----------------
  function distTxt(km) {
    const auv = km / AU_KM;
    if (km < 2e6) return nf(km, 0) + ' ' + t('km');
    if (km < 1e9) return nf(km / 1e6, 1) + ' ' + t('mkm') + ' (' + nf(auv, 2) + ' ' + t('au') + ')';
    return nf(km / 1e9, 2) + ' ' + t('bkm') + ' (' + nf(auv, 1) + ' ' + t('au') + ')';
  }
  // A number with its unit, with the right Arabic count form (1, 2, 3-10, 11+, decimals take the singular).
  const AR_UNITS = {
    seconds: ['ثانية واحدة', 'ثانيتان', 'ثوانٍ', 'ثانية', 'ثانية'], minutes: ['دقيقة واحدة', 'دقيقتان', 'دقائق', 'دقيقة', 'دقيقة'],
    hours: ['ساعة واحدة', 'ساعتان', 'ساعات', 'ساعة', 'ساعة'], days: ['يوم واحد', 'يومان', 'أيام', 'يومًا', 'يوم'],
    years: ['سنة واحدة', 'سنتان', 'سنوات', 'سنة', 'سنة'] };
  const EN_ONE = { seconds: 'second', minutes: 'minute', hours: 'hour', days: 'day', years: 'year' };
  function U(v, dec, unit) {
    const r = Number(Math.abs(v).toFixed(dec)), txt = nf(v, dec);
    if (!ar()) return txt + ' ' + (r === 1 ? EN_ONE[unit] : t(unit));
    const f = AR_UNITS[unit];
    if (r !== Math.floor(r)) return txt + ' ' + f[4];
    if (r === 1) return f[0];
    if (r === 2) return f[1];
    const m = r % 100;
    if (m >= 3 && m <= 10) return txt + ' ' + f[2];
    if (m >= 11) return txt + ' ' + f[3];
    return txt + ' ' + f[4];
  }
  function timeTxt(sec) {
    if (sec < 120) return U(sec, 1, 'seconds');
    if (sec < 7200) return U(sec / 60, 1, 'minutes');
    if (sec < 3 * 86400) return U(sec / 3600, 1, 'hours');
    return U(sec / 86400, 1, 'days');
  }
  function hoursTxt(h) {
    const a = Math.abs(h);
    let s = a >= 72 ? U(a / 24, 1, 'days') + ' (' + U(a, 1, 'hours') + ')' : U(a, 1, 'hours');
    if (h < 0) s += (ar() ? '، ' : ', ') + t('retro');
    return s;
  }
  function periodTxt(d) { return d >= 700 ? U(d / 365.25, d > 36500 ? 0 : 1, 'years') + ' (' + U(d, 0, 'days') + ')' : U(d, 1, 'days'); }
  function massTxt(m) {
    if (m >= 1e5) return '1.989 × 10³⁰ ' + t('kg');
    if (m < 0.01) return nf(m * 1000, 3) + ' × 10²¹ ' + t('kg');
    return nf(m, 3) + ' × 10²⁴ ' + t('kg');
  }
  const dirTxt = (az) => t('dirs')[Math.round(az / 45) % 8];
  const clock = (ms) => ms == null ? '-' : new Date(ms).toLocaleTimeString(ar() ? 'ar-KW-u-nu-latn' : 'en-GB', { hour: '2-digit', minute: '2-digit' });

  // ---------------- views ----------------
  function setView(v) {
    st.view = v;
    $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.v === v));
    $$('.view').forEach((e) => e.classList.toggle('on', e.id === 'v-' + v));
    if (v === 'earth') openEarth();
    if (v === 'galaxy') { if (!KS_GALAXY.inited) KS_GALAXY.init($('#cGalaxy'), $('#lGalaxy')); renderGalInfo(); }
    if (v === 'sky') renderSky();
    if (v === 'compare') renderCompare();
    if (v === 'ask' || v === 'apod') KS_ASSIST.open(v);
    if (v === 'quiz') { if (!quiz.qs) newQuiz(); else if (quiz.lang !== KS_I18N.lang) renderQuiz(); }
    setTimeout(resize, 0);
  }

  function resize() {
    const s = $('#v-solar .stage'); if (s.clientWidth) S.resize(s.clientWidth, s.clientHeight);
    const g = $('#v-galaxy .stage'); if (g.clientWidth) KS_GALAXY.resize(g.clientWidth, g.clientHeight);
    if (KS_EARTH.inited) KS_EARTH.resize();
  }

  // ---------------- body list ----------------
  function renderList() {
    const groups = [['gStar', [D.sun]], ['gPlanets', D.planets], ['gDwarfs', D.dwarfs], ['gComets', D.comets], ['gCraft', D.craft]];
    let h = `<button class="item ${st.sel ? '' : 'on'}" data-id=""><i style="background:radial-gradient(#fff,#ffcc55 40%,#5fa8ff)"></i>${esc(t('overview'))}</button>`;
    for (const [k, list] of groups) {
      h += `<div class="grp"><h4>${esc(t(k))}</h4>`;
      for (const b of list) h += `<button class="item ${st.sel === b.id ? 'on' : ''}" data-id="${b.id}"><i style="background:${b.color}"></i>${esc(L(b.name))}</button>`;
      h += '</div>';
    }
    h += `<div class="opts"><h4 class="muted small">${esc(t('show'))}</h4>
      <label class="chk"><input type="checkbox" data-o="orbits" ${opt.orbits ? 'checked' : ''}> ${esc(t('orbits'))}</label><br>
      <label class="chk"><input type="checkbox" data-o="labels" ${opt.labels ? 'checked' : ''}> ${esc(t('labels'))}</label><br>
      <label class="chk"><input type="checkbox" data-o="moons" ${opt.moons ? 'checked' : ''}> ${esc(t('moonsOpt'))}</label><br>
      <label class="chk"><input type="checkbox" data-o="belts" ${opt.belts ? 'checked' : ''}> ${esc(t('belts'))}</label><br>
      <label class="chk"><input type="checkbox" data-o="comets" ${opt.comets ? 'checked' : ''}> ${esc(t('cometsOpt'))}</label>
      <p class="muted small">${esc(t('scaleNote'))}</p></div>`;
    $('#list').innerHTML = h;
  }
  const opt = { orbits: true, labels: true, moons: true, belts: true, comets: true };
  $('#list').addEventListener('click', (e) => {
    const b = e.target.closest('.item'); if (!b) return;
    if (b.dataset.id) S.select(b.dataset.id); else S.overview();
  });
  $('#list').addEventListener('change', (e) => { const k = e.target.dataset.o; if (!k) return; opt[k] = e.target.checked; S.setOption(k, opt[k]); });

  // ---------------- info panel ----------------
  function liveInfo(b) {
    const jd = A.jdOf(st.simMs);
    if (b.id === 'sun') {
      const e = A.helio(D.planets[2], jd), r = A.len(e) * AU_KM;
      return kv([[t('fromEarth'), distTxt(r)], [t('lightEarth'), timeTxt(r / C_KMS)]]);
    }
    if (b.parent && b.id !== 'moon') return '';
    if (b.id === 'moon') {
      const m = A.moonGeo(jd);
      return kv([[t('fromEarth'), distTxt(m.dist)], [t('lightEarth'), timeTxt(m.dist / C_KMS)]]);
    }
    const h = A.helio(b, jd), r = A.len(h) * AU_KM, rows = [[t('fromSun'), distTxt(r)], [t('lightSun'), timeTxt(r / C_KMS)]];
    if (b.id !== 'earth') { const d = A.len(A.sub(h, A.helio(D.planets[2], jd))) * AU_KM; rows.push([t('fromEarth'), distTxt(d)], [t('lightEarth'), timeTxt(d / C_KMS)]); }
    if (b.kind !== 'craft') { const a = A.elements(b, jd).a * AU_KM; rows.push([t('speedNow'), nf(Math.sqrt(GM_SUN * (2 / r - 1 / a)), 1) + ' ' + t('kms')]); }
    else rows.push([t('speedNow'), nf(b.v * AU_KM / 31557600, 1) + ' ' + t('kms')]);
    return kv(rows) + (b.orb || b.kind === 'craft' ? `<p class="muted small">${esc(t('approxPos'))}</p>` : '');
  }
  function kv(rows) { return '<div class="kv">' + rows.map(([k, v]) => `<div>${esc(k)}</div><div>${esc(v)}</div>`).join('') + '</div>'; }

  function keyNumbers(b) {
    const f = b.f; if (!f) return '';
    const r = [];
    const C = (k) => f[k] !== undefined && f[k] !== null;
    if (b.id === 'sun') {
      r.push([t('fMass'), massTxt(f.mass)], [t('fDiam'), nf(f.diam, 0) + ' ' + t('km') + ' (109 ' + t('timesEarth') + ')'], [t('fDens'), nf(f.dens, 0) + ' ' + t('kgm3')],
        [t('fGrav'), nf(f.grav, 0) + ' ' + t('ms2')], [t('fEsc'), nf(f.esc, 1) + ' ' + t('kms')], [t('fRot'), hoursTxt(f.rot)], [t('fSurf'), nf(f.temp, 0) + ' ' + t('celsius')],
        [t('fCore'), '15 ' + t('millionC')], [t('fAge'), nf(f.age, 1) + ' ' + t('billionYears')]);
      return kv(r);
    }
    if (C('mass')) r.push([t('fMass'), massTxt(f.mass)]);
    if (C('diam')) r.push([t('fDiam'), nf(f.diam, f.diam < 100 ? 1 : 0) + ' ' + t('km')]);
    if (C('dens')) r.push([t('fDens'), nf(f.dens, 0) + ' ' + t('kgm3')]);
    if (C('grav')) r.push([t('fGrav'), nf(f.grav, 2) + ' ' + t('ms2')]);
    if (C('esc')) r.push([t('fEsc'), nf(f.esc, 1) + ' ' + t('kms')]);
    if (C('rot')) r.push([t('fRot'), hoursTxt(f.rot)]);
    if (C('day')) r.push([t('fDay'), hoursTxt(Math.abs(f.day))]);
    if (C('distE')) r.push([t('fDistE'), distTxt(f.distE * 1e6)]);
    if (C('dist')) r.push([t('fDist'), distTxt(f.dist * 1e6)]);
    if (C('peri')) r.push([t('fPeri'), distTxt(f.peri * 1e6)]);
    if (C('aph')) r.push([t('fAph'), distTxt(f.aph * 1e6)]);
    if (C('per')) r.push([t('fPer'), periodTxt(f.per)]);
    if (C('vel')) r.push([t('fVel'), nf(f.vel, 1) + ' ' + t('kms')]);
    if (C('inc')) r.push([t('fInc'), nf(f.inc, 1) + '°']);
    if (C('ecc')) r.push([t('fEcc'), nf(f.ecc, 3)]);
    if (C('obl')) r.push([t('fObl'), nf(f.obl, 1) + '°']);
    if (C('temp')) r.push([t('fTemp'), nf(f.temp, 0) + ' ' + t('celsius')]);
    if (C('tmin')) r.push([t('fRange'), nf(f.tmin, 0) + ' … ' + nf(f.tmax, 0) + ' ' + t('celsius')]);
    if (f.pres !== undefined) r.push([t('fPres'), f.pres === null ? t('noSurface') : (f.pres === 0 ? '≈ 0' : nf(f.pres, f.pres < 0.1 ? 5 : 0) + ' ' + t('bar'))]);
    if (C('moons')) r.push([t('fMoons'), nf(f.moons, 0)]);
    if (f.rings !== undefined) r.push([t('fRings'), f.rings ? t('yes') : t('no')]);
    if (f.mag !== undefined) r.push([t('fMag'), f.mag ? t('yes') : t('no')]);
    return kv(r) + (C('dist') ? `<p class="muted small">${esc(t('auNote'))}</p>` : '');
  }
  function vsEarth(b) {
    const f = b.f, e = D.planets[2].f; if (!f || !f.mass || b.id === 'earth' || b.id === 'sun') return '';
    return kv([[t('fDiam'), nf(f.diam / e.diam, 3) + ' ' + t('timesEarth')], [t('fMass'), nf(f.mass / e.mass, f.mass / e.mass < 0.01 ? 4 : 3) + ' ' + t('timesEarth')], [t('fGrav'), nf(f.grav / e.grav, 2) + ' ' + t('timesEarth')]]);
  }

  function renderInfo() {
    const id = st.sel, el = $('#info');
    if (!id) {
      el.innerHTML = `<h1>${esc(t('tabSolar'))}</h1><div class="type">${esc(L(D.sun.type))}</div>
        <p class="desc">${esc(ar() ? 'تتكون المجموعة الشمسية من الشمس وكل ما يدور حولها: ثمانية كواكب، وخمسة كواكب قزمة معروفة، ومئات الأقمار، وملايين الكويكبات والمذنبات. وقد تكونت قبل نحو 4.6 مليار سنة من سحابة من الغاز والغبار. اضغط أي جرم في القائمة أو في المشهد لترى تفاصيله، واستخدم أزرار الوقت في الأسفل لتحريك الكواكب في مداراتها.' : 'The Solar System is the Sun and everything that circles it: eight planets, five known dwarf planets, hundreds of moons and millions of asteroids and comets. It formed about 4.6 billion years ago from a cloud of gas and dust. Click anything in the list or in the 3D view to see its details, and use the time controls at the bottom to move the planets along their orbits.')}</p>
        <div class="card">${kv([[t('gPlanets'), '8'], [t('gDwarfs'), '5'], [ar() ? 'العمر' : 'Age', '4.6 ' + t('billionYears')], [ar() ? 'قطر مدار نبتون' : 'Width of Neptune\'s orbit', '9 ' + t('bkm')], [ar() ? 'بعد حد الغلاف الشمسي' : 'Edge of the Sun\'s bubble (heliopause)', '~120 ' + t('au')]])}</div>
        <h3>${esc(t('facts'))}</h3><ul class="facts">${(ar() ? ['يدور كل الكواكب حول الشمس في الاتجاه نفسه وفي مستوى متقارب تقريبًا.', 'الكواكب الأربعة الداخلية صخرية، والأربعة الخارجية عمالقة من الغاز والجليد.', 'لو كانت الشمس بحجم كرة قدم في الكويت، لكانت الأرض حبة فلفل على بعد 25 مترًا، ونبتون على بعد 750 مترًا.'] : ['All the planets orbit the Sun in the same direction and almost in the same flat plane.', 'The four inner planets are rocky; the four outer ones are giants of gas and ice.', 'If the Sun were a football, Earth would be a peppercorn 25 m away and Neptune would be 750 m away.']).map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`;
      return;
    }
    const b = byId[id];
    let h = `<h1>${esc(L(b.name))}</h1><div class="type">${esc(L(b.type) || (b.parent ? t('parentOf') + ' ' + L(byId[b.parent].name) : ''))}</div>`;
    h += `<p class="desc">${esc(L(b.desc))}</p>`;
    const btns = [];
    if (id === 'earth') btns.push(`<button class="accent" data-act="earth">🌍 ${esc(t('exploreEarth'))}</button>`);
    if (['mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'moon'].includes(id)) btns.push(`<button data-act="sky">🔭 ${esc(t('seeTonight'))}</button>`);
    btns.push(`<button data-act="ask">✨ ${esc(t('askAbout'))}</button>`);
    if (btns.length) h += `<div class="btnrow">${btns.join('')}</div>`;
    if (b.parent && id !== 'moon') {
      h += `<div class="card">${kv([[t('parentOf'), L(byId[b.parent].name)], [t('fDiam'), nf(b.R * 2, 0) + ' ' + t('km')], [ar() ? 'البعد عن الكوكب' : 'Distance from the planet', nf(b.a, 0) + ' ' + t('km')], [t('fPer'), U(Math.abs(b.P), 2, 'days') + (b.P < 0 ? (ar() ? '، ' : ', ') + t('retro') : '')], [t('discovered'), L(b.disc)]])}</div>`;
      h += `<div class="btnrow"><button data-go="${b.parent}">← ${esc(L(byId[b.parent].name))}</button></div>`;
    } else h += `<div class="card"><h3 style="margin-top:0">${esc(t('liveBox'))}</h3><div id="liveBox">${liveInfo(b)}</div></div>`;
    if (b.f) h += `<h3>${esc(t('keyNums'))}</h3><div class="card">${keyNumbers(b)}</div>`;
    const vs = vsEarth(b); if (vs) h += `<h3>${esc(t('vsEarth'))}</h3><div class="card">${vs}</div>`;
    if (b.atmo) {
      h += `<h3>${esc(t('atmo'))}</h3><div class="card">` + b.atmo.map(([g, p]) => `<div class="kv"><div>${esc(L(g))}</div><div>${nf(p, p < 1 ? 3 : 1)}%</div></div><div class="bar"><b style="width:${Math.max(1, p)}%"></b></div>`).join('') + (b.atmoNote ? `<p class="muted small">${esc(L(b.atmoNote))}</p>` : '') + '</div>';
    }
    const ms = D.moons.filter((m) => m.parent === id);
    if (ms.length) h += `<h3>${esc(t('moonsH'))}</h3><div class="chips">${ms.map((m) => `<span class="chip" data-go="${m.id}">${esc(L(m.name))}</span>`).join('')}</div>`;
    if (b.missions) h += `<h3>${esc(t('missions'))}</h3><div class="card">${b.missions.map(([y, n, d]) => `<div class="mis"><div class="y">${y}</div><div><b>${esc(n)}</b><br><span class="muted">${esc(L(d))}</span></div></div>`).join('')}</div>`;
    if (b.facts) h += `<h3>${esc(t('facts'))}</h3><ul class="facts">${b.facts.map((x) => `<li>${esc(L(x))}</li>`).join('')}</ul>`;
    el.innerHTML = h;
  }
  $('#info').addEventListener('click', (e) => {
    const g = e.target.closest('[data-go]'); if (g) { S.select(g.dataset.go); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'earth') setView('earth');
    if (a.dataset.act === 'sky') setView('sky');
    if (a.dataset.act === 'ask' && st.sel) { setView('ask'); KS_ASSIST.prefill(t('askAboutQ').replace('{0}', L(byId[st.sel].name))); }
  });
  S.onSelect = (id) => { st.sel = id; renderList(); renderInfo(); };

  // ---------------- time controls ----------------
  function speedText() {
    if (!st.playing) return t('paused');
    return t(SPK[st.sp]) + (st.dir < 0 ? ' · ' + t('backwards') : '');
  }
  function updateTimeUi() {
    $('#tSpeed').textContent = speedText();
    $('#tPlay').textContent = st.playing ? '❚❚' : '▶';
    $('#tPlay').title = st.playing ? t('pause') : t('play');
    $('#tRev').classList.toggle('on', st.dir < 0);
    const y = new Date(st.simMs).getFullYear();
    const live = st.playing && st.sp === 0 && st.dir > 0 && Math.abs(st.simMs - Date.now()) < 120000;
    $('#tNote').textContent = live ? '● ' + t('liveNow') : (y < 1800 || y > 2050 ? t('outOfRange') : '');
    $('#tNow').classList.toggle('accent', !live);
  }
  function toLocalInput(ms) { const d = new Date(ms - new Date(ms).getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16); }
  $('#tPlay').onclick = () => { st.playing = !st.playing; updateTimeUi(); };
  $('#tSlow').onclick = () => { st.sp = Math.max(0, st.sp - 1); st.playing = true; updateTimeUi(); };
  $('#tFast').onclick = () => { st.sp = Math.min(SPEEDS.length - 1, st.sp + 1); st.playing = true; updateTimeUi(); };
  $('#tRev').onclick = () => { st.dir = -st.dir; st.playing = true; if (st.sp === 0) st.sp = 3; updateTimeUi(); };
  $('#tNow').onclick = () => { st.simMs = Date.now(); st.sp = 0; st.dir = 1; st.playing = true; updateTimeUi(); };
  $('#tDate').addEventListener('change', (e) => { const v = Date.parse(e.target.value); if (!isNaN(v)) { st.simMs = v; updateTimeUi(); } });
  $('#tDate').title = t('dateHint');
  $('#sVis').onclick = () => { $('#sVis').classList.add('on'); $('#sTrue').classList.remove('on'); S.setOption('scale', 'visual'); };
  $('#sTrue').onclick = () => { $('#sTrue').classList.add('on'); $('#sVis').classList.remove('on'); S.setOption('scale', 'true'); };
  $('#bOverview').onclick = () => S.overview();

  // ---------------- Earth ----------------
  let earthReady = false;
  function openEarth() {
    if (earthReady) return; earthReady = true;
    $('#eStatus').textContent = t('eLoading');
    const s = document.createElement('script'); s.src = 'lib/cesium/Cesium.js';
    s.onload = async () => {
      try {
        await KS_EARTH.init($('#cesium'));
        $('#eStatus').textContent = navigator.onLine === false ? t('eOffline') : '';
        if ($('#issOn').checked) KS_EARTH.issStart();
      } catch (e) { $('#eStatus').textContent = 'Earth view error: ' + e.message; }
    };
    s.onerror = () => { $('#eStatus').textContent = 'Could not load the 3D globe.'; };
    document.body.appendChild(s);
  }
  function renderPlaces() {
    let h = '';
    D.earthPlaces.forEach((g, gi) => { h += `<div class="pgrp">${esc(L(g.g))}</div>`; g.items.forEach((p, pi) => { h += `<button class="place" data-p="${gi}.${pi}">📍 ${esc(L(p[0]))}</button>`; }); });
    $('#ePlaces').innerHTML = h;
  }
  $('#ePlaces').addEventListener('click', (e) => { const b = e.target.closest('[data-p]'); if (!b || !KS_EARTH.inited) return; const [g, i] = b.dataset.p.split('.').map(Number); const p = D.earthPlaces[g].items[i]; KS_EARTH.flyTo(p[1], p[2], p[3]); });
  $('#eLayers').addEventListener('click', (e) => { const b = e.target.closest('[data-l]'); if (!b || !KS_EARTH.inited) return; $$('#eLayers button').forEach((x) => x.classList.toggle('on', x === b)); KS_EARTH.setLayer(b.dataset.l); });
  $('#eSun').onchange = (e) => KS_EARTH.inited && KS_EARTH.setLighting(e.target.checked);
  $('#eHome').onclick = () => KS_EARTH.inited && KS_EARTH.home();
  $('#eIn').onclick = () => KS_EARTH.inited && KS_EARTH.zoom(1);
  $('#eOut').onclick = () => KS_EARTH.inited && KS_EARTH.zoom(-1);
  $('#eGo').onclick = () => { const la = parseFloat($('#eLat').value), lo = parseFloat($('#eLon').value); if (isFinite(la) && isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180) KS_EARTH.flyTo(la, lo, 3000); };
  $('#issOn').onchange = (e) => { if (!KS_EARTH.inited) return; if (e.target.checked) { $('#issBox').textContent = t('issWait'); KS_EARTH.issStart(); } else { KS_EARTH.issStop(); $('#issBox').innerHTML = ''; $('#issFol').checked = false; } };
  $('#issFol').onchange = (e) => { if (e.target.checked && !$('#issOn').checked) { $('#issOn').checked = true; $('#issOn').onchange({ target: $('#issOn') }); } KS_EARTH.followIss(e.target.checked); };
  let lastIss = null, eMouse = null, eHeight = null;
  KS_EARTH.onInfo = (d) => {
    if (d.iss) { lastIss = d.iss; renderIss(); }
    if (d.issErr && !lastIss) $('#issBox').textContent = t('issErr');
    if ('mouse' in d) eMouse = d.mouse;
    if ('height' in d) eHeight = d.height;
    $('#eCoords').textContent = (eMouse ? eMouse[0].toFixed(4) + '°, ' + eMouse[1].toFixed(4) + '°   ' : '') + (eHeight ? t('eHeight') + ': ' + (eHeight > 10000 ? nf(eHeight / 1000, 0) + ' km' : nf(eHeight, 0) + ' m') : '');
  };
  function renderIss() {
    const d = lastIss; if (!d) return;
    const lat = d.latitude, lon = d.longitude;
    $('#issBox').innerHTML = kv([[t('issLat'), `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? 'N' : 'S'}, ${Math.abs(lon).toFixed(2)}°${lon >= 0 ? 'E' : 'W'}`], [t('issAlt'), nf(d.altitude, 0) + ' ' + t('km')], [t('issSpeed'), nf(d.velocity, 0) + ' ' + (ar() ? 'كم/س' : 'km/h')], ['☀', d.visibility === 'eclipsed' ? t('issShadow') : t('issSun')]]) + `<p class="muted small">${esc(t('issNote'))}</p>`;
  }

  // ---------------- Galaxy ----------------
  function renderGalInfo() {
    const f = ar() ? [
      ['القطر', 'نحو 100000 سنة ضوئية'], ['عدد النجوم', 'من 100 إلى 400 مليار'], ['العمر', 'نحو 13.6 مليار سنة'], ['الكتلة', 'نحو 1.5 تريليون كتلة شمسية (مع المادة المظلمة)'],
      ['بعد الشمس عن المركز', 'نحو 26000 سنة ضوئية'], ['سرعة الشمس حول المركز', 'نحو 230 كم في الثانية'], ['الدورة الواحدة للشمس', 'نحو 230 مليون سنة'],
      ['الثقب الأسود في المركز', 'القوس A*، كتلته 4.3 مليون ضعف كتلة الشمس'], ['سُمك القرص', 'نحو 1000 سنة ضوئية'], ['أقرب مجرة كبيرة', 'المرأة المسلسلة (أندروميدا)، على بعد 2.5 مليون سنة ضوئية']
    ] : [
      ['Diameter', 'about 100,000 light-years'], ['Stars', '100 to 400 billion'], ['Age', 'about 13.6 billion years'], ['Mass', 'about 1.5 trillion Suns (with dark matter)'],
      ['Sun\'s distance from the centre', 'about 26,000 light-years'], ['Sun\'s speed around the centre', 'about 230 km/s'], ['One lap of the Sun', 'about 230 million years'],
      ['Black hole at the centre', 'Sagittarius A*, 4.3 million times the Sun\'s mass'], ['Thickness of the disc', 'about 1,000 light-years'], ['Nearest big galaxy', 'Andromeda, 2.5 million light-years away']];
    const facts = ar() ? ['سُمّيت درب التبانة لأنها تبدو في السماء المظلمة كشريط حليبي من الضوء، ويسمّيها العرب أيضًا «المجرّة».', 'كل النجوم التي نراها بالعين المجردة تقريبًا تقع في جزء صغير من المجرة قريب منا.', 'التقطت شبكة مقراب أفق الحدث أول صورة لظل الثقب الأسود في مركز المجرة عام 2022.', 'تقترب مجرة أندروميدا منا بسرعة نحو 110 كم في الثانية، وقد تندمج المجرتان بعد مليارات السنين.', 'السنة الضوئية هي المسافة التي يقطعها الضوء في سنة: نحو 9.46 تريليون كم.']
      : ['It is called the Milky Way because from a dark place it looks like a milky band of light across the sky.', 'Almost every star you can see with your eyes is in a small part of the galaxy close to us.', 'The Event Horizon Telescope took the first picture of the shadow of the black hole at the centre in 2022.', 'Andromeda is coming towards us at about 110 km/s; the two galaxies may merge in several billion years.', 'A light-year is how far light goes in a year: about 9.46 trillion km.'];
    $('#galInfo').innerHTML = `<h1>${esc(t('galTitle'))}</h1><div class="type">${ar() ? 'مجرة حلزونية ذات قضيب' : 'Barred spiral galaxy'}</div>
      <p class="desc">${ar() ? 'مجرتنا قرص هائل من النجوم والغاز والغبار، له قضيب في المركز وأذرع حلزونية. وتقع الشمس في ذراع صغير يُسمّى ذراع الجبار، في منتصف المسافة تقريبًا بين المركز والحافة.' : 'Our galaxy is a huge disc of stars, gas and dust with a bar in the middle and spiral arms. The Sun sits in a small arm called the Orion Spur, about halfway from the centre to the edge.'}</p>
      <div class="card">${kv(f)}</div><h3>${esc(t('facts'))}</h3><ul class="facts">${facts.map((x) => `<li>${esc(x)}</li>`).join('')}</ul><p class="muted small">${esc(t('galModel'))}</p>`;
  }
  $$('[data-g]').forEach((b) => b.onclick = () => { $$('[data-g]').forEach((x) => x.classList.toggle('on', x === b)); KS_GALAXY.view(b.dataset.g); });

  // ---------------- Tonight's sky ----------------
  let skyData = null;
  function skyPlace() { return D.places.find((p) => p.id === $('#skyPlace').value) || D.places[0]; }
  function renderSky() {
    const sel = $('#skyPlace');
    if (!sel.options.length || sel.dataset.lang !== I.lang) {
      const cur = sel.value || localStorage.getItem('ks-place') || 'kuwait';
      sel.innerHTML = D.places.map((p) => `<option value="${p.id}">${esc(L(p.name))}</option>`).join(''); sel.value = cur; sel.dataset.lang = I.lang;
    }
    const p = skyPlace();
    const bodies = [D.moons[0], ...D.planets.filter((x) => x.id !== 'earth')];
    skyData = A.tonight(bodies, p.lat, p.lon, Date.now());
    const sd = skyData;
    $('#skySun').innerHTML = `<span class="chip">🌇 ${esc(t('skySunset'))} ${clock(sd.set)}</span><span class="chip">🌌 ${esc(t('skyDark'))} ${clock(sd.dusk)} – ${clock(sd.dawn)}</span><span class="chip">🌅 ${esc(t('skySunrise'))} ${clock(sd.rise)}</span>`;
    let h = `<tr><th>${esc(t('colBody'))}</th><th>${esc(t('colSee'))}</th><th>${esc(t('colWhen'))}</th><th>${esc(t('colRise'))}</th><th>${esc(t('colMag'))}</th><th>${esc(t('colNow'))}</th></tr>`;
    for (const r of sd.list) {
      let v, cls;
      if (r.firstUp === null) { v = r.elong < 18 ? t('vSun') : t('vNo'); cls = 'nope'; }
      else if (r.mag < 1) { v = t('vEasy'); cls = 'ok'; } else if (r.mag < 5.8) { v = t('vEye'); cls = 'ok'; } else { v = t('vScope'); cls = 'mid'; }
      const when = r.firstUp === null ? '-' : `${clock(r.best.t)}<br><span class="muted">${dirTxt(r.best.az)}${ar() ? "، " : ", "}${esc(t('high').replace('{0}', Math.round(r.best.alt)))}</span>`;
      const rs = (r.riseT || r.setT) ? `${r.riseT ? '↑ ' + clock(r.riseT) : ''} ${r.setT ? '↓ ' + clock(r.setT) : ''}` : (r.best.alt > 0 ? t('allNight') : '-');
      const now = r.now.alt > 0 ? `${dirTxt(r.now.az)}${ar() ? "، " : ", "}${esc(t("high").replace("{0}", Math.round(r.now.alt)))}` : `<span class="muted">${esc(t('down'))}</span>`;
      h += `<tr class="${r.firstUp === null ? 'dim' : ''}"><td><b style="color:${r.b.color}">●</b> ${esc(L(r.b.name))}</td><td class="${cls}">${esc(v)}</td><td>${when}</td><td>${rs}</td><td>${r.mag === undefined ? '-' : nf(r.mag, 1)}</td><td>${now}</td></tr>`;
    }
    $('#skyTable').innerHTML = h;
    // default slider: now if dark, else dusk
    const now = Date.now(), t0 = sd.set, t1 = sd.rise;
    const k = now > t0 && now < t1 ? (now - t0) / (t1 - t0) : ((sd.dusk || t0) - t0) / (t1 - t0) + 0.05;
    $('#skySlider').value = Math.round(Math.min(1, Math.max(0, k)) * 100);
    drawDome();
  }
  function drawDome() {
    if (!skyData) return;
    const cv = $('#skyDome'), g = cv.getContext('2d'), W = cv.width, cx = W / 2, cy = W / 2, R = W / 2 - 40;
    const p = skyPlace(), ms = skyData.set + (skyData.rise - skyData.set) * $('#skySlider').value / 100, jd = A.jdOf(ms);
    $('#skyT').textContent = clock(ms);
    g.clearRect(0, 0, W, W);
    const sun = A.geo(D.sun, jd), sh = A.altAz(sun.ra, sun.dec, p.lat, p.lon, jd).alt;
    const sky = sh > -6 ? '#1d2f57' : sh > -12 ? '#122042' : '#070d1f';
    g.fillStyle = sky; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#2c4270'; g.lineWidth = 1;
    for (const a of [30, 60]) { g.beginPath(); g.arc(cx, cy, R * (90 - a) / 90, 0, Math.PI * 2); g.stroke(); }
    g.strokeStyle = '#5a76a8'; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#9fb3d6'; g.font = '600 15px Segoe UI, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const dn = t('dirs');
    [[0, dn[0]], [90, dn[2]], [180, dn[4]], [270, dn[6]]].forEach(([az, s]) => { const x = cx - (R + 22) * Math.sin(az * Math.PI / 180), y = cy - (R + 22) * Math.cos(az * Math.PI / 180); g.fillText(s, x, y); });
    // random faint stars (fixed seed)
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    g.fillStyle = 'rgba(255,255,255,0.5)'; for (let i = 0; i < 260; i++) { const r = Math.sqrt(rnd()) * R, a = rnd() * Math.PI * 2; g.fillRect(cx + r * Math.cos(a), cy + r * Math.sin(a), 1.2, 1.2); }
    const bodies = [D.moons[0], ...D.planets.filter((x) => x.id !== 'earth')];
    for (const b of bodies) {
      const q = A.geo(b, jd), h = A.altAz(q.ra, q.dec, p.lat, p.lon, jd);
      if (h.alt < 0) continue;
      const r = R * (90 - h.alt) / 90, x = cx - r * Math.sin(h.az * Math.PI / 180), y = cy - r * Math.cos(h.az * Math.PI / 180);
      const size = b.id === 'moon' ? 11 : Math.max(3, 7 - (q.mag || 6) * 0.8);
      g.fillStyle = b.id === 'moon' ? '#eeeeee' : b.color; g.beginPath(); g.arc(x, y, size, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#e6ecf7'; g.font = '13px Segoe UI, sans-serif'; g.fillText(L(b.name), x, y - size - 9);
    }
  }
  $('#skyPlace').onchange = () => { localStorage.setItem('ks-place', $('#skyPlace').value); renderSky(); };
  $('#skySlider').oninput = drawDome;

  // ---------------- Compare ----------------
  const imgs = {};
  function img(name) { if (!imgs[name]) { imgs[name] = new Image(); imgs[name].onload = () => st.view === 'compare' && drawCompare(); imgs[name].src = 'tex/' + name; } return imgs[name]; }
  let cmpMode = 'planets';
  function drawBall(g, b, x, y, r) {
    g.save(); g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.clip();
    const im = b.tex ? img(b.tex) : null;
    if (im && im.complete && im.naturalWidth) g.drawImage(im, im.naturalWidth * 0.3, 0, im.naturalWidth * 0.4, im.naturalHeight, x - r, y - r, 2 * r, 2 * r);
    else { g.fillStyle = b.color; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
    const sh = g.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r * 1.05); sh.addColorStop(0, 'rgba(255,255,255,0.08)'); sh.addColorStop(0.7, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.55)');
    if (b.id !== 'sun') { g.fillStyle = sh; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
    g.restore();
  }
  function drawCompare() {
    const cv = $('#cmpCanvas'), g = cv.getContext('2d'), W = cv.width, H = cv.height;
    g.clearRect(0, 0, W, H); g.fillStyle = '#050a16'; g.fillRect(0, 0, W, H);
    g.textAlign = 'center'; g.textBaseline = 'top'; g.font = '600 15px Segoe UI, sans-serif';
    const rtl = ar();
    let list, scale, x;
    const base = H - 70;
    if (cmpMode === 'small') {
      list = [D.planets[2], D.planets[0], ...D.moons.filter((m) => m.R > 700), D.dwarfs[1], D.dwarfs[4], D.dwarfs[2], D.dwarfs[3], D.dwarfs[0]].sort((a, b) => b.R - a.R);
      scale = (H - 120) / 2 / 6371;
    } else list = D.planets;
    if (cmpMode === 'planets') scale = (H - 120) / 2 / 69911 * 0.82;
    if (cmpMode === 'sun') {
      scale = (H - 120) / 2 / 69911 * 0.42;
      const rs = 695700 * scale; x = 70 - rs + rs * 0.12;
      drawBall(g, D.sun, rtl ? W - x : x, base - (H - 120) / 2 * 0.42 - 20, rs);
      g.fillStyle = '#ffd77a'; g.fillText(L(D.sun.name), rtl ? W - 50 : 50, 10);
    }
    const sum = list.reduce((s, b) => s + 2 * b.R * scale, 0);
    const startX = cmpMode === 'sun' ? 150 : 40, gap = (W - startX - 40 - sum) / Math.max(1, list.length - 1);
    x = startX;
    for (const b of list) {
      const r = b.R * scale, cx = x + r, cxx = rtl ? W - cx : cx, cy = base - Math.max(r, 2);
      if (b.id === 'saturn') { g.strokeStyle = 'rgba(220,200,150,0.65)'; g.lineWidth = Math.max(2, r * 0.18); g.beginPath(); g.ellipse(cxx, cy, r * 1.85, r * 0.34, -0.18, 0, Math.PI * 2); g.stroke(); }
      drawBall(g, b, cxx, cy, Math.max(r, 2));
      g.fillStyle = '#e6ecf7'; g.font = '600 14px Segoe UI, sans-serif'; g.fillText(L(b.name), cxx, base + 10);
      g.fillStyle = '#93a3bf'; g.font = '12.5px Segoe UI, sans-serif'; g.fillText(nf(b.f && b.f.diam ? b.f.diam : b.R * 2, 0) + ' ' + t('km'), cxx, base + 30);
      x += 2 * r + gap;
    }
  }
  function renderCompare() {
    drawCompare();
    const w = parseFloat($('#wIn').value) || 70, ge = 9.8;
    const ws = [D.sun, D.planets[0], D.planets[1], D.planets[2], D.moons[0], D.planets[3], D.dwarfs[0], D.planets[4], D.planets[5], D.planets[6], D.planets[7], D.dwarfs[1]];
    $('#wTable').innerHTML = ws.map((b) => `<tr><td><b style="color:${b.color}">●</b> ${esc(L(b.name))}</td><td style="text-align:end"><b>${nf(w * b.f.grav / ge, 1)}</b> ${esc(t('kg'))}</td></tr>`).join('');
    const bd = Date.parse($('#aIn').value), now = Date.now();
    if (isNaN(bd) || bd > now) { $('#aTable').innerHTML = ''; return; }
    const days = (now - bd) / 86400000;
    $('#aTable').innerHTML = `<tr><th></th><th>${esc(t('ageYears'))}</th><th>${esc(t('nextBday'))}</th></tr>` + [...D.planets, D.dwarfs[1]].map((b) => {
      const P = b.f.per, age = days / P, next = new Date(bd + Math.ceil(age + 1e-9) * P * 86400000);
      return `<tr><td><b style="color:${b.color}">●</b> ${esc(L(b.name))}</td><td><b>${nf(age, age < 1 ? 3 : 2)}</b></td><td>${next.getFullYear() > 9999 ? '-' : next.toLocaleDateString(ar() ? 'ar-KW-u-nu-latn' : 'en-GB', { year: 'numeric', month: 'short', day: 'numeric' })}</td></tr>`;
    }).join('');
  }
  $('#cmpMode').addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (!b) return; cmpMode = b.dataset.c; $$('#cmpMode button').forEach((x) => x.classList.toggle('on', x === b)); drawCompare(); });
  $('#wIn').oninput = renderCompare; $('#aIn').oninput = renderCompare;

  // ---------------- Quiz ----------------
  const quiz = {};
  function newQuiz() {
    const idx = D.quiz.map((_, i) => i).sort(() => Math.random() - 0.5).slice(0, 10);
    quiz.qs = idx; quiz.i = 0; quiz.score = 0; quiz.answered = false; renderQuiz();
  }
  function renderQuiz() {
    const el = $('#quiz');
    quiz.lang = KS_I18N.lang;
    if (quiz.i >= quiz.qs.length) {
      const s = quiz.score, msg = s >= 9 ? t('quizGreat') : s >= 6 ? t('quizGood') : t('quizTry');
      el.innerHTML = `<h2>${esc(t('quizDone'))}</h2><p class="qq">${esc(t('quizScore'))}: ${s} / ${quiz.qs.length}</p><p>${esc(msg)}</p><button class="accent" id="qNew">${esc(t('quizNew'))}</button>`;
      $('#qNew').onclick = newQuiz; return;
    }
    const q = D.quiz[quiz.qs[quiz.i]];
    el.innerHTML = `<div class="row" style="justify-content:space-between"><h2>${esc(t('quizTitle'))}</h2><span class="muted">${esc(t('quizQ'))} ${quiz.i + 1} / ${quiz.qs.length} · ${esc(t('quizScore'))}: ${quiz.score}</span></div>
      <div class="qbar"><b style="width:${quiz.i / quiz.qs.length * 100}%"></b></div><div class="qq">${esc(L(q[0]))}</div>
      ${q[1].map((o, i) => `<button class="qa" data-a="${i}">${esc(L(o))}</button>`).join('')}<div class="qexp" id="qExp"></div>`;
    quiz.answered = false;
  }
  $('#quiz').addEventListener('click', (e) => {
    const b = e.target.closest('[data-a]');
    if (b && !quiz.answered) {
      quiz.answered = true;
      const q = D.quiz[quiz.qs[quiz.i]], a = +b.dataset.a, ok = a === q[2];
      if (ok) quiz.score++;
      $$('.qa').forEach((x) => { const i = +x.dataset.a; if (i === q[2]) x.classList.add('right'); else if (i === a) x.classList.add('wrong'); });
      $('#qExp').innerHTML = `<p><b class="${ok ? 'ok' : 'mid'}">${esc(ok ? t('quizRight') : t('quizWrong'))}</b> ${esc(L(q[3]))}</p><button class="accent" id="qNext">${esc(t('quizNext'))}</button>`;
      return;
    }
    if (e.target.id === 'qNext') { quiz.i++; renderQuiz(); }
  });

  // ---------------- Help & sources ----------------
  function openModal(html) { $('#mBody').innerHTML = html; $('#modal').classList.remove('hidden'); }
  function closeModal() { $('#modal').classList.add('hidden'); }
  $('#mClose').onclick = closeModal;
  $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') closeModal(); });
  function block(b) {
    const l = I.lang;
    switch (b.type) {
      case 'p': return `<p>${esc(b[l])}</p>`;
      case 'list': return `<ul>${b[l].map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`;
      case 'steps': return `<ol>${b[l].map((x) => `<li>${esc(x)}</li>`).join('')}</ol>`;
      case 'table': return `<table class="tbl">${b[l].map((r, i) => `<tr>${r.map((c) => i ? `<td>${esc(c)}</td>` : `<th>${esc(c)}</th>`).join('')}</tr>`).join('')}</table>`;
      case 'tip': return `<div class="tip">${esc(b[l])}</div>`;
      case 'warn': return `<div class="warn">⚠ ${esc(b[l])}</div>`;
      case 'img': return `<img src="guide/${l === 'ar' && b.src_ar ? b.src_ar : b.src}" alt="" onerror="this.style.display='none'"><div class="cap">${esc(b.cap[l])}</div>`;
    }
    return '';
  }
  function openHelp(sec) {
    const H = window.KS_HELP; if (!H) return;
    const l = I.lang;
    let nav = H.sections.map((s) => `<a href="#" data-s="${s.id}">${esc(s.title[l])}</a>`).join('');
    nav += `<a href="#" data-s="faq">${esc(t('faq'))}</a><a href="#" data-s="trouble">${esc(t('trouble'))}</a>`;
    let body = H.sections.map((s) => `<h2 id="h-${s.id}">${esc(s.title[l])}</h2>${s.blocks.map(block).join('')}`).join('');
    body += `<h2 id="h-faq">${esc(t('faq'))}</h2>` + H.faq.map((f) => `<p><b>${esc(f.q[l])}</b><br>${esc(f.a[l])}</p>`).join('');
    body += `<h2 id="h-trouble">${esc(t('trouble'))}</h2>` + H.troubleshooting.map((f) => `<p><b>${esc(f.problem[l])}</b><br>${esc(f.fix[l])}</p>`).join('');
    body += `<p class="muted">${esc(t('appName'))} ${VERSION} · ${esc(t('by'))}</p>`;
    openModal(`<div class="help"><nav><b>${esc(t('contents'))}</b>${nav}</nav><article id="hArt">${body}</article></div>`);
    $('.help nav').addEventListener('click', (e) => { const a = e.target.closest('[data-s]'); if (!a) return; e.preventDefault(); const h = $('#h-' + a.dataset.s); if (h) $('#hArt').scrollTop = h.offsetTop - 10; });
    if (sec) { const h = $('#h-' + sec); if (h) $('#hArt').scrollTop = h.offsetTop - 10; }
  }
  function openSources() {
    const en = !ar();
    const items = [
      ['NASA NSSDCA Planetary Fact Sheets', 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/', en ? 'Sizes, masses, orbits, temperatures and other planet numbers.' : 'أحجام الكواكب وكتلها ومداراتها ودرجات حرارتها وغيرها من الأرقام.'],
      ['NASA Science', 'https://science.nasa.gov/solar-system/', en ? 'Descriptions, moon counts, missions and facts.' : 'الأوصاف وعدد الأقمار والبعثات والمعلومات.'],
      ['JPL Solar System Dynamics', 'https://ssd.jpl.nasa.gov/planets/approx_pos.html', en ? 'Formulas for the planet positions (E. M. Standish) and small-body orbits.' : 'معادلات مواقع الكواكب (إ. م. ستانديش) ومدارات الأجرام الصغيرة.'],
      ['Solar System Scope textures (CC BY 4.0)', 'https://www.solarsystemscope.com/textures/', en ? 'Pictures of the Sun, planets, Moon, Saturn\'s rings and the Milky Way sky, based on NASA data.' : 'صور الشمس والكواكب والقمر وحلقات زحل وسماء درب التبانة، المبنية على بيانات NASA.'],
      ['Esri World Imagery, World Street Map, World Boundaries and Places', 'https://www.esri.com/', en ? 'Satellite pictures, street maps and place names on the 3D Earth (© Esri, Maxar, Earthstar Geographics and the GIS User Community).' : 'صور الأقمار الصناعية وخرائط الشوارع وأسماء الأماكن على الأرض ثلاثية الأبعاد (© Esri وMaxar وEarthstar Geographics ومجتمع مستخدمي نظم المعلومات الجغرافية).'],
      ['NASA GIBS, Black Marble', 'https://earthdata.nasa.gov/gibs', en ? 'Night lights of the Earth.' : 'أضواء الأرض ليلًا.'],
      ['Where the ISS at? (wheretheiss.at)', 'https://wheretheiss.at/', en ? 'Live position of the International Space Station.' : 'الموقع المباشر لمحطة الفضاء الدولية.'],
      ['CesiumJS (Apache License 2.0)', 'https://cesium.com/platform/cesiumjs/', en ? 'The 3D globe.' : 'الكرة الأرضية ثلاثية الأبعاد.'],
      ['three.js (MIT License)', 'https://threejs.org/', en ? 'The 3D Solar System and Milky Way.' : 'المجموعة الشمسية ودرب التبانة ثلاثيتا الأبعاد.']
    ];
    openModal(`<div class="srcs"><h2>${esc(t('srcTitle'))}</h2><ul>${items.map(([n, u, d]) => `<li><a href="${u}" class="ext">${esc(n)}</a><br><span class="muted">${esc(d)}</span></li>`).join('')}</ul>
      <p class="muted">${en ? 'Kankon is not affiliated with NASA, ESA, Esri or the other sources above. Planet and spacecraft positions are calculated with published formulas and are approximate.' : 'Kankon غير مرتبط بـNASA أو وكالة الفضاء الأوروبية أو Esri أو المصادر الأخرى المذكورة. وتُحسب مواقع الكواكب والمركبات بمعادلات منشورة، وهي تقريبية.'}</p>
      <p>${esc(t('appName'))} ${VERSION} · ${esc(t('by'))}</p></div>`);
  }
  $('#bHelp').onclick = () => openHelp();
  $('#bSources').onclick = (e) => { e.preventDefault(); openSources(); };
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F1') { e.preventDefault(); openHelp(); }
    if (e.key === 'Escape') closeModal();
    if (e.target.tagName === 'INPUT' || st.view !== 'solar') return;
    if (e.key === ' ') { e.preventDefault(); $('#tPlay').click(); }
  });
  // outside links open in the browser
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="http"]'); if (!a) return;
    e.preventDefault();
    if (location.hostname === '127.0.0.1') fetch('/__open?u=' + encodeURIComponent(a.href)).catch(() => {});
    else window.open(a.href, '_blank');
  });

  // ---------------- language ----------------
  $('#bLang').onclick = () => I.setLang(ar() ? 'en' : 'ar');
  I.on(() => {
    renderList(); renderInfo(); updateTimeUi(); renderPlaces(); renderIss();
    if (st.view === 'galaxy') renderGalInfo();
    if (st.view === 'sky') renderSky();
    if (st.view === 'compare') renderCompare();
    if (st.view === 'quiz') renderQuiz();
    $('#tDate').title = t('dateHint');
    $('#ver').textContent = t('version') + ' ' + VERSION;
    if (!$('#modal').classList.contains('hidden') && $('.help')) openHelp();
  });
  $$('#tabs button').forEach((b) => b.onclick = () => setView(b.dataset.v));

  // ---------------- main loop ----------------
  let lastT = performance.now(), lastInfo = 0, lastDate = 0;
  function loop(now) {
    const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
    if (st.playing) {
      st.simMs += st.dir * SPEEDS[st.sp] * dt * 86400000;
      st.simMs = Math.max(Date.UTC(-2999, 0, 1), Math.min(Date.UTC(3000, 0, 1), st.simMs));
    }
    if (st.view === 'solar') { S.update(A.jdOf(st.simMs)); S.frame(); }
    if (st.view === 'galaxy') KS_GALAXY.frame();
    if (now - lastInfo > 500) {
      lastInfo = now;
      const lb = $('#liveBox'); if (lb && st.sel) lb.innerHTML = liveInfo(byId[st.sel]);
      if (now - lastDate > 250 && document.activeElement !== $('#tDate')) { lastDate = now; $('#tDate').value = toLocalInput(st.simMs); }
      updateTimeUi();
    }
    requestAnimationFrame(loop);
  }

  // ---------------- start ----------------
  S.init($('#cSolar'), $('#lSolar'));
  $('#ver').textContent = t('version') + ' ' + VERSION;
  window.addEventListener('resize', resize);
  I.setLang('en');
  setView('solar');
  resize();
  S.update(A.jdOf(st.simMs));
  S.overview();
  updateTimeUi();
  requestAnimationFrame(loop);

  // for the build's screenshots and self-test
  window.KS_APP = {
    context: () => ({ appPage: st.view, openWorld: st.sel && byId[st.sel] ? byId[st.sel].name.en : null,
      dateShownUTC: new Date(st.simMs).toISOString().slice(0, 16), timeRunning: st.playing, userLanguage: I.lang,
      skyCity: skyPlace().name.en, today: new Date().toISOString().slice(0, 10) }),
    st, setView, setLang: I.setLang, select: (id) => S.select(id), overview: () => S.overview(), openHelp, openSources, closeModal,
    setTime: (iso) => { st.simMs = Date.parse(iso); }, setSpeed: (i, playing) => { st.sp = i; st.playing = playing !== false; updateTimeUi(); },
    scale: (m) => (m === 'true' ? $('#sTrue') : $('#sVis')).click(), earthFly: (la, lo, h) => KS_EARTH.flyTo(la, lo, h), earthLayer: (k) => { const b = document.querySelector(`#eLayers [data-l="${k}"]`); b && b.click(); },
    iss: (on) => { $('#issOn').checked = on; $('#issOn').onchange({ target: $('#issOn') }); }, galaxy: (k) => document.querySelector(`[data-g="${k}"]`).click(),
    cmp: (k) => document.querySelector(`[data-c="${k}"]`).click(), quizAnswer: (i) => { const b = document.querySelectorAll('.qa')[i]; b && b.click(); },
    ok: () => !!(S.objs.earth && S.objs.earth.group.position.length() > 0)
  };
})();
