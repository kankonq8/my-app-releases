/* Kankon Space - Earth explorer (CesiumJS, Apache-2.0). Imagery: Esri World Imagery / World Street Map / boundaries and places,
   NASA GIBS Black Marble (night lights); offline fallback = the built-in Earth picture. Live ISS position from wheretheiss.at. */
window.KS_EARTH = (function () {
  let viewer, sunOn = true, inited = false, layers = {}, iss = null, issTimer = null, issFollow = false, issTrack = [], issFuture = [], onInfo = () => {};
  const C = () => window.Cesium;
  const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/';
  const esriCredit = 'Imagery © Esri, Maxar, Earthstar Geographics, and the GIS User Community';

  function provider(url, max, credit) {
    return new (C().UrlTemplateImageryProvider)({ url, maximumLevel: max, credit: new (C().Credit)(credit) });
  }

  async function init(div) {
    if (inited) return;
    inited = true;
    const Ce = C();
    Ce.Ion.defaultAccessToken = '';
    viewer = new Ce.Viewer(div, {
      baseLayer: false, baseLayerPicker: false, geocoder: false, homeButton: false, sceneModePicker: false, navigationHelpButton: false,
      animation: false, timeline: false, fullscreenButton: false, infoBox: false, selectionIndicator: false,
      terrainProvider: new Ce.EllipsoidTerrainProvider(), shouldAnimate: true, requestRenderMode: false
    });
    const sc = viewer.scene;
    sc.globe.enableLighting = true;
    sc.globe.lightingFadeOutDistance = 1.5e6; sc.globe.lightingFadeInDistance = 4e6;   // closer than 1,500 km the ground is shown fully lit
    sc.globe.nightFadeOutDistance = 1.5e6; sc.globe.nightFadeInDistance = 4e6;
    sc.globe.showGroundAtmosphere = true;
    sc.globe.baseColor = Ce.Color.fromCssColorString('#0b1a33');
    sc.globe.maximumScreenSpaceError = 1.5;
    sc.screenSpaceCameraController.minimumZoomDistance = 80;
    sc.screenSpaceCameraController.maximumZoomDistance = 60000000;
    viewer.clock.currentTime = Ce.JulianDate.now();
    viewer.clock.multiplier = 1;
    // offline base: the built-in picture of the Earth
    try {
      const base = await Ce.SingleTileImageryProvider.fromUrl('tex/earth_daymap.jpg');
      viewer.imageryLayers.addImageryProvider(base, 0);
    } catch (e) { /* ignore */ }
    try {
      const nb = viewer.imageryLayers.addImageryProvider(await Ce.SingleTileImageryProvider.fromUrl('tex/earth_nightmap.jpg'), 1);
      layers.nb = nb; nb.dayAlpha = 0.0; nb.nightAlpha = 1.0; nb.brightness = 3.5;
    } catch (e) { /* ignore */ }
    layers.sat = viewer.imageryLayers.addImageryProvider(provider(ESRI + 'World_Imagery/MapServer/tile/{z}/{y}/{x}', 19, esriCredit));
    layers.street = viewer.imageryLayers.addImageryProvider(provider(ESRI + 'World_Street_Map/MapServer/tile/{z}/{y}/{x}', 19, 'Map © Esri, HERE, Garmin, OpenStreetMap contributors'));
    layers.street.show = false;
    layers.night = viewer.imageryLayers.addImageryProvider(provider('https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_Black_Marble/default/2016-01-01/GoogleMapsCompatible_Level8/{z}/{y}/{x}.png', 8, 'Night lights: NASA Earth Observatory / GIBS (Black Marble)'));
    layers.night.show = false;
    // city lights on the night side when Real day and night is on
    layers.nightAuto = viewer.imageryLayers.addImageryProvider(provider('https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_Black_Marble/default/2016-01-01/GoogleMapsCompatible_Level8/{z}/{y}/{x}.png', 8, 'Night lights: NASA Earth Observatory / GIBS (Black Marble)'));
    layers.nightAuto.dayAlpha = 0.0; layers.nightAuto.nightAlpha = 1.0; layers.nightAuto.brightness = 3.5;
    layers.labels = viewer.imageryLayers.addImageryProvider(provider(ESRI + 'Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', 19, 'Labels © Esri'));
    setLayer("hybrid");
    home(0);
    // mouse coordinates
    const h = new Ce.ScreenSpaceEventHandler(sc.canvas);
    h.setInputAction((m) => {
      const c = viewer.camera.pickEllipsoid(m.endPosition, sc.globe.ellipsoid);
      if (c) { const g = Ce.Cartographic.fromCartesian(c); onInfo({ mouse: [Ce.Math.toDegrees(g.latitude), Ce.Math.toDegrees(g.longitude)] }); }
      else onInfo({ mouse: null });
    }, Ce.ScreenSpaceEventType.MOUSE_MOVE);
    viewer.camera.changed.addEventListener(() => { checkNear(); onInfo({ height: viewer.camera.positionCartographic.height }); });
    viewer.camera.percentageChanged = 0.01;
    // ISS entity
    iss = viewer.entities.add({
      name: 'ISS', position: Ce.Cartesian3.fromDegrees(0, 0, 420000),
      billboard: { image: issIcon(), scale: 0.75, verticalOrigin: Ce.VerticalOrigin.CENTER },
      label: { text: 'ISS', font: '600 14px Segoe UI, sans-serif', fillColor: Ce.Color.fromCssColorString('#ffe082'), outlineColor: Ce.Color.BLACK, outlineWidth: 3, style: Ce.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new Ce.Cartesian2(0, -26) },
      show: false
    });
    viewer.entities.add({ polyline: { positions: new Ce.CallbackProperty(() => issTrack, false), width: 2, material: Ce.Color.fromCssColorString('#ffd54a').withAlpha(0.9) } });
    viewer.entities.add({ polyline: { positions: new Ce.CallbackProperty(() => issFuture, false), width: 1.5, material: new Ce.PolylineDashMaterialProperty({ color: Ce.Color.fromCssColorString('#ffd54a').withAlpha(0.6) }) } });
  }

  function issIcon() {
    const c = document.createElement('canvas'); c.width = 64; c.height = 40; const g = c.getContext('2d');
    g.fillStyle = '#5b8bd6'; g.fillRect(2, 14, 24, 12); g.fillRect(38, 14, 24, 12);
    g.fillStyle = '#e8e8e8'; g.fillRect(26, 18, 12, 4); g.fillRect(28, 10, 8, 20);
    g.strokeStyle = '#ffd54a'; g.lineWidth = 2; g.strokeRect(1, 1, 62, 38);
    return c.toDataURL();
  }

  function home(dur) {
    const Ce = C();
    viewer.camera.flyTo({ destination: Ce.Cartesian3.fromDegrees(47.9, 25, 17000000), duration: dur === undefined ? 2 : dur });
  }
  function flyTo(lat, lon, h, tilt) {
    const Ce = C();
    issFollow = false;
    const pitch = tilt === false || h > 200000 ? -90 : -50;
    const back = pitch === -90 ? 0 : h / Math.tan(50 * Math.PI / 180) / 111320;
    viewer.camera.flyTo({ destination: Ce.Cartesian3.fromDegrees(lon, lat - back, h), orientation: { heading: 0, pitch: Ce.Math.toRadians(pitch), roll: 0 }, duration: 3.2 });
  }
  function setLayer(k) {
    layers.sat.show = k === 'sat' || k === 'hybrid';
    layers.street.show = k === 'street';
    layers.night.show = k === 'night';
    layers.labels.show = k === 'hybrid' || k === 'night';
    layers.mode = k;
    // Real day and night: the night side is dark with city lights. The ground haze is off then (it blacks out the night side),
    // and the Night lights map is always shown fully (it is already a night picture).
    const lit = sunOn && k !== 'night';
    viewer.scene.globe.enableLighting = lit;
    viewer.scene.globe.showGroundAtmosphere = !lit;
    layers.nightAuto.show = lit && (k === 'sat' || k === 'hybrid') && !near();
    if (layers.nb) layers.nb.show = lit && !near();
  }
  // Closer than 1,500 km the ground is shown fully lit, so the city lights pictures are hidden there.
  function near() { return viewer.camera.positionCartographic.height < 1.5e6; }
  let wasNear = null;
  function checkNear() { const n = near(); if (n !== wasNear) { wasNear = n; setLayer(layers.mode || 'hybrid'); } }
  function setLighting(on) { sunOn = on; setLayer(layers.mode || 'hybrid'); }
  function zoom(f) { const h = viewer.camera.positionCartographic.height; if (f > 0) viewer.camera.zoomIn(h * 0.5); else viewer.camera.zoomOut(h); }

  async function fetchJson(url) { const r = await fetch(url, { cache: 'no-store' }); if (!r.ok) throw new Error(r.status); return r.json(); }
  async function issTick() {
    const Ce = C();
    try {
      const d = await fetchJson('https://api.wheretheiss.at/v1/satellites/25544');
      const p = Ce.Cartesian3.fromDegrees(d.longitude, d.latitude, d.altitude * 1000);
      iss.position = p; iss.show = true;
      issTrack.push(p); if (issTrack.length > 400) issTrack.shift();
      onInfo({ iss: d });
      if (issFollow) viewer.camera.flyTo({ destination: Ce.Cartesian3.fromDegrees(d.longitude, d.latitude, 3500000), duration: 1.5 });
    } catch (e) { onInfo({ issErr: true }); }
  }
  async function issPath() {
    const Ce = C();
    try {
      const now = Math.floor(Date.now() / 1000), ts = [];
      for (let i = 1; i <= 10; i++) ts.push(now + i * 600);
      const d = await fetchJson('https://api.wheretheiss.at/v1/satellites/25544/positions?timestamps=' + ts.join(',') + '&units=kilometers');
      const pts = [];
      for (let i = 0; i < d.length; i++) pts.push(Ce.Cartesian3.fromDegrees(d[i].longitude, d[i].latitude, d[i].altitude * 1000));
      issFuture = pts;
    } catch (e) { /* ignore */ }
  }
  function issStart() {
    if (issTimer) return;
    issTick(); issPath();
    issTimer = setInterval(issTick, 5000);
    issStart.p = setInterval(issPath, 5 * 60000);
  }
  function issStop() { clearInterval(issTimer); clearInterval(issStart.p); issTimer = null; if (iss) iss.show = false; issTrack = []; issFuture = []; issFollow = false; }
  function followIss(on) { issFollow = on; if (on && iss && iss.show) issTick(); }
  function resize() { if (viewer) viewer.resize(); }
  function shot() { viewer.render(); return viewer.canvas.toDataURL('image/png'); }

  return { init, home, flyTo, setLayer, setLighting, zoom, issStart, issStop, followIss, resize, shot,
    set onInfo(f) { onInfo = f; }, get inited() { return inited; }, get viewer() { return viewer; } };
})();
