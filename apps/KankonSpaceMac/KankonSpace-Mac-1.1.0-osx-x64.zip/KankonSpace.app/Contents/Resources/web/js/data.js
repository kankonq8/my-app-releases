/* Kankon Space - data.
   Sources: NASA NSSDCA Planetary Fact Sheets (nssdc.gsfc.nasa.gov/planetary/factsheet), NASA Science (science.nasa.gov),
   JPL "Approximate Positions of the Planets" (E.M. Standish, Table 1, valid 1800-2050), JPL Small-Body Database (dwarf planets, comets).
   Numbers are rounded the way NASA's fact sheets round them. Moon counts are NASA's (2025). */
window.KS_DATA = (function () {
  const T = (en, ar) => ({ en, ar });

  // Keplerian elements: [a(au), e, I(deg), L(deg), long.peri(deg), long.node(deg)] at J2000 + rates per Julian century
  const planets = [
    {
      id: 'mercury', kind: 'planet', name: T('Mercury', 'عطارد'), type: T('Rocky planet', 'كوكب صخري'), tex: 'mercury.jpg', color: '#a8a39d',
      R: 2439.7, tilt: 0.034, rotH: 1407.6,
      el: [0.38709927, 0.20563593, 7.00497902, 252.25032350, 77.45779628, 48.33076593, 0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081],
      f: { mass: 0.330, diam: 4879, dens: 5429, grav: 3.7, esc: 4.3, rot: 1407.6, day: 4222.6, dist: 57.9, peri: 46.0, aph: 69.8, per: 88.0, vel: 47.4, inc: 7.0, ecc: 0.206, obl: 0.034, temp: 167, tmin: -180, tmax: 430, pres: 0, moons: 0, rings: false, mag: true },
      desc: T('The smallest planet and the closest to the Sun. Mercury has almost no air to hold heat, so its days are hot enough to melt lead while its nights are colder than Antarctica. Its grey, cratered surface looks like our Moon.',
        'أصغر الكواكب وأقربها إلى الشمس. لا يكاد يملك غلافًا جويًّا يحفظ الحرارة، فنهاره حارٌّ يكفي لصهر الرصاص، وليله أبرد من القارة القطبية الجنوبية. وسطحه الرمادي المليء بالفوهات يشبه سطح قمرنا.'),
      atmo: [[T('Oxygen', 'الأكسجين'), 42], [T('Sodium', 'الصوديوم'), 29], [T('Hydrogen', 'الهيدروجين'), 22], [T('Helium', 'الهيليوم'), 6], [T('Potassium', 'البوتاسيوم'), 0.5]],
      atmoNote: T('Only a very thin exosphere: atoms knocked off the surface by the solar wind.', 'غلاف خارجي رقيق جدًّا فقط: ذرات تقتلعها الرياح الشمسية من السطح.'),
      missions: [[1974, 'Mariner 10', T('First spacecraft to visit Mercury (three flybys, 1974-75).', 'أول مركبة تزور عطارد (ثلاث مرات عبور، 1974-1975).')],
        [2011, 'MESSENGER', T('First to orbit Mercury (2011-2015); mapped the whole planet and found water ice in shadowed polar craters.', 'أول مركبة تدور حول عطارد (2011-2015)، رسمت خريطة الكوكب كله ووجدت جليد الماء في فوهات قطبية مظللة.')],
        [2018, 'BepiColombo', T('ESA and JAXA mission launched in 2018; its two orbiters reach Mercury orbit in late 2026.', 'بعثة وكالة الفضاء الأوروبية واليابانية، أُطلقت عام 2018، ويدخل مسباراها مدار عطارد أواخر عام 2026.')]],
      facts: [T('A year on Mercury (88 Earth days) is shorter than one of its solar days (176 Earth days).', 'سنة عطارد (88 يومًا أرضيًّا) أقصر من يومه الشمسي الواحد (176 يومًا أرضيًّا).'),
        T('From Mercury the Sun looks about three times bigger than from Earth.', 'تبدو الشمس من عطارد أكبر بنحو ثلاث مرات مما تبدو من الأرض.'),
        T('Mercury is shrinking: as its iron core cools, the crust wrinkles into cliffs hundreds of kilometres long.', 'عطارد يتقلص: فمع تبرّد لبّه الحديدي يتجعد قشره مكوِّنًا جروفًا يمتد طولها مئات الكيلومترات.'),
        T('Its iron core fills about 85% of the planet\'s radius.', 'يشغل لبّه الحديدي نحو 85% من نصف قطر الكوكب.')]
    },
    {
      id: 'venus', kind: 'planet', name: T('Venus', 'الزهرة'), type: T('Rocky planet', 'كوكب صخري'), tex: 'venus_atmosphere.jpg', color: '#e8cda2',
      R: 6051.8, tilt: 177.4, rotH: -5832.5,
      el: [0.72333566, 0.00677672, 3.39467605, 181.97909950, 131.60246718, 76.67984255, 0.00000390, -0.00004107, -0.00078890, 58517.81538729, 0.00268329, -0.27769418],
      f: { mass: 4.87, diam: 12104, dens: 5243, grav: 8.9, esc: 10.4, rot: -5832.5, day: 2802.0, dist: 108.2, peri: 107.5, aph: 108.9, per: 224.7, vel: 35.0, inc: 3.4, ecc: 0.007, obl: 177.4, temp: 464, pres: 92, moons: 0, rings: false, mag: false },
      desc: T('The hottest planet, even though Mercury is closer to the Sun. Thick clouds of sulfuric acid trap the heat in a runaway greenhouse. Venus spins backwards and so slowly that its day is longer than its year. It is the brightest planet in our sky.',
        'أشد الكواكب حرارة، مع أن عطارد أقرب منه إلى الشمس، إذ تحبس سحبُ حمض الكبريتيك الكثيفة الحرارةَ في احتباس حراري جامح. تدور الزهرة حول نفسها بالعكس وببطء شديد حتى إن يومها أطول من سنتها، وهي ألمع كوكب في سمائنا.'),
      atmo: [[T('Carbon dioxide', 'ثاني أكسيد الكربون'), 96.5], [T('Nitrogen', 'النيتروجين'), 3.5], [T('Sulfur dioxide', 'ثاني أكسيد الكبريت'), 0.015]],
      atmoNote: T('Pressure at the surface is 92 times Earth\'s, like being 900 m under the sea.', 'الضغط على السطح 92 ضعف ضغط الأرض، كأنك على عمق 900 متر تحت البحر.'),
      missions: [[1962, 'Mariner 2', T('First successful flyby of another planet.', 'أول عبور ناجح بجوار كوكب آخر.')],
        [1970, 'Venera 7', T('Soviet lander: first spacecraft to send data from the surface of another planet.', 'مسبار سوفيتي، أول مركبة ترسل بيانات من سطح كوكب آخر.')],
        [1982, 'Venera 13', T('Sent the first colour pictures from the surface of Venus.', 'أرسل أول صور ملونة من سطح الزهرة.')],
        [1990, 'Magellan', T('Mapped 98% of the surface with radar (1990-1994).', 'رسم خريطة 98% من السطح بالرادار (1990-1994).')],
        [2006, 'Venus Express', T('ESA orbiter that studied the atmosphere (2006-2014).', 'مسبار أوروبي درس الغلاف الجوي (2006-2014).')],
        [2015, 'Akatsuki', T('Japanese orbiter that studied the super-fast winds (2015-2024).', 'مسبار ياباني درس الرياح فائقة السرعة (2015-2024).')]],
      facts: [T('Venus rotates "backwards": the Sun rises in the west and sets in the east.', 'تدور الزهرة «بالعكس»، فتشرق الشمس فيها من الغرب وتغرب في الشرق.'),
        T('Its surface is hotter than a pizza oven (464 °C) day and night, at the poles and the equator.', 'سطحها أسخن من فرن البيتزا (464 °م) ليلًا ونهارًا، عند القطبين وعند خط الاستواء.'),
        T('The cloud tops race around the planet in only 4 days, 60 times faster than the planet turns.', 'تدور قمم السحب حول الكوكب في 4 أيام فقط، أسرع 60 مرة من دوران الكوكب نفسه.'),
        T('Venus is almost the same size as Earth, which is why it is called Earth\'s twin.', 'حجم الزهرة قريب جدًّا من حجم الأرض، ولهذا تُسمّى توأم الأرض.')]
    },
    {
      id: 'earth', kind: 'planet', name: T('Earth', 'الأرض'), type: T('Rocky planet', 'كوكب صخري'), tex: 'earth_daymap.jpg', color: '#4b7bd1',
      R: 6371.0, tilt: 23.44, rotH: 23.9345,
      el: [1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0.0, 0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0.0],
      f: { mass: 5.97, diam: 12756, dens: 5514, grav: 9.8, esc: 11.2, rot: 23.9, day: 24.0, dist: 149.6, peri: 147.1, aph: 152.1, per: 365.2, vel: 29.8, inc: 0.0, ecc: 0.017, obl: 23.4, temp: 15, tmin: -89, tmax: 57, pres: 1, moons: 1, rings: false, mag: true },
      desc: T('Our home, and the only place we know of with life. Earth is the largest of the four rocky planets and the only world with liquid water on its surface: oceans cover 71% of it. Its magnetic field and atmosphere shield us from the Sun\'s radiation.',
        'موطننا، والمكان الوحيد الذي نعرف أن فيه حياة. الأرض أكبر الكواكب الصخرية الأربعة، والعالم الوحيد الذي يوجد على سطحه ماء سائل، إذ تغطي المحيطات 71% منه. ويحمينا مجالها المغناطيسي وغلافها الجوي من إشعاع الشمس.'),
      atmo: [[T('Nitrogen', 'النيتروجين'), 78.08], [T('Oxygen', 'الأكسجين'), 20.95], [T('Argon', 'الأرغون'), 0.93], [T('Carbon dioxide', 'ثاني أكسيد الكربون'), 0.042]],
      atmoNote: T('Plus water vapour, about 1% on average.', 'إضافة إلى بخار الماء، نحو 1% في المتوسط.'),
      missions: [[1957, 'Sputnik 1', T('The first artificial satellite.', 'أول قمر اصطناعي.')],
        [1961, 'Vostok 1', T('Yuri Gagarin, the first human in space.', 'يوري غاغارين، أول إنسان في الفضاء.')],
        [1985, 'Discovery STS-51-G', T('Prince Sultan bin Salman, the first Arab and Muslim in space.', 'الأمير سلطان بن سلمان، أول عربي ومسلم يصعد إلى الفضاء.')],
        [1998, 'ISS', T('International Space Station; people have lived on it without a break since November 2000.', 'محطة الفضاء الدولية، يقيم فيها البشر دون انقطاع منذ نوفمبر 2000.')],
        [2019, 'Hazzaa Al Mansoori', T('First Emirati astronaut, on the ISS.', 'أول رائد فضاء إماراتي، على متن محطة الفضاء الدولية.')]],
      facts: [T('Earth is the densest planet in the Solar System.', 'الأرض أكثف كواكب المجموعة الشمسية.'),
        T('Earth\'s spin is slowing: a day was about 21 hours long 600 million years ago.', 'دوران الأرض يتباطأ، فقد كان طول اليوم نحو 21 ساعة قبل 600 مليون سنة.'),
        T('We are closest to the Sun in early January, not in summer. Seasons come from the 23.4° tilt.', 'نكون أقرب إلى الشمس في أوائل يناير لا في الصيف، فالفصول سببها ميل المحور 23.4 درجة.'),
        T('Earth moves around the Sun at about 107,000 km/h.', 'تدور الأرض حول الشمس بسرعة نحو 107000 كم في الساعة.')]
    },
    {
      id: 'mars', kind: 'planet', name: T('Mars', 'المريخ'), type: T('Rocky planet', 'كوكب صخري'), tex: 'mars.jpg', color: '#c1440e',
      R: 3389.5, tilt: 25.19, rotH: 24.6229,
      el: [1.52371034, 0.09339410, 1.84969142, -4.55343205, -23.94362959, 49.55953891, 0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343],
      f: { mass: 0.642, diam: 6792, dens: 3934, grav: 3.7, esc: 5.0, rot: 24.6, day: 24.7, dist: 228.0, peri: 206.7, aph: 249.3, per: 687.0, vel: 24.1, inc: 1.8, ecc: 0.094, obl: 25.2, temp: -65, tmin: -153, tmax: 20, pres: 0.01, moons: 2, rings: false, mag: false },
      desc: T('The red planet. Iron oxide (rust) in its dust gives Mars its colour. It is a cold desert with the biggest volcano and the longest canyon in the Solar System, polar ice caps, and clear signs that rivers and lakes once flowed there.',
        'الكوكب الأحمر، ويستمد لونه من أكسيد الحديد (الصدأ) في غباره. وهو صحراء باردة فيها أكبر بركان وأطول وادٍ في المجموعة الشمسية، وقمم جليدية عند القطبين، وعلامات واضحة على أن أنهارًا وبحيرات جرت عليه في الماضي.'),
      atmo: [[T('Carbon dioxide', 'ثاني أكسيد الكربون'), 95], [T('Nitrogen', 'النيتروجين'), 2.8], [T('Argon', 'الأرغون'), 2], [T('Oxygen', 'الأكسجين'), 0.17]],
      atmoNote: T('The air is about 100 times thinner than Earth\'s; dust storms can cover the whole planet.', 'الهواء أرقّ من هواء الأرض بنحو 100 مرة، وقد تغطي العواصف الترابية الكوكب كله.'),
      missions: [[1965, 'Mariner 4', T('First close pictures of Mars.', 'أول صور قريبة للمريخ.')],
        [1976, 'Viking 1 & 2', T('First successful landers that worked for years.', 'أول مسبارين هبطا بنجاح وعملا سنوات.')],
        [1997, 'Pathfinder / Sojourner', T('First rover on Mars.', 'أول عربة جوّالة على المريخ.')],
        [2004, 'Spirit & Opportunity', T('Twin rovers; Opportunity drove 45 km over 14 years.', 'عربتان توأمان، قطعت Opportunity منهما 45 كم خلال 14 سنة.')],
        [2012, 'Curiosity', T('Car-sized rover exploring Gale crater.', 'عربة بحجم سيارة تستكشف فوهة غيل.')],
        [2021, 'Hope (Emirates Mars Mission)', T('The UAE\'s orbiter, the first Arab mission to another planet; studies the Martian weather.', 'مسبار الأمل الإماراتي، أول بعثة عربية إلى كوكب آخر، يدرس طقس المريخ.')],
        [2021, 'Perseverance & Ingenuity', T('Rover collecting rock samples, and the first helicopter to fly on another planet.', 'عربة تجمع عينات الصخور، وأول مروحية تطير على كوكب آخر.')],
        [2021, 'Tianwen-1 / Zhurong', T('China\'s first orbiter, lander and rover at Mars.', 'أول مسبار ومركبة هبوط وعربة صينية على المريخ.')]],
      facts: [T('Olympus Mons is about 22 km high, nearly 2.5 times the height of Everest.', 'يبلغ ارتفاع جبل أوليمبوس نحو 22 كم، أي نحو مرتين ونصف ارتفاع جبل إيفرست.'),
        T('Valles Marineris is about 4,000 km long, as wide as the United States.', 'يبلغ طول وادي مارينر نحو 4000 كم، أي ما يعادل عرض الولايات المتحدة تقريبًا.'),
        T('Sunsets on Mars look blue.', 'غروب الشمس على المريخ يبدو أزرق.'),
        T('A person who weighs 100 kg on Earth would weigh about 38 kg on Mars.', 'من يزن 100 كغ على الأرض يزن نحو 38 كغ على المريخ.')]
    },
    {
      id: 'jupiter', kind: 'planet', name: T('Jupiter', 'المشتري'), type: T('Gas giant', 'عملاق غازي'), tex: 'jupiter.jpg', color: '#c99b70',
      R: 69911, tilt: 3.13, rotH: 9.925,
      el: [5.20288700, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909, -0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106],
      f: { mass: 1898, diam: 142984, dens: 1326, grav: 23.1, esc: 59.5, rot: 9.9, day: 9.9, dist: 778.5, peri: 740.6, aph: 816.4, per: 4331, vel: 13.1, inc: 1.3, ecc: 0.049, obl: 3.1, temp: -110, pres: null, moons: 95, rings: true, mag: true },
      desc: T('The giant of the Solar System: more than twice as massive as all the other planets together, and 11 times wider than Earth. Jupiter is a ball of hydrogen and helium with colourful cloud bands and the Great Red Spot, a storm bigger than Earth that has raged for centuries.',
        'عملاق المجموعة الشمسية: كتلته أكثر من ضعف كتل الكواكب الأخرى مجتمعة، وقطره 11 ضعف قطر الأرض. وهو كرة من الهيدروجين والهيليوم ذات أحزمة سحب ملونة، وفيه البقعة الحمراء العظيمة، وهي عاصفة أكبر من الأرض مستمرة منذ قرون.'),
      atmo: [[T('Hydrogen', 'الهيدروجين'), 89.8], [T('Helium', 'الهيليوم'), 10.2], [T('Methane', 'الميثان'), 0.3], [T('Ammonia', 'الأمونيا'), 0.026]],
      atmoNote: T('No solid surface: the gas gets denser and hotter until it becomes liquid metallic hydrogen.', 'لا سطح صلبًا له: يزداد الغاز كثافة وحرارة حتى يصير هيدروجينًا فلزيًّا سائلًا.'),
      missions: [[1973, 'Pioneer 10', T('First spacecraft to fly past Jupiter.', 'أول مركبة تعبر بجوار المشتري.')],
        [1979, 'Voyager 1 & 2', T('Found Jupiter\'s faint rings and volcanoes on Io.', 'اكتشفتا حلقات المشتري الباهتة وبراكين القمر آيو.')],
        [1995, 'Galileo', T('First orbiter (1995-2003); dropped a probe into the clouds.', 'أول مسبار يدور حوله (1995-2003)، وأسقط مسبارًا في سحبه.')],
        [2016, 'Juno', T('Orbiting over the poles since 2016, studying the interior and auroras.', 'يدور فوق القطبين منذ 2016 ويدرس باطن الكوكب وشفقه القطبي.')],
        [2023, 'JUICE', T('ESA mission to the icy moons; arrives in 2031.', 'بعثة أوروبية إلى الأقمار الجليدية، تصل عام 2031.')],
        [2024, 'Europa Clipper', T('NASA mission to the ocean moon Europa; arrives in 2030.', 'بعثة NASA إلى القمر أوروبا ذي المحيط، تصل عام 2030.')]],
      facts: [T('Jupiter has the shortest day of all planets: under 10 hours.', 'يوم المشتري أقصر أيام الكواكب كلها: أقل من 10 ساعات.'),
        T('About 1,300 Earths would fit inside Jupiter.', 'يتسع المشتري لنحو 1300 أرض.'),
        T('Its moon Ganymede is bigger than the planet Mercury.', 'قمره غانيميد أكبر من كوكب عطارد.'),
        T('Its strong gravity pulls in or flings away many comets, helping protect the inner planets.', 'جاذبيته القوية تجتذب كثيرًا من المذنبات أو تقذفها بعيدًا، فتساعد على حماية الكواكب الداخلية.')]
    },
    {
      id: 'saturn', kind: 'planet', name: T('Saturn', 'زحل'), type: T('Gas giant', 'عملاق غازي'), tex: 'saturn.jpg', color: '#e3cf9a',
      R: 58232, tilt: 26.73, rotH: 10.656,
      el: [9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448, -0.00125060, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794],
      f: { mass: 568, diam: 120536, dens: 687, grav: 9.0, esc: 35.5, rot: 10.7, day: 10.7, dist: 1432.0, peri: 1407.6, aph: 1503.5, per: 10747, vel: 9.7, inc: 2.5, ecc: 0.052, obl: 26.7, temp: -140, pres: null, moons: 274, rings: true, mag: true },
      desc: T('The jewel of the Solar System. Saturn\'s bright rings are made of billions of pieces of ice and rock, from dust grains to house-sized chunks. The rings are about 280,000 km wide but mostly only about 10 m thick. Saturn has the most known moons of any planet.',
        'جوهرة المجموعة الشمسية. تتكون حلقاته اللامعة من مليارات القطع من الجليد والصخر، من حبيبات الغبار إلى كتل بحجم البيوت. يبلغ عرض الحلقات نحو 280000 كم، لكن سُمكها في معظمها نحو 10 أمتار فقط. ولزحل أكبر عدد معروف من الأقمار بين الكواكب.'),
      atmo: [[T('Hydrogen', 'الهيدروجين'), 96.3], [T('Helium', 'الهيليوم'), 3.25], [T('Methane', 'الميثان'), 0.45]],
      atmoNote: T('Winds near the equator reach about 1,800 km/h.', 'تبلغ سرعة الرياح قرب خط الاستواء نحو 1800 كم في الساعة.'),
      missions: [[1979, 'Pioneer 11', T('First spacecraft to fly past Saturn.', 'أول مركبة تعبر بجوار زحل.')],
        [1980, 'Voyager 1 & 2', T('Flybys in 1980 and 1981 revealed the ring details.', 'عبرتا عامي 1980 و1981 وكشفتا تفاصيل الحلقات.')],
        [2004, 'Cassini-Huygens', T('Orbited Saturn for 13 years (2004-2017); Huygens landed on Titan in 2005.', 'دار حول زحل 13 عامًا (2004-2017)، وهبط Huygens على تيتان عام 2005.')],
        [2028, 'Dragonfly', T('NASA drone to fly on Titan; launch planned for 2028.', 'طائرة مسيّرة من NASA ستطير على تيتان، والإطلاق مخطط له عام 2028.')]],
      facts: [T('Saturn is the only planet less dense than water: in a big enough bathtub it would float.', 'زحل هو الكوكب الوحيد الأقل كثافة من الماء، ولو وُجد حوض كبير بما يكفي لطفا فيه.'),
        T('A six-sided jet stream, the Hexagon, spins around its north pole.', 'يدور حول قطبه الشمالي تيار هوائي سداسي الشكل يُسمّى «السداسي».'),
        T('Its moon Enceladus sprays water from an underground ocean into space.', 'قمره إنسيلادوس ينفث الماء من محيط تحت سطحه إلى الفضاء.'),
        T('Every 13-15 years the rings turn edge-on to Earth and almost disappear in telescopes (last time March 2025).', 'كل 13 إلى 15 سنة تتجه حافة الحلقات نحو الأرض فتكاد تختفي في المقاريب (آخر مرة في مارس 2025).')]
    },
    {
      id: 'uranus', kind: 'planet', name: T('Uranus', 'أورانوس'), type: T('Ice giant', 'عملاق جليدي'), tex: 'uranus.jpg', color: '#9fd3dc',
      R: 25362, tilt: 97.77, rotH: -17.24,
      el: [19.18916464, 0.04725744, 0.77263783, 313.23810451, 170.95427630, 74.01692503, -0.00196176, -0.00004397, -0.00242939, 428.48202785, 0.40805281, 0.04240589],
      f: { mass: 86.8, diam: 51118, dens: 1270, grav: 8.7, esc: 21.3, rot: -17.2, day: 17.2, dist: 2867.0, peri: 2732.7, aph: 3001.4, per: 30589, vel: 6.8, inc: 0.8, ecc: 0.047, obl: 97.8, temp: -195, pres: null, moons: 29, rings: true, mag: true },
      desc: T('The tilted planet. Uranus rolls around the Sun on its side, with its axis tipped by 98°, so each pole gets 42 years of sunlight and then 42 years of darkness. Methane in its air gives it a blue-green colour. It was the first planet found with a telescope (William Herschel, 1781).',
        'الكوكب المائل. يتدحرج أورانوس حول الشمس على جنبه، فمحوره مائل 98 درجة، فينال كل قطب 42 سنة من ضوء الشمس ثم 42 سنة من الظلام. ويمنحه الميثان في هوائه لونًا أزرق مخضرًّا. وهو أول كوكب اكتُشف بالمقراب (وليام هيرشل، 1781).'),
      atmo: [[T('Hydrogen', 'الهيدروجين'), 82.5], [T('Helium', 'الهيليوم'), 15.2], [T('Methane', 'الميثان'), 2.3]],
      atmoNote: T('The coldest atmosphere of any planet: down to -224 °C.', 'أبرد غلاف جوي بين الكواكب: حتى -224 °م.'),
      missions: [[1986, 'Voyager 2', T('The only spacecraft ever to visit Uranus (January 1986); found 10 new moons and 2 new rings.', 'المركبة الوحيدة التي زارت أورانوس (يناير 1986)، واكتشفت 10 أقمار جديدة وحلقتين جديدتين.')]],
      facts: [T('Uranus\'s moons are named after characters from Shakespeare and Alexander Pope.', 'سُمّيت أقمار أورانوس بأسماء شخصيات من أعمال شكسبير وألكسندر بوب.'),
        T('It has 13 known rings, dark and narrow.', 'له 13 حلقة معروفة، داكنة وضيقة.'),
        T('Like Venus, it spins the opposite way to most planets.', 'يدور حول نفسه، مثل الزهرة، عكس اتجاه دوران معظم الكواكب.'),
        T('A new small moon was found by the James Webb Space Telescope in 2025.', 'اكتشف مقراب جيمس ويب الفضائي قمرًا صغيرًا جديدًا له عام 2025.')]
    },
    {
      id: 'neptune', kind: 'planet', name: T('Neptune', 'نبتون'), type: T('Ice giant', 'عملاق جليدي'), tex: 'neptune.jpg', color: '#3e66f9',
      R: 24622, tilt: 28.32, rotH: 16.11,
      el: [30.06992276, 0.00859048, 1.77004347, -55.12002969, 44.96476227, 131.78422574, 0.00026291, 0.00005105, 0.00035372, 218.45945325, -0.32241464, -0.00508664],
      f: { mass: 102, diam: 49528, dens: 1638, grav: 11.0, esc: 23.5, rot: 16.1, day: 16.1, dist: 4515.0, peri: 4471.1, aph: 4558.9, per: 59800, vel: 5.4, inc: 1.8, ecc: 0.010, obl: 28.3, temp: -200, pres: null, moons: 16, rings: true, mag: true },
      desc: T('The farthest planet: dark, cold and windy. Neptune was the first planet found by mathematics: astronomers predicted where it should be from the way it pulled on Uranus, and Johann Galle saw it there in 1846. Its winds are the fastest in the Solar System.',
        'أبعد الكواكب: مظلم وبارد وعاصف. ونبتون أول كوكب اكتُشف بالرياضيات، إذ توقّع الفلكيون مكانه من أثر جاذبيته في أورانوس، فرآه يوهان غالِه هناك عام 1846. ورياحه أسرع رياح في المجموعة الشمسية.'),
      atmo: [[T('Hydrogen', 'الهيدروجين'), 80], [T('Helium', 'الهيليوم'), 19], [T('Methane', 'الميثان'), 1.5]],
      atmoNote: T('Winds reach about 2,000 km/h.', 'تبلغ سرعة الرياح نحو 2000 كم في الساعة.'),
      missions: [[1989, 'Voyager 2', T('The only spacecraft ever to visit Neptune (August 1989); saw the Great Dark Spot and geysers on Triton.', 'المركبة الوحيدة التي زارت نبتون (أغسطس 1989)، ورصدت البقعة المظلمة العظيمة والينابيع الحارة على تريتون.')]],
      facts: [T('One Neptune year lasts 165 Earth years; it completed its first orbit since discovery in 2011.', 'سنة نبتون تعادل 165 سنة أرضية، وقد أكمل أول دورة له منذ اكتشافه عام 2011.'),
        T('Sunlight takes about 4 hours to reach Neptune.', 'يحتاج ضوء الشمس نحو 4 ساعات ليصل إلى نبتون.'),
        T('Its largest moon Triton orbits backwards and will one day be torn apart by Neptune\'s gravity.', 'قمره الأكبر تريتون يدور في الاتجاه المعاكس، وستمزقه جاذبية نبتون يومًا ما.'),
        T('Neptune is not visible to the naked eye.', 'لا يُرى نبتون بالعين المجردة.')]
    }
  ];

  // Dwarf planets and comets: [a, e, I, node, argPeri, T(perihelion, JD), period(days, optional)]
  const dwarfs = [
    {
      id: 'ceres', kind: 'dwarf', name: T('Ceres', 'سيريس'), type: T('Dwarf planet (asteroid belt)', 'كوكب قزم (حزام الكويكبات)'), color: '#9b958c',
      R: 469.7, tilt: 4, rotH: 9.07, orb: [2.767, 0.0785, 10.59, 80.27, 73.4, 2459920.5],
      f: { mass: 0.000939, diam: 939, dens: 2162, grav: 0.28, esc: 0.51, rot: 9.1, day: 9.1, dist: 413.7, per: 1682, vel: 17.9, inc: 10.6, ecc: 0.079, temp: -105, moons: 0 },
      desc: T('The largest object in the asteroid belt between Mars and Jupiter, and the only dwarf planet in the inner Solar System. Ceres was the first asteroid ever found (Giuseppe Piazzi, 1 January 1801). Bright salt spots in Occator crater show that salty water once came up from inside.',
        'أكبر جرم في حزام الكويكبات بين المريخ والمشتري، والكوكب القزم الوحيد في المجموعة الشمسية الداخلية. وسيريس أول كويكب اكتُشف (جوزيبي بيازي، 1 يناير 1801). وتدل البقع الملحية اللامعة في فوهة أوكاتور على أن ماءً مالحًا صعد يومًا من باطنه.'),
      missions: [[2015, 'Dawn', T('Orbited Ceres from 2015 to 2018 after visiting Vesta.', 'دار حول سيريس من 2015 إلى 2018 بعد زيارة فيستا.')]],
      facts: [T('Ceres holds about a third of all the mass in the asteroid belt.', 'يحوي سيريس نحو ثلث كتلة حزام الكويكبات كله.'), T('It may still have pockets of salty liquid water under its crust.', 'ربما لا تزال تحت قشرته جيوب من الماء المالح السائل.')]
    },
    {
      id: 'pluto', kind: 'dwarf', name: T('Pluto', 'بلوتو'), type: T('Dwarf planet (Kuiper belt)', 'كوكب قزم (حزام كايبر)'), color: '#d9c2a5',
      R: 1188.3, tilt: 122.5, rotH: -153.3,
      el: [39.48211675, 0.24882730, 17.14001206, 238.92903833, 224.06891629, 110.30393684, -0.00031596, 0.00005170, 0.00004818, 145.20780515, -0.04062942, -0.01183482],
      f: { mass: 0.0130, diam: 2376, dens: 1850, grav: 0.62, esc: 1.2, rot: -153.3, day: 153.3, dist: 5906.4, peri: 4436.8, aph: 7375.9, per: 90560, vel: 4.7, inc: 17.2, ecc: 0.244, obl: 122.5, temp: -225, pres: 0.00001, moons: 5 },
      desc: T('Once called the ninth planet, Pluto was renamed a dwarf planet in 2006. In 2015 New Horizons showed a world of nitrogen-ice plains, water-ice mountains and blue haze. Its heart-shaped glacier, Tombaugh Regio, is bigger than Texas. Found by Clyde Tombaugh in 1930.',
        'كان يُسمّى الكوكب التاسع، ثم صُنّف كوكبًا قزمًا عام 2006. وفي 2015 كشفت المركبة New Horizons عالمًا من سهول جليد النيتروجين وجبال جليد الماء وضباب أزرق. ومنطقة تومبو التي على شكل قلب أكبر من ولاية تكساس. اكتشفه كلايد تومبو عام 1930.'),
      atmo: [[T('Nitrogen', 'النيتروجين'), 99], [T('Methane', 'الميثان'), 0.5], [T('Carbon monoxide', 'أول أكسيد الكربون'), 0.05]],
      atmoNote: T('A very thin air that freezes onto the ground when Pluto moves far from the Sun.', 'هواء رقيق جدًّا يتجمّد على الأرض عندما يبتعد بلوتو عن الشمس.'),
      missions: [[2015, 'New Horizons', T('Flew past Pluto on 14 July 2015, the only visit so far.', 'عبر بجوار بلوتو في 14 يوليو 2015، وهي الزيارة الوحيدة حتى الآن.')]],
      facts: [T('Pluto is smaller than our Moon.', 'بلوتو أصغر من قمرنا.'), T('Its moon Charon is half its size; the two always show each other the same face.', 'قمره شارون بنصف حجمه، ويواجه كلٌّ منهما الآخر بالوجه نفسه دائمًا.'), T('Some of Clyde Tombaugh\'s ashes are flying on New Horizons.', 'تحمل New Horizons جزءًا من رماد كلايد تومبو.')]
    },
    {
      id: 'haumea', kind: 'dwarf', name: T('Haumea', 'هاوميا'), type: T('Dwarf planet (Kuiper belt)', 'كوكب قزم (حزام كايبر)'), color: '#e6e2da',
      R: 780, tilt: 0, rotH: 3.92, orb: [43.0, 0.196, 28.2, 121.8, 240.9, 2499000.5],
      f: { diam: 1632, rot: 3.9, day: 3.9, dist: 6430, per: 103000, inc: 28.2, ecc: 0.196, temp: -241, moons: 2 },
      desc: T('An egg-shaped dwarf planet that spins once every 3.9 hours, one of the fastest spins of any large object. Haumea has two small moons and a ring.', 'كوكب قزم بيضاوي الشكل يدور حول نفسه مرة كل 3.9 ساعة، وهو من أسرع الأجرام الكبيرة دورانًا. وله قمران صغيران وحلقة.'),
      facts: [T('It is about twice as long as it is wide because of its fast spin.', 'طوله نحو ضعف عرضه بسبب دورانه السريع.')]
    },
    {
      id: 'makemake', kind: 'dwarf', name: T('Makemake', 'ماكيماكي'), type: T('Dwarf planet (Kuiper belt)', 'كوكب قزم (حزام كايبر)'), color: '#c9a38a',
      R: 715, tilt: 0, rotH: 22.8, orb: [45.4, 0.161, 29.0, 79.6, 297.2, 2408000.5],
      f: { diam: 1430, rot: 22.8, day: 22.8, dist: 6790, per: 111800, inc: 29.0, ecc: 0.161, temp: -239, moons: 1 },
      desc: T('A reddish dwarf planet in the Kuiper belt, found around Easter 2005 and named after a god of the Rapa Nui people of Easter Island.', 'كوكب قزم مائل إلى الحمرة في حزام كايبر، اكتُشف قرب عيد الفصح 2005، وسُمّي باسم إله عند شعب رابا نوي في جزيرة القيامة.'),
      facts: [T('Its surface is covered with frozen methane and ethane.', 'سطحه مغطى بالميثان والإيثان المتجمدين.')]
    },
    {
      id: 'eris', kind: 'dwarf', name: T('Eris', 'إيريس'), type: T('Dwarf planet (scattered disc)', 'كوكب قزم (القرص المبعثر)'), color: '#eeeeee',
      R: 1163, tilt: 0, rotH: 378, orb: [67.9, 0.437, 44.0, 36.0, 151.6, 2545000.5],
      f: { diam: 2326, dist: 10150, per: 204000, inc: 44.0, ecc: 0.437, temp: -243, moons: 1 },
      desc: T('Almost the same size as Pluto but more massive. Its discovery in 2005 started the debate that led to Pluto being called a dwarf planet. Eris is now about 96 times farther from the Sun than Earth.', 'بحجم بلوتو تقريبًا لكنها أكبر كتلة منه. وأطلق اكتشافها عام 2005 النقاش الذي انتهى بتصنيف بلوتو كوكبًا قزمًا. وتبعد إيريس الآن عن الشمس نحو 96 ضعف بعد الأرض عنها.'),
      facts: [T('One orbit takes about 559 years.', 'تستغرق دورتها الواحدة نحو 559 سنة.')]
    }
  ];

  const comets = [
    {
      id: 'halley', kind: 'comet', name: T('Halley\'s Comet', 'مذنب هالي'), type: T('Periodic comet (1P)', 'مذنب دوري (1P)'), color: '#cfe8ff',
      R: 5.5, orb: [17.834, 0.96714, 162.26, 58.42, 111.33, 2446470.5],
      f: { diam: 11, per: 27510, ecc: 0.967, inc: 162.3 },
      desc: T('The most famous comet, seen every 75-76 years. Edmond Halley predicted its return in 1758. It was last near the Sun in February 1986 and returns in July 2061. It reached its farthest point, beyond Neptune, in December 2023.', 'أشهر المذنبات، ويُرى كل 75 إلى 76 سنة. تنبأ إدموند هالي بعودته عام 1758. وآخر اقتراب له من الشمس كان في فبراير 1986، ويعود في يوليو 2061. وبلغ أبعد نقطة في مداره، وراء نبتون، في ديسمبر 2023.'),
      missions: [[1986, 'Giotto', T('ESA probe that photographed Halley\'s nucleus from 600 km.', 'مسبار أوروبي صوّر نواة هالي من مسافة 600 كم.')]],
      facts: [T('Its dust makes two meteor showers each year: the Eta Aquariids (May) and the Orionids (October).', 'يكوّن غباره زخّتين من الشهب كل عام: إيتا الدلويات (مايو) والجباريات (أكتوبر).')]
    },
    {
      id: 'encke', kind: 'comet', name: T('Comet Encke', 'مذنب إنكي'), type: T('Periodic comet (2P)', 'مذنب دوري (2P)'), color: '#d8f0ff',
      R: 2.4, orb: [2.215, 0.8483, 11.78, 334.57, 186.55, 2460240.5],
      f: { diam: 4.8, per: 1204, ecc: 0.848, inc: 11.8 },
      desc: T('The comet with the shortest known orbit of the bright comets: it returns every 3.3 years. Its debris causes the Taurid meteors in October and November.', 'المذنب ذو أقصر مدار بين المذنبات اللامعة المعروفة، إذ يعود كل 3.3 سنة. ويسبب حطامه شهب الثوريات في أكتوبر ونوفمبر.'),
      facts: [T('It was the second comet ever found to be periodic, after Halley.', 'كان ثاني مذنب ثبت أنه دوري، بعد هالي.')]
    },
    {
      id: 'cg67p', kind: 'comet', name: T('Comet 67P', 'المذنب 67P'), type: T('Periodic comet (Churyumov-Gerasimenko)', 'مذنب دوري (تشوريوموف-غيراسيمنكو)'), color: '#e0e0e0',
      R: 2.0, orb: [3.463, 0.6405, 7.04, 50.14, 12.78, 2459520.5],
      f: { diam: 4.1, per: 2353, ecc: 0.641, inc: 7.0 },
      desc: T('The rubber-duck-shaped comet visited by ESA\'s Rosetta. In November 2014 its lander Philae made the first landing on a comet.', 'المذنب الذي يشبه البطة المطاطية، وقد زارته مركبة Rosetta الأوروبية. وفي نوفمبر 2014 حقق مسبارها Philae أول هبوط على مذنب.'),
      missions: [[2014, 'Rosetta & Philae', T('Orbited the comet for two years and landed on it.', 'دارت حول المذنب عامين وهبطت عليه.')]],
      facts: [T('Rosetta found that the comet\'s water is different from Earth\'s oceans.', 'وجدت Rosetta أن ماء المذنب يختلف عن ماء محيطات الأرض.')]
    },
    {
      id: 'halebopp', kind: 'comet', name: T('Comet Hale-Bopp', 'مذنب هيل-بوب'), type: T('Long-period comet', 'مذنب طويل الدورة'), color: '#e8f4ff',
      R: 30, orb: [186.0, 0.9951, 89.43, 282.47, 130.59, 2450539.5],
      f: { diam: 60, per: 926000, ecc: 0.995, inc: 89.4 },
      desc: T('The great comet of 1997, visible to the naked eye for a record 18 months, even from cities. It will not return for about 2,500 years.', 'المذنب العظيم لعام 1997، ظل يُرى بالعين المجردة مدة قياسية بلغت 18 شهرًا، حتى من المدن. ولن يعود قبل نحو 2500 سنة.'),
      facts: [T('Its nucleus is about 60 km across, very large for a comet.', 'يبلغ قطر نواته نحو 60 كم، وهو كبير جدًّا بالنسبة إلى مذنب.')]
    }
  ];

  // Moons: a (km), period (days, negative = retrograde), R (km), discovered
  const moons = [
    { id: 'moon', parent: 'earth', name: T('Moon', 'القمر'), tex: 'moon.jpg', color: '#cfcfcf', a: 384400, P: 27.3217, R: 1737.4, disc: T('-', '-'),
      f: { mass: 0.073, diam: 3475, dens: 3344, grav: 1.6, esc: 2.4, rot: 655.7, day: 708.7, distE: 0.384, per: 27.3, vel: 1.0, inc: 5.1, ecc: 0.055, obl: 6.7, temp: -20, tmin: -173, tmax: 127, pres: 0, moons: 0 },
      desc: T('Earth\'s only natural satellite, probably formed from debris after a Mars-sized body hit the young Earth. It always shows us the same face, controls the tides, and is the only other world people have walked on: 12 astronauts between 1969 and 1972.',
        'القمر الطبيعي الوحيد للأرض، ويُرجّح أنه تكوّن من حطام اصطدام جرم بحجم المريخ بالأرض في بداياتها. ويرينا دائمًا الوجه نفسه، ويتحكم في المد والجزر، وهو العالم الوحيد غير الأرض الذي مشى عليه البشر: 12 رائد فضاء بين 1969 و1972.'),
      missions: [[1959, 'Luna 2', T('First spacecraft to reach the Moon.', 'أول مركبة تصل إلى القمر.')], [1966, 'Luna 9', T('First soft landing.', 'أول هبوط سلس.')], [1969, 'Apollo 11', T('Neil Armstrong and Buzz Aldrin, the first people on the Moon.', 'نيل أرمسترونغ وباز ألدرين، أول من وطئ القمر.')], [1972, 'Apollo 17', T('The last crewed landing so far.', 'آخر هبوط مأهول حتى الآن.')], [2019, 'Chang\'e 4', T('First landing on the far side.', 'أول هبوط على الجانب البعيد.')], [2023, 'Chandrayaan-3', T('India\'s landing near the south pole.', 'هبوط الهند قرب القطب الجنوبي.')], [2024, 'Chang\'e 6', T('First samples brought back from the far side.', 'أول عينات تُجلب من الجانب البعيد.')], [2026, 'Artemis II', T('Crewed flight around the Moon, the first since 1972.', 'رحلة مأهولة حول القمر، الأولى منذ 1972.')]],
      facts: [T('The Moon moves about 3.8 cm farther from Earth every year.', 'يبتعد القمر عن الأرض نحو 3.8 سم كل عام.'), T('For phases, moonrise and the Hijri crescent, see the Kankon Moon app in Kankon Launcher.', 'لمعرفة أطوار القمر وشروقه والهلال الهجري، افتح Kankon Moon من Kankon Launcher.')] },
    { id: 'phobos', parent: 'mars', name: T('Phobos', 'فوبوس'), color: '#8a7b6d', a: 9376, P: 0.3189, R: 11.1, disc: T('Asaph Hall, 1877', 'آساف هول، 1877'), desc: T('The larger moon of Mars, a lumpy rock 22 km across that circles Mars three times a day. It is slowly falling and will break apart in about 50 million years.', 'القمر الأكبر للمريخ، صخرة غير منتظمة عرضها 22 كم تدور حوله ثلاث مرات في اليوم. ويقترب من المريخ ببطء، وسيتفكك بعد نحو 50 مليون سنة.') },
    { id: 'deimos', parent: 'mars', name: T('Deimos', 'ديموس'), color: '#9c8f80', a: 23463, P: 1.263, R: 6.2, disc: T('Asaph Hall, 1877', 'آساف هول، 1877'), desc: T('The small outer moon of Mars, only 12 km across.', 'القمر الخارجي الصغير للمريخ، عرضه 12 كم فقط.') },
    { id: 'io', parent: 'jupiter', name: T('Io', 'آيو'), color: '#e8d56a', a: 421700, P: 1.769, R: 1821.6, disc: T('Galileo, 1610', 'غاليليو، 1610'), desc: T('The most volcanic world known, with over 400 active volcanoes, heated by Jupiter\'s tides.', 'أكثر العوالم المعروفة نشاطًا بركانيًّا، فيه أكثر من 400 بركان نشط، تسخّن باطنَه قوى المدّ الناتجة عن جاذبية المشتري.') },
    { id: 'europa', parent: 'jupiter', name: T('Europa', 'أوروبا'), color: '#d8c8a8', a: 671034, P: 3.551, R: 1560.8, disc: T('Galileo, 1610', 'غاليليو، 1610'), desc: T('An icy moon with a salty ocean under its crust holding about twice the water of Earth\'s oceans; a top place to look for life.', 'قمر جليدي تحت قشرته محيط مالح فيه نحو ضعف ماء محيطات الأرض، ومن أهم الأماكن للبحث عن الحياة.') },
    { id: 'ganymede', parent: 'jupiter', name: T('Ganymede', 'غانيميد'), color: '#a89f94', a: 1070412, P: 7.155, R: 2634.1, disc: T('Galileo, 1610', 'غاليليو، 1610'), desc: T('The largest moon in the Solar System, bigger than Mercury, and the only moon with its own magnetic field.', 'أكبر قمر في المجموعة الشمسية، أكبر من عطارد، والقمر الوحيد الذي له مجال مغناطيسي خاص.') },
    { id: 'callisto', parent: 'jupiter', name: T('Callisto', 'كاليستو'), color: '#6f665c', a: 1882709, P: 16.689, R: 2410.3, disc: T('Galileo, 1610', 'غاليليو، 1610'), desc: T('The most heavily cratered object in the Solar System.', 'أكثر أجرام المجموعة الشمسية امتلاءً بالفوهات.') },
    { id: 'mimas', parent: 'saturn', name: T('Mimas', 'ميماس'), color: '#c8c8c8', a: 185539, P: 0.942, R: 198.2, disc: T('William Herschel, 1789', 'وليام هيرشل، 1789'), desc: T('Its giant crater Herschel makes it look like the Death Star.', 'فوهته العملاقة هيرشل تجعله يشبه «نجمة الموت» في أفلام Star Wars.') },
    { id: 'enceladus', parent: 'saturn', name: T('Enceladus', 'إنسيلادوس'), color: '#f4f4f4', a: 238042, P: 1.370, R: 252.1, disc: T('William Herschel, 1789', 'وليام هيرشل، 1789'), desc: T('A bright white moon that shoots geysers of water from an ocean under its south pole.', 'قمر أبيض لامع ينفث ينابيع من الماء من محيط تحت قطبه الجنوبي.') },
    { id: 'tethys', parent: 'saturn', name: T('Tethys', 'تيثيس'), color: '#dcdcdc', a: 294672, P: 1.888, R: 531.1, disc: T('G. D. Cassini, 1684', 'جيوفاني كاسيني، 1684'), desc: T('Made almost entirely of water ice.', 'يتكوّن كله تقريبًا من جليد الماء.') },
    { id: 'dione', parent: 'saturn', name: T('Dione', 'ديوني'), color: '#d0d0d0', a: 377415, P: 2.737, R: 561.4, disc: T('G. D. Cassini, 1684', 'جيوفاني كاسيني، 1684'), desc: T('An icy moon with bright ice cliffs.', 'قمر جليدي فيه جروف جليدية لامعة.') },
    { id: 'rhea', parent: 'saturn', name: T('Rhea', 'ريا'), color: '#c4c4c4', a: 527068, P: 4.518, R: 763.8, disc: T('G. D. Cassini, 1672', 'جيوفاني كاسيني، 1672'), desc: T('Saturn\'s second-largest moon.', 'ثاني أكبر أقمار زحل.') },
    { id: 'titan', parent: 'saturn', name: T('Titan', 'تيتان'), color: '#d9a441', a: 1221865, P: 15.945, R: 2574.7, disc: T('Christiaan Huygens, 1655', 'كريستيان هويغنز، 1655'), desc: T('The only moon with a thick atmosphere, and the only other world with lakes and rivers on its surface, made of liquid methane.', 'القمر الوحيد ذو الغلاف الجوي الكثيف، والعالم الوحيد غير الأرض الذي على سطحه بحيرات وأنهار، لكنها من الميثان السائل.') },
    { id: 'iapetus', parent: 'saturn', name: T('Iapetus', 'يابيتوس'), color: '#8f7f6a', a: 3560854, P: 79.33, R: 734.4, disc: T('G. D. Cassini, 1671', 'جيوفاني كاسيني، 1671'), desc: T('One side is dark as coal, the other bright as snow.', 'أحد وجهيه داكن كالفحم والآخر لامع كالثلج.') },
    { id: 'miranda', parent: 'uranus', name: T('Miranda', 'ميراندا'), color: '#bdbdbd', a: 129872, P: 1.413, R: 235.8, disc: T('Gerard Kuiper, 1948', 'جيرارد كايبر، 1948'), desc: T('Has the tallest known cliff in the Solar System, Verona Rupes, about 20 km high.', 'فيه أعلى جرف معروف في المجموعة الشمسية، فيرونا روبيس، بارتفاع نحو 20 كم.') },
    { id: 'ariel', parent: 'uranus', name: T('Ariel', 'أرييل'), color: '#c9c9c9', a: 190945, P: 2.520, R: 578.9, disc: T('William Lassell, 1851', 'وليام لاسيل، 1851'), desc: T('The brightest of Uranus\'s large moons.', 'ألمع أقمار أورانوس الكبيرة.') },
    { id: 'umbriel', parent: 'uranus', name: T('Umbriel', 'أمبريل'), color: '#7d7d7d', a: 265998, P: 4.144, R: 584.7, disc: T('William Lassell, 1851', 'وليام لاسيل، 1851'), desc: T('The darkest of Uranus\'s large moons.', 'أعتم أقمار أورانوس الكبيرة.') },
    { id: 'titania', parent: 'uranus', name: T('Titania', 'تيتانيا'), color: '#b6aea4', a: 436298, P: 8.706, R: 788.9, disc: T('William Herschel, 1787', 'وليام هيرشل، 1787'), desc: T('The largest moon of Uranus.', 'أكبر أقمار أورانوس.') },
    { id: 'oberon', parent: 'uranus', name: T('Oberon', 'أوبيرون'), color: '#a79d93', a: 583519, P: 13.463, R: 761.4, disc: T('William Herschel, 1787', 'وليام هيرشل، 1787'), desc: T('The outermost large moon of Uranus.', 'أبعد أقمار أورانوس الكبيرة.') },
    { id: 'triton', parent: 'neptune', name: T('Triton', 'تريتون'), color: '#d6c7c0', a: 354759, P: -5.877, R: 1353.4, disc: T('William Lassell, 1846', 'وليام لاسيل، 1846'), desc: T('Orbits backwards, so it was probably captured from the Kuiper belt. Voyager 2 saw nitrogen geysers on it.', 'يدور في الاتجاه المعاكس، فالأرجح أنه أُسر من حزام كايبر. ورصدت Voyager 2 عليه ينابيع من النيتروجين.') },
    { id: 'charon', parent: 'pluto', name: T('Charon', 'شارون'), color: '#a9a29a', a: 19591, P: 6.387, R: 606, disc: T('James Christy, 1978', 'جيمس كريستي، 1978'), desc: T('Half the size of Pluto; the two orbit a point in space between them.', 'بنصف حجم بلوتو، ويدور الاثنان حول نقطة في الفضاء بينهما.') }
  ];

  const sun = {
    id: 'sun', kind: 'star', name: T('Sun', 'الشمس'), type: T('Yellow dwarf star (G2V)', 'نجم قزم أصفر (G2V)'), tex: 'sun.jpg', color: '#ffcc55', R: 695700, tilt: 7.25, rotH: 609.12,
    f: { mass: 1988500, diam: 1392700, dens: 1408, grav: 274, esc: 617.6, rot: 609.1, temp: 5500, core: 15000000, age: 4.6 },
    desc: T('Our star: a 4.6-billion-year-old ball of hot plasma that holds 99.86% of all the mass in the Solar System. In its core, 600 million tonnes of hydrogen turn into helium every second, and that energy lights and warms all the planets. Sunlight takes about 8 minutes 20 seconds to reach Earth.',
      'نجمنا: كرة من البلازما الحارة عمرها 4.6 مليار سنة، تضم 99.86% من كتلة المجموعة الشمسية كلها. وفي لبّها يتحول 600 مليون طن من الهيدروجين إلى هيليوم كل ثانية، وهذه الطاقة تضيء الكواكب كلها وتدفئها. ويستغرق ضوء الشمس نحو 8 دقائق و20 ثانية ليصل إلى الأرض.'),
    atmo: [[T('Hydrogen', 'الهيدروجين'), 73.5], [T('Helium', 'الهيليوم'), 24.9], [T('Oxygen, carbon, iron and others', 'الأكسجين والكربون والحديد وغيرها'), 1.6]],
    atmoNote: T('Composition by mass.', 'التركيب بحسب الكتلة.'),
    missions: [[1995, 'SOHO', T('ESA/NASA observatory watching the Sun since 1995; it has also found over 5,000 comets.', 'مرصد أوروبي أمريكي يراقب الشمس منذ 1995، واكتشف أيضًا أكثر من 5000 مذنب.')],
      [2010, 'Solar Dynamics Observatory', T('Takes detailed pictures of the Sun every few seconds.', 'يلتقط صورًا مفصلة للشمس كل بضع ثوانٍ.')],
      [2018, 'Parker Solar Probe', T('The closest any spacecraft has come: 6.1 million km from the surface on 24 December 2024, at 692,000 km/h, the fastest object ever built.', 'أقرب مركبة إلى الشمس، إذ اقتربت إلى 6.1 مليون كم من سطحها في 24 ديسمبر 2024، بسرعة 692000 كم في الساعة، وهي أسرع جسم صنعه الإنسان.')],
      [2020, 'Solar Orbiter', T('ESA mission that took the first pictures of the Sun\'s poles.', 'بعثة أوروبية التقطت أول صور لقطبي الشمس.')],
      [2023, 'Aditya-L1', T('India\'s first solar observatory.', 'أول مرصد شمسي هندي.')]],
    facts: [T('About 1.3 million Earths would fit inside the Sun.', 'تتسع الشمس لنحو 1.3 مليون أرض.'),
      T('The surface is about 5,500 °C, but the outer atmosphere (corona) is over 1 million °C, and scientists are still working out why.', 'تبلغ حرارة السطح نحو 5500 °م، أما الغلاف الخارجي (الهالة) فتتجاوز حرارته مليون درجة، وما زال العلماء يبحثون عن السبب.'),
      T('The Sun circles the centre of the Milky Way at about 230 km/s; one lap takes about 230 million years.', 'تدور الشمس حول مركز درب التبانة بسرعة نحو 230 كم في الثانية، وتستغرق الدورة الواحدة نحو 230 مليون سنة.'),
      T('In about 5 billion years the Sun will swell into a red giant.', 'بعد نحو 5 مليارات سنة ستنتفخ الشمس لتصبح عملاقًا أحمر.')]
  };

  // Spacecraft far away: distance from the Sun (au) at epoch + speed (au/year) + ecliptic direction
  const craft = [
    { id: 'voyager1', kind: 'craft', name: T('Voyager 1', 'Voyager 1'), type: T('NASA space probe', 'مسبار فضائي تابع لـNASA'), color: '#ffd28a', au0: 165.2, t0: 2460676.5, v: 3.58, lon: 255.0, lat: 35.0,
      desc: T('Launched on 5 September 1977. Voyager 1 is the farthest human-made object. It passed Jupiter (1979) and Saturn (1980) and left the heliosphere for interstellar space in August 2012. In November 2026 it reaches one light-day from Earth.', 'أُطلقت في 5 سبتمبر 1977، وهي أبعد جسم صنعه الإنسان. عبرت بجوار المشتري (1979) وزحل (1980)، وغادرت الغلاف الشمسي إلى الفضاء بين النجمي في أغسطس 2012. وفي نوفمبر 2026 يبلغ بُعدها عن الأرض يومًا ضوئيًّا واحدًا.'),
      facts: [T('It carries the Golden Record with sounds and greetings from Earth, including one in Arabic.', 'تحمل الأسطوانة الذهبية التي فيها أصوات وتحيات من الأرض، منها تحية باللغة العربية.'), T('Its radio signal is weaker than a billionth of a billionth of a watt when it reaches Earth.', 'تصل إشارتها الراديوية إلى الأرض أضعف من جزء من مليار من مليار من الواط.')] },
    { id: 'voyager2', kind: 'craft', name: T('Voyager 2', 'Voyager 2'), type: T('NASA space probe', 'مسبار فضائي تابع لـNASA'), color: '#ffd28a', au0: 138.2, t0: 2460676.5, v: 3.23, lon: 289.4, lat: -34.6,
      desc: T('Launched on 20 August 1977. The only spacecraft that has visited all four giant planets: Jupiter (1979), Saturn (1981), Uranus (1986) and Neptune (1989). It entered interstellar space in November 2018.', 'أُطلقت في 20 أغسطس 1977، وهي المركبة الوحيدة التي زارت الكواكب العملاقة الأربعة: المشتري (1979) وزحل (1981) وأورانوس (1986) ونبتون (1989). ودخلت الفضاء بين النجمي في نوفمبر 2018.'),
      facts: [T('Its power source loses about 4 watts a year, so instruments are switched off one by one.', 'يفقد مصدر طاقتها نحو 4 واط كل عام، لذلك تُطفأ أجهزتها واحدًا بعد الآخر.')] }
  ];

  // Did-you-know quiz (answers: index of the right option)
  const quiz = [
    [T('Which planet is the hottest?', 'أي الكواكب هو الأشد حرارة؟'), [T('Mercury', 'عطارد'), T('Venus', 'الزهرة'), T('Mars', 'المريخ'), T('Jupiter', 'المشتري')], 1, T('Venus (464 °C): its thick CO₂ air traps the heat.', 'الزهرة (464 °م): هواؤها الكثيف من ثاني أكسيد الكربون يحبس الحرارة.')],
    [T('Which planet has the most known moons?', 'أي الكواكب لديه أكبر عدد معروف من الأقمار؟'), [T('Jupiter', 'المشتري'), T('Uranus', 'أورانوس'), T('Saturn', 'زحل'), T('Neptune', 'نبتون')], 2, T('Saturn, with 274 known moons.', 'زحل، وله 274 قمرًا معروفًا.')],
    [T('How long does sunlight take to reach Earth?', 'كم يستغرق ضوء الشمس ليصل إلى الأرض؟'), [T('8 seconds', '8 ثوانٍ'), T('About 8 minutes', 'نحو 8 دقائق'), T('1 hour', 'ساعة واحدة'), T('1 day', 'يوم واحد')], 1, T('About 8 minutes 20 seconds.', 'نحو 8 دقائق و20 ثانية.')],
    [T('Which is the largest moon in the Solar System?', 'ما أكبر قمر في المجموعة الشمسية؟'), [T('Titan', 'تيتان'), T('Our Moon', 'قمرنا'), T('Ganymede', 'غانيميد'), T('Europa', 'أوروبا')], 2, T('Ganymede, a moon of Jupiter, is bigger than Mercury.', 'غانيميد، أحد أقمار المشتري، وهو أكبر من عطارد.')],
    [T('Which planet spins on its side?', 'أي الكواكب يدور على جنبه؟'), [T('Uranus', 'أورانوس'), T('Neptune', 'نبتون'), T('Saturn', 'زحل'), T('Mars', 'المريخ')], 0, T('Uranus, tilted 98°.', 'أورانوس، ومحوره مائل 98 درجة.')],
    [T('Where is the biggest volcano in the Solar System?', 'أين يقع أكبر بركان في المجموعة الشمسية؟'), [T('Earth', 'الأرض'), T('Venus', 'الزهرة'), T('Io', 'آيو'), T('Mars', 'المريخ')], 3, T('Olympus Mons on Mars, about 22 km high.', 'جبل أوليمبوس على المريخ، بارتفاع نحو 22 كم.')],
    [T('Which planet would float in water?', 'أي الكواكب يطفو على الماء؟'), [T('Saturn', 'زحل'), T('Jupiter', 'المشتري'), T('Neptune', 'نبتون'), T('Earth', 'الأرض')], 0, T('Saturn is less dense than water.', 'زحل أقل كثافة من الماء.')],
    [T('What is the name of the UAE\'s mission to Mars?', 'ما اسم بعثة الإمارات إلى المريخ؟'), [T('Hope', 'الأمل'), T('Falcon', 'الصقر'), T('Rashid', 'راشد'), T('Zayed', 'زايد')], 0, T('Hope (Al Amal) reached Mars orbit in February 2021.', 'دخل مسبار الأمل مدار المريخ في فبراير 2021.')],
    [T('Which spacecraft is the farthest from Earth?', 'ما أبعد مركبة فضائية عن الأرض؟'), [T('Voyager 2', 'Voyager 2'), T('New Horizons', 'New Horizons'), T('Voyager 1', 'Voyager 1'), T('Pioneer 10', 'Pioneer 10')], 2, T('Voyager 1, about one light-day away in late 2026.', 'Voyager 1، إذ يبلغ بُعدها نحو يوم ضوئي أواخر 2026.')],
    [T('How long is a year on Neptune?', 'كم تبلغ سنة نبتون؟'), [T('12 Earth years', '12 سنة أرضية'), T('84 Earth years', '84 سنة أرضية'), T('165 Earth years', '165 سنة أرضية'), T('248 Earth years', '248 سنة أرضية')], 2, T('About 165 Earth years.', 'نحو 165 سنة أرضية.')],
    [T('Which planet has the shortest day?', 'أي الكواكب يومه أقصر؟'), [T('Earth', 'الأرض'), T('Jupiter', 'المشتري'), T('Mercury', 'عطارد'), T('Mars', 'المريخ')], 1, T('Jupiter: just under 10 hours.', 'المشتري: أقل بقليل من 10 ساعات.')],
    [T('When was Pluto classified as a dwarf planet?', 'متى صُنّف بلوتو كوكبًا قزمًا؟'), [T('1930', '1930'), T('1989', '1989'), T('2006', '2006'), T('2015', '2015')], 2, T('In 2006, by the International Astronomical Union.', 'عام 2006، بقرار من الاتحاد الفلكي الدولي.')],
    [T('What makes Mars red?', 'ما الذي يجعل المريخ أحمر؟'), [T('Lava', 'الحمم'), T('Rust (iron oxide)', 'الصدأ (أكسيد الحديد)'), T('Red plants', 'نباتات حمراء'), T('Sunlight', 'ضوء الشمس')], 1, T('Iron oxide in its dust and rocks.', 'أكسيد الحديد في غباره وصخوره.')],
    [T('Which moon has lakes of liquid methane?', 'أي الأقمار فيه بحيرات من الميثان السائل؟'), [T('Titan', 'تيتان'), T('Io', 'آيو'), T('Triton', 'تريتون'), T('Phobos', 'فوبوس')], 0, T('Titan, Saturn\'s largest moon.', 'تيتان، أكبر أقمار زحل.')],
    [T('About how many Earths fit inside the Sun?', 'كم أرضًا تتسع لها الشمس تقريبًا؟'), [T('1,000', '1,000'), T('100,000', '100,000'), T('1.3 million', '1.3 مليون'), T('1 billion', 'مليار')], 2, T('About 1.3 million.', 'نحو 1.3 مليون.')],
    [T('Which planet was found by mathematics before it was seen?', 'أي الكواكب اكتُشف بالرياضيات قبل أن يُرى؟'), [T('Uranus', 'أورانوس'), T('Neptune', 'نبتون'), T('Pluto', 'بلوتو'), T('Saturn', 'زحل')], 1, T('Neptune, in 1846.', 'نبتون، عام 1846.')],
    [T('How long does the Sun take to circle the Milky Way?', 'كم تستغرق الشمس لتدور حول درب التبانة؟'), [T('1 million years', 'مليون سنة'), T('230 million years', '230 مليون سنة'), T('4.6 billion years', '4.6 مليار سنة'), T('It does not move', 'لا تتحرك')], 1, T('About 230 million years.', 'نحو 230 مليون سنة.')],
    [T('Who was the first Arab in space?', 'من أول عربي صعد إلى الفضاء؟'), [T('Hazzaa Al Mansoori', 'هزاع المنصوري'), T('Sultan bin Salman', 'سلطان بن سلمان'), T('Muhammed Faris', 'محمد فارس'), T('Sultan Al Neyadi', 'سلطان النيادي')], 1, T('Prince Sultan bin Salman, on the Space Shuttle Discovery in June 1985.', 'الأمير سلطان بن سلمان، على متن مكوك الفضاء ديسكفري في يونيو 1985.')],
    [T('Between which planets is the main asteroid belt?', 'بين أي كوكبين يقع حزام الكويكبات الرئيسي؟'), [T('Earth and Mars', 'الأرض والمريخ'), T('Mars and Jupiter', 'المريخ والمشتري'), T('Jupiter and Saturn', 'المشتري وزحل'), T('Neptune and Pluto', 'نبتون وبلوتو')], 1, T('Between Mars and Jupiter.', 'بين المريخ والمشتري.')],
    [T('When will Halley\'s Comet return?', 'متى يعود مذنب هالي؟'), [T('2031', '2031'), T('2061', '2061'), T('2086', '2086'), T('2100', '2100')], 1, T('In July 2061.', 'في يوليو 2061.')],
    [T('Which planet is closest in size to Earth?', 'أي الكواكب أقرب حجمًا إلى الأرض؟'), [T('Mars', 'المريخ'), T('Venus', 'الزهرة'), T('Mercury', 'عطارد'), T('Neptune', 'نبتون')], 1, T('Venus, Earth\'s "twin".', 'الزهرة، «توأم» الأرض.')],
    [T('How fast does the ISS go around Earth?', 'كم تستغرق محطة الفضاء الدولية لتدور حول الأرض؟'), [T('About 90 minutes', 'نحو 90 دقيقة'), T('About 12 hours', 'نحو 12 ساعة'), T('1 day', 'يومًا واحدًا'), T('1 month', 'شهرًا')], 0, T('About 92 minutes, at roughly 28,000 km/h.', 'نحو 92 دقيقة، بسرعة تقارب 28000 كم في الساعة.')],
    [T('About how many stars are in the Milky Way?', 'كم نجمًا في درب التبانة تقريبًا؟'), [T('About 1 million', 'نحو مليون'), T('About 100 million', 'نحو 100 مليون'), T('100 to 400 billion', 'من 100 إلى 400 مليار'), T('Exactly 8', '8 فقط')], 2, T('Between 100 and 400 billion.', 'بين 100 و400 مليار.')],
    [T('Which planet has the strongest winds?', 'أي الكواكب رياحه أقوى؟'), [T('Earth', 'الأرض'), T('Jupiter', 'المشتري'), T('Neptune', 'نبتون'), T('Mars', 'المريخ')], 2, T('Neptune, up to about 2,000 km/h.', 'نبتون، حتى نحو 2000 كم في الساعة.')],
    [T('Which spacecraft landed on a comet?', 'أي مركبة هبطت على مذنب؟'), [T('Philae (Rosetta)', 'Philae (Rosetta)'), T('Juno', 'Juno'), T('Cassini', 'Cassini'), T('Hope', 'الأمل')], 0, T('Philae, on comet 67P in November 2014.', 'Philae، على المذنب 67P في نوفمبر 2014.')]
  ];

  // Places for "Tonight's sky"
  const places = [
    { id: 'kuwait', name: T('Kuwait City', 'مدينة الكويت'), lat: 29.3759, lon: 47.9774 },
    { id: 'jahra', name: T('Al Jahra', 'الجهراء'), lat: 29.3375, lon: 47.6581 },
    { id: 'ahmadi', name: T('Al Ahmadi', 'الأحمدي'), lat: 29.0769, lon: 48.0838 },
    { id: 'riyadh', name: T('Riyadh', 'الرياض'), lat: 24.7136, lon: 46.6753 },
    { id: 'makkah', name: T('Makkah', 'مكة المكرمة'), lat: 21.4225, lon: 39.8262 },
    { id: 'jeddah', name: T('Jeddah', 'جدة'), lat: 21.4858, lon: 39.1925 },
    { id: 'dammam', name: T('Dammam', 'الدمام'), lat: 26.4207, lon: 50.0888 },
    { id: 'manama', name: T('Manama', 'المنامة'), lat: 26.2285, lon: 50.5860 },
    { id: 'doha', name: T('Doha', 'الدوحة'), lat: 25.2854, lon: 51.5310 },
    { id: 'abudhabi', name: T('Abu Dhabi', 'أبوظبي'), lat: 24.4539, lon: 54.3773 },
    { id: 'dubai', name: T('Dubai', 'دبي'), lat: 25.2048, lon: 55.2708 },
    { id: 'muscat', name: T('Muscat', 'مسقط'), lat: 23.5880, lon: 58.3829 },
    { id: 'baghdad', name: T('Baghdad', 'بغداد'), lat: 33.3152, lon: 44.3661 },
    { id: 'amman', name: T('Amman', 'عمّان'), lat: 31.9454, lon: 35.9284 },
    { id: 'cairo', name: T('Cairo', 'القاهرة'), lat: 30.0444, lon: 31.2357 },
    { id: 'london', name: T('London', 'لندن'), lat: 51.5072, lon: -0.1276 }
  ];

  // Earth explorer: famous places (lat, lon, camera height m)
  const earthPlaces = [
    { g: T('Kuwait', 'الكويت'), items: [
      [T('Kuwait Towers', 'أبراج الكويت'), 29.3897, 48.0036, 1200],
      [T('Liberation Tower', 'برج التحرير'), 29.3707, 47.9750, 1500],
      [T('Grand Mosque, Kuwait', 'المسجد الكبير'), 29.3727, 47.9830, 1200],
      [T('Failaka Island', 'جزيرة فيلكا'), 29.4400, 48.3300, 30000],
      [T('Sheikh Jaber Al-Ahmad Causeway', 'جسر الشيخ جابر الأحمد'), 29.4300, 47.9900, 30000],
      [T('Kuwait (whole country)', 'الكويت (الدولة كلها)'), 29.30, 47.65, 380000]] },
    { g: T('Arab world', 'العالم العربي'), items: [
      [T('Masjid al-Haram, Makkah', 'المسجد الحرام، مكة المكرمة'), 21.4225, 39.8262, 1500],
      [T('Al-Masjid an-Nabawi, Madinah', 'المسجد النبوي، المدينة المنورة'), 24.4672, 39.6112, 1500],
      [T('Burj Khalifa, Dubai', 'برج خليفة، دبي'), 25.1972, 55.2744, 2000],
      [T('Palm Jumeirah, Dubai', 'نخلة جميرا، دبي'), 25.1124, 55.1390, 14000],
      [T('Pyramids of Giza', 'أهرامات الجيزة'), 29.9792, 31.1342, 2500],
      [T('Petra, Jordan', 'البتراء، الأردن'), 30.3285, 35.4444, 3000],
      [T('AlUla, Saudi Arabia', 'العُلا، السعودية'), 26.6084, 37.9232, 20000],
      [T('Nile Delta', 'دلتا النيل'), 30.9, 31.1, 400000]] },
    { g: T('World', 'العالم'), items: [
      [T('Mount Everest', 'جبل إيفرست'), 27.9881, 86.9250, 15000],
      [T('Grand Canyon', 'غراند كانيون'), 36.1069, -112.1129, 25000],
      [T('Eiffel Tower, Paris', 'برج إيفل، باريس'), 48.8584, 2.2945, 1500],
      [T('Statue of Liberty, New York', 'تمثال الحرية، نيويورك'), 40.6892, -74.0445, 1500],
      [T('Great Barrier Reef', 'الحاجز المرجاني العظيم'), -18.2871, 147.6992, 300000],
      [T('Amazon River', 'نهر الأمازون'), -3.4653, -62.2159, 600000],
      [T('Great Wall of China (Badaling)', 'سور الصين العظيم (بادالينغ)'), 40.3588, 116.0200, 2500],
      [T('Kennedy Space Center', 'مركز كينيدي للفضاء'), 28.5729, -80.6490, 8000],
      [T('Baikonur Cosmodrome', 'قاعدة بايكونور الفضائية'), 45.9650, 63.3050, 30000],
      [T('Sahara Desert', 'الصحراء الكبرى'), 23.4, 12.0, 3000000]] }
  ];

  return { planets, dwarfs, comets, moons, sun, craft, quiz, places, earthPlaces, T };
})();
