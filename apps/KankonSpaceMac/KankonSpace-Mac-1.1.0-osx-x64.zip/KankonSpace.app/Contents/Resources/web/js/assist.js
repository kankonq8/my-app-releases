/* Kankon Space - "Ask about space" (AI with the user's own key: OpenAI, Google Gemini or Anthropic Claude)
   and NASA's Astronomy Picture of the Day (api.nasa.gov, free key or DEMO_KEY).
   Keys are kept only on this computer (the app's own storage) and sent only to the provider the user chose. */
window.KS_ASSIST = (function () {
  const I = window.KS_I18N, t = I.t;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ar = () => I.lang === 'ar';
  const CFG_KEY = 'ks.ai', CHAT_KEY = 'ks.chat', APOD_KEY = 'ks.apod';
  const PROVIDERS = {
    anthropic: { name: 'Anthropic Claude', keyUrl: 'https://console.anthropic.com/settings/keys', def: 'claude-opus-5-5' },
    openai: { name: 'OpenAI (ChatGPT)', keyUrl: 'https://platform.openai.com/api-keys', def: 'gpt-5-mini' },
    gemini: { name: 'Google Gemini', keyUrl: 'https://aistudio.google.com/app/apikey', def: 'gemini-2.5-flash' }
  };

  function load(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
  let demo = false; // guide screenshots: show an example without touching the user's saved settings
  function save(k, v) { if (demo) return; try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  let cfg = load(CFG_KEY, { provider: 'anthropic', keys: {}, models: {}, nasa: '' });
  let chat = load(CHAT_KEY, []);
  let busy = false, inited = false;

  const hasKey = () => demo || !!(cfg.keys[cfg.provider] || '').trim();
  const model = () => cfg.models[cfg.provider] || PROVIDERS[cfg.provider].def;

  // ---------------- providers ----------------
  async function readError(r) {
    let m = 'HTTP ' + r.status;
    try { const j = await r.json(); m = (j.error && (j.error.message || j.error.type)) || j.message || m; } catch (e) { /* ignore */ }
    if (r.status === 401 || r.status === 403) m = t('aiBadKey') + ' (' + m + ')';
    if (r.status === 429) m = t('aiLimit') + ' (' + m + ')';
    return new Error(m);
  }

  // msgs: [{role:'user'|'assistant', text}]
  async function complete(system, msgs) {
    const p = cfg.provider, key = (cfg.keys[p] || '').trim(), m = model();
    if (!key) throw new Error(t('aiNoKey'));
    if (p === 'anthropic') {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2026-10-21',
          'anthropic-dangerous-direct-browser-access': 'true', 'anthropic-beta': 'server-side-fallback-2026-07-01' },
        body: JSON.stringify({ model: m, max_tokens: 4000, system, fallbacks: 'default', output_config: { effort: 'low' },
          messages: msgs.map((x) => ({ role: x.role, content: x.text })) })
      });
      if (!r.ok) throw await readError(r);
      const j = await r.json();
      if (j.stop_reason === 'refusal') throw new Error(t('aiRefused'));
      return (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
    }
    if (p === 'openai') {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
        body: JSON.stringify({ model: m, messages: [{ role: 'system', content: system }, ...msgs.map((x) => ({ role: x.role, content: x.text }))] })
      });
      if (!r.ok) throw await readError(r);
      const j = await r.json();
      return ((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim();
    }
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] },
        contents: msgs.map((x) => ({ role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: x.text }] })) })
    });
    if (!r.ok) throw await readError(r);
    const j = await r.json();
    const c = j.candidates && j.candidates[0];
    return ((c && c.content && c.content.parts) || []).map((x) => x.text || '').join('').trim();
  }

  // The models this key can use (newest first), so the user can pick one; also checks the key.
  async function listModels() {
    const p = cfg.provider, key = (cfg.keys[p] || '').trim();
    if (!key) throw new Error(t('aiNoKey'));
    let ids = [];
    if (p === 'anthropic') {
      const r = await fetch('https://api.anthropic.com/v1/models?limit=100', { headers: { 'x-api-key': key, 'anthropic-version': '2026-10-21', 'anthropic-dangerous-direct-browser-access': 'true' } });
      if (!r.ok) throw await readError(r);
      ids = ((await r.json()).data || []).map((x) => x.id);
    } else if (p === 'openai') {
      const r = await fetch('https://api.openai.com/v1/models', { headers: { authorization: 'Bearer ' + key } });
      if (!r.ok) throw await readError(r);
      ids = ((await r.json()).data || []).map((x) => x.id).filter((id) => /^(gpt-[4-9]|o[1-9]|chatgpt)/.test(id) && !/audio|realtime|transcribe|tts|search|image|codex|instruct|embedding|\d{4}-\d{2}-\d{2}/.test(id)).sort().reverse();
    } else {
      const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { headers: { 'x-goog-api-key': key } });
      if (!r.ok) throw await readError(r);
      ids = ((await r.json()).models || []).filter((x) => (x.supportedGenerationMethods || []).includes('generateContent'))
        .map((x) => x.name.replace(/^models\//, '')).filter((id) => /^gemini/.test(id) && !/image|tts|embedding|audio|live/.test(id)).sort().reverse();
    }
    return ids;
  }

  function systemPrompt() {
    const c = (window.KS_APP && KS_APP.context) ? KS_APP.context() : {};
    return [
      'You are the astronomy guide inside Kankon Space, a desktop app (by Kankon, kankon.net) that shows the Solar System, the Earth, the Milky Way and the night sky.',
      'Answer questions about space, astronomy, planets, moons, the Sun, stars, galaxies, space missions and the sky. If a question is not about space or science, answer briefly and kindly steer back to space.',
      ar() ? 'Reply in clear Modern Standard Arabic (فصحى). Keep spacecraft, mission and organisation names in English (for example Voyager 1, NASA).' : 'Reply in clear, simple English.',
      'Be accurate. Use numbers from NASA and other trusted sources and say when something is uncertain or not yet known. Never invent facts.',
      'Keep answers short (about 80 to 200 words) unless the user asks for more detail. Use short paragraphs or simple lists; no tables.',
      'For what is visible in the sky tonight, remind the user that the app\'s "Tonight\'s sky" page has exact times for their city.',
      'Context from the app: ' + JSON.stringify(c)
    ].join('\n');
  }

  // ---------------- Ask page ----------------
  function fmt(s) {
    // light formatting: **bold**, lines starting with - or • become list items, blank lines split paragraphs
    const lines = esc(s).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').split('\n');
    let h = '', inList = false;
    for (const ln of lines) {
      const m = ln.match(/^\s*(?:[-•*]|\d+[.)])\s+(.*)/);
      if (m) { if (!inList) { h += '<ul>'; inList = true; } h += '<li>' + m[1] + '</li>'; continue; }
      if (inList) { h += '</ul>'; inList = false; }
      if (ln.trim()) h += '<p>' + ln.replace(/^#+\s*/, '') + '</p>';
    }
    if (inList) h += '</ul>';
    return h;
  }

  function renderChat() {
    const box = $('#askChat'); if (!box) return;
    if (!chat.length) {
      box.innerHTML = `<div class="askEmpty"><h3>${esc(t('askHello'))}</h3><p class="muted">${esc(t('askHint'))}</p>
        <div class="chips">${t('askSamples').map((q) => `<span class="chip" data-q="${esc(q)}">${esc(q)}</span>`).join('')}</div></div>`;
    } else {
      box.innerHTML = chat.map((m) => `<div dir="auto" class="msg ${m.role}${m.err ? ' err' : ''}">${m.role === 'user' ? esc(m.text) : fmt(m.text)}</div>`).join('') +
        (busy ? `<div class="msg assistant busy">${esc(t('aiThinking'))}</div>` : '');
    }
    box.scrollTop = box.scrollHeight;
    $('#askSend').disabled = busy;
  }

  function renderSettings() {
    const el = $('#askSet'); if (!el) return;
    const p = cfg.provider, P = PROVIDERS[p];
    el.innerHTML = `<h3 style="margin-top:0">${esc(t('aiSettings'))}</h3>
      <label class="fld"><span>${esc(t('aiProvider'))}</span><select id="aiProv">${Object.keys(PROVIDERS).map((k) => `<option value="${k}" ${k === p ? 'selected' : ''}>${PROVIDERS[k].name}</option>`).join('')}</select></label>
      <label class="fld"><span>${esc(t('aiKey'))}</span><input id="aiKey" type="password" autocomplete="off" spellcheck="false" placeholder="${esc(t('aiKeyPh'))}" value="${esc(cfg.keys[p] || '')}"></label>
      <label class="fld"><span>${esc(t('aiModel'))}</span><select id="aiModel"><option>${esc(model())}</option></select></label>
      <div class="row"><button class="accent" id="aiSave">${esc(t('aiSaveTest'))}</button>${cfg.keys[p] ? `<button id="aiDel">${esc(t('aiRemove'))}</button>` : ''}</div>
      <div id="aiStatus" class="small"></div>
      <p class="small muted">${esc(t('aiGetKey'))} <a href="${P.keyUrl}">${esc(P.name)}</a></p>
      <p class="small muted">${esc(t('aiPrivacy'))}</p>`;
    $('#aiProv').onchange = (e) => { cfg.provider = e.target.value; save(CFG_KEY, cfg); renderSettings(); updateKeyNote(); };
    $('#aiModel').onchange = (e) => { cfg.models[p] = e.target.value; save(CFG_KEY, cfg); };
    $('#aiSave').onclick = async () => {
      cfg.keys[p] = $('#aiKey').value.trim(); save(CFG_KEY, cfg);
      const s = $('#aiStatus'); s.className = 'small'; s.textContent = t('aiChecking');
      try {
        const ids = await listModels();
        const cur = model();
        const best = ids.includes(cur) ? cur : (ids.includes(P.def) ? P.def : pickDefault(p, ids) || cur);
        cfg.models[p] = best; save(CFG_KEY, cfg);
        const opts = ids.length ? ids : [best];
        $('#aiModel').innerHTML = opts.map((id) => `<option ${id === best ? 'selected' : ''}>${esc(id)}</option>`).join('');
        s.className = 'small ok'; s.textContent = '✓ ' + t('aiKeyOk');
      } catch (e) { s.className = 'small bad'; s.textContent = netMsg(e); }
      updateKeyNote();
    };
    const del = $('#aiDel'); if (del) del.onclick = () => { delete cfg.keys[p]; save(CFG_KEY, cfg); renderSettings(); updateKeyNote(); };
  }
  function pickDefault(p, ids) {
    if (p === 'anthropic') return ids.find((x) => /^claude-opus/.test(x)) || ids[0];
    if (p === 'openai') return ids.find((x) => /^gpt-\d.*-mini$/.test(x)) || ids.find((x) => /^gpt-/.test(x));
    return ids.find((x) => /flash/.test(x) && !/lite/.test(x)) || ids[0];
  }
  function netMsg(e) { return e && e.name === 'TypeError' ? t('aiNet') : (e && e.message) || String(e); }
  function updateKeyNote() { const n = $('#askNoKey'); if (n) n.style.display = hasKey() ? 'none' : ''; }

  async function ask(q) {
    q = (q || '').trim(); if (!q || busy) return;
    if (!hasKey()) { updateKeyNote(); $('#aiKey') && $('#aiKey').focus(); return; }
    chat.push({ role: 'user', text: q }); busy = true; renderChat();
    $('#askIn').value = '';
    try {
      const hist = chat.filter((m) => !m.err).slice(-12);
      const a = await complete(systemPrompt(), hist);
      chat.push({ role: 'assistant', text: a || '…' });
    } catch (e) { chat.push({ role: 'assistant', text: '⚠ ' + netMsg(e), err: true }); }
    busy = false; chat = chat.slice(-40); save(CHAT_KEY, chat); renderChat();
  }

  function initAsk() {
    $('#askSend').onclick = () => ask($('#askIn').value);
    $('#askIn').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask($('#askIn').value); } });
    $('#askClear').onclick = () => { chat = []; save(CHAT_KEY, chat); renderChat(); };
    $('#askChat').addEventListener('click', (e) => { const c = e.target.closest('[data-q]'); if (c) ask(c.dataset.q); });
    $('#askNoKey').addEventListener('click', () => $('#aiKey') && $('#aiKey').focus());
  }

  // ---------------- NASA picture of the day ----------------
  const apodCache = load(APOD_KEY, {});
  let apodDay = null, apodData = null, apodTr = null;
  const today = () => { const d = new Date(Date.now() - 5 * 3600000); return d.toISOString().slice(0, 10); }; // NASA posts on US Eastern time
  async function loadApod(day) {
    day = day || apodDay || today(); apodDay = day; apodTr = null; apodData = null;
    const box = $('#apodBox'); $('#apodDate').value = day; $('#apodDate').max = today();
    if (apodCache[day]) { apodData = apodCache[day]; return renderApod(); }
    box.innerHTML = `<p class="muted">${esc(t('apodLoading'))}</p>`;
    try {
      const k = (cfg.nasa || '').trim() || 'DEMO_KEY';
      const r = await fetch('https://api.nasa.gov/planetary/apod?thumbs=true&date=' + day + '&api_key=' + encodeURIComponent(k));
      if (day !== apodDay) return; // the user already moved to another day
      if (r.status >= 500) throw new Error('down');
      if (!r.ok) throw await readError(r);
      const j = await r.json();
      if (day !== apodDay) return;
      // NASA sometimes answers with a generic placeholder (the NASA logo) instead of the real picture
      if (!j || !j.url || /nasa-logo/i.test(j.url) || j.title === 'NASA Science') throw new Error('down');
      apodData = j;
      apodCache[day] = apodData;
      const keys = Object.keys(apodCache).sort(); while (keys.length > 30) delete apodCache[keys.shift()];
      save(APOD_KEY, apodCache);
      renderApod();
    } catch (e) {
      if (day !== apodDay) return;
      const down = e && e.message === 'down';
      box.innerHTML = `<p class="bad">${esc(e && e.name === 'TypeError' ? t('apodOffline') : down ? t('apodDown') : t('apodErr') + ' ' + netMsg(e))}</p>` +
        `<p><a href="https://apod.nasa.gov/apod/astropix.html">apod.nasa.gov</a></p>`;
    }
  }
  function renderApod() {
    const d = apodData, box = $('#apodBox'); if (!d || !box) return;
    const img = d.media_type === 'video' ? (d.thumbnail_url || '') : (d.url || '');
    const big = d.hdurl || d.url;
    const dir = apodTr ? 'rtl' : 'ltr';
    let h = `<h2 dir="${dir}">${esc(apodTr ? apodTr.title : d.title)}</h2><div class="muted small">${esc(d.date)}${d.copyright ? ' · © ' + esc(d.copyright.trim()) : ''} · NASA APOD</div>`;
    if (img) h += `<a href="${esc(d.media_type === 'video' ? d.url : big)}" class="apodImg"><img src="${esc(img)}" alt=""></a>`;
    if (d.media_type === 'video') h += `<p><a href="${esc(d.url)}">▶ ${esc(t('apodVideo'))}</a></p>`;
    h += `<div class="apodTxt" dir="${dir}">${fmt(apodTr ? apodTr.text : d.explanation || '')}</div>`;
    if (ar() && !apodTr) h += `<div class="row"><button id="apodTr" class="accent">${esc(t('apodTranslate'))}</button><span id="apodTrSt" class="small muted"></span></div>`;
    if (ar() && apodTr) h += `<p class="small muted">${esc(t('apodTrNote'))}</p>`;
    box.innerHTML = h;
    const b = $('#apodTr'); if (b) b.onclick = translateApod;
  }
  async function translateApod() {
    const s = $('#apodTrSt');
    if (!hasKey()) { s.textContent = t('apodNeedKey'); return; }
    s.textContent = t('aiThinking'); $('#apodTr').disabled = true;
    try {
      const out = await complete('Translate the astronomy text the user sends into clear Modern Standard Arabic (فصحى). Keep names of spacecraft, telescopes, missions and organisations in English. Reply with the title on the first line, then the translated text. No notes.',
        [{ role: 'user', text: apodData.title + '\n\n' + apodData.explanation }]);
      const i = out.indexOf('\n');
      apodTr = { title: i > 0 ? out.slice(0, i).replace(/^#+\s*/, '').trim() : apodData.title, text: i > 0 ? out.slice(i + 1).trim() : out };
      renderApod();
    } catch (e) { s.textContent = '⚠ ' + netMsg(e); $('#apodTr').disabled = false; }
  }
  function initApod() {
    $('#apodDate').onchange = (e) => e.target.value && loadApod(e.target.value);
    $('#apodPrev').onclick = () => { const d = new Date(apodDay + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - 1); loadApod(d.toISOString().slice(0, 10)); };
    $('#apodNext').onclick = () => { const d = new Date(apodDay + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + 1); const s = d.toISOString().slice(0, 10); if (s <= today()) loadApod(s); };
    $('#apodToday').onclick = () => loadApod(today());
    $('#apodRandom').onclick = () => { const a = Date.UTC(1995, 5, 16), b = Date.parse(today() + 'T00:00:00Z'); loadApod(new Date(a + Math.random() * (b - a)).toISOString().slice(0, 10)); };
    $('#nasaKey').value = cfg.nasa || '';
    $('#nasaSave').onclick = () => { cfg.nasa = $('#nasaKey').value.trim(); save(CFG_KEY, cfg); $('#nasaSt').textContent = '✓'; };
  }

  function init() {
    if (inited) return; inited = true;
    initAsk(); initApod();
    I.on(() => { renderSettings(); renderChat(); updateKeyNote(); if (apodData) { apodTr = null; renderApod(); } });
  }
  function open(view) {
    init();
    if (view === 'ask') { renderSettings(); renderChat(); updateKeyNote(); setTimeout(() => $('#askIn').focus(), 50); }
    if (view === 'apod') loadApod();
  }

  return { open, load: (d) => loadApod(d), ask: (q) => { open('ask'); return ask(q); }, prefill: (q) => { open('ask'); $('#askIn').value = q; $('#askIn').focus(); },
    get hasKey() { return hasKey(); },
    _demo: (c) => { demo = true; cfg = JSON.parse(JSON.stringify(cfg)); cfg.keys = {}; chat = c; open('ask'); renderSettings(); renderChat(); updateKeyNote(); } };
})();
