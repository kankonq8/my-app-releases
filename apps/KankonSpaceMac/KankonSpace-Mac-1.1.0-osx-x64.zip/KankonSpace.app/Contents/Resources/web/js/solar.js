/* Kankon Space - the 3D Solar System (three.js r147). */
window.KS_SOLAR = (function () {
  const A = window.KS_ASTRO, D = window.KS_DATA, D2R = Math.PI / 180;
  const AU_KM = 149597870.7;
  let renderer, scene, camera, controls, root, canvas, labelsEl;
  const objs = {};             // id -> {b, group, spin, mesh, marker, label, orbitLine, kind, parent}
  let belt, kuiper, beltEls, kuiperEls, helioRing;
  let scaleMode = 'visual', showOrbits = true, showLabels = true, showMoons = true, showBelts = true;
  let focusId = null, fly = null, lastFocusPos = null;
  let jdOrbits = 0;
  const texLoader = new THREE.TextureLoader();
  let onSelect = () => {};

  // ---------- scale ----------
  function distS(rAu) { return scaleMode === 'true' ? rAu * 60 : 60 * Math.pow(rAu, 0.42); }
  function radS(km, kind) {
    if (scaleMode === 'true') return km / AU_KM * 60;
    if (kind === 'star') return 11;
    if (kind === 'comet') return 0.35;
    if (kind === 'moon') return Math.max(0.12, 1.25 * Math.pow(km / 6371, 0.5));
    return Math.max(0.42, 1.6 * Math.pow(km / 6371, 0.5));
  }
  // heliocentric ecliptic au -> scene vector
  function toScene(v, out) {
    const r = Math.hypot(v[0], v[1], v[2]);
    const k = r > 0 ? distS(r) / r : 0;
    return (out || new THREE.Vector3()).set(v[0] * k, v[2] * k, -v[1] * k);
  }

  function glowTexture(inner, outer) {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const g = c.getContext('2d'), gr = g.createRadialGradient(128, 128, 0, 128, 128, 128);
    gr.addColorStop(0, inner); gr.addColorStop(0.25, inner.replace(/[\d.]+\)$/, '0.55)')); gr.addColorStop(1, outer);
    g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
    return new THREE.CanvasTexture(c);
  }
  function dotTexture() {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d'); g.beginPath(); g.arc(32, 32, 26, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill();
    return new THREE.CanvasTexture(c);
  }
  const DOT = () => dotTexture();
  let dotTex;

  function tex(name) { const t = texLoader.load('tex/' + name); t.anisotropy = 4; return t; }

  // ---------- Earth day/night shader ----------
  function earthMaterial() {
    return new THREE.ShaderMaterial({
      uniforms: { dayT: { value: tex('earth_daymap.jpg') }, nightT: { value: tex('earth_nightmap.jpg') }, sunDir: { value: new THREE.Vector3(1, 0, 0) } },
      vertexShader: `#include <common>
#include <logdepthbuf_pars_vertex>
varying vec2 vUv; varying vec3 vN;
void main(){ vUv = uv; vN = normalize(mat3(modelMatrix) * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
#include <logdepthbuf_vertex>
}`,
      fragmentShader: `uniform sampler2D dayT; uniform sampler2D nightT; uniform vec3 sunDir; varying vec2 vUv; varying vec3 vN;
#include <common>
#include <logdepthbuf_pars_fragment>
void main(){
#include <logdepthbuf_fragment>
 float d = dot(normalize(vN), sunDir); float k = smoothstep(-0.12, 0.18, d);
 vec3 day = texture2D(dayT, vUv).rgb; vec3 night = texture2D(nightT, vUv).rgb;
 vec3 c = day * (0.05 + 1.15 * max(d, 0.0)) * k + night * (1.0 - k) * 1.3 + day * 0.03;
 gl_FragColor = vec4(c, 1.0);
}`
    });
  }

  function makeLabel(id, text, cls) {
    const el = document.createElement('div');
    el.className = 'lbl ' + cls; el.textContent = text; el.dataset.id = id;
    el.addEventListener('click', (e) => { e.stopPropagation(); select(id); });
    labelsEl.appendChild(el);
    return el;
  }

  function addBody(b, parentGroup) {
    const kind = b.kind || 'moon';
    const g = new THREE.Group();
    const tilt = new THREE.Group();
    const spin = new THREE.Group();
    g.add(tilt); tilt.add(spin);
    if (b.id === 'earth') tilt.rotation.x = -A.obliq(2451545) * D2R;
    else tilt.rotation.x = -(b.tilt || 0) * D2R;
    let mat;
    if (b.id === 'sun') mat = new THREE.MeshBasicMaterial({ map: tex(b.tex), color: 0xffffff });
    else if (b.id === 'earth') mat = earthMaterial();
    else if (b.tex) mat = new THREE.MeshPhongMaterial({ map: tex(b.tex), shininess: 4 });
    else mat = new THREE.MeshPhongMaterial({ color: new THREE.Color(b.color), shininess: 3 });
    const seg = (kind === 'planet' || kind === 'star' || b.id === 'moon') ? 64 : 24;
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, seg, seg / 2), mat);
    mesh.userData.id = b.id;
    if (b.id === 'haumea') mesh.scale.set(1.0, 0.52, 0.75);
    spin.add(mesh);
    if (b.id === 'earth') {
      const cl = new THREE.Mesh(new THREE.SphereGeometry(1.012, 64, 32), new THREE.MeshLambertMaterial({ color: 0xffffff, alphaMap: tex('earth_clouds.jpg'), transparent: true, depthWrite: false }));
      spin.add(cl); objs.earthClouds = cl;
      const atm = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture('rgba(120,170,255,0.5)', 'rgba(60,120,255,0)'), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
      atm.scale.set(2.9, 2.9, 1); tilt.add(atm);
    }
    if (b.id === 'saturn' || b.id === 'uranus' || b.id === 'neptune') {
      const inner = b.id === 'saturn' ? 1.24 : 1.6, outer = b.id === 'saturn' ? 2.27 : (b.id === 'uranus' ? 2.0 : 2.5);
      const rg = new THREE.RingGeometry(inner, outer, 128, 1);
      const pos = rg.attributes.position, uv = rg.attributes.uv, v = new THREE.Vector3();
      for (let i = 0; i < pos.count; i++) { v.fromBufferAttribute(pos, i); uv.setXY(i, (v.length() - inner) / (outer - inner), 0.5); }
      const rm = b.id === 'saturn'
        ? new THREE.MeshBasicMaterial({ map: tex('saturn_ring_alpha.png'), side: THREE.DoubleSide, transparent: true, depthWrite: false, opacity: 0.95 })
        : new THREE.MeshBasicMaterial({ color: 0x8899aa, side: THREE.DoubleSide, transparent: true, opacity: 0.12, depthWrite: false });
      const ring = new THREE.Mesh(rg, rm); ring.rotation.x = -Math.PI / 2; tilt.add(ring);
    }
    if (b.id === 'sun') {
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture('rgba(255,220,140,0.9)', 'rgba(255,140,40,0)'), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
      glow.scale.set(5.2, 5.2, 1); g.add(glow);
      objs.sunGlow = glow;
    }
    const marker = new THREE.Sprite(new THREE.SpriteMaterial({ map: dotTex, color: new THREE.Color(b.color), sizeAttenuation: false, depthWrite: false, transparent: true }));
    marker.scale.set(0.009, 0.009, 1);
    marker.renderOrder = 2;
    g.add(marker);
    (parentGroup || root).add(g);
    const cls = kind === 'moon' ? 'moon' : kind;
    const o = { b, kind, group: g, tilt, spin, mesh, marker, label: makeLabel(b.id, '', cls), parent: b.parent || null };
    objs[b.id] = o;
    return o;
  }

  function addOrbit(o) {
    const geo = new THREE.BufferGeometry();
    const n = o.kind === 'comet' ? 400 : 256;
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array((n + 1) * 3), 3));
    const col = new THREE.Color(o.b.color);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: o.kind === 'planet' ? 0.45 : 0.28, depthWrite: false }));
    line.userData.n = n;
    root.add(line);
    o.orbitLine = line;
  }
  function updateOrbit(o, jd) {
    const pts = A.orbitPoints(o.b, jd, o.orbitLine.userData.n), arr = o.orbitLine.geometry.attributes.position.array, v = new THREE.Vector3();
    for (let i = 0; i < pts.length; i++) { toScene(pts[i], v); arr[i * 3] = v.x; arr[i * 3 + 1] = v.y; arr[i * 3 + 2] = v.z; }
    o.orbitLine.geometry.attributes.position.needsUpdate = true;
    o.orbitLine.geometry.computeBoundingSphere();
  }

  function moonOrbit(o) {
    const n = 128, geo = new THREE.BufferGeometry(), arr = new Float32Array((n + 1) * 3);
    for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; arr[i * 3] = Math.cos(a); arr[i * 3 + 2] = -Math.sin(a); }
    geo.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0x8899bb, transparent: true, opacity: 0.25, depthWrite: false }));
    return line;
  }

  // ---------- belts ----------
  function makeBelt(count, aMin, aMax, eMax, iMax, color, size) {
    const els = new Float32Array(count * 6); // a, e, I, node, w, M0
    for (let i = 0; i < count; i++) {
      let a = aMin + Math.random() * (aMax - aMin);
      if (aMin < 4 && Math.random() < 0.18) a = 2.5 + (Math.random() - 0.5) * 0.08 + (Math.random() < 0.5 ? 0.33 : 0); // gaps feel
      els.set([a, Math.random() * eMax, (Math.random() + Math.random() - 1) * iMax, Math.random() * 360, Math.random() * 360, Math.random() * Math.PI * 2], i * 6);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3));
    const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color, size, sizeAttenuation: false, transparent: true, opacity: 0.75, depthWrite: false }));
    root.add(pts);
    return { pts, els, count };
  }
  function updateBelt(bt, jd) {
    const arr = bt.pts.geometry.attributes.position.array, v = new THREE.Vector3();
    const dt = jd - 2451545;
    for (let i = 0; i < bt.count; i++) {
      const k = i * 6, a = bt.els[k];
      const M = bt.els[k + 5] + 2 * Math.PI * dt / (365.25 * Math.pow(a, 1.5));
      const p = A.kepXYZ(a, bt.els[k + 1], bt.els[k + 2], bt.els[k + 3], bt.els[k + 4], M % (2 * Math.PI));
      toScene(p, v); arr[i * 3] = v.x; arr[i * 3 + 1] = v.y; arr[i * 3 + 2] = v.z;
    }
    bt.pts.geometry.attributes.position.needsUpdate = true;
    bt.pts.geometry.computeBoundingSphere();
  }

  // ---------- comet tails ----------
  function makeTail(o) {
    const n = 260, geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    const seeds = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) seeds.set([Math.pow(Math.random(), 0.7), (Math.random() - 0.5), (Math.random() - 0.5)], i * 3);
    const m = new THREE.PointsMaterial({ color: 0xbfe3ff, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false });
    const p = new THREE.Points(geo, m); root.add(p);
    o.tail = { p, seeds, n };
  }
  function updateTail(o, helioPos, scenePos) {
    const r = Math.hypot(helioPos[0], helioPos[1], helioPos[2]);
    const t = o.tail; t.p.visible = r < 5 && o.group.visible;
    if (!t.p.visible) return;
    const dir = scenePos.clone().normalize();
    const L = scaleMode === 'true' ? Math.min(1.5, 0.6 / (r * r)) * 60 : Math.min(30, 9 / Math.max(0.3, r));
    const side = new THREE.Vector3(0, 1, 0).cross(dir).normalize(), up = dir.clone().cross(side).normalize();
    const arr = t.p.geometry.attributes.position.array;
    for (let i = 0; i < t.n; i++) {
      const s = t.seeds[i * 3], w = s * L * 0.16;
      arr[i * 3] = scenePos.x + dir.x * s * L + side.x * t.seeds[i * 3 + 1] * w + up.x * t.seeds[i * 3 + 2] * w;
      arr[i * 3 + 1] = scenePos.y + dir.y * s * L + side.y * t.seeds[i * 3 + 1] * w + up.y * t.seeds[i * 3 + 2] * w;
      arr[i * 3 + 2] = scenePos.z + dir.z * s * L + side.z * t.seeds[i * 3 + 1] * w + up.z * t.seeds[i * 3 + 2] * w;
    }
    t.p.geometry.attributes.position.needsUpdate = true;
    t.p.geometry.computeBoundingSphere();
  }

  // ---------- sky ----------
  function makeSky() {
    const geo = new THREE.SphereGeometry(1, 64, 32);
    const m = new THREE.MeshBasicMaterial({ map: tex('stars_milky_way.jpg'), side: THREE.BackSide, depthWrite: false, depthTest: false });
    const sky = new THREE.Mesh(geo, m);
    sky.renderOrder = -10;
    // galactic -> equatorial (J2000) -> ecliptic -> scene
    const Tg = [[-0.0548755604, 0.4941094279, -0.8676661490], [-0.8734370902, -0.4448296300, -0.1980763734], [-0.4838350155, 0.7469822445, 0.4559837762]];
    const e = 23.4392911 * D2R;
    const gal2scene = (g) => {
      const q = [Tg[0][0] * g[0] + Tg[1][0] * g[1] + Tg[2][0] * g[2], Tg[0][1] * g[0] + Tg[1][1] * g[1] + Tg[2][1] * g[2], Tg[0][2] * g[0] + Tg[1][2] * g[1] + Tg[2][2] * g[2]];
      const ec = [q[0], q[1] * Math.cos(e) + q[2] * Math.sin(e), -q[1] * Math.sin(e) + q[2] * Math.cos(e)];
      return new THREE.Vector3(ec[0], ec[2], -ec[1]);
    };
    const m4 = new THREE.Matrix4().makeBasis(gal2scene([1, 0, 0]), gal2scene([0, 0, 1]), gal2scene([0, 1, 0]));
    sky.quaternion.setFromRotationMatrix(m4);
    sky.onBeforeRender = () => { sky.position.copy(camera.position); const s = camera.far * 0.5; sky.scale.set(s, s, s); };
    scene.add(sky);
  }

  function init(cv, lbls) {
    canvas = cv; labelsEl = lbls;
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, logarithmicDepthBuffer: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(50, 1, 0.00001, 2e6);
    camera.position.set(0, 150, 260);
    controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true; controls.dampingFactor = 0.08; controls.rotateSpeed = 0.6; controls.zoomSpeed = 1.1;
    controls.maxDistance = 2e5;
    controls.addEventListener('start', () => { fly = null; });
    root = new THREE.Group(); scene.add(root);
    dotTex = DOT();
    makeSky();
    scene.add(new THREE.AmbientLight(0xffffff, 0.13));
    const sunLight = new THREE.PointLight(0xffffff, 1.35, 0, 0); scene.add(sunLight);

    addBody(D.sun);
    for (const p of D.planets) { addOrbit(addBody(p)); }
    for (const p of D.dwarfs) { addOrbit(addBody(p)); }
    for (const c of D.comets) { const o = addBody(c); addOrbit(o); makeTail(o); }
    for (const c of D.craft) { const o = addBody({ ...c, R: 0.001 }); o.mesh.visible = false; o.marker.scale.set(0.007, 0.007, 1); }
    for (const m of D.moons) {
      const p = objs[m.parent];
      const o = addBody({ ...m, kind: 'moon' }, p.group);
      o.orbitLine = moonOrbit(o); (m.id === 'moon' ? p.group : p.tilt).add(o.orbitLine);
      // moons orbit in the parent's equator plane (Earth's Moon uses its real position)
      if (m.id !== 'moon') { p.tilt.remove(o.group); p.tilt.add(o.group); }
      o.marker.scale.set(0.006, 0.006, 1);
    }
    belt = makeBelt(3500, 2.15, 3.3, 0.18, 14, 0xa89c88, 1.4);
    kuiper = makeBelt(2600, 39, 48, 0.12, 12, 0x7f8fa6, 1.2);
    // heliopause (about 120 au)
    const hg = new THREE.RingGeometry(0.995, 1.0, 256);
    helioRing = new THREE.Mesh(hg, new THREE.MeshBasicMaterial({ color: 0x5fa8ff, transparent: true, opacity: 0.25, side: THREE.DoubleSide, depthWrite: false }));
    helioRing.rotation.x = -Math.PI / 2; root.add(helioRing);
    helioRing.userData.label = makeLabel('heliopause', '', 'region');
    helioRing.userData.label.style.pointerEvents = 'none';
    canvas.addEventListener('click', onClick);
    applyScale();
  }

  function applyScale() {
    for (const id in objs) {
      const o = objs[id]; if (!o || !o.b) continue;
      const r = radS(o.b.R, o.kind);
      o.mesh.scale.multiplyScalar(0); // reset then set
      const s = o.b.id === 'haumea' ? [1, 0.52, 0.75] : [1, 1, 1];
      o.mesh.scale.set(r * s[0], r * s[1], r * s[2]);
      if (o.b.id === 'earth') objs.earthClouds.scale.set(r, r, r);
      o.tilt.children.forEach((c) => { if (c.geometry && c.geometry.type === 'RingGeometry') c.scale.set(r, r, r); if (c.isSprite) c.scale.set(r * 2.9, r * 2.9, 1); });
      if (id === 'sun') objs.sunGlow.scale.set(r * 5.2, r * 5.2, 1);
    }
    // moon orbit radius
    for (const m of D.moons) {
      const o = objs[m.id], p = objs[m.parent], rp = radS(p.b.R, p.kind);
      o.orbitR = scaleMode === 'true' ? m.a / AU_KM * 60 : rp * (1.25 + 0.95 * Math.log(m.a / p.b.R));
      o.orbitLine.scale.set(o.orbitR, o.orbitR, o.orbitR);
    }
    const hr = distS(121);
    helioRing.scale.set(hr, hr, hr);
    jdOrbits = 0;
    controls.minDistance = scaleMode === 'true' ? 0.0001 : 1;
  }

  let curJd = 0;
  function update(jd) {
    curJd = jd;
    const v = new THREE.Vector3();
    const all = [D.sun, ...D.planets, ...D.dwarfs, ...D.comets, ...D.craft];
    if (Math.abs(jd - jdOrbits) > 30) {
      jdOrbits = jd;
      for (const b of all) if (objs[b.id].orbitLine) updateOrbit(objs[b.id], jd);
    }
    for (const b of all) {
      const o = objs[b.id];
      if (b.kind === 'star') continue;
      const h = A.helio(b, jd);
      toScene(h, v); o.group.position.copy(v); o.helio = h;
      if (o.tail) updateTail(o, h, v);
    }
    // spin
    const hrs = (jd - 2451545) * 24;
    for (const b of [D.sun, ...D.planets, ...D.dwarfs]) {
      const o = objs[b.id];
      if (b.id === 'earth') o.spin.rotation.y = A.gmst(jd) * D2R;
      else if (b.rotH) o.spin.rotation.y = (hrs / b.rotH % 1) * Math.PI * 2;
    }
    if (objs.earthClouds) objs.earthClouds.rotation.y = hrs / 400;
    // moons
    for (const m of D.moons) {
      const o = objs[m.id];
      if (m.id === 'moon') {
        const g = A.moonGeo(jd), lo = g.lon * D2R, la = g.lat * D2R;
        o.group.position.set(Math.cos(la) * Math.cos(lo), Math.sin(la), -Math.cos(la) * Math.sin(lo)).multiplyScalar(o.orbitR);
        o.spin.rotation.y = Math.atan2(-o.group.position.z, o.group.position.x) + Math.PI;  // same face to Earth
      } else {
        const a = 2 * Math.PI * ((jd - 2451545) / m.P) + (m.id.charCodeAt(0) * 37 + m.id.length * 11) % 360 * D2R;
        o.group.position.set(Math.cos(a) * o.orbitR, 0, -Math.sin(a) * o.orbitR);
        o.spin.rotation.y = a + Math.PI;
      }
    }
    // Earth shader sun direction
    const e = objs.earth; e.mesh.material.uniforms.sunDir.value.copy(e.group.position).multiplyScalar(-1).normalize();
    if (belt.pts.visible) updateBelt(belt, jd);
    if (kuiper.pts.visible && (Math.random() < 0.2)) updateBelt(kuiper, jd);
  }

  // ---------- selection & camera ----------
  function worldPos(id) { const v = new THREE.Vector3(); objs[id].group.getWorldPosition(v); return v; }
  function viewDist(id) {
    const o = objs[id];
    if (id === 'heliopause') return 600;
    if (o.kind === 'craft') return scaleMode === 'true' ? 2000 : 120;
    const r = o.mesh.scale.x;
    if (o.kind === 'star') return r * 6;
    if (scaleMode !== 'true' && (id === 'saturn' || id === 'jupiter')) return r * 9;
    return Math.max(r * 6, scaleMode === 'true' ? 0.00005 : 3);
  }
  function select(id, noFly) {
    if (!objs[id]) return;
    focusId = id;
    const target = worldPos(id);
    if (!noFly) {
      const dir = camera.position.clone().sub(controls.target).normalize();
      if (dir.lengthSq() < 0.1) dir.set(0, 0.4, 1).normalize();
      dir.y = Math.max(dir.y, 0.25); dir.normalize();
      fly = { t0: performance.now(), dur: 1400, fromPos: camera.position.clone(), fromTgt: controls.target.clone(), dist: viewDist(id), dir };
    }
    lastFocusPos = target.clone();
    onSelect(id);
  }
  function overview() {
    focusId = null; lastFocusPos = null;
    const d = scaleMode === 'true' ? 4500 : 420;
    fly = { t0: performance.now(), dur: 1400, fromPos: camera.position.clone(), fromTgt: controls.target.clone(), toPos: new THREE.Vector3(0, d * 0.55, d), toTgt: new THREE.Vector3() };
    onSelect(null);
  }
  function onClick(ev) {
    const r = canvas.getBoundingClientRect();
    const m = new THREE.Vector2(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    const rc = new THREE.Raycaster(); rc.setFromCamera(m, camera);
    const meshes = []; for (const id in objs) if (objs[id] && objs[id].mesh && objs[id].group.visible) meshes.push(objs[id].mesh);
    const hit = rc.intersectObjects(meshes, false)[0];
    if (hit) select(hit.object.userData.id);
  }

  function frame() {
    // follow the focused body
    if (focusId) {
      const p = worldPos(focusId);
      if (lastFocusPos && !fly) { const d = p.clone().sub(lastFocusPos); camera.position.add(d); controls.target.add(d); }
      lastFocusPos = p;
    }
    if (fly) {
      const k = Math.min(1, (performance.now() - fly.t0) / fly.dur), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      let toTgt = fly.toTgt, toPos = fly.toPos;
      if (focusId && !toPos) { toTgt = worldPos(focusId); toPos = toTgt.clone().add(fly.dir.clone().multiplyScalar(fly.dist)); }
      // fly through a log-distance path so long trips look smooth
      controls.target.lerpVectors(fly.fromTgt, toTgt, e);
      const fromOff = fly.fromPos.clone().sub(fly.fromTgt), toOff = toPos.clone().sub(toTgt);
      const dl = Math.exp(Math.log(fromOff.length() + 1e-9) * (1 - e) + Math.log(toOff.length() + 1e-9) * e);
      const dir = fromOff.normalize().lerp(toOff.normalize(), e).normalize();
      camera.position.copy(controls.target).add(dir.multiplyScalar(dl));
      if (k >= 1) fly = null;
    }
    controls.update();
    renderer.render(scene, camera);
    drawLabels();
  }

  function drawLabels() {
    const w = canvas.clientWidth, h = canvas.clientHeight, v = new THREE.Vector3();
    const camDist = camera.position.distanceTo(controls.target);
    const lang = window.KS_I18N ? KS_I18N.lang : 'en';
    for (const id in objs) {
      const o = objs[id]; if (!o || !o.label) continue;
      const el = o.label;
      let show = showLabels && o.group.visible;
      if (o.kind === 'moon') show = show && showMoons && (focusId === o.parent || focusId === id || (o.parent === 'earth' && camDist < 40 && scaleMode !== 'true'));
      if (show) {
        o.group.getWorldPosition(v);
        const dCam = v.distanceTo(camera.position);
        v.project(camera);
        if (v.z > 1 || v.z < -1) show = false;
        else {
          el.style.transform = `translate(${((v.x + 1) / 2 * w).toFixed(1)}px, ${((1 - v.y) / 2 * h).toFixed(1)}px)`;
          if (o.kind === 'moon' && scaleMode !== 'true' && o.parent !== focusId && id !== focusId) show = false;
          el.style.opacity = (o.kind === 'dwarf' || o.kind === 'comet') && camDist > 900 && id !== focusId ? '0.55' : '1';
          if (o.kind === 'moon' && o.parent === 'earth' && dCam > 60 && focusId !== 'earth' && focusId !== 'moon') show = false;
        }
      }
      const txt = o.b.name[lang];
      if (el.textContent !== txt) el.textContent = txt;
      el.classList.toggle('sel', id === focusId);
      el.style.display = show ? '' : 'none';
    }
    // heliopause label
    const hl = helioRing.userData.label;
    if (showLabels && helioRing.visible && camDist > 250) {
      v.set(0, 0, -helioRing.scale.x); v.project(camera);
      if (v.z < 1) { hl.style.display = ''; hl.style.transform = `translate(${((v.x + 1) / 2 * w).toFixed(1)}px, ${((1 - v.y) / 2 * h).toFixed(1)}px)`; hl.textContent = KS_I18N.t('heliopause'); }
      else hl.style.display = 'none';
    } else hl.style.display = 'none';
  }

  function resize(w, h) { renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }

  function setOption(k, val) {
    if (k === 'scale') { scaleMode = val; applyScale(); update(curJd); if (focusId) select(focusId); else overview(); }
    if (k === 'orbits') { showOrbits = val; for (const id in objs) if (objs[id] && objs[id].orbitLine) objs[id].orbitLine.visible = val; helioRing.visible = val; }
    if (k === 'labels') showLabels = val;
    if (k === 'moons') { showMoons = val; for (const m of D.moons) { objs[m.id].group.visible = val; objs[m.id].orbitLine.visible = val && showOrbits; } }
    if (k === 'belts') { showBelts = val; belt.pts.visible = val; kuiper.pts.visible = val; if (val) { updateBelt(belt, curJd); updateBelt(kuiper, curJd); } }
    if (k === 'comets') { for (const c of D.comets) { objs[c.id].group.visible = val; objs[c.id].orbitLine.visible = val && showOrbits; } }
  }

  function shotState(cam, tgt) { camera.position.set(...cam); controls.target.set(...tgt); fly = null; focusId = null; }

  return {
    init, update, frame, resize, select, overview, setOption, shotState,
    set onSelect(f) { onSelect = f; }, get focus() { return focusId; }, get scaleMode() { return scaleMode; },
    objs, get camera() { return camera; }, get renderer() { return renderer; }
  };
})();
