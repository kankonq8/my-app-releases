/* Kankon Space - astronomy. Positions from JPL "Approximate Positions of the Planets" (Keplerian elements, J2000 ecliptic),
   the Moon from the Astronomical Almanac low-precision series. Good to a fraction of a degree between 1800 and 2050. */
window.KS_ASTRO = (function () {
  const D2R = Math.PI / 180, R2D = 180 / Math.PI, AU = 149597870.7;
  const jdOf = (t) => t / 86400000 + 2440587.5;            // t = ms since 1970
  const msOf = (jd) => (jd - 2440587.5) * 86400000;
  const norm = (d) => ((d % 360) + 360) % 360;

  function solveKepler(M, e) {          // M in radians
    let E = e < 0.8 ? M : Math.PI;
    for (let i = 0; i < 30; i++) {
      const dE = (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
      E -= dE; if (Math.abs(dE) < 1e-10) break;
    }
    return E;
  }

  // a, e, I, node, argPeri (deg), M (rad) -> heliocentric ecliptic [x,y,z] au
  function kepXYZ(a, e, I, node, w, M) {
    let x, y;
    if (e < 1) {
      const E = solveKepler(M, e);
      x = a * (Math.cos(E) - e); y = a * Math.sqrt(1 - e * e) * Math.sin(E);
    } else { x = a; y = 0; }
    const cw = Math.cos(w * D2R), sw = Math.sin(w * D2R), cO = Math.cos(node * D2R), sO = Math.sin(node * D2R), cI = Math.cos(I * D2R), sI = Math.sin(I * D2R);
    return [
      (cw * cO - sw * sO * cI) * x + (-sw * cO - cw * sO * cI) * y,
      (cw * sO + sw * cO * cI) * x + (-sw * sO + cw * cO * cI) * y,
      (sw * sI) * x + (cw * sI) * y
    ];
  }

  // Orbital elements of a body at jd: {a,e,I,node,w,M(rad),P(days)}
  function elements(b, jd) {
    if (b.el) {
      const T = (jd - 2451545.0) / 36525, el = b.el;
      const a = el[0] + el[6] * T, e = el[1] + el[7] * T, I = el[2] + el[8] * T, L = el[3] + el[9] * T, wp = el[4] + el[10] * T, node = el[5] + el[11] * T;
      const M = norm(L - wp);
      return { a, e, I, node, w: wp - node, M: M * D2R, P: 365.25 * Math.pow(a, 1.5) };
    }
    const o = b.orb, P = 365.25 * Math.pow(o[0], 1.5);
    const M = 2 * Math.PI * ((jd - o[5]) / P);
    return { a: o[0], e: o[1], I: o[2], node: o[3], w: o[4], M: ((M % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI), P };
  }

  function helio(b, jd) {
    if (b.kind === 'craft') {
      const r = b.au0 + b.v * (jd - b.t0) / 365.25;
      const lo = b.lon * D2R, la = b.lat * D2R;
      return [r * Math.cos(la) * Math.cos(lo), r * Math.cos(la) * Math.sin(lo), r * Math.sin(la)];
    }
    if (b.kind === 'star') return [0, 0, 0];
    const k = elements(b, jd);
    return kepXYZ(k.a, k.e, k.I, k.node, k.w, k.M);
  }

  // Points along the orbit (for drawing): n points, heliocentric au
  function orbitPoints(b, jd, n) {
    const k = elements(b, jd), pts = [];
    for (let i = 0; i <= n; i++) {
      let M;
      if (k.e > 0.9) { // spread points by eccentric anomaly so the tight perihelion end is smooth
        const E = (i / n) * 2 * Math.PI; M = E - k.e * Math.sin(E);
      } else M = (i / n) * 2 * Math.PI;
      pts.push(kepXYZ(k.a, k.e, k.I, k.node, k.w, M));
    }
    return pts;
  }

  const len = (v) => Math.hypot(v[0], v[1], v[2]);
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];

  // Moon, geocentric ecliptic: lon, lat (deg), distance (km)
  function moonGeo(jd) {
    const T = (jd - 2451545.0) / 36525, s = (d) => Math.sin(d * D2R), c = (d) => Math.cos(d * D2R);
    const lon = 218.32 + 481267.881 * T + 6.29 * s(135.0 + 477198.87 * T) - 1.27 * s(259.3 - 413335.36 * T) + 0.66 * s(235.7 + 890534.22 * T)
      + 0.21 * s(269.9 + 954397.74 * T) - 0.19 * s(357.5 + 35999.05 * T) - 0.11 * s(186.5 + 966404.03 * T);
    const lat = 5.13 * s(93.3 + 483202.02 * T) + 0.28 * s(228.2 + 960400.89 * T) - 0.28 * s(318.3 + 6003.15 * T) - 0.17 * s(217.6 - 407332.21 * T);
    const par = 0.9508 + 0.0518 * c(135.0 + 477198.87 * T) + 0.0095 * c(259.3 - 413335.36 * T) + 0.0078 * c(235.7 + 890534.22 * T) + 0.0028 * c(269.9 + 954397.74 * T);
    return { lon: norm(lon), lat, dist: 6378.14 / Math.sin(par * D2R) };
  }

  function gmst(jd) {   // degrees
    const T = (jd - 2451545.0) / 36525;
    return norm(280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * T * T);
  }
  const obliq = (jd) => 23.439291 - 0.0130042 * (jd - 2451545.0) / 36525;

  // ecliptic (of date) vector -> RA/Dec (deg)
  function eclToEq(v, jd) {
    const e = obliq(jd) * D2R;
    const x = v[0], y = v[1] * Math.cos(e) - v[2] * Math.sin(e), z = v[1] * Math.sin(e) + v[2] * Math.cos(e);
    return { ra: norm(Math.atan2(y, x) * R2D), dec: Math.atan2(z, Math.hypot(x, y)) * R2D };
  }
  // precess a J2000 ecliptic vector to the ecliptic of date (longitude only, enough here)
  function precess(v, jd) {
    const p = 1.396971 * (jd - 2451545.0) / 36525 * D2R, c = Math.cos(p), s = Math.sin(p);
    return [v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2]];
  }
  function altAz(ra, dec, lat, lon, jd) {
    const H = (gmst(jd) + lon - ra) * D2R, d = dec * D2R, p = lat * D2R;
    const alt = Math.asin(Math.sin(p) * Math.sin(d) + Math.cos(p) * Math.cos(d) * Math.cos(H));
    const az = Math.atan2(-Math.cos(d) * Math.sin(H), Math.sin(d) * Math.cos(p) - Math.cos(d) * Math.sin(p) * Math.cos(H));
    return { alt: alt * R2D, az: norm(az * R2D) };
  }

  const earth = () => window.KS_DATA.planets[2];

  // Geocentric view of a body: RA/Dec, distance (au), elongation, magnitude
  function geo(b, jd) {
    const E = helio(earth(), jd);
    if (b.id === 'sun') {
      const g = precess([-E[0], -E[1], -E[2]], jd), eq = eclToEq(g, jd);
      return { ...eq, dist: len(E), mag: -26.7 };
    }
    if (b.id === 'moon') {
      const m = moonGeo(jd), lo = m.lon * D2R, la = m.lat * D2R;
      const v = [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)], eq = eclToEq(v, jd);
      const sunLon = Math.atan2(-E[1], -E[0]) * R2D + 1.396971 * (jd - 2451545.0) / 36525;
      const el = Math.acos(Math.cos(la) * Math.cos((m.lon - sunLon) * D2R)) * R2D;
      return { ...eq, dist: m.dist / AU, km: m.dist, elong: el, mag: -12.7 + 0.026 * (180 - el) + 4e-9 * Math.pow(180 - el, 4) };
    }
    const H = helio(b, jd), g = sub(H, E), d = len(g), r = len(H), R = len(E);
    const eq = eclToEq(precess(g, jd), jd);
    const cosi = Math.max(-1, Math.min(1, (r * r + d * d - R * R) / (2 * r * d))), i = Math.acos(cosi) * R2D;
    const cosel = Math.max(-1, Math.min(1, (R * R + d * d - r * r) / (2 * R * d)));
    const lg = 5 * Math.log10(r * d);
    const mags = {
      mercury: -0.42 + lg + 0.038 * i - 0.000273 * i * i + 0.000002 * i * i * i,
      venus: -4.40 + lg + 0.0009 * i + 0.000239 * i * i - 0.00000065 * i * i * i,
      mars: -1.52 + lg + 0.016 * i, jupiter: -9.40 + lg + 0.005 * i, saturn: -8.88 + lg + 0.044 * i,
      uranus: -7.19 + lg, neptune: -6.87 + lg, pluto: -1.0 + lg, ceres: 3.3 + lg
    };
    return { ...eq, dist: d, r, phase: i, elong: Math.acos(cosel) * R2D, mag: mags[b.id] };
  }

  // Sky tonight for a place: from today's sunset to tomorrow's sunrise (local computer time)
  function tonight(bodies, lat, lon, nowMs) {
    const step = 10 * 60000;
    const sunB = window.KS_DATA.sun;
    const sunAlt = (ms) => { const g = geo(sunB, jdOf(ms)); return altAz(g.ra, g.dec, lat, lon, jdOf(ms)).alt; };
    // find sunset: search from local noon today (or now if it's night after midnight)
    const d0 = new Date(nowMs); d0.setHours(12, 0, 0, 0);
    let start = d0.getTime();
    if (new Date(nowMs).getHours() < 6) start -= 86400000;  // after midnight: tonight started yesterday
    let set = null, rise = null, dusk = null, dawn = null;
    for (let t = start; t < start + 36 * 3600000; t += step) {
      const a = sunAlt(t), b2 = sunAlt(t + step);
      if (set === null && a > -0.833 && b2 <= -0.833) set = interp(t, step, a, b2, -0.833);
      if (set !== null && dusk === null && a > -12 && b2 <= -12) dusk = interp(t, step, a, b2, -12);
      if (set !== null && dawn === null && a < -12 && b2 >= -12) dawn = interp(t, step, a, b2, -12);
      if (set !== null && rise === null && a < -0.833 && b2 >= -0.833) { rise = interp(t, step, a, b2, -0.833); break; }
    }
    if (set === null) set = start + 6 * 3600000;
    if (rise === null) rise = set + 12 * 3600000;
    const out = [];
    for (const b of bodies) {
      let best = { alt: -90 }, firstUp = null, lastUp = null, riseT = null, setT = null, prev = null;
      for (let t = set - 3600000; t <= rise + 3600000; t += step) {
        const jd = jdOf(t), g = geo(b, jd), h = altAz(g.ra, g.dec, lat, lon, jd);
        if (prev !== null) {
          if (prev < 0 && h.alt >= 0 && riseT === null) riseT = t;
          if (prev >= 0 && h.alt < 0 && setT === null && t > set) setT = t;
        }
        prev = h.alt;
        if (t >= set && t <= rise) {
          if (h.alt > best.alt) best = { alt: h.alt, az: h.az, t };
          if (h.alt > 5 && sunAlt(t) < -6) { if (firstUp === null) firstUp = t; lastUp = t; }
        }
      }
      const jdN = jdOf(nowMs), gN = geo(b, jdN), now = altAz(gN.ra, gN.dec, lat, lon, jdN);
      const gB = geo(b, jdOf(best.t || nowMs));
      out.push({ b, best, now, firstUp, lastUp, riseT, setT, mag: gB.mag, elong: gB.elong, dist: gB.dist, visible: firstUp !== null && gB.mag !== undefined && gB.mag < 6 });
    }
    return { set, rise, dusk, dawn, list: out };
  }
  function interp(t, step, a, b, target) { return t + step * (target - a) / (b - a); }

  return { jdOf, msOf, helio, elements, orbitPoints, moonGeo, gmst, obliq, geo, altAz, eclToEq, tonight, AU, D2R, R2D, len, sub, kepXYZ };
})();
