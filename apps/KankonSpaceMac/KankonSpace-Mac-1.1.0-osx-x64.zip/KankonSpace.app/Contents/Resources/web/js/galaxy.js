/* Kankon Space - the Milky Way (a model built from published structure: central bar, two major and two minor arms, Orion Spur).
   1 scene unit = 100 light-years. */
window.KS_GALAXY = (function () {
  let renderer, scene, camera, controls, canvas, labelsEl, inited = false, pts;
  const labels = [];
  const T = (en, ar) => ({ en, ar });
  const SUN = { r: 260, ang: 0 };   // 26,000 ly from the centre

  function rnd() { return (Math.random() + Math.random() + Math.random() - 1.5) / 1.5; }

  function build() {
    const N = 110000, pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
    const arms = [
      { a0: 0.0, w: 1.0, c: [0.62, 0.75, 1.0] },        // Perseus
      { a0: Math.PI, w: 1.0, c: [0.62, 0.75, 1.0] },     // Scutum-Centaurus
      { a0: Math.PI / 2, w: 0.55, c: [0.75, 0.82, 1.0] },  // Sagittarius-Carina (minor)
      { a0: 3 * Math.PI / 2, w: 0.55, c: [0.75, 0.82, 1.0] } // Norma / Outer (minor)
    ];
    const pitch = Math.tan(12.5 * Math.PI / 180);
    let i = 0;
    const put = (x, y, z, c, f) => { pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z; col[i * 3] = c[0] * f; col[i * 3 + 1] = c[1] * f; col[i * 3 + 2] = c[2] * f; i++; };
    // bulge
    for (let k = 0; k < 20000; k++) { const r = Math.pow(Math.random(), 1.6) * 60; const t = Math.random() * Math.PI * 2, p = Math.acos(2 * Math.random() - 1); put(r * Math.sin(p) * Math.cos(t), r * Math.cos(p) * 0.55, r * Math.sin(p) * Math.sin(t), [1.0, 0.86, 0.62], 0.6 + Math.random() * 0.5); }
    // bar (tilted ~27 deg to the Sun-centre line)
    for (let k = 0; k < 10000; k++) { const x = rnd() * 95, y = rnd() * 8, z = rnd() * 20; const a = 27 * Math.PI / 180; put(x * Math.cos(a) - z * Math.sin(a), y, x * Math.sin(a) + z * Math.cos(a), [1.0, 0.82, 0.58], 0.55 + Math.random() * 0.4); }
    // arms: logarithmic spirals from the bar ends
    while (i < N - 12000) {
      const arm = arms[Math.floor(Math.random() * arms.length)];
      if (Math.random() > arm.w) continue;
      const r = 70 + Math.pow(Math.random(), 0.8) * 430;
      const th = arm.a0 + Math.log(r / 70) / pitch;
      const spread = 9 + r * 0.06;
      const x = r * Math.cos(th) + rnd() * spread, z = r * Math.sin(th) + rnd() * spread, y = rnd() * (6 + r * 0.01);
      const young = Math.random() < 0.3;
      put(x, y, z, young ? arm.c : [0.95, 0.9, 0.82], (0.45 + Math.random() * 0.55) * (1.2 - r / 600));
    }
    // disc haze
    while (i < N) { const r = Math.pow(Math.random(), 0.7) * 520, t = Math.random() * Math.PI * 2; put(r * Math.cos(t), rnd() * 10, r * Math.sin(t), [0.85, 0.8, 0.75], 0.18 + Math.random() * 0.2); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    pts = new THREE.Points(g, new THREE.PointsMaterial({ size: 1.6, vertexColors: true, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
    scene.add(pts);
    // centre glow
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
    const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,230,180,0.9)'); gr.addColorStop(1, 'rgba(255,180,90,0)'); x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }));
    glow.scale.set(200, 200, 1); scene.add(glow);
    // the Sun: on the Orion Spur between Perseus and Sagittarius arms
    SUN.ang = Math.log(SUN.r / 70) / pitch + 0.5 * Math.PI + 0.55;
    const sp = new THREE.Vector3(SUN.r * Math.cos(SUN.ang), 0, SUN.r * Math.sin(SUN.ang));
    // Orion spur stars
    const spur = [];
    for (let k = 0; k < 2500; k++) { const s = (Math.random() - 0.5) * 80; spur.push(sp.x + Math.cos(SUN.ang + 1.2) * s + rnd() * 7, rnd() * 4, sp.z + Math.sin(SUN.ang + 1.2) * s + rnd() * 7); }
    const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(spur, 3));
    scene.add(new THREE.Points(sg, new THREE.PointsMaterial({ size: 1.4, color: 0xbfd2ff, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false })));
    const ring = new THREE.Mesh(new THREE.RingGeometry(5, 6.5, 48), new THREE.MeshBasicMaterial({ color: 0xffd54a, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.copy(sp); scene.add(ring);
    const lab = (pos, t, cls) => { const el = document.createElement('div'); el.className = 'lbl ' + (cls || 'region'); labelsEl.appendChild(el); labels.push({ pos, t, el }); };
    lab(sp, T('You are here: the Sun', 'أنت هنا: الشمس'), 'here');
    lab(new THREE.Vector3(0, 0, 0), T('Galactic centre (Sagittarius A*)', 'مركز المجرة (القوس A*)'));
    const armLab = (a0, r, t) => { const th = a0 + Math.log(r / 70) / pitch; lab(new THREE.Vector3(r * Math.cos(th), 0, r * Math.sin(th)), t); };
    armLab(0, 400, T('Perseus Arm', 'ذراع برشاوس'));
    armLab(Math.PI, 380, T('Scutum-Centaurus Arm', 'ذراع الترس-قنطورس'));
    armLab(Math.PI / 2, 300, T('Sagittarius Arm', 'ذراع القوس'));
    armLab(3 * Math.PI / 2, 330, T('Norma Arm', 'ذراع الزاوية'));
    lab(new THREE.Vector3(sp.x + Math.cos(SUN.ang + 1.2) * 40, 0, sp.z + Math.sin(SUN.ang + 1.2) * 40), T('Orion Spur', 'ذراع الجبار'));
    lab(new THREE.Vector3(-900, -400, 1200), T('Large Magellanic Cloud (160,000 ly)', 'سحابة ماجلان الكبرى (160,000 سنة ضوئية)'));
    lab(new THREE.Vector3(-700, -800, 1500), T('Small Magellanic Cloud (200,000 ly)', 'سحابة ماجلان الصغرى (200,000 سنة ضوئية)'));
    for (const [x, y, z, s] of [[-900, -400, 1200, 70], [-700, -800, 1500, 45]]) {
      const g2 = new THREE.BufferGeometry(), a = [];
      for (let k = 0; k < 2500; k++) a.push(x + rnd() * s, y + rnd() * s * 0.6, z + rnd() * s);
      g2.setAttribute('position', new THREE.Float32BufferAttribute(a, 3));
      scene.add(new THREE.Points(g2, new THREE.PointsMaterial({ size: 1.3, color: 0xcdd8ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false })));
    }
    return sp;
  }

  function init(cv, lbls) {
    canvas = cv; labelsEl = lbls;
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(50, 1, 1, 50000);
    controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true; controls.dampingFactor = 0.08; controls.maxDistance = 6000; controls.minDistance = 20;
    build();
    camera.position.set(0, 620, 700);
    inited = true;
  }
  function frame() {
    if (!inited) return;
    pts.rotation.y += 0.0002;
    controls.update(); renderer.render(scene, camera);
    const w = canvas.clientWidth, h = canvas.clientHeight, v = new THREE.Vector3(), lang = KS_I18N.lang;
    for (const l of labels) {
      v.copy(l.pos); if (l.el.className.indexOf('here') < 0 && l.pos.lengthSq() < 1e6 && l.pos.lengthSq() > 0) v.applyAxisAngle(new THREE.Vector3(0, 1, 0), pts.rotation.y);
      v.project(camera);
      const ok = v.z < 1;
      l.el.style.display = ok ? '' : 'none';
      if (ok) l.el.style.transform = `translate(${((v.x + 1) / 2 * w).toFixed(1)}px, ${((1 - v.y) / 2 * h).toFixed(1)}px)`;
      if (l.el.textContent !== l.t[lang]) l.el.textContent = l.t[lang];
    }
  }
  function resize(w, h) { if (!inited) return; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
  function view(k) {
    if (k === 'top') camera.position.set(0, 1100, 1);
    else if (k === 'side') camera.position.set(0, 40, 1100);
    else camera.position.set(0, 620, 700);
    controls.target.set(0, 0, 0);
  }
  return { init, frame, resize, view, get inited() { return inited; } };
})();
