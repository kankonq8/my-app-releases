/* Kankon Space - interface text (English default, Arabic right-to-left). */
window.KS_I18N = (function () {
  const S = {
    appName: ['Kankon Space', 'Kankon Space'],
    by: ['by Kankon · kankon.net', 'من Kankon · kankon.net'],
    tabSolar: ['Solar System', 'المجموعة الشمسية'], tabEarth: ['Earth', 'الأرض'], tabGalaxy: ['Milky Way', 'درب التبانة'],
    tabSky: ['Tonight\'s sky', 'سماء الليلة'], tabCompare: ['Compare', 'مقارنة'], tabQuiz: ['Quiz', 'اختبار'],
    help: ['Help', 'المساعدة'], lang: ['العربية', 'English'], sources: ['Sources', 'المصادر'],
    gStar: ['Star', 'النجم'], gPlanets: ['Planets', 'الكواكب'], gDwarfs: ['Dwarf planets', 'الكواكب القزمة'], gComets: ['Comets', 'المذنبات'], gCraft: ['Farthest spacecraft', 'أبعد المركبات الفضائية'],
    overview: ['Whole Solar System', 'المجموعة الشمسية كاملة'],
    show: ['Show', 'إظهار'], orbits: ['Orbits', 'المدارات'], labels: ['Names', 'الأسماء'], moonsOpt: ['Moons', 'الأقمار'], belts: ['Asteroid and Kuiper belts', 'حزام الكويكبات وحزام كايبر'], cometsOpt: ['Comets', 'المذنبات'],
    scale: ['Scale', 'المقياس'], scaleVisual: ['Easy view', 'عرض مريح'], scaleTrue: ['True scale', 'المقياس الحقيقي'],
    scaleNote: ['Easy view makes the planets bigger and the distances shorter so everything fits. True scale shows real sizes and distances: the planets become tiny dots.', 'العرض المريح يكبّر الكواكب ويقصّر المسافات حتى يتسع المشهد لكل شيء. والمقياس الحقيقي يعرض الأحجام والمسافات الحقيقية، فتصبح الكواكب نقاطًا صغيرة جدًّا.'],
    now: ['Now', 'الآن'], pause: ['Pause', 'إيقاف مؤقت'], play: ['Play', 'تشغيل'], slower: ['Slower', 'أبطأ'], faster: ['Faster', 'أسرع'], reverse: ['Backwards in time', 'رجوع بالزمن'],
    spReal: ['real time', 'الوقت الحقيقي'], spMin: ['1 minute per second', 'دقيقة في الثانية'], spHour: ['1 hour per second', 'ساعة في الثانية'], spDay: ['1 day per second', 'يوم في الثانية'],
    spWeek: ['1 week per second', 'أسبوع في الثانية'], spMonth: ['1 month per second', 'شهر في الثانية'], spYear: ['1 year per second', 'سنة في الثانية'],
    paused: ['paused', 'متوقف مؤقتًا'], backwards: ['backwards', 'رجوع بالزمن'], liveNow: ['Live: positions for right now', 'مباشر: المواقع في هذه اللحظة'],
    dateHint: ['Pick any date to see where the planets were or will be.', 'اختر أي تاريخ لترى أين كانت الكواكب أو أين ستكون.'],
    outOfRange: ['Positions are most accurate between 1800 and 2050.', 'المواقع أدق ما تكون بين عامي 1800 و2050.'],
    // info panel
    liveBox: ['Where it is now', 'أين هو الآن'], fromSun: ['Distance from the Sun', 'البعد عن الشمس'], fromEarth: ['Distance from Earth', 'البعد عن الأرض'],
    lightSun: ['Sunlight takes', 'يستغرق ضوء الشمس'], lightEarth: ['Light from Earth takes', 'يستغرق الضوء من الأرض'], speedNow: ['Speed around the Sun', 'السرعة حول الشمس'],
    keyNums: ['Key numbers (NASA)', 'أرقام رئيسية (NASA)'], vsEarth: ['Compared with Earth', 'مقارنة بالأرض'], atmo: ['Atmosphere', 'الغلاف الجوي'], moonsH: ['Main moons', 'أهم الأقمار'],
    missions: ['Missions', 'البعثات'], facts: ['Did you know?', 'هل تعلم؟'], exploreEarth: ['Explore Earth in 3D', 'استكشف الأرض ثلاثية الأبعاد'], seeTonight: ['Can I see it tonight?', 'هل أراه الليلة؟'],
    focus: ['Go to', 'انتقل إلى'], parentOf: ['Moon of', 'يدور حول'], discovered: ['Discovered', 'الاكتشاف'],
    fMass: ['Mass', 'الكتلة'], fDiam: ['Diameter', 'القطر'], fDens: ['Density', 'الكثافة'], fGrav: ['Gravity', 'الجاذبية'], fEsc: ['Escape speed', 'سرعة الإفلات'],
    fRot: ['Spins once in', 'يدور حول نفسه في'], fDay: ['Length of a day (sunrise to sunrise)', 'طول اليوم (من شروق إلى شروق)'], fDist: ['Average distance from the Sun', 'متوسط البعد عن الشمس'],
    fDistE: ['Average distance from Earth', 'متوسط البعد عن الأرض'], fPeri: ['Closest to the Sun', 'أقرب نقطة من الشمس'], fAph: ['Farthest from the Sun', 'أبعد نقطة عن الشمس'],
    fPer: ['One orbit (a year) takes', 'الدورة الواحدة (السنة) تستغرق'], fVel: ['Average orbital speed', 'متوسط السرعة المدارية'], fInc: ['Orbit tilt (to Earth\'s orbit)', 'ميل المدار (عن مدار الأرض)'],
    fEcc: ['Orbit shape (eccentricity; 0 = circle)', 'شكل المدار (الاختلاف المركزي؛ 0 = دائرة)'], fObl: ['Axis tilt', 'ميل المحور'], fTemp: ['Average temperature', 'متوسط درجة الحرارة'],
    fRange: ['Temperature range', 'مدى درجات الحرارة'], fPres: ['Air pressure at the surface', 'الضغط الجوي على السطح'], fMoons: ['Known moons', 'الأقمار المعروفة'], fRings: ['Rings', 'الحلقات'],
    fMag: ['Global magnetic field', 'مجال مغناطيسي عام'], fCore: ['Core temperature', 'حرارة اللب'], fAge: ['Age', 'العمر'], fSurf: ['Surface temperature', 'حرارة السطح'],
    yes: ['Yes', 'نعم'], no: ['No', 'لا'], noSurface: ['No solid surface', 'ليس له سطح صلب'], retro: ['backwards (retrograde)', 'في الاتجاه المعاكس (حركة تراجعية)'],
    hours: ['hours', 'ساعة'], days: ['days', 'يومًا'], years: ['years', 'سنة'], minutes: ['minutes', 'دقيقة'], seconds: ['seconds', 'ثانية'],
    km: ['km', 'كم'], kms: ['km/s', 'كم/ث'], kg: ['kg', 'كغ'], mkm: ['million km', 'مليون كم'], bkm: ['billion km', 'مليار كم'], au: ['au', 'وحدة فلكية'], bar: ['bar', 'بار'],
    timesEarth: ['× Earth', '× الأرض'], ms2: ['m/s²', 'م/ث²'], kgm3: ['kg/m³', 'كغ/م³'], celsius: ['°C', '°م'], billionYears: ['billion years', 'مليار سنة'], millionC: ['million °C', 'مليون °م'],
    auNote: ['1 au (astronomical unit) = Earth-Sun distance = 149.6 million km', 'الوحدة الفلكية = بعد الأرض عن الشمس = 149.6 مليون كم'],
    heliopause: ['Heliopause: edge of the Sun\'s bubble (~120 au)', 'حدّ الغلاف الشمسي: نهاية فقاعة الشمس (نحو 120 وحدة فلكية)'],
    approxPos: ['Position is approximate.', 'الموقع تقريبي.'],
    // earth
    eTitle: ['Explore the Earth', 'استكشف الأرض'], eHint: ['Drag to turn the globe, scroll or pinch to zoom, right-drag or Ctrl-drag to tilt. Zoom all the way in to see streets and houses.', 'اسحب لتدوير الكرة الأرضية، واستخدم عجلة الفأرة أو باعد بين إصبعيك للتكبير، واسحب بالزر الأيمن أو مع Ctrl لإمالة المنظر. كبّر إلى أقصى حد لترى الشوارع والبيوت.'],
    eMap: ['Map', 'الخريطة'], eSat: ['Satellite', 'قمر اصطناعي'], eHybrid: ['Satellite + names', 'قمر اصطناعي + أسماء'], eStreet: ['Streets', 'الشوارع'], eNight: ['Night lights', 'أضواء الليل'],
    eSunlight: ['Real day and night', 'الليل والنهار الحقيقيان'], eHome: ['Whole Earth', 'الأرض كاملة'], ePlaces: ['Famous places', 'أماكن مشهورة'],
    eGoto: ['Go to coordinates', 'الانتقال إلى إحداثيات'], eLat: ['Latitude', 'خط العرض'], eLon: ['Longitude', 'خط الطول'], eGo: ['Go', 'انتقل'],
    eMouse: ['Pointer', 'المؤشر'], eHeight: ['Camera height', 'ارتفاع الكاميرا'],
    issTitle: ['International Space Station (live)', 'محطة الفضاء الدولية (مباشر)'], issShow: ['Show the ISS', 'إظهار المحطة'], issFollow: ['Follow it', 'تتبّعها'],
    issLat: ['Over', 'فوق'], issAlt: ['Height', 'الارتفاع'], issSpeed: ['Speed', 'السرعة'], issSun: ['In sunlight', 'في ضوء الشمس'], issShadow: ['In Earth\'s shadow', 'في ظل الأرض'],
    issErr: ['Cannot reach the ISS service. Check the internet.', 'تعذّر الوصول إلى خدمة موقع المحطة. تحقّق من الاتصال بالإنترنت.'], issWait: ['Getting the ISS position…', 'جارٍ جلب موقع المحطة…'],
    issNote: ['The yellow line is where it has been; the dashed line is where it goes in the next 100 minutes. It circles the Earth about every 92 minutes.', 'الخط الأصفر هو المسار الذي قطعته، والخط المتقطع هو مسارها في الدقائق المئة القادمة. وهي تدور حول الأرض مرة كل 92 دقيقة تقريبًا.'],
    eOffline: ['No internet: showing the built-in picture of the Earth. Detailed maps need the internet.', 'لا يوجد اتصال بالإنترنت: تُعرض صورة الأرض المضمّنة. والخرائط المفصّلة تحتاج إلى الإنترنت.'],
    eLoading: ['Loading the 3D Earth…', 'جارٍ تحميل الأرض ثلاثية الأبعاد…'],
    // galaxy
    galTitle: ['The Milky Way', 'مجرة درب التبانة'], galTop: ['From above', 'من الأعلى'], galSide: ['From the side', 'من الجانب'], galTilt: ['Tilted', 'منظر مائل'],
    galModel: ['This is a model built from what astronomers have measured. Nobody has photographed our galaxy from outside: we live inside it.', 'هذا نموذج مبني على قياسات الفلكيين، فلم يصوّر أحد مجرتنا من الخارج لأننا نعيش داخلها.'],
    // sky
    skyTitle: ['What can I see tonight?', 'ماذا أرى الليلة؟'], skyPlace: ['Place', 'المكان'], skyNote: ['Times use this computer\'s clock. Brightness: smaller numbers are brighter; up to about 6 can be seen without a telescope from a dark place.', 'الأوقات بحسب ساعة هذا الحاسوب. السطوع: كلما صغر الرقم كان الجرم ألمع، وما يصل إلى نحو 6 يُرى دون مقراب من مكان مظلم.'],
    skySunset: ['Sunset', 'غروب الشمس'], skySunrise: ['Sunrise', 'شروق الشمس'], skyDark: ['Dark sky', 'السماء المظلمة'],
    colBody: ['Object', 'الجرم'], colSee: ['Tonight', 'الليلة'], colWhen: ['Best time', 'أفضل وقت'], colWhere: ['Where to look', 'أين تنظر'], colRise: ['Rises / sets', 'يشرق / يغرب'], colMag: ['Brightness', 'السطوع'], colNow: ['Now', 'الآن'],
    vEasy: ['Easy to see', 'يُرى بسهولة'], vEye: ['Visible', 'يُرى بالعين المجردة'], vScope: ['Needs a telescope', 'يحتاج إلى مقراب'], vNo: ['Not tonight', 'لا يُرى الليلة'], vSun: ['Too close to the Sun', 'قريب جدًّا من الشمس'],
    up: ['up', 'فوق الأفق'], down: ['below the horizon', 'تحت الأفق'], skyTime: ['Sky at', 'السماء في الساعة'],
    skyDome: ['North is at the top, the centre is straight overhead, the ring is the horizon.', 'الشمال في الأعلى، والمركز فوق رأسك مباشرة، والحلقة هي الأفق.'],
    dirs: [['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'], ['شمال', 'شمال شرقي', 'شرق', 'جنوب شرقي', 'جنوب', 'جنوب غربي', 'غرب', 'شمال غربي']],
    high: ['{0}° high', 'على ارتفاع {0}°'], allNight: ['all night', 'طوال الليل'], moonLink: ['For the Moon\'s phase, moonrise and the Hijri crescent open Kankon Moon in Kankon Launcher.', 'لمعرفة طور القمر ووقت شروقه والهلال الهجري، افتح Kankon Moon من Kankon Launcher.'],
    // compare
    cmpTitle: ['Sizes to scale', 'الأحجام وفق المقياس الحقيقي'], cmpPlanets: ['Planets', 'الكواكب'], cmpSun: ['With the Sun', 'مع الشمس'], cmpDwarfs: ['Dwarf planets and big moons', 'الكواكب القزمة والأقمار الكبيرة'],
    weightT: ['Your weight on other worlds', 'وزنك على العوالم الأخرى'], weightIn: ['Your weight on Earth (kg)', 'وزنك على الأرض (كغ)'],
    ageT: ['Your age on other planets', 'عمرك على الكواكب الأخرى'], ageIn: ['Your birthday', 'تاريخ ميلادك'], ageYears: ['Age (years)', 'العمر بالسنوات'], nextBday: ['Next birthday there', 'عيد ميلادك القادم هناك'],
    weightNote: ['Weight here is what a scale would show on the surface (for giant planets: at the cloud tops).', 'الوزن هنا هو ما يُظهره الميزان على السطح (وفي الكواكب العملاقة: عند قمم السحب).'],
    // quiz
    quizTitle: ['Space quiz', 'اختبار الفضاء'], quizNext: ['Next question', 'السؤال التالي'], quizNew: ['New round', 'جولة جديدة'], quizScore: ['Score', 'النتيجة'], quizQ: ['Question', 'السؤال'],
    quizRight: ['Correct!', 'إجابة صحيحة!'], quizWrong: ['Not quite.', 'إجابة غير صحيحة.'], quizDone: ['Round finished', 'انتهت الجولة'],
    quizGreat: ['Excellent, you are a real astronomer!', 'ممتاز، أنت فلكي حقيقي!'], quizGood: ['Well done!', 'أحسنت!'], quizTry: ['Have a look around the app and try again.', 'تجوّل في البرنامج ثم حاول مرة أخرى.'],
    // misc
    close: ['Close', 'إغلاق'], contents: ['Contents', 'المحتويات'], faq: ['Questions and answers', 'الأسئلة الشائعة'], trouble: ['If something goes wrong', 'إذا واجهتك مشكلة'],
    version: ['Version', 'الإصدار'], srcTitle: ['Sources and credits', 'المصادر والشكر'],
    launcherOnly: ['Kankon Space opens from Kankon Launcher.', 'يُفتح Kankon Space من Kankon Launcher.']
  };
  let lang = 'en';
  const listeners = [];
  function t(k) { const v = S[k]; if (!v) return k; return v[lang === 'ar' ? 1 : 0]; }
  function L(o) { return o ? (o[lang] || o.en) : ''; }
  function setLang(l) {
    lang = l; document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i]').forEach((e) => { e.textContent = t(e.dataset.i); });
    document.querySelectorAll('[data-it]').forEach((e) => { e.title = t(e.dataset.it); });
    listeners.forEach((f) => f(l));
  }
  return { t, L, setLang, on: (f) => listeners.push(f), get lang() { return lang; } };
})();
