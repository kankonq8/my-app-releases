/* Gulf Weather - UI. by Kankon · kankon.net */
(function () {
  const { COUNTRIES, CITIES } = GW;
  const $ = id => document.getElementById(id);
  const S = window.GW_STRINGS;
  const st = { lang: 'en', city: 'kuwait', data: null, src: 'loading', updatedAt: null, t: 0, playing: false, speed: 1, dragging: false, view: 'scene', grid: null };
  try { const c = localStorage.getItem('gw-city'); if (c && CITIES.some(x => x.id === c)) st.city = c; } catch (e) { }
  const T = (k, ...a) => { let s = (S[st.lang] && S[st.lang][k]) || S.en[k] || k; a.forEach((v, i) => { s = s.replace('{' + i + '}', v); }); return s; };
  const city = () => CITIES.find(c => c.id === st.city);
  const ctry = id => COUNTRIES.find(c => c.id === id);
  const D = () => st.data && st.data[st.city];
  const parseT = s => { const m = /(\d+)-(\d+)-(\d+)T(\d+):(\d+)/.exec(s); return Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5]); };
  const loc = () => st.lang === 'ar' ? 'ar-u-nu-latn-ca-gregory' : 'en-GB';
  const fmt = (ms, o) => new Intl.DateTimeFormat(loc(), Object.assign({ timeZone: 'UTC' }, o)).format(new Date(ms));
  const fmtTime = ms => new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-US', { timeZone: 'UTC', hour: 'numeric', minute: '2-digit' }).format(new Date(ms));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const r0 = v => v == null ? null : Math.round(v);

  /* ---------- conditions ---------- */
  function cond(h) {
    if (!h) return 'clear';
    const c = h.code, vis = h.vis, dust = h.dust;
    if (c >= 95) return 'thunder';
    if ((dust != null && dust >= 1000) || (vis != null && vis < 1000 && h.hum < 70)) return 'dustStorm';
    if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return h.precip >= 4 || c === 65 || c === 82 ? 'heavyRain' : 'rain';
    if (c >= 51 && c <= 57) return 'drizzle';
    if (c === 45 || c === 48 || (vis != null && vis < 1000 && h.hum >= 80)) return 'fog';
    if ((dust != null && dust >= 300) || (vis != null && vis < 5000 && h.hum < 70)) return 'dust';
    if ((dust != null && dust >= 150) || (vis != null && vis < 8000 && h.hum < 60)) return 'haze';
    if (c === 3) return h.cloud >= 95 ? 'overcast' : 'cloudy';
    if (c === 1 || c === 2) return 'partly';
    return h.isDay ? 'clear' : 'clearNight';
  }
  const PRI = ['thunder', 'dustStorm', 'heavyRain', 'rain', 'dust', 'fog', 'drizzle', 'haze', 'overcast', 'cloudy', 'partly', 'clear', 'clearNight'];
  function dayCond(di) {
    const hs = D().hours.slice(di * 24 + 9, di * 24 + 19); let best = 'clear';
    hs.forEach(h => { const c = cond(Object.assign({}, h, { isDay: 1 })); if (PRI.indexOf(c) < PRI.indexOf(best)) best = c; });
    // light rain for one hour should not hide a mostly clear day unless it is a real event
    return best;
  }

  /* ---------- icons ---------- */
  const SUN = (x, y, r) => `<g><circle cx="${x}" cy="${y}" r="${r}" fill="url(#gs)"/>${[0, 45, 90, 135, 180, 225, 270, 315].map(a => { const rad = a * Math.PI / 180; return `<line x1="${x + Math.cos(rad) * (r + 3)}" y1="${y + Math.sin(rad) * (r + 3)}" x2="${x + Math.cos(rad) * (r + 7)}" y2="${y + Math.sin(rad) * (r + 7)}" stroke="#ffc24a" stroke-width="2.6" stroke-linecap="round"/>`; }).join('')}</g>`;
  const MOON = (x, y) => `<path d="M${x + 6} ${y - 12}a12 12 0 1 0 9 19 10 10 0 0 1-9-19z" fill="#e8ecff"/>`;
  const CLOUD = (x, y, s, c) => `<path transform="translate(${x} ${y}) scale(${s})" d="M10 30h26a9 9 0 0 0 0-18 12 12 0 0 0-23 3A7.5 7.5 0 0 0 10 30z" fill="${c || '#fff'}"/>`;
  const DEF = '<defs><radialGradient id="gs"><stop offset="0" stop-color="#ffe58a"/><stop offset="1" stop-color="#ffb21e"/></radialGradient></defs>';
  function icon(c) {
    let b = '';
    switch (c) {
      case 'clear': b = SUN(24, 24, 10); break;
      case 'clearNight': b = MOON(22, 24); break;
      case 'partly': b = SUN(18, 18, 8) + CLOUD(8, 14, 0.9); break;
      case 'cloudy': b = CLOUD(-2, 6, 0.8, '#cfd8e3') + CLOUD(6, 12, 0.95); break;
      case 'overcast': b = CLOUD(-2, 4, 0.85, '#9aa6b5') + CLOUD(6, 12, 0.95, '#c3ccd8'); break;
      case 'fog': b = CLOUD(4, 2, 0.9, '#d8dee8') + [32, 37, 42].map((y, i) => `<line x1="${8 + i * 2}" y1="${y}" x2="${40 - i * 2}" y2="${y}" stroke="#e6ebf2" stroke-width="2.6" stroke-linecap="round"/>`).join(''); break;
      case 'drizzle': case 'rain': case 'heavyRain': {
        const n = c === 'heavyRain' ? 5 : c === 'rain' ? 3 : 2;
        b = CLOUD(4, 2, 0.9, '#c3ccd8') + Array.from({ length: n }, (_, i) => `<line x1="${14 + i * 6}" y1="${34}" x2="${11 + i * 6}" y2="${43}" stroke="#5cc8ff" stroke-width="2.6" stroke-linecap="round"/>`).join(''); break;
      }
      case 'thunder': b = CLOUD(4, 2, 0.9, '#8d98a8') + '<path d="M25 30l-6 9h6l-3 8 9-11h-6l3-6z" fill="#ffd34d"/>'; break;
      case 'dust': case 'dustStorm': case 'haze': {
        const col = c === 'haze' ? '#e8c995' : '#d9a560';
        b = (c === 'haze' ? SUN(24, 18, 8).replace('url(#gs)', '#f5d58a') : '') + [14, 22, 30, 38].map((y, i) => `<path d="M${6 + (i % 2) * 4} ${y}q8 -4 16 0t16 0" fill="none" stroke="${col}" stroke-width="${c === 'dustStorm' ? 3.4 : 2.6}" stroke-linecap="round" opacity="${c === 'haze' && i < 2 ? 0 : 1}"/>`).join('');
        if (c === 'dustStorm') b += '<circle cx="40" cy="12" r="2" fill="#d9a560"/><circle cx="36" cy="44" r="1.6" fill="#d9a560"/>';
        break;
      }
    }
    return `<svg viewBox="0 0 48 48">${DEF}${b}</svg>`;
  }

  /* ---------- alerts ---------- */
  function alertsForDay(di) {
    const d = D(); const day = d.days[di]; const hs = d.hours.slice(di * 24, di * 24 + 24); const out = [];
    const mx = Math.max(...hs.map(h => h.temp)), mn = Math.min(...hs.map(h => h.temp));
    const g = Math.max(...hs.map(h => h.gust || 0)), uv = Math.max(day.uvmax || 0, ...hs.map(h => h.uv || 0));
    const cs = hs.map(cond);
    if (mx >= 50) out.push(['r', '🔥', 'a.heatExt', Math.round(mx) + '°']); else if (mx >= 45) out.push(['o', '🔥', 'a.heat', Math.round(mx) + '°']); else if (mx >= 40) out.push(['y', '🥵', 'a.hot', Math.round(mx) + '°']);
    if (cs.includes('dustStorm')) out.push(['r', '🌪️', 'a.dustStorm', '']); else if (cs.includes('dust')) out.push(['o', '🌫️', 'a.dust', '']);
    if (cs.includes('thunder')) out.push(['o', '⛈️', 'a.thunder', '']);
    const ps = hs.reduce((a, h) => a + (h.precip || 0), 0);
    if (ps >= 10 || hs.some(h => h.precip >= 5)) out.push(['r', '🌧️', 'a.heavyRain', ps.toFixed(0) + ' ' + T('mm')]);
    if (g >= 55) out.push([g >= 70 ? 'r' : 'o', '💨', 'a.wind', Math.round(g) + ' ' + T('kmh')]);
    if (cs.includes('fog')) out.push(['y', '🌫️', 'a.fog', '']);
    if (uv >= 11) out.push(['o', '☀️', 'a.uvExt', 'UV ' + Math.round(uv)]); else if (uv >= 8) out.push(['y', '☀️', 'a.uv', 'UV ' + Math.round(uv)]);
    if (mn <= 5) out.push(['b', '🥶', 'a.cold', Math.round(mn) + '°']);
    return out;
  }

  /* ---------- helpers ---------- */
  const DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const dirName = d => T('d.' + DIRS[Math.round(((d % 360) + 360) % 360 / 45) % 8]);
  const uvLvl = u => u < 3 ? ['uv.low', '#3ee07a'] : u < 6 ? ['uv.mod', '#ffd34d'] : u < 8 ? ['uv.high', '#ff9f43'] : u < 11 ? ['uv.vhigh', '#ff5d5d'] : ['uv.ext', '#c86bff'];
  const dustLvl = d => d < 50 ? 'dust.low' : d < 150 ? 'dust.mod' : d < 500 ? 'dust.high' : 'dust.vhigh';
  function interp(t) {
    const hs = D().hours, i = clamp(Math.floor(t), 0, hs.length - 1), j = Math.min(i + 1, hs.length - 1), f = t - i, a = hs[i], b = hs[j];
    const L = (k) => (a[k] == null || b[k] == null) ? (a[k] != null ? a[k] : b[k]) : a[k] + (b[k] - a[k]) * f;
    let dd = b.dir - a.dir; if (dd > 180) dd -= 360; if (dd < -180) dd += 360;
    return { temp: L('temp'), cloud: L('cloud'), precip: L('precip'), wind: L('wind'), gust: L('gust'), vis: L('vis'), dust: L('dust'), hum: L('hum'), dir: a.dir + dd * f, code: f < 0.5 ? a.code : b.code, isDay: a.isDay };
  }
  const nowIndex = () => { const d = D(); return clamp((Date.now() + d.utcOffset * 1000 - parseT(d.hours[0].t)) / 36e5, 0, d.hours.length - 1); };

  /* ---------- scene ---------- */
  let scene, noGL = false;
  try { scene = createWeatherScene($('scene')); } catch (e) { noGL = true; scene = { setTarget() { }, jump() { }, frame() { }, setCountry() { } }; $('viewBtn').style.display = 'none'; }
  const mapv = createMapView($('map'), window.GW_MAP);
  mapv.onCity = id => { if (id === st.city) { setView('scene'); } else selectCity(id); };
  const tzOf = c => (st.data && st.data[c.id] ? st.data[c.id].utcOffset / 3600 : c.tz);
  const mapT = () => st.t + (3 - tzOf(city()));
  function fitMap() { const W = window.innerWidth, H = window.innerHeight, rtl = st.lang === 'ar'; mapv.setFitBox({ x0: rtl ? 20 : 374, x1: rtl ? W - 374 : W - 20, y0: 76, y1: H - 300 }); }
  function setView(v) { if (noGL) v = 'map'; st.view = v; document.body.classList.toggle('mapMode', v === 'map'); if (v === 'map') fitMap(); renderView(); }
  function renderView() {
    $('viewBtn').textContent = st.view === 'map' ? '🏜️  ' + T('sceneView') : '🗺️  ' + T('mapView');
    const L = mapv.layers(); document.querySelectorAll('#layers button').forEach(b => { b.textContent = T('l.' + b.dataset.l); b.classList.toggle('on', !!L[b.dataset.l]); });
    const st2 = mapv.TSTOPS.filter(x => x[0] <= 50), g = st2.map(x => `rgb(${x[1].join(',')}) ${(x[0] / 50 * 100).toFixed(0)}%`).join(',');
    $('legend').innerHTML = `<div>${T('legendTemp')}</div><div class="gb" style="background:linear-gradient(90deg,${g})"></div><div class="lb"><span>0</span><span>10</span><span>20</span><span>30</span><span>40</span><span>50</span></div>` +
      `<div class="rk"><span>${T('legendRain')}:</span><span><i style="background:#50d2ff"></i>${T('rainLight')}</span><span><i style="background:#2878ff"></i>${T('rainMod')}</span><span><i style="background:#ffd400"></i>${T('rainHeavy')}</span><span><i style="background:#ff3c3c"></i>${T('rainVery')}</span></div>` +
      `<div class="rk"><span><i style="background:#d6a058"></i>${T('l.dust')}</span><span><i style="background:#fff"></i>${T('l.cloud')}</span></div><div style="margin-top:8px">${T('mapHint')}</div>`;
  }
  $('viewBtn').onclick = () => setView(st.view === 'map' ? 'scene' : 'map');
  document.querySelectorAll('#layers button').forEach(b => b.onclick = () => { const L = mapv.layers(); mapv.setLayers({ [b.dataset.l]: !L[b.dataset.l] }); renderView(); });
  window.addEventListener('resize', () => { if (st.view === 'map') fitMap(); });
  function sceneParams(t) {
    const d = D(), hs = d.hours, di = clamp(Math.floor(t / 24), 0, d.days.length - 1), day = d.days[di];
    const sr = GW.hoursOf(day.sunrise), ss = GW.hoursOf(day.sunset), lt = (t % 24 + 24) % 24;
    let elev, az;
    if (lt >= sr && lt <= ss) { const f = (lt - sr) / (ss - sr); elev = Math.sin(Math.PI * f) * 0.85; az = f; }
    else { const nl = 24 - (ss - sr); const nf = ((lt - ss + 24) % 24) / nl; elev = -Math.sin(Math.PI * nf) * 0.6; az = 1 + nf; }
    const h = interp(t), c = cond(Object.assign({}, h, { code: h.code, isDay: 1 }));
    let dust = 0;
    if (h.dust != null) dust = Math.max(dust, clamp((h.dust - 80) / 900, 0, 1));
    if (h.vis != null && h.hum < 75) dust = Math.max(dust, clamp((9000 - h.vis) / 8500, 0, 1));
    let fog = (c === 'fog') ? clamp((2000 - (h.vis || 500)) / 1800, 0.5, 1) : 0;
    if (fog) dust = 0;
    let rain = clamp(h.precip / 5, 0, 1); if (rain > 0 && rain < 0.15) rain = 0.15;
    const thunder = h.code >= 95 ? 1 : 0;
    return { elev, az, cloud: clamp(h.cloud / 100, 0, 1), rain, dust, fog, wind: h.wind || 0, windDir: h.dir || 0, thunder, heat: clamp((h.temp - 38) / 10, 0, 1) };
  }

  /* ---------- rendering UI ---------- */
  function applyLang() {
    const html = document.documentElement; html.lang = st.lang; html.dir = st.lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-t]').forEach(e => { e.textContent = T(e.dataset.t); });
    $('langBtn').textContent = T('langBtn'); mapv.setLang(st.lang); renderView(); if (st.view === 'map') fitMap(); renderAll();
  }
  function renderStatus() {
    const dot = $('dot'); let s;
    if (st.src === 'live') { s = T('live') + ' · ' + T('updated', fmtTime(st.updatedAt + (D() ? D().utcOffset * 1000 : 0))); dot.className = 'dotLive'; }
    else if (st.src === 'cache') { s = T('cached', fmt(st.updatedAt + 3 * 36e5, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })); dot.className = 'dotLive off'; }
    else if (st.src === 'sample') { s = T('sample'); dot.className = 'dotLive off'; }
    else { s = T('loading'); dot.className = 'dotLive off'; }
    $('statusTxt').textContent = s; $('status').title = T('refresh');
  }
  function renderCityBtn() { mapv.setSelected(st.city); const c = city(); $('cbFlag').textContent = ctry(c.c).flag; $('cbName').textContent = c[st.lang]; }
  function renderNow() {
    const d = D(); if (!d) return; const c = city(), i = clamp(Math.floor(st.t), 0, d.hours.length - 1), h = d.hours[i], di = Math.floor(i / 24), day = d.days[di];
    $('nPlace').innerHTML = `<span class="cc ltr">${ctry(c.c).flag}</span>  ${ctry(c.c)[st.lang]}`; $('nCity').textContent = c[st.lang];
    const ms = parseT(h.t);
    $('nWhen').textContent = fmt(ms, { weekday: 'long', day: 'numeric', month: 'long' }) + ' · ' + fmtTime(ms);
    $('nNow').style.display = Math.abs(st.t - nowIndex()) < 1 ? '' : 'none';
    $('nTemp').innerHTML = Math.round(h.temp) + '<sup>°C</sup>';
    const cn = cond(h); $('nIcon').innerHTML = icon(cn); $('nCond').textContent = T('c.' + cn);
    $('nFeels').textContent = T('feelsLike', Math.round(h.feels) + '°');
    $('mHum').textContent = r0(h.hum) + '%'; $('bHum').style.width = clamp(h.hum, 0, 100) + '%';
    $('mWind').innerHTML = `<span class="ltr">${r0(h.wind)}</span> ${T('kmh')} · ${dirName(h.dir)}`;
    $('mDirA').style.transform = `rotate(${(h.dir + 90) % 360}deg)`;
    $('mGust').textContent = T('gusts') + ' ' + r0(h.gust) + ' ' + T('kmh');
    const ul = uvLvl(h.uv || 0); $('mUv').textContent = (h.uv || 0).toFixed(0); $('mUvL').textContent = T(ul[0]); $('bUv').style.width = clamp((h.uv || 0) / 12 * 100, 3, 100) + '%'; $('bUv').style.background = ul[1];
    $('mVis').innerHTML = h.vis == null ? T('na') : h.vis >= 10000 ? T('visMore') : `<span class="ltr">${(h.vis / 1000).toFixed(1)}</span> ${T('km')}`;
    $('mDust').textContent = T('dust') + ': ' + (h.dust != null ? T(dustLvl(h.dust)) + ' (' + Math.round(h.dust) + ' ' + T('ugm3') + ')' : T('na'));
    $('mRise').textContent = fmtTime(parseT(day.sunrise)); $('mSet').textContent = fmtTime(parseT(day.sunset));
    renderAlerts(di);
    document.querySelectorAll('.day').forEach((e, k) => e.classList.toggle('sel', k === di));
  }
  let lastAlertDay = -1, lastAlertLang = '';
  function renderAlerts(di) {
    if (di === lastAlertDay && lastAlertLang === st.lang + st.city) return; lastAlertDay = di; lastAlertLang = st.lang + st.city;
    const a = alertsForDay(di), d = D(), ms = parseT(d.days[di].date + 'T12:00');
    $('alerts').innerHTML = `<h3>${T('alertsFor', fmt(ms, { weekday: 'long', day: 'numeric', month: 'short' }))}</h3>` +
      (a.length ? a.map(x => `<div class="al ${x[0]}"><span class="ic">${x[1]}</span><div>${T(x[2])}${x[3] ? `<div class="sub ltr">${x[3]}</div>` : ''}</div></div>`).join('') : `<div class="none">✅ ${T('noAlerts')}</div>`);
  }
  function renderDays() {
    const d = D(); if (!d) return; const ni = Math.floor(nowIndex() / 24);
    $('days').innerHTML = d.days.map((day, k) => {
      const ms = parseT(day.date + 'T12:00'), al = alertsForDay(k), w = al.find(x => x[0] === 'r') ? '#ff5d5d' : al.find(x => x[0] === 'o') ? '#ff9f43' : al.length ? '#ffd34d' : '';
      const name = k === ni ? T('today') : k === ni + 1 ? T('tomorrow') : fmt(ms, { weekday: 'short' });
      return `<button class="day" data-k="${k}">${w ? `<i class="warn" style="background:${w}"></i>` : ''}<div class="dn">${name}</div><div class="dd">${fmt(ms, { day: 'numeric', month: 'short' })}</div>${icon(dayCond(k))}<div class="tt ltr">${Math.round(day.tmax)}°<span>${Math.round(day.tmin)}°</span></div></button>`;
    }).join('');
    document.querySelectorAll('.day').forEach(e => e.onclick = () => {
      const k = +e.dataset.k, ni = nowIndex(); st.t = (k === Math.floor(ni / 24)) ? ni : k * 24 + 14; st.playing = false; renderCtrl(); renderNow(); scene.setTarget(sceneParams(st.t));
    });
  }
  function renderCtrl() {
    $('playBtn').innerHTML = st.playing ? '❚❚ ' + T('pause') : '▶ ' + T('play'); $('playBtn').classList.toggle('on', st.playing);
    $('speedBtn').textContent = T('speed') + ' ×' + st.speed;
  }
  function renderPicker() {
    const all = st.data;
    $('pk').innerHTML = `<h2>${T('chooseCity')}</h2>` + COUNTRIES.map(co => `<div class="ctry"><h4><span class="ltr">${co.flag}</span>${co[st.lang]}</h4><div class="cities">` +
      CITIES.filter(c => c.c === co.id).map(c => {
        const d = all && all[c.id]; let tp = '', ic = '';
        if (d) { const i = Math.floor(clamp((Date.now() + d.utcOffset * 1000 - parseT(d.hours[0].t)) / 36e5, 0, d.hours.length - 1)); const h = d.hours[i]; tp = Math.round(h.temp) + '°'; ic = icon(cond(h)); }
        return `<button class="ci ${c.id === st.city ? 'sel' : ''}" data-c="${c.id}">${ic}<div><div class="n">${c[st.lang]}</div><div class="x">${d ? T('c.' + cond(d.hours[Math.floor(clamp((Date.now() + d.utcOffset * 1000 - parseT(d.hours[0].t)) / 36e5, 0, d.hours.length - 1))])) : ''}</div></div><span class="tp ltr">${tp}</span></button>`;
      }).join('') + '</div></div>').join('');
    document.querySelectorAll('.ci').forEach(b => b.onclick = () => { selectCity(b.dataset.c); $('picker').classList.remove('open'); });
  }
  function selectCity(id) {
    st.city = id; try { localStorage.setItem('gw-city', id); } catch (e) { }
    st.t = nowIndex(); st.playing = false; lastAlertDay = -1; scene.setCountry(city().c, !!city().inland); renderAll(); scene.setTarget(sceneParams(st.t)); scene.jump();
  }
  function renderAll() { renderStatus(); renderCityBtn(); if (!D()) return; renderDays(); renderNow(); renderCtrl(); drawChart(); }

  /* ---------- chart ---------- */
  const cv = $('chart'), cx = cv.getContext('2d');
  function drawChart() {
    const d = D(); if (!d) return; const dpr = Math.min(window.devicePixelRatio || 1, 2), W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== W * dpr || cv.height !== H * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
    cx.setTransform(dpr, 0, 0, dpr, 0, 0); cx.clearRect(0, 0, W, H);
    const hs = d.hours, n = hs.length, rtl = st.lang === 'ar';
    const X = i => { const x = (i / (n - 1)) * (W - 16) + 8; return rtl ? W - x : x; };
    const temps = hs.map(h => h.temp), mx = Math.max(...temps) + 1, mn = Math.min(...temps) - 1, Y = v => 14 + (1 - (v - mn) / (mx - mn)) * (H - 40);
    // day/night shading
    d.days.forEach((day, k) => {
      const sr = k * 24 + GW.hoursOf(day.sunrise), ss = k * 24 + GW.hoursOf(day.sunset);
      cx.fillStyle = 'rgba(255,215,120,.07)'; const a = X(sr), b = X(ss); cx.fillRect(Math.min(a, b), 0, Math.abs(b - a), H - 18);
      cx.strokeStyle = 'rgba(255,255,255,.15)'; cx.beginPath(); cx.moveTo(X(k * 24), 0); cx.lineTo(X(k * 24), H - 18); cx.stroke();
    });
    // dust band
    hs.forEach((h, i) => { const c = cond(h); if (c === 'dust' || c === 'dustStorm' || c === 'haze') { cx.fillStyle = c === 'dustStorm' ? 'rgba(217,165,96,.45)' : 'rgba(217,165,96,.2)'; cx.fillRect(Math.min(X(i), X(i + 1)), H - 24, Math.abs(X(i + 1) - X(i)) + 0.5, 5); } });
    // rain bars
    hs.forEach((h, i) => { if (h.precip > 0.05) { const bh = Math.min(30, h.precip * 6); cx.fillStyle = 'rgba(92,200,255,.6)'; cx.fillRect(X(i) - 1.5, H - 19 - bh, 3, bh); } });
    // temp line
    const grad = cx.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, 'rgba(255,170,70,.45)'); grad.addColorStop(1, 'rgba(255,170,70,0)');
    cx.beginPath(); hs.forEach((h, i) => { i ? cx.lineTo(X(i), Y(h.temp)) : cx.moveTo(X(i), Y(h.temp)); }); cx.lineTo(X(n - 1), H - 18); cx.lineTo(X(0), H - 18); cx.closePath(); cx.fillStyle = grad; cx.fill();
    cx.beginPath(); hs.forEach((h, i) => { i ? cx.lineTo(X(i), Y(h.temp)) : cx.moveTo(X(i), Y(h.temp)); }); cx.strokeStyle = '#ffc861'; cx.lineWidth = 2; cx.stroke();
    // labels: max/min per day
    cx.font = '600 11px Segoe UI, -apple-system, Tahoma, sans-serif'; cx.fillStyle = 'rgba(255,255,255,.85)'; cx.textAlign = 'center';
    d.days.forEach((day, k) => {
      const seg = hs.slice(k * 24, k * 24 + 24); let im = 0; seg.forEach((h, j) => { if (h.temp > seg[im].temp) im = j; });
      cx.fillText(Math.round(seg[im].temp) + '°', X(k * 24 + im), Y(seg[im].temp) - 5);
      cx.fillStyle = 'rgba(255,255,255,.55)'; cx.font = '11px Segoe UI, -apple-system, Tahoma, sans-serif';
      [6, 12, 18].forEach(hh => cx.fillText(fmtTime(Date.UTC(2000, 0, 1, hh)).replace(':00', ''), X(k * 24 + hh), H - 4));
      cx.fillStyle = 'rgba(255,255,255,.85)'; cx.font = '600 11px Segoe UI, -apple-system, Tahoma, sans-serif';
    });
    // now marker
    const ni = nowIndex(); cx.strokeStyle = 'rgba(255,255,255,.5)'; cx.setLineDash([3, 3]); cx.beginPath(); cx.moveTo(X(ni), 0); cx.lineTo(X(ni), H - 18); cx.stroke(); cx.setLineDash([]);
    // playhead
    const px = X(st.t), h = interp(st.t); cx.strokeStyle = '#fff'; cx.lineWidth = 2; cx.beginPath(); cx.moveTo(px, 0); cx.lineTo(px, H - 18); cx.stroke();
    cx.fillStyle = '#fff'; cx.beginPath(); cx.arc(px, Y(h.temp), 6, 0, Math.PI * 2); cx.fill(); cx.fillStyle = '#ffc861'; cx.beginPath(); cx.arc(px, Y(h.temp), 3.5, 0, Math.PI * 2); cx.fill();
  }
  function tFromX(clientX) {
    const r = cv.getBoundingClientRect(); let f = (clientX - r.left - 8) / (r.width - 16); if (st.lang === 'ar') f = 1 - f;
    return clamp(f, 0, 1) * (D().hours.length - 1);
  }
  $('chartWrap').addEventListener('pointerdown', e => { if (!D()) return; st.dragging = true; st.playing = false; $('chartWrap').setPointerCapture(e.pointerId); st.t = tFromX(e.clientX); renderCtrl(); });
  $('chartWrap').addEventListener('pointermove', e => { if (st.dragging) st.t = tFromX(e.clientX); });
  $('chartWrap').addEventListener('pointerup', () => { st.dragging = false; });

  /* ---------- controls ---------- */
  $('playBtn').onclick = () => { st.playing = !st.playing; if (st.playing && st.t >= D().hours.length - 1.01) st.t = 0; renderCtrl(); };
  const SPEEDS = [1, 3, 6, 12]; $('speedBtn').onclick = () => { st.speed = SPEEDS[(SPEEDS.indexOf(st.speed) + 1) % SPEEDS.length]; renderCtrl(); };
  $('nowBtn').onclick = () => { st.t = nowIndex(); st.playing = false; renderCtrl(); };
  $('langBtn').onclick = () => { st.lang = st.lang === 'en' ? 'ar' : 'en'; lastAlertDay = -1; applyLang(); };
  $('cityBtn').onclick = () => { renderPicker(); $('picker').classList.add('open'); };
  $('picker').onclick = e => { if (e.target.id === 'picker') $('picker').classList.remove('open'); };
  $('status').onclick = () => load(true);
  window.addEventListener('keydown', e => {
    if (!D()) return; const dir = st.lang === 'ar' ? -1 : 1;
    if (e.key === 'ArrowRight') { st.t = clamp(st.t + dir, 0, D().hours.length - 1); st.playing = false; renderCtrl(); }
    if (e.key === 'ArrowLeft') { st.t = clamp(st.t - dir, 0, D().hours.length - 1); st.playing = false; renderCtrl(); }
    if (e.key === ' ') { $('playBtn').click(); e.preventDefault(); }
    if (e.key === 'Escape') $('picker').classList.remove('open');
  });
  window.addEventListener('resize', () => drawChart());

  /* ---------- data loading ---------- */
  function setData(data, src, at, grid) { const first = !st.data; st.data = data; st.grid = grid || GW.sampleGrid(data); mapv.setData(st.grid, data, CITIES); st.src = src; st.updatedAt = at; if (first) st.t = nowIndex(); lastAlertDay = -1; renderAll(); scene.setTarget(sceneParams(st.t)); if (first) scene.jump(); }
  async function load(force) {
    st.src = st.data ? st.src : 'loading'; renderStatus();
    if (!force) { try { const c = JSON.parse(localStorage.getItem('gw-cache') || 'null'); if (c && c.data && Date.now() - c.at < 36 * 36e5) setData(c.data, 'cache', c.at); } catch (e) { } }
    try {
      const live = await GW.fetchLive(); const at = Date.now();
      try { localStorage.setItem('gw-cache', JSON.stringify({ at, data: live })); } catch (e) { }
      let grid = null; try { grid = await GW.fetchGrid(); } catch (e) { grid = null; }
      setData(live, 'live', at, grid);
    } catch (e) {
      st.err = String((e && e.message) || e); setTimeout(() => load(true), 20000);
      if (!st.data) setData(GW.sampleAll(), 'sample', Date.now());
    }
  }
  if (window.GW_EMBED_SAMPLE) { setData(GW.sampleAll(), 'sample', Date.now()); } else { load(false); }
  setInterval(() => { if (st.src !== 'sample') load(true); }, 60 * 60 * 1000);

  /* ---------- loop ---------- */
  let last = performance.now(), lastHour = -1, chartTick = 0;
  function loop(now) {
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (D()) {
      if (st.playing) { st.t += dt * st.speed; if (st.t >= D().hours.length - 1) { st.t = D().hours.length - 1; st.playing = false; renderCtrl(); } }
      scene.setTarget(sceneParams(st.t));
      const hi = Math.floor(st.t); if (hi !== lastHour) { lastHour = hi; renderNow(); }
      if ((chartTick += dt) > 0.05 || st.dragging) { chartTick = 0; drawChart(); }
    }
    if (st.view === 'map') { if (D()) mapv.setTime(mapT()); mapv.frame(dt); } else scene.frame(dt);
    requestAnimationFrame(loop);
  }
  scene.setCountry(city().c, !!city().inland); applyLang(); setView('map'); requestAnimationFrame(loop);
  window.GW_APP = { st, mapv, selectCity, setView, setLang: l => { st.lang = l; applyLang(); }, setT: t => { st.t = t; } };
})();
