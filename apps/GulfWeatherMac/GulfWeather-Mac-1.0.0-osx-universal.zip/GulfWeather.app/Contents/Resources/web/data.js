/* Gulf Weather - cities, live data (Open-Meteo, no key) and offline sample. by Kankon · kankon.net */
(function () {
  const COUNTRIES = [
    { id: 'KW', en: 'Kuwait', ar: 'الكويت', flag: 'KW' },
    { id: 'SA', en: 'Saudi Arabia', ar: 'السعودية', flag: 'SA' },
    { id: 'AE', en: 'UAE', ar: 'الإمارات', flag: 'AE' },
    { id: 'QA', en: 'Qatar', ar: 'قطر', flag: 'QA' },
    { id: 'BH', en: 'Bahrain', ar: 'البحرين', flag: 'BH' },
    { id: 'OM', en: 'Oman', ar: 'عُمان', flag: 'OM' }
  ];
  // climate: Nov baseline used only for the offline sample
  const CITIES = [
    { id: 'kuwait', c: 'KW', en: 'Kuwait City', ar: 'مدينة الكويت', lat: 29.3759, lon: 47.9774, tz: 3, cl: [27, 15, 45, 16] },
    { id: 'jahra', c: 'KW', en: 'Al Jahra', ar: 'الجهراء', lat: 29.3375, lon: 47.6581, tz: 3, cl: [27, 13, 40, 17] },
    { id: 'ahmadi', c: 'KW', en: 'Al Ahmadi', ar: 'الأحمدي', lat: 29.0769, lon: 48.0838, tz: 3, cl: [27, 16, 50, 16] },
    { id: 'riyadh', inland: true, c: 'SA', en: 'Riyadh', ar: 'الرياض', lat: 24.7136, lon: 46.6753, tz: 3, cl: [28, 15, 30, 12] },
    { id: 'jeddah', c: 'SA', en: 'Jeddah', ar: 'جدة', lat: 21.4858, lon: 39.1925, tz: 3, cl: [33, 24, 62, 13] },
    { id: 'dammam', c: 'SA', en: 'Dammam', ar: 'الدمام', lat: 26.4207, lon: 50.0888, tz: 3, cl: [29, 18, 58, 15] },
    { id: 'makkah', inland: true, c: 'SA', en: 'Makkah', ar: 'مكة المكرمة', lat: 21.3891, lon: 39.8579, tz: 3, cl: [34, 23, 45, 9] },
    { id: 'madinah', inland: true, c: 'SA', en: 'Madinah', ar: 'المدينة المنورة', lat: 24.5247, lon: 39.5692, tz: 3, cl: [30, 18, 28, 11] },
    { id: 'dubai', c: 'AE', en: 'Dubai', ar: 'دبي', lat: 25.2048, lon: 55.2708, tz: 4, cl: [31, 22, 60, 13] },
    { id: 'abudhabi', c: 'AE', en: 'Abu Dhabi', ar: 'أبوظبي', lat: 24.4539, lon: 54.3773, tz: 4, cl: [31, 21, 60, 14] },
    { id: 'sharjah', c: 'AE', en: 'Sharjah', ar: 'الشارقة', lat: 25.3463, lon: 55.4209, tz: 4, cl: [31, 20, 58, 12] },
    { id: 'doha', c: 'QA', en: 'Doha', ar: 'الدوحة', lat: 25.2854, lon: 51.531, tz: 3, cl: [30, 21, 58, 15] },
    { id: 'manama', c: 'BH', en: 'Manama', ar: 'المنامة', lat: 26.2235, lon: 50.5876, tz: 3, cl: [28, 21, 65, 16] },
    { id: 'muscat', c: 'OM', en: 'Muscat', ar: 'مسقط', lat: 23.588, lon: 58.3829, tz: 4, cl: [31, 23, 55, 11] },
    { id: 'salalah', c: 'OM', en: 'Salalah', ar: 'صلالة', lat: 17.0151, lon: 54.0924, tz: 4, cl: [30, 21, 60, 10] }
  ];

  const pad = n => String(n).padStart(2, '0');
  const iso = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:00`;
  const hoursOf = s => { const m = /T(\d\d):(\d\d)/.exec(s); return m ? +m[1] + +m[2] / 60 : 12; };

  // NOAA-style sunrise/sunset, returns local hours
  function sunTimes(lat, lon, tz, y, m, d) {
    const rad = Math.PI / 180, N = Math.floor(275 * m / 9) - Math.floor((m + 9) / 12) * (1 + Math.floor((y - 4 * Math.floor(y / 4) + 2) / 3)) + d - 30;
    function calc(rise) {
      const lh = lon / 15, t = N + ((rise ? 6 : 18) - lh) / 24, M = 0.9856 * t - 3.289;
      let L = M + 1.916 * Math.sin(M * rad) + 0.02 * Math.sin(2 * M * rad) + 282.634; L = (L + 360) % 360;
      let RA = Math.atan(0.91764 * Math.tan(L * rad)) / rad; RA = (RA + 360) % 360;
      RA += Math.floor(L / 90) * 90 - Math.floor(RA / 90) * 90; RA /= 15;
      const sd = 0.39782 * Math.sin(L * rad), cd = Math.cos(Math.asin(sd));
      const ch = (Math.cos(90.833 * rad) - sd * Math.sin(lat * rad)) / (cd * Math.cos(lat * rad));
      let H = rise ? 360 - Math.acos(ch) / rad : Math.acos(ch) / rad; H /= 15;
      const Tm = H + RA - 0.06571 * t - 6.622; return ((Tm - lh + tz) % 24 + 24) % 24;
    }
    return [calc(true), calc(false)];
  }

  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
  function hash(str) { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; }

  // Offline sample: realistic November pattern with a few events to show the animations
  const EVENTS = {
    kuwait: { 2: 'dust', 5: 'thunder', 6: 'cloudy' }, jahra: { 2: 'dust', 5: 'rain' }, ahmadi: { 2: 'dust', 5: 'thunder' },
    riyadh: { 2: 'dust', 3: 'haze' }, jeddah: { 4: 'thunder', 5: 'cloudy' }, dammam: { 2: 'haze', 5: 'rain' },
    makkah: { 4: 'thunder' }, madinah: { 3: 'dust' }, dubai: { 1: 'fog', 6: 'rain', 7: 'cloudy' }, abudhabi: { 1: 'fog', 6: 'cloudy' },
    sharjah: { 1: 'fog', 6: 'rain' }, doha: { 3: 'haze', 6: 'cloudy' }, manama: { 5: 'rain', 6: 'cloudy' }, muscat: { 7: 'thunder' }, salalah: { 0: 'cloudy', 1: 'cloudy', 8: 'rain' }
  };
  function sample(city, startDate) {
    const r = rng(hash(city.id + '2026')), [tmx, tmn, hum0, wind0] = city.cl, ev = EVENTS[city.id] || {};
    const base = new Date(Date.UTC(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate()));
    const hours = [], days = [];
    for (let di = 0; di < 10; di++) {
      const dd = new Date(base.getTime() + di * 864e5), e = ev[di] || 'clear';
      const [sr, ss] = sunTimes(city.lat, city.lon, city.tz, dd.getUTCFullYear(), dd.getUTCMonth() + 1, dd.getUTCDate());
      const dmax = tmx + (r() - 0.5) * 3 - di * 0.15 + (e === 'dust' ? -1.5 : 0) + (e === 'thunder' || e === 'rain' ? -4 : 0);
      const dmin = tmn + (r() - 0.5) * 2 - di * 0.1;
      let dayCode = 0, psum = 0, wmax = 0, uvmax = 0, dmaxSeen = -99, dminSeen = 99;
      for (let h = 0; h < 24; h++) {
        const t = dd.getTime() + h * 36e5, hf = h;
        const ph = Math.cos(((hf - 15) / 24) * Math.PI * 2); // 1 at 3 PM
        let temp = (dmax + dmin) / 2 + ph * (dmax - dmin) / 2 + (r() - 0.5) * 0.4;
        let hum = hum0 - ph * 18 + (r() - 0.5) * 5;
        let wind = wind0 * (0.7 + 0.5 * Math.max(0, Math.sin((hf - 8) / 24 * Math.PI * 2))) + r() * 4;
        let dir = 300 + (r() - 0.5) * 50, cloud = r() < 0.15 ? 20 + r() * 30 : r() * 10, precip = 0, code = 0, vis = 20000 + r() * 4000, dust = 10 + r() * 30;
        const midday = hf >= 9 && hf <= 18;
        if (e === 'dust') { const peak = Math.exp(-Math.pow((hf - 14) / 4.5, 2)); wind = 22 + peak * 38 + r() * 6; dir = 320 + (r() - 0.5) * 20; vis = 9000 - peak * 8300; dust = 120 + peak * 1600; cloud = 10; }
        if (e === 'haze') { vis = 4500 + r() * 1500; dust = 220 + r() * 120; wind = wind * 1.4; }
        if (e === 'cloudy') { cloud = 60 + r() * 35; }
        if (e === 'rain' && hf >= 10 && hf <= 19) { cloud = 85 + r() * 15; precip = Math.max(0, Math.sin((hf - 10) / 9 * Math.PI)) * (1 + r() * 2); hum += 20; dir = 140 + r() * 40; }
        else if (e === 'rain') cloud = 50 + r() * 30;
        if (e === 'thunder' && hf >= 12 && hf <= 20) { cloud = 95; precip = Math.max(0, Math.sin((hf - 12) / 8 * Math.PI)) * (3 + r() * 5); hum += 25; wind = 25 + r() * 25; dir = 150 + r() * 30; }
        else if (e === 'thunder') cloud = 40 + r() * 40;
        if (e === 'fog' && hf <= 8) { vis = 400 + hf * 300; hum = 92 + r() * 6; }
        hum = Math.max(8, Math.min(100, hum)); if (e === 'thunder' || e === 'rain') temp -= precip * 0.6;
        // code
        if (e === 'thunder' && precip > 0.5) code = 95; else if (precip > 2.5) code = 63; else if (precip > 0.3) code = 61;
        else if (e === 'fog' && vis < 1000) code = 45; else if (cloud > 85) code = 3; else if (cloud > 50) code = 2; else if (cloud > 20) code = 1;
        const isDay = hf + 0.5 > sr && hf + 0.5 < ss ? 1 : 0;
        const uv = isDay ? Math.max(0, Math.sin(Math.PI * (hf + 0.5 - sr) / (ss - sr))) * (city.lat < 22 ? 8.5 : 6.5) * (1 - cloud / 160) : 0;
        const gust = wind * (1.35 + r() * 0.25);
        hours.push({ t: iso(new Date(t)), temp: +temp.toFixed(1), feels: +(temp + (hum > 60 && temp > 26 ? (hum - 60) * 0.12 : 0) - wind * 0.04).toFixed(1), hum: Math.round(hum), wind: +wind.toFixed(1), gust: +gust.toFixed(1), dir: Math.round((dir + 360) % 360), code, cloud: Math.round(Math.min(100, cloud)), precip: +precip.toFixed(1), uv: +uv.toFixed(1), vis: Math.round(vis), dust: Math.round(dust), isDay });
        psum += precip; wmax = Math.max(wmax, wind); uvmax = Math.max(uvmax, uv); dmaxSeen = Math.max(dmaxSeen, temp); dminSeen = Math.min(dminSeen, temp);
        if (midday) dayCode = Math.max(dayCode, code);
      }
      const ds = iso(dd).slice(0, 10), hm = x => `${pad(Math.floor(x))}:${pad(Math.round((x % 1) * 60) % 60)}`;
      days.push({ date: ds, code: e === 'dust' ? 1 : dayCode, tmax: +dmaxSeen.toFixed(1), tmin: +dminSeen.toFixed(1), sunrise: ds + 'T' + hm(sr), sunset: ds + 'T' + hm(ss), uvmax: +uvmax.toFixed(1), precip: +psum.toFixed(1), windmax: +wmax.toFixed(1) });
    }
    return { hours, days, utcOffset: city.tz * 3600, sample: true };
  }

  const HOURLY = 'temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_gusts_10m,wind_direction_10m,weather_code,cloud_cover,precipitation,uv_index,visibility,is_day';
  const DAILY = 'weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,wind_speed_10m_max';

  async function fetchJSON(url, ms) {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), ms || 15000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json(); } finally { clearTimeout(tm); }
  }

  async function fetchLive() {
    const lat = CITIES.map(c => c.lat).join(','), lon = CITIES.map(c => c.lon).join(',');
    const fc = await fetchJSON(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=${HOURLY}&daily=${DAILY}&forecast_days=10&timezone=auto`);
    let aq = null;
    try { aq = await fetchJSON(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&hourly=dust,pm10&forecast_days=7&timezone=auto`); } catch (e) { aq = null; }
    const fcs = Array.isArray(fc) ? fc : [fc], aqs = aq ? (Array.isArray(aq) ? aq : [aq]) : [];
    const out = {};
    CITIES.forEach((c, i) => {
      const f = fcs[i], H = f.hourly, D = f.daily, a = aqs[i] && aqs[i].hourly;
      const dustBy = {}; if (a) a.time.forEach((t, k) => { dustBy[t] = a.dust[k]; });
      const hours = H.time.map((t, k) => ({
        t, temp: H.temperature_2m[k], feels: H.apparent_temperature[k], hum: H.relative_humidity_2m[k], wind: H.wind_speed_10m[k], gust: H.wind_gusts_10m[k],
        dir: H.wind_direction_10m[k], code: H.weather_code[k], cloud: H.cloud_cover[k], precip: H.precipitation[k], uv: H.uv_index[k],
        vis: H.visibility ? H.visibility[k] : null, dust: dustBy[t] != null ? dustBy[t] : null, isDay: H.is_day[k]
      }));
      const days = D.time.map((d, k) => ({ date: d, code: D.weather_code[k], tmax: D.temperature_2m_max[k], tmin: D.temperature_2m_min[k], sunrise: D.sunrise[k], sunset: D.sunset[k], uvmax: D.uv_index_max[k], precip: D.precipitation_sum[k], windmax: D.wind_speed_10m_max[k] }));
      out[c.id] = { hours, days, utcOffset: f.utc_offset_seconds, sample: false };
    });
    return out;
  }

  function sampleAll() { const now = new Date(); const out = {}; CITIES.forEach(c => { out[c.id] = sample(c, new Date(now.getTime() + c.tz * 36e5)); }); return out; }

  window.GW = { COUNTRIES, CITIES, fetchLive, sampleAll, hoursOf, sunTimes };
})();

/* ---------- map grid (2° over the Gulf), times fixed to UTC+3 ---------- */
(function () {
  const LONS = [], LATS = []; for (let x = 34; x <= 60; x += 2) LONS.push(x); for (let y = 12; y <= 32; y += 2) LATS.push(y);
  const NX = LONS.length, NY = LATS.length;
  const pad = n => String(n).padStart(2, '0');

  async function fetchGrid() {
    const lat = [], lon = []; LATS.forEach(y => LONS.forEach(x => { lat.push(y); lon.push(x); }));
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.join(',')}&longitude=${lon.join(',')}&hourly=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,precipitation&forecast_days=10&timezone=Asia%2FRiyadh`;
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 30000);
    let r; try { r = await fetch(url, { signal: ctl.signal }); } finally { clearTimeout(tm); }
    if (!r.ok) throw new Error('HTTP ' + r.status); const a = await r.json();
    const n = a[0].hourly.time.length, P = NX * NY, mk = () => new Float32Array(n * P);
    const g = { NX, NY, LONS, LATS, n, start: a[0].hourly.time[0], temp: mk(), u: mk(), v: mk(), cloud: mk(), precip: mk(), dust: null };
    a.forEach((p, i) => { const H = p.hourly; for (let t = 0; t < n; t++) {
      const o = t * P + i, sp = H.wind_speed_10m[t] || 0, dir = (H.wind_direction_10m[t] || 0) * Math.PI / 180;
      g.temp[o] = H.temperature_2m[t]; g.u[o] = -sp * Math.sin(dir); g.v[o] = -sp * Math.cos(dir); g.cloud[o] = H.cloud_cover[t]; g.precip[o] = H.precipitation[t]; } });
    return g;
  }

  // offline sample grid built from the sample city data + smooth synthetic patterns
  function sampleGrid(cities) {
    const n = 240, P = NX * NY, mk = () => new Float32Array(n * P);
    const g = { NX, NY, LONS, LATS, n, temp: mk(), u: mk(), v: mk(), cloud: mk(), precip: mk(), dust: mk(), sample: true };
    const C = window.GW.CITIES.map(c => ({ c, d: cities[c.id], sh: c.tz - 3 }));
    for (let t = 0; t < n; t++) {
      for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) {
        const lon = LONS[i], lat = LATS[j], o = t * P + j * NX + i;
        const lh = ((t + (lon - 45) / 15) % 24 + 24) % 24, ph = Math.cos((lh - 15) / 24 * Math.PI * 2);
        const sea = (lon > 49 && lon < 56 && lat > 24 && lat < 29.5 && lon - 49 > (29.5 - lat) * 0.4) || lat < 15 || (lon < 39 && lat < 27) || (lon > 57 && lat < 22);
        let temp = 33 - (lat - 14) * 0.55 + ph * (sea ? 2 : 7) - (lat > 30 ? 3 : 0);
        let ang = (315 + Math.sin(t / 30 + lon / 6) * 30) * Math.PI / 180, sp = 14 + 6 * Math.sin(t / 17 + lat / 3);
        // a slow-moving low that brings clouds/rain across
        const cx = 36 + ((t / 240) * 30), cy = 26 - (t / 240) * 6, dx = lon - cx, dy = lat - cy, rr = Math.hypot(dx, dy);
        const sw = Math.exp(-rr * rr / 40);
        let u = -sp * Math.sin(ang), v = -sp * Math.cos(ang);
        u += -dy * sw * 6; v += dx * sw * 6;
        let cloud = Math.max(0, sw * 100 * (0.6 + 0.4 * Math.sin(t / 5 + lon)) + (lat < 18 ? 30 : 0) * (0.5 + 0.5 * Math.sin(t / 9)));
        let precip = sw > 0.8 ? (sw - 0.8) * 10 : 0, dust = 30;
        // blend with nearby cities (inverse distance)
        let ws = 0, tt = 0, uu = 0, vv = 0, cc = 0, pp = 0, du = 0;
        C.forEach(({ c, d, sh }) => {
          const k = t + sh; if (k < 0 || k >= d.hours.length) return; const h = d.hours[k];
          const dd = Math.hypot((c.lon - lon) * 0.92, c.lat - lat), w = 1 / Math.pow(dd + 0.6, 3);
          const a2 = h.dir * Math.PI / 180; ws += w; tt += w * h.temp; uu += w * -h.wind * Math.sin(a2); vv += w * -h.wind * Math.cos(a2); cc += w * h.cloud; pp += w * h.precip; du += w * (h.dust || 30);
        });
        const near = Math.min(1, ws * 1.2);
        g.temp[o] = temp * (1 - near) + (tt / ws) * near; g.u[o] = u * (1 - near) + (uu / ws) * near; g.v[o] = v * (1 - near) + (vv / ws) * near;
        g.cloud[o] = Math.min(100, cloud * (1 - near) + (cc / ws) * near); g.precip[o] = precip * (1 - near) + (pp / ws) * near; g.dust[o] = 30 * (1 - near) + (du / ws) * near;
      }
    }
    return g;
  }
  Object.assign(window.GW, { fetchGrid, sampleGrid, GRID: { LONS, LATS, NX, NY } });
})();
