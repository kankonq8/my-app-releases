/* Gulf Weather strings (en / ar). Same keys in both. */
window.GW_STRINGS = {
  en: {
    appName: 'Gulf Weather', byline: 'by Kankon · kankon.net', dataBy: 'Weather data: Open-Meteo', langBtn: 'العربية',
    live: 'Live', updated: 'Updated {0}', sample: 'Sample data (offline)', cached: 'Saved forecast · {0}', loading: 'Loading forecast…', refresh: 'Refresh',
    chooseCity: 'Choose a city', now: 'Now', play: 'Play', pause: 'Pause', speed: 'Speed', feelsLike: 'Feels like {0}',
    humidity: 'Humidity', wind: 'Wind', gusts: 'Gusts', uv: 'UV index', visibility: 'Visibility', dust: 'Dust', rain: 'Rain', sunrise: 'Sunrise', sunset: 'Sunset',
    kmh: 'km/h', km: 'km', visMore: '10+ km', mm: 'mm', ugm3: 'µg/m³', today: 'Today', tomorrow: 'Tomorrow', tenDays: '10-day forecast', noAlerts: 'No weather alerts',
    'c.clear': 'Clear', 'c.clearNight': 'Clear night', 'c.partly': 'Partly cloudy', 'c.cloudy': 'Cloudy', 'c.overcast': 'Overcast', 'c.fog': 'Fog',
    'c.drizzle': 'Drizzle', 'c.rain': 'Rain', 'c.heavyRain': 'Heavy rain', 'c.thunder': 'Thunderstorm', 'c.dust': 'Dusty', 'c.dustStorm': 'Dust storm', 'c.haze': 'Hazy',
    'uv.low': 'Low', 'uv.mod': 'Moderate', 'uv.high': 'High', 'uv.vhigh': 'Very high', 'uv.ext': 'Extreme',
    'dust.low': 'Low', 'dust.mod': 'Moderate', 'dust.high': 'High', 'dust.vhigh': 'Very high', 'na': '—',
    'a.heatExt': 'Extreme heat', 'a.heat': 'Heat warning', 'a.hot': 'Very hot: drink water', 'a.dustStorm': 'Dust storm: low visibility', 'a.dust': 'Dust / haze',
    'a.wind': 'Strong wind', 'a.thunder': 'Thunderstorm', 'a.heavyRain': 'Heavy rain: flooding risk', 'a.fog': 'Fog: low visibility on roads', 'a.uv': 'Very high UV', 'a.uvExt': 'Extreme UV', 'a.cold': 'Cold night',
    'd.N': 'N', 'd.NE': 'NE', 'd.E': 'E', 'd.SE': 'SE', 'd.S': 'S', 'd.SW': 'SW', 'd.W': 'W', 'd.NW': 'NW',
    alertsFor: 'Alerts · {0}', mapView: 'Map', sceneView: '3D view', 'l.temp': 'Temperature', 'l.wind': 'Wind', 'l.cloud': 'Clouds & rain', 'l.dust': 'Dust', legendTemp: 'Temperature °C', legendRain: 'Rain', rainLight: 'Light', rainMod: 'Moderate', rainHeavy: 'Heavy', rainVery: 'Very heavy', mapHint: 'Click a city · scroll to zoom · drag to move', dragHint: 'Drag the timeline or press Play to watch the weather move'
  },
  ar: {
    appName: 'Gulf Weather', byline: 'من Kankon · kankon.net', dataBy: 'بيانات الطقس: Open-Meteo', langBtn: 'English',
    live: 'مباشر', updated: 'آخر تحديث {0}', sample: 'بيانات تجريبية (بدون إنترنت)', cached: 'توقعات محفوظة · {0}', loading: 'جاري تحميل التوقعات…', refresh: 'تحديث',
    chooseCity: 'اختر المدينة', now: 'الحين', play: 'تشغيل', pause: 'إيقاف مؤقت', speed: 'السرعة', feelsLike: 'الحرارة المحسوسة {0}',
    humidity: 'الرطوبة', wind: 'الرياح', gusts: 'الهبّات', uv: 'مؤشر الأشعة فوق البنفسجية (UV)', visibility: 'مدى الرؤية', dust: 'الغبار', rain: 'المطر', sunrise: 'الشروق', sunset: 'الغروب',
    kmh: 'كم/س', km: 'كم', visMore: 'أكثر من 10 كم', mm: 'ملم', ugm3: 'µg/m³', today: 'اليوم', tomorrow: 'بكرة', tenDays: 'توقعات 10 أيام', noAlerts: 'ما فيه تنبيهات طقس',
    'c.clear': 'صافي', 'c.clearNight': 'ليل صافي', 'c.partly': 'غائم جزئيًا', 'c.cloudy': 'غائم', 'c.overcast': 'غائم كليًا', 'c.fog': 'ضباب',
    'c.drizzle': 'رذاذ', 'c.rain': 'مطر', 'c.heavyRain': 'مطر غزير', 'c.thunder': 'عاصفة رعدية', 'c.dust': 'غبار', 'c.dustStorm': 'عاصفة غبارية', 'c.haze': 'غبار خفيف',
    'uv.low': 'منخفض', 'uv.mod': 'متوسط', 'uv.high': 'عالي', 'uv.vhigh': 'عالي جدًا', 'uv.ext': 'شديد',
    'dust.low': 'قليل', 'dust.mod': 'متوسط', 'dust.high': 'عالي', 'dust.vhigh': 'عالي جدًا', 'na': '—',
    'a.heatExt': 'حر شديد جدًا', 'a.heat': 'تنبيه حر', 'a.hot': 'حر شديد: اشرب ماي', 'a.dustStorm': 'عاصفة غبارية: الرؤية قليلة', 'a.dust': 'غبار وعجاج',
    'a.wind': 'رياح قوية', 'a.thunder': 'عاصفة رعدية', 'a.heavyRain': 'مطر غزير: احتمال تجمع مياه', 'a.fog': 'ضباب: الرؤية قليلة في الطرق', 'a.uv': 'أشعة UV عالية جدًا', 'a.uvExt': 'أشعة UV شديدة', 'a.cold': 'ليل بارد',
    'd.N': 'شمال', 'd.NE': 'شمال شرق', 'd.E': 'شرق', 'd.SE': 'جنوب شرق', 'd.S': 'جنوب', 'd.SW': 'جنوب غرب', 'd.W': 'غرب', 'd.NW': 'شمال غرب',
    alertsFor: 'تنبيهات · {0}', mapView: 'الخريطة', sceneView: 'عرض 3D', 'l.temp': 'الحرارة', 'l.wind': 'الرياح', 'l.cloud': 'الغيوم والمطر', 'l.dust': 'الغبار', legendTemp: 'الحرارة °C', legendRain: 'المطر', rainLight: 'خفيف', rainMod: 'متوسط', rainHeavy: 'غزير', rainVery: 'غزير جدًا', mapHint: 'اضغط على مدينة · مرّر العجلة للتكبير · اسحب للتحريك', dragHint: 'اسحب الخط الزمني أو اضغط «تشغيل» وشوف الطقس يتحرك'
  }
};
