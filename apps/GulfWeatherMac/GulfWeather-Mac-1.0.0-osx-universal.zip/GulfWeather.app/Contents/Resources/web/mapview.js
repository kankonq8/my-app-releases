/* Gulf Weather - animated weather map (temperature, wind flow, clouds & rain, dust). by Kankon · kankon.net */
(function () {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const TSTOPS = [[0, [59, 76, 192]], [10, [79, 154, 216]], [16, [72, 196, 196]], [21, [110, 210, 130]], [25, [190, 226, 100]], [29, [255, 224, 102]], [33, [255, 170, 70]], [37, [255, 112, 60]], [41, [226, 58, 58]], [46, [176, 23, 79]], [52, [110, 14, 92]]];
  function tcol(t) {
    if (t <= TSTOPS[0][0]) return TSTOPS[0][1];
    for (let i = 1; i < TSTOPS.length; i++) if (t <= TSTOPS[i][0]) { const a = TSTOPS[i - 1], b = TSTOPS[i], f = (t - a[0]) / (b[0] - a[0]); return [a[1][0] + (b[1][0] - a[1][0]) * f, a[1][1] + (b[1][1] - a[1][1]) * f, a[1][2] + (b[1][2] - a[1][2]) * f]; }
    return TSTOPS[TSTOPS.length - 1][1];
  }
  // value noise for cloud texture
  const NN = 64, NZ = new Float32Array(NN * NN); { let s = 12345; for (let i = 0; i < NN * NN; i++) { s = (s * 1664525 + 1013904223) >>> 0; NZ[i] = s / 4294967296; } }
  function noise(x, y) {
    const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const g = (a, b) => NZ[((b & 63) * NN) + (a & 63)];
    return (g(xi, yi) * (1 - sx) + g(xi + 1, yi) * sx) * (1 - sy) + (g(xi, yi + 1) * (1 - sx) + g(xi + 1, yi + 1) * sx) * sy;
  }
  const fbm = (x, y) => noise(x, y) * 0.55 + noise(x * 2.1, y * 2.1) * 0.3 + noise(x * 4.3, y * 4.3) * 0.15;

  window.createMapView = function (canvas, M) {
    const ctx = canvas.getContext('2d');
    const trail = document.createElement('canvas'), tctx = trail.getContext('2d');
    const K = M.k, S = M.s, X = lon => (lon - 34) * K * S, Y = lat => (33 - lat) * S;
    const shapes = M.shapes.map(s => ({ c: s.c, p: new Path2D(s.d) }));
    const RL = 28, RT = 38, RW = 145, RH = 121; // raster over lon 28..64, lat 8..38 (0.25°)
    const rast = { temp: document.createElement('canvas'), cloud: document.createElement('canvas'), dust: document.createElement('canvas') };
    Object.values(rast).forEach(c => { c.width = RW; c.height = RH; });
    let grid = null, cities = null, CITIES = [], tm = 0, lastRast = -1, layers = { temp: true, wind: true, cloud: true, dust: true }, sel = null, lang = 'en';
    let z = 1, ox = 0, oy = 0, W = 0, H = 0, dpr = 1, fitted = false, fitBox = null, time = 0;
    const P = [], PN = 1800;
    function spawn(p) { p.lon = 34 + Math.random() * 26; p.lat = 12 + Math.random() * 20; p.age = Math.floor(Math.random() * 90); p.max = 60 + Math.random() * 70; }
    for (let i = 0; i < PN; i++) { const p = {}; spawn(p); P.push(p); }

    function fit() {
      const b = fitBox || { x0: 370, y0: 70, x1: W - 20, y1: H - 300 };
      const lo0 = 36.5, lo1 = 60, la0 = 15.5, la1 = 31.5;
      const zw = (b.x1 - b.x0) / (X(lo1) - X(lo0)), zh = (b.y1 - b.y0) / (Y(la0) - Y(la1));
      z = Math.max(0.3, Math.min(zw, zh)); ox = (b.x0 + b.x1) / 2 - z * (X(lo0) + X(lo1)) / 2; oy = (b.y0 + b.y1) / 2 - z * (Y(la0) + Y(la1)) / 2;
      clearTrail();
    }
    function resize() {
      const w = canvas.clientWidth, h = canvas.clientHeight, d = Math.min(window.devicePixelRatio || 1, 2);
      if (w !== W || h !== H || d !== dpr) { W = w; H = h; dpr = d; canvas.width = w * d; canvas.height = h * d; trail.width = w * d; trail.height = h * d; if (!fitted) { fit(); fitted = true; } else clearTrail(); }
    }
    function clearTrail() { tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.clearRect(0, 0, trail.width, trail.height); }
    const sx = lon => X(lon) * z + ox, sy = lat => Y(lat) * z + oy;

    // snapshot of all fields at the current time (interpolated), then fast bilinear lookups
    let snap = null, snapT = -1;
    function makeSnap() {
      const g = grid, P2 = g.NX * g.NY, t0 = clamp(Math.floor(tm), 0, g.n - 1), t1 = Math.min(t0 + 1, g.n - 1), at = clamp(tm - t0, 0, 1);
      const pick = arr => { if (!arr) return null; const o = new Float32Array(P2), a = t0 * P2, b = t1 * P2; for (let i = 0; i < P2; i++) o[i] = arr[a + i] * (1 - at) + arr[b + i] * at; return o; };
      snap = { temp: pick(g.temp), u: pick(g.u), v: pick(g.v), cloud: pick(g.cloud), precip: pick(g.precip), dust: pick(g.dust) }; snapT = tm;
    }
    function sample(arr, lon, lat) {
      const NX = grid.NX; let fx = (lon - 34) * 0.5, fy = (lat - 12) * 0.5;
      if (fx < 0) fx = 0; else if (fx > NX - 1.001) fx = NX - 1.001; if (fy < 0) fy = 0; else if (fy > grid.NY - 1.001) fy = grid.NY - 1.001;
      const i = fx | 0, j = fy | 0, ax = fx - i, ay = fy - j, o = j * NX + i;
      return (arr[o] * (1 - ax) + arr[o + 1] * ax) * (1 - ay) + (arr[o + NX] * (1 - ax) + arr[o + NX + 1] * ax) * ay;
    }
    function cityHour(c, t) { const d = cities[c.id]; if (!d) return null; const k = clamp(Math.round(t + (c.tz - 3)), 0, d.hours.length - 1); return d.hours[k]; }
    function dustAt(lon, lat, t) {
      if (snap.dust) return sample(snap.dust, lon, lat);
      let ws = 0, s = 0; CITIES.forEach(c => { const h = cityHour(c, t); if (!h || h.dust == null) return; const d = Math.hypot((c.lon - lon) * 0.92, c.lat - lat), w = 1 / Math.pow(d + 0.6, 3); ws += w; s += w * h.dust; });
      const near = Math.min(1, ws * 1.2); return ws ? (s / ws) * near + 25 * (1 - near) : 25;
    }

    function buildRasters() {
      const it = ctxs => ctxs; const tc = rast.temp.getContext('2d'), cc = rast.cloud.getContext('2d'), dc = rast.dust.getContext('2d');
      const ti = tc.createImageData(RW, RH), ci = cc.createImageData(RW, RH), di = dc.createImageData(RW, RH);
      const drift = tm * 0.08;
      for (let y = 0; y < RH; y++) {
        const lat = RT - y * 0.25;
        for (let x = 0; x < RW; x++) {
          const lon = RL + x * 0.25, o = (y * RW + x) * 4, edge = 1;
          if (layers.temp) { const c = tcol(sample(snap.temp, lon, lat)); ti.data[o] = c[0]; ti.data[o + 1] = c[1]; ti.data[o + 2] = c[2]; ti.data[o + 3] = 255 * edge; }
          if (layers.cloud) {
            const cl = sample(snap.cloud, lon, lat) / 100, pr = sample(snap.precip, lon, lat);
            const n = fbm(lon * 0.9 + drift, lat * 0.9 - drift * 0.3);
            let a = clamp((cl - 0.12) * 1.3, 0, 1) * (0.35 + 0.75 * n); a = clamp(a * 0.95, 0, 0.9);
            let r = 255, g = 255, b = 255;
            if (pr > 0.08) { const k = pr; if (k < 1) { r = 80; g = 210; b = 255; } else if (k < 4) { r = 40; g = 120; b = 255; } else if (k < 10) { r = 255; g = 212; b = 0; } else { r = 255; g = 60; b = 60; } a = Math.max(a, clamp(0.45 + pr * 0.08, 0, 0.85) * (0.55 + 0.45 * n)); }
            ci.data[o] = r; ci.data[o + 1] = g; ci.data[o + 2] = b; ci.data[o + 3] = a * 255 * edge;
          }
          if (layers.dust) {
            const du = dustAt(lon, lat, tm), a = clamp((du - 120) / 900, 0, 0.85) * (0.6 + 0.4 * fbm(lon * 1.3 - drift * 1.5, lat * 1.3));
            di.data[o] = 214; di.data[o + 1] = 160; di.data[o + 2] = 88; di.data[o + 3] = a * 255 * edge;
          }
        }
      }
      tc.putImageData(ti, 0, 0); cc.putImageData(ci, 0, 0); dc.putImageData(di, 0, 0);
    }

    function drawRaster(c, alpha) {
      ctx.globalAlpha = alpha; ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
      const x0 = sx(RL - 0.125), y0 = sy(RT + 0.125), x1 = sx(RL + (RW - 1) * 0.25 + 0.125), y1 = sy(RT - (RH - 1) * 0.25 - 0.125);
      ctx.drawImage(c, x0, y0, x1 - x0, y1 - y0); ctx.globalAlpha = 1;
    }

    const PRIMARY = { jahra: 1, ahmadi: 1, sharjah: 1, makkah: 1, dammam: 1 };
    let markers = [];
    function drawMarkers() {
      markers = []; const pxDeg = z * S; ctx.textAlign = 'center';
      CITIES.forEach(c => {
        if (PRIMARY[c.id] && pxDeg < 70 && c.id !== sel) return;
        const h = cityHour(c, tm); if (!h) return; const x = sx(c.lon), y = sy(c.lat), isSel = c.id === sel;
        const t = Math.round(h.temp) + '°', col = tcol(h.temp);
        ctx.font = '700 13px Segoe UI, -apple-system, Tahoma, sans-serif'; const tw = ctx.measureText(t).width + 16;
        ctx.fillStyle = isSel ? '#ffc861' : 'rgba(12,20,36,.82)'; ctx.strokeStyle = `rgb(${col[0] | 0},${col[1] | 0},${col[2] | 0})`; ctx.lineWidth = 2;
        rr(x - tw / 2, y - 30, tw, 21, 10); ctx.fill(); ctx.stroke();
        ctx.fillStyle = isSel ? '#2a1d00' : '#fff'; ctx.fillText(t, x, y - 15);
        ctx.beginPath(); ctx.arc(x, y, isSel ? 5 : 3.5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.font = (isSel ? '700 ' : '600 ') + '11.5px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.6)';
        ctx.strokeText(c[lang], x, y + 16); ctx.fillStyle = '#fff'; ctx.fillText(c[lang], x, y + 16);
        markers.push({ id: c.id, x, y: y - 10 });
      });
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

    function frame(dt) {
      resize(); time += dt; if (!grid) return;
      if (!snap || Math.abs(tm - snapT) > 0.01) makeSnap();
      if (Math.abs(tm - lastRast) > 0.04 || lastRast < 0) { buildRasters(); lastRast = tm; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#0b2238'); bg.addColorStop(1, '#071626'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      // land
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      shapes.forEach(s => { ctx.fillStyle = s.c ? '#3a3f48' : '#2b3038'; ctx.fill(s.p); });
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (layers.temp) { ctx.save(); ctx.globalCompositeOperation = 'source-over'; drawRaster(rast.temp, 0.55); ctx.restore(); }
      // borders + coast
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      ctx.lineJoin = 'round';
      shapes.forEach(s => { ctx.strokeStyle = s.c ? 'rgba(255,255,255,.75)' : 'rgba(255,255,255,.35)'; ctx.lineWidth = (s.c ? 1.1 : 0.7) / z; ctx.stroke(s.p); });
      if (sel) { const s = shapes.find(q => q.c === (CITIES.find(c => c.id === sel) || {}).c); if (s) { ctx.strokeStyle = 'rgba(255,200,97,.95)'; ctx.lineWidth = 2 / z; ctx.stroke(s.p); } }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (layers.dust) drawRaster(rast.dust, 1);
      if (layers.cloud) drawRaster(rast.cloud, 0.9);
      // wind particles
      if (layers.wind) {
        tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.globalCompositeOperation = 'destination-in'; tctx.fillStyle = 'rgba(0,0,0,0.9)'; tctx.fillRect(0, 0, trail.width, trail.height);
        tctx.globalCompositeOperation = 'source-over'; tctx.setTransform(dpr, 0, 0, dpr, 0, 0); tctx.lineWidth = 1.3; tctx.strokeStyle = 'rgba(255,255,255,.8)'; tctx.beginPath();
        const k = Math.min(dt, 0.05) * 0.028;
        for (const p of P) {
          const u = sample(snap.u, p.lon, p.lat), v = sample(snap.v, p.lon, p.lat);
          const x0 = sx(p.lon), y0 = sy(p.lat); p.lon += u * k / K; p.lat += v * k; p.age++;
          if (p.age > p.max || p.lon < 34 || p.lon > 60 || p.lat < 12 || p.lat > 32) { spawn(p); p.age = 0; continue; }
          tctx.moveTo(x0, y0); tctx.lineTo(sx(p.lon), sy(p.lat));
        }
        tctx.stroke(); ctx.drawImage(trail, 0, 0, W, H);
      }
      drawMarkers();
    }

    // interaction
    let drag = null, moved = false;
    canvas.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, ox, oy }; moved = false; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 4) moved = true; ox = drag.ox + dx; oy = drag.oy + dy; if (moved) clearTrail(); });
    canvas.addEventListener('pointerup', e => {
      const was = drag; drag = null; if (!was || moved) return;
      const r = canvas.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      let best = null, bd = 28; markers.forEach(m => { const d = Math.hypot(m.x - x, m.y - y); if (d < bd) { bd = d; best = m; } });
      if (best && api.onCity) api.onCity(best.id);
    });
    canvas.addEventListener('wheel', e => {
      e.preventDefault(); const r = canvas.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, f = Math.exp(-e.deltaY * 0.0015);
      const nz = clamp(z * f, 0.3, 12); ox = x - (x - ox) * (nz / z); oy = y - (y - oy) * (nz / z); z = nz; clearTrail();
    }, { passive: false });

    const api = {
      setData(g, cityData, cityList) { grid = g; cities = cityData; CITIES = cityList; lastRast = -1; snap = null; },
      setTime(t) { tm = clamp(t, 0, grid ? grid.n - 1 : 0); },
      setLayers(l) { Object.assign(layers, l); lastRast = -1; clearTrail(); },
      layers: () => Object.assign({}, layers),
      setSelected(id) { sel = id; }, setLang(l) { lang = l; },
      reset() { fit(); }, setFitBox(b) { fitBox = b; fit(); },
      tempColor: tcol, TSTOPS, frame, onCity: null
    };
    return api;
  };
})();
