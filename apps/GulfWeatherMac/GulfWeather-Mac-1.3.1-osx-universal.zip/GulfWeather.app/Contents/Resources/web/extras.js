/* Gulf Weather - extras: prayer times, vs yesterday, air quality, marine, kashta outlook, favourites,
   my location, spoken summary, alerts. Works in WebView2 and WKWebView. by Kankon · kankon.net */
(function () {
  const A = window.GW_APP, S = window.GW_STRINGS; if (!A) return;
  const $ = id => document.getElementById(id), st = A.st, CITIES = window.GW.CITIES;
  const T = (k, ...a) => A.T(k, ...a);
  const rad = x => x * Math.PI / 180, deg = x => x * 180 / Math.PI;
  const pad = n => String(n).padStart(2, '0');
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };

  /* ---------- strings ---------- */
  Object.assign(S.en, {
    xp: 'Insights', xpTitle: 'Insights', fav: 'Favourites', favAdd: 'Add to favourites', favRemove: 'Remove from favourites', favNone: 'Tap ★ to save a place here.',
    prayer: 'Prayer times', fajr: 'Fajr', sunrise2: 'Sunrise', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha', nextIn: '{0} in {1}',
    vsYest: 'Compared with yesterday', warmer: '{0}° warmer than yesterday', cooler: '{0}° cooler than yesterday', same: 'About the same as yesterday', yest: 'Yesterday',
    hi: 'High', lo: 'Low', air: 'Air quality', aqi: 'AQI', pm10: 'PM10', pm25: 'PM2.5', dustL: 'Dust',
    'aq.good': 'Good', 'aq.mod': 'Moderate', 'aq.sens': 'Unhealthy for sensitive groups', 'aq.bad': 'Unhealthy', 'aq.vbad': 'Very unhealthy',
    'aqa.good': 'Air is clean. Enjoy being outside.', 'aqa.mod': 'Fine for most people. Very sensitive people should take it easy outside.',
    'aqa.sens': 'People with asthma or heart problems: stay inside and wear a mask outdoors.', 'aqa.bad': 'Everyone: limit time outside and wear a mask.', 'aqa.vbad': 'Stay inside, close windows, wear an N95 mask if you must go out.',
    marine: 'Sea and waves', wave: 'Wave height', period: 'Wave period', seaT: 'Sea temperature', seaW: 'Wind at sea', mPeriodS: 's', mInland: 'No sea here.',
    'sea.calm': 'Calm sea, good for fishing and boats.', 'sea.mod': 'Moderate waves, be careful with small boats.', 'sea.rough': 'Rough sea. Stay on land.',
    kashta: 'Camping outlook', kashtaSub: 'Night and day conditions for the desert', night: 'Night', 'k.great': 'Great', 'k.fine': 'Fine', 'k.cold': 'Cold night', 'k.windy': 'Windy', 'k.dusty': 'Dusty', 'k.wet': 'Rain', 'k.hot': 'Hot',
    place: 'Place', speak: 'Speak the summary', speaking: 'Speaking…', stopSpeak: 'Stop',
    notify: 'Alerts for my places', notifyOn: 'On', notifyOff: 'Off', notifyOnMsg: 'Alerts are on for your places.', notifyDenied: 'Notifications are blocked on this device. Alerts still show inside the app.',
    myLoc: 'My location', myLocUse: 'Use my location', myLocNear: 'Nearest: {0} ({1} km)', myLocFail: 'Could not get your location. Allow location for this app and try again.', myLocBusy: 'Finding you…',
    radar: 'Radar', 'l.radar': 'Radar', radarNote: 'Rain radar · {0}', radarFail: 'Rain radar is not available right now.',
    needNet: 'Needs internet.', loadingSmall: 'Loading…', offlineSmall: 'Not available offline.',
    sumHello: 'Weather summary for {0}.', sumNow: 'Now {0}, {1}.', sumHigh: 'Today the high is {0} and the low is {1}.', sumRain: 'Rain is expected today.', sumDust: 'There is dust today, take care.', sumWind: 'Strong wind today.', sumHot: 'It will be very hot today, drink water.', sumTomorrow: 'Tomorrow {0}, high {1}.', sumPrayer: 'Next prayer is {0}.'
  });
  Object.assign(S.ar, {
    xp: 'معلومات إضافية', xpTitle: 'معلومات إضافية', fav: 'المفضلة', favAdd: 'أضف للمفضلة', favRemove: 'احذف من المفضلة', favNone: 'اضغط ★ عشان تحفظ أماكنك هنا.',
    prayer: 'مواقيت الصلاة', fajr: 'الفجر', sunrise2: 'الشروق', dhuhr: 'الظهر', asr: 'العصر', maghrib: 'المغرب', isha: 'العشاء', nextIn: '{0} بعد {1}',
    vsYest: 'مقارنة بأمس', warmer: 'أحر من أمس بـ {0}°', cooler: 'أبرد من أمس بـ {0}°', same: 'تقريباً مثل أمس', yest: 'أمس',
    hi: 'العظمى', lo: 'الصغرى', air: 'جودة الهواء', aqi: 'مؤشر الجودة', pm10: 'PM10', pm25: 'PM2.5', dustL: 'الغبار',
    'aq.good': 'جيدة', 'aq.mod': 'متوسطة', 'aq.sens': 'غير صحية للفئات الحساسة', 'aq.bad': 'غير صحية', 'aq.vbad': 'غير صحية جداً',
    'aqa.good': 'الهوا نظيف، استمتع بالطلعة.', 'aqa.mod': 'زينة لأغلب الناس، والحساسين يخففون المجهود برا.',
    'aqa.sens': 'مرضى الربو والقلب: خلكم داخل البيت، والبسوا كمامة إذا طلعتوا.', 'aqa.bad': 'الكل: قللوا الوقت برا والبسوا كمامة.', 'aqa.vbad': 'خلك داخل البيت وسكّر الشبابيك، والبس كمامة N95 إذا لازم تطلع.',
    marine: 'البحر والموج', wave: 'ارتفاع الموج', period: 'فترة الموج', seaT: 'حرارة البحر', seaW: 'الرياح على البحر', mPeriodS: 'ث', mInland: 'ما فيه بحر هنا.',
    'sea.calm': 'البحر هادي، مناسب للصيد والقوارب.', 'sea.mod': 'موج متوسط، انتبه إذا قاربك صغير.', 'sea.rough': 'البحر هايج، خلك على البر.',
    kashta: 'توقعات الكشتة', kashtaSub: 'أجواء الليل والنهار بالبر', night: 'الليل', 'k.great': 'ممتاز', 'k.fine': 'زين', 'k.cold': 'ليل بارد', 'k.windy': 'رياح', 'k.dusty': 'غبار', 'k.wet': 'مطر', 'k.hot': 'حار',
    place: 'المكان', speak: 'اقرأ الملخص', speaking: 'جاري القراءة…', stopSpeak: 'إيقاف',
    notify: 'تنبيهات لأماكني', notifyOn: 'شغّال', notifyOff: 'موقف', notifyOnMsg: 'تم تشغيل التنبيهات لأماكنك.', notifyDenied: 'الإشعارات مقفلة على هالجهاز، بس التنبيهات بتظهر داخل البرنامج.',
    myLoc: 'موقعي', myLocUse: 'استخدم موقعي', myLocNear: 'الأقرب: {0} ({1} كم)', myLocFail: 'ما قدرت أحدد موقعك. اسمح للبرنامج يوصل لموقعك وجرب مرة ثانية.', myLocBusy: 'جاري تحديد موقعك…',
    radar: 'الرادار', 'l.radar': 'الرادار', radarNote: 'رادار المطر · {0}', radarFail: 'رادار المطر مو متوفر الحين.',
    needNet: 'يحتاج إنترنت.', loadingSmall: 'جاري التحميل…', offlineSmall: 'مو متوفر بدون إنترنت.',
    sumHello: 'ملخص الطقس في {0}.', sumNow: 'الحين {0}، {1}.', sumHigh: 'اليوم العظمى {0} والصغرى {1}.', sumRain: 'متوقع مطر اليوم.', sumDust: 'فيه غبار اليوم، انتبهوا.', sumWind: 'رياح قوية اليوم.', sumHot: 'الجو حار مرة اليوم، اشربوا مي.', sumTomorrow: 'باجر {0}، والعظمى {1}.', sumPrayer: 'الصلاة الجاية {0}.'
  });

  Object.assign(S.en, {
    clim: 'Climate over the years', climSub: 'Compares the same period in every year since 1950 for this place (ERA5 reanalysis, free from Open-Meteo).',
    climFrom: 'From', climTo: 'To', pAll: 'Whole year', pSummer: 'Summer', pWinter: 'Winter', pSar: 'Autumn rains',
    climTemp: 'Average temperature (°C)', climRain: 'Total rain (mm)', climRainDays: 'Rainy days (1 mm or more)', climHot: 'Days of 45° or more', climHot50: 'Days of 50° or more', climStorm: 'Stormy days (5 mm+ rain, or rain with strong gusts)',
    climLoading: 'Loading 75 years of data…', climFail: 'Could not load the history. Trying again soon.', climSample: 'Needs the internet for the history.',
    climUp: '{0}° warmer every ten years', climDown: '{0}° cooler every ten years', climFlat: 'Temperature is about steady',
    climCmp: 'Last 10 years: {0}° average. First 10 years ({1}): {2}°.', climRainTrend: 'Rain: last 10 years average {0} mm, first 10 years {1} mm.',
    climHotTrend: 'Days of 45° or more: last 10 years average {0} a year, first 10 years {1}.', climStormTrend: 'Stormy days: last 10 years average {0} a year, first 10 years {1}.',
    climDecade: 'Decade', climYears: '{0} to {1}', climNote: 'Note: these are model averages over a grid area, so peak heat and rain can read lower than weather-station records. The trend over the years is what matters.'
  });
  Object.assign(S.ar, {
    clim: 'المناخ عبر السنين', climSub: 'يقارن نفس الفترة من كل سنة من 1950 لين الحين لهذا المكان (بيانات ERA5 مجانية من Open-Meteo).',
    climFrom: 'من', climTo: 'إلى', pAll: 'السنة كلها', pSummer: 'الصيف', pWinter: 'الشتا', pSar: 'سرايات الخريف',
    climTemp: 'معدل الحرارة (°C)', climRain: 'مجموع المطر (مم)', climRainDays: 'أيام المطر (1 مم وأكثر)', climHot: 'أيام 45° وأكثر', climHot50: 'أيام 50° وأكثر', climStorm: 'الأيام العاصفة (مطر 5 مم وأكثر، أو مطر مع هبّات قوية)',
    climLoading: 'جاري تحميل بيانات 75 سنة…', climFail: 'ما قدرت أحمّل بيانات السنين اللي طافت. بنعيد المحاولة بعد شوي.', climSample: 'يحتاج إنترنت عشان يجيب بيانات السنين اللي طافت.',
    climUp: 'أحر بـ {0}° كل عشر سنين', climDown: 'أبرد بـ {0}° كل عشر سنين', climFlat: 'الحرارة تقريبًا ثابتة',
    climCmp: 'آخر 10 سنين: المعدل {0}°. أول 10 سنين ({1}): {2}°.', climRainTrend: 'المطر: معدل آخر 10 سنين {0} مم، وأول 10 سنين {1} مم.',
    climHotTrend: 'أيام 45° وأكثر: معدل آخر 10 سنين {0} في السنة، وأول 10 سنين {1}.', climStormTrend: 'الأيام العاصفة: معدل آخر 10 سنين {0} في السنة، وأول 10 سنين {1}.',
    climDecade: 'العقد', climYears: 'من {0} إلى {1}', climNote: 'ملاحظة: هذي معدلات من نموذج مناخي لمساحة كاملة، فأعلى حرارة وكمية المطر ممكن تطلع أقل من قراءات محطات الرصد. المهم هو الاتجاه عبر السنين.'
  });

  /* ---------- native bridge (Mac app): location, voice, notifications ---------- */
  const nat = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gw;
  const GWN = window.GWNative = window.GWNative || {};

  /* ---------- helpers ---------- */
  const city = () => CITIES.find(c => c.id === st.city);
  const D = () => st.data && st.data[st.city];
  const hourIdx = () => Math.max(0, Math.min(Math.floor(st.t), D() ? D().hours.length - 1 : 0));
  const dayIdx = () => Math.floor(hourIdx() / 24);
  const cname = c => c[st.lang];
  const degW = n => { if (st.lang !== 'ar') return n + ' degrees'; const a = Math.abs(n); return a === 1 ? 'درجة' : a === 2 ? 'درجتين' : (a >= 3 && a <= 10) ? n + ' درجات' : n + ' درجة'; };
  const fmtHM = (h) => { h = ((h % 24) + 24) % 24; let m = Math.round((h % 1) * 60), hh = Math.floor(h); if (m === 60) { m = 0; hh = (hh + 1) % 24; } const ap = hh >= 12 ? (st.lang === 'ar' ? 'م' : 'PM') : (st.lang === 'ar' ? 'ص' : 'AM'); return ((hh % 12) || 12) + ':' + pad(m) + ' ' + ap; };
  const distKm = (a, b) => { const R = 6371, dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon), x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(x)); };

  /* ---------- prayer times (Kuwait method: Fajr 18°, Isha 17.5°, Asr standard) ---------- */
  function prayerTimes(lat, lon, tz, y, m, d) {
    const jd = (() => { let Y = y, M = m; if (M <= 2) { Y--; M += 12; } const a = Math.floor(Y / 100), b = 2 - a + Math.floor(a / 4); return Math.floor(365.25 * (Y + 4716)) + Math.floor(30.6001 * (M + 1)) + d + b - 1524.5; })();
    const sunPos = j => { const D0 = j - 2451545.0, g = (357.529 + 0.98560028 * D0) % 360, q = (280.459 + 0.98564736 * D0) % 360, L = (q + 1.915 * Math.sin(rad(g)) + 0.020 * Math.sin(rad(2 * g))) % 360, e = 23.439 - 0.00000036 * D0, RA = deg(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))) / 15; return { dec: deg(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L)))), eq: q / 15 - ((RA + 24) % 24) }; };
    const sp = sunPos(jd + 0.5), noon = 12 + tz - lon / 15 - (((sp.eq + 12) % 24) - 12);
    const ha = (ang) => { const c = (-Math.sin(rad(ang)) - Math.sin(rad(lat)) * Math.sin(rad(sp.dec))) / (Math.cos(rad(lat)) * Math.cos(rad(sp.dec))); return Math.abs(c) > 1 ? NaN : deg(Math.acos(c)) / 15; };
    const asrHa = (() => { const a = Math.atan(1 / (1 + Math.tan(rad(Math.abs(lat - sp.dec))))); const c = (Math.sin(a) - Math.sin(rad(lat)) * Math.sin(rad(sp.dec))) / (Math.cos(rad(lat)) * Math.cos(rad(sp.dec))); return deg(Math.acos(c)) / 15; })();
    const rise = noon - ha(0.833), set = noon + ha(0.833);
    return { fajr: noon - ha(18), sunrise: rise, dhuhr: noon + 0.0083, asr: noon + asrHa, maghrib: set + 0.0083, isha: noon + ha(17.5) };
  }
  function prayerFor(c, ms) { const dt = new Date(ms); return prayerTimes(c.lat, c.lon, c.tz, dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate()); }

  /* ---------- network helpers ---------- */
  const cache = {};
  async function getJSON(key, url, ttl) {
    const c = cache[key]; if (c && Date.now() - c.at < (ttl || 3600e3)) return c.v;
    const ctl = new AbortController(), tm = setTimeout(() => ctl.abort(), 15000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); const v = await r.json(); cache[key] = { at: Date.now(), v }; return v; } finally { clearTimeout(tm); }
  }
  const isSample = () => st.src === 'sample';
  const nowMsLocal = () => { const d = D(), c = city(); return Date.now() + (d ? d.utcOffset * 1000 : c.tz * 3600e3); };

  const yestData = {}, aqData = {}, seaData = {}, errAt = {};
  // load one extra data set; on failure retry after a minute (the free API can answer 429 when many calls arrive together)
  function loadExtra(store_, key, url, ttl, pick) {
    const cur = store_[key.slice(1)];
    if (cur === 'loading' || (cur && cur !== 'err') || (cur === 'err' && Date.now() - (errAt[key] || 0) < 60000)) return;
    store_[key.slice(1)] = 'loading';
    getJSON(key, url, ttl).then(j => { store_[key.slice(1)] = pick(j) || 'err'; if (store_[key.slice(1)] === 'err') errAt[key] = Date.now(); render(); })
      .catch(() => { store_[key.slice(1)] = 'err'; errAt[key] = Date.now(); render(); setTimeout(render, 62000); });
  }
  function ensureData(c) {
    if (isSample()) return;
    const id = c.id;
    loadExtra(yestData, 'y' + id, `https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&hourly=temperature_2m&past_days=1&forecast_days=1&timezone=auto`, 3600e3,
      j => { const t = j.hourly.temperature_2m.slice(0, 24).filter(v => v != null); return t.length ? { hi: Math.max(...t), lo: Math.min(...t) } : null; });
    loadExtra(aqData, 'a' + id, `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${c.lat}&longitude=${c.lon}&current=us_aqi,pm10,pm2_5,dust&timezone=auto`, 1800e3, j => j.current || null);
    if (!c.inland) loadExtra(seaData, 'm' + id, `https://marine-api.open-meteo.com/v1/marine?latitude=${c.lat}&longitude=${c.lon}&hourly=wave_height,wave_period,sea_surface_temperature&forecast_days=2&timezone=auto`, 3600e3, j => j.hourly || null);
  }

  /* ---------- panel ---------- */
  const css = document.createElement('style');
  css.textContent = `
  #xp{position:fixed;top:84px;inset-inline-end:14px;width:370px;max-height:calc(100vh - 84px - 312px);overflow:auto;padding:12px 14px 16px;z-index:7;display:none}
  body.xpOpen #xp{display:block}body.xpOpen .alerts,body.xpOpen .kwp{display:none!important}
  #xp h3{font-size:14px;margin:14px 0 8px;display:flex;align-items:center;gap:8px}#xp h3:first-child{margin-top:2px}
  #xp .row{display:flex;justify-content:space-between;gap:10px;padding:6px 10px;border-radius:10px;background:rgba(255,255,255,.07);font-size:13px;margin-bottom:5px}
  #xp .row.next{background:rgba(255,200,97,.22);outline:1px solid rgba(255,200,97,.6)}#xp .row b{font-weight:700}
  #xp .sm{font-size:12px;color:var(--mut);margin:4px 2px}
  #xp .btn{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:12px;background:rgba(255,255,255,.12);font-size:13px;font-weight:600;margin:4px 6px 4px 0;cursor:pointer;border:0;color:inherit}
  #xp .btn:hover{background:rgba(255,255,255,.22)}#xp .btn.on{background:rgba(92,200,255,.3)}
  #xp .chips{display:flex;flex-wrap:wrap;gap:6px}#xp .chip{padding:5px 10px;border-radius:12px;background:rgba(255,255,255,.12);font-size:12.5px;cursor:pointer}#xp .chip:hover{background:rgba(255,255,255,.24)}
  #xp table{width:100%;border-collapse:collapse;font-size:12px}#xp td,#xp th{padding:5px 3px;text-align:center}#xp th{color:var(--mut);font-weight:600}#xp td:first-child,#xp th:first-child{text-align:start}
  #xp .k-great{color:#7be07b}#xp .k-fine{color:#c8e46c}#xp .k-cold{color:#7cc4ff}#xp .k-windy,#xp .k-dusty{color:#ffb35c}#xp .k-wet{color:#5cc8ff}#xp .k-hot{color:#ff7a5c}
  #xp .aq{display:inline-block;padding:2px 9px;border-radius:9px;font-weight:700;font-size:12px;color:#102;}
  #xBtn{white-space:nowrap}#favBtn{font-size:20px;padding:8px 12px;color:#ffc861}
  #toast{position:fixed;top:78px;left:50%;transform:translateX(-50%);z-index:20;max-width:520px;display:none;padding:12px 18px;font-size:14px}
  .rdr{position:fixed;bottom:322px;left:50%;transform:translateX(-50%);z-index:4;padding:6px 14px;font-size:12px;display:none}body.mapMode .rdr.show{display:block}`;
  document.head.appendChild(css);

  const xp = document.createElement('aside'); xp.id = 'xp'; xp.className = 'glass'; document.body.appendChild(xp);
  const toast = document.createElement('div'); toast.id = 'toast'; toast.className = 'glass'; document.body.appendChild(toast);
  const top = document.querySelector('.top'), cityBtn = $('cityBtn');
  const favBtn = document.createElement('button'); favBtn.id = 'favBtn'; favBtn.className = 'glass'; cityBtn.after(favBtn);
  const xBtn = document.createElement('button'); xBtn.id = 'xBtn'; xBtn.className = 'viewBtn glass'; $('viewBtn').after(xBtn);
  xBtn.onclick = () => { document.body.classList.toggle('xpOpen'); render(); };
  const isFav = id => store.get('gw-favs', []).includes(id);
  favBtn.onclick = () => { let f = store.get('gw-favs', []); f = f.includes(st.city) ? f.filter(x => x !== st.city) : f.concat(st.city); store.set('gw-favs', f); render(); };
  function showToast(msg) { toast.textContent = msg; toast.style.display = 'block'; clearTimeout(showToast.t); showToast.t = setTimeout(() => { toast.style.display = 'none'; }, 7000); }

  /* ---------- sections ---------- */
  function secPrayer(c, ms, isToday) {
    const p = prayerFor(c, ms), names = [['fajr', 'fajr'], ['sunrise', 'sunrise2'], ['dhuhr', 'dhuhr'], ['asr', 'asr'], ['maghrib', 'maghrib'], ['isha', 'isha']];
    let nextK = null, nextIn = '';
    if (isToday) { const nowH = ((nowMsLocal() % 864e5) / 36e5); for (const [k] of names) { if (k !== 'sunrise' && p[k] > nowH) { nextK = k; const mins = Math.round((p[k] - nowH) * 60); nextIn = (mins >= 60 ? Math.floor(mins / 60) + (st.lang === 'ar' ? ' س ' : 'h ') : '') + (mins % 60) + (st.lang === 'ar' ? ' د' : 'm'); break; } } }
    return `<h3>🕌 ${T('prayer')}</h3>` + names.map(([k, lab]) => `<div class="row${k === nextK ? ' next' : ''}"><span>${T(lab)}</span><b>${fmtHM(p[k])}</b></div>`).join('') + (nextK ? `<div class="sm">${T('nextIn', T(nextK === 'sunrise' ? 'sunrise2' : nextK), nextIn)}</div>` : '');
  }
  function secYest(c, day) {
    const d = D(); let y = yestData[c.id]; const hs = d.hours.slice(day * 24, day * 24 + 24), hi = Math.max(...hs.map(h => h.temp)), lo = Math.min(...hs.map(h => h.temp));
    if (isSample() && day === Math.floor(window.GW_APP.nowIndex() / 24) && !y) { y = { hi: hi - 2 + (c.lat % 3), lo: lo - 1 + (c.lon % 2) }; }
    if (!y || y === 'loading') return `<h3>📈 ${T('vsYest')}</h3><div class="sm">${T('loadingSmall')}</div>`;
    if (y === 'err') return `<h3>📈 ${T('vsYest')}</h3><div class="sm">${T('offlineSmall')}</div>`;
    if (day !== Math.floor(A.nowIndex() / 24)) return '';
    const diff = Math.round(hi - y.hi), txt = diff > 0 ? T('warmer', diff) : diff < 0 ? T('cooler', -diff) : T('same');
    return `<h3>📈 ${T('vsYest')}</h3><div class="row"><span>${T('today')}</span><b>${T('hi')} ${Math.round(hi)}° · ${T('lo')} ${Math.round(lo)}°</b></div><div class="row"><span>${T('yest')}</span><b>${T('hi')} ${Math.round(y.hi)}° · ${T('lo')} ${Math.round(y.lo)}°</b></div><div class="sm"><b>${txt}</b></div>`;
  }
  const aqLevel = v => v <= 50 ? ['good', '#7be07b'] : v <= 100 ? ['mod', '#ffe066'] : v <= 150 ? ['sens', '#ffb35c'] : v <= 200 ? ['bad', '#ff7a5c'] : ['vbad', '#d98cff'];
  function secAir(c) {
    let a = aqData[c.id]; const d = D(), h = d.hours[hourIdx()];
    if (isSample() || a === 'err' || (!a && isSample())) { const du = h.dust != null ? h.dust : 40; a = { us_aqi: Math.min(300, Math.round(30 + du * 0.6)), pm10: Math.round(du * 1.2), pm2_5: Math.round(du * 0.35), dust: Math.round(du) }; }
    if (!a || a === 'loading') return `<h3>🌫️ ${T('air')}</h3><div class="sm">${T('loadingSmall')}</div>`;
    const lv = aqLevel(a.us_aqi || 0);
    return `<h3>🌫️ ${T('air')}</h3><div class="row"><span>${T('aqi')}</span><b><span class="aq" style="background:${lv[1]}">${Math.round(a.us_aqi || 0)} · ${T('aq.' + lv[0])}</span></b></div>
      <div class="row"><span>${T('pm10')}</span><b class="ltr">${Math.round(a.pm10 || 0)} ${T('ugm3')}</b></div><div class="row"><span>${T('pm25')}</span><b class="ltr">${Math.round(a.pm2_5 || 0)} ${T('ugm3')}</b></div>
      <div class="row"><span>${T('dustL')}</span><b class="ltr">${Math.round(a.dust || 0)} ${T('ugm3')}</b></div><div class="sm">${T('aqa.' + lv[0])}</div>`;
  }
  function secMarine(c) {
    if (c.inland) return `<h3>🌊 ${T('marine')}</h3><div class="sm">${T('mInland')}</div>`;
    let wh, wp, sst; const d = D(), h = d.hours[hourIdx()], m = seaData[c.id];
    if (isSample() || m === 'err') { const k = Math.max(0, Math.min(23, hourIdx() % 24)); wh = Math.max(0.2, 0.3 + (h.wind || 10) / 40); wp = 3 + (h.wind || 10) / 12; sst = 22 + 6 * Math.max(0, Math.min(1, (c.cl ? c.cl[0] : 28) / 40)); }
    else if (!m || m === 'loading') return `<h3>🌊 ${T('marine')}</h3><div class="sm">${T('loadingSmall')}</div>`;
    else { const k = Math.min(hourIdx(), m.time.length - 1); wh = m.wave_height[k]; wp = m.wave_period[k]; sst = m.sea_surface_temperature[k]; }
    if (wh == null) return `<h3>🌊 ${T('marine')}</h3><div class="sm">${T('offlineSmall')}</div>`;
    const lv = wh < 0.6 ? 'calm' : wh < 1.5 ? 'mod' : 'rough';
    return `<h3>🌊 ${T('marine')}</h3><div class="row"><span>${T('wave')}</span><b class="ltr">${wh.toFixed(1)} m</b></div><div class="row"><span>${T('period')}</span><b class="ltr">${Math.round(wp || 0)} ${T('mPeriodS')}</b></div>
      <div class="row"><span>${T('seaT')}</span><b class="ltr">${Math.round(sst)}°C</b></div><div class="row"><span>${T('seaW')}</span><b class="ltr">${Math.round(h.wind)} ${T('kmh')}</b></div><div class="sm">${T('sea.' + lv)}</div>`;
  }
  function kashtaRate(d, di) {
    const hs = d.hours.slice(di * 24, di * 24 + 24); if (!hs.length) return 'fine';
    const nights = hs.filter(h => { const hh = +h.t.slice(11, 13); return hh >= 19 || hh <= 5; }), mn = Math.min(...(nights.length ? nights : hs).map(h => h.temp)), mx = Math.max(...hs.map(h => h.temp));
    const rain = hs.reduce((a, h) => a + (h.precip || 0), 0), wind = Math.max(...hs.map(h => h.wind || 0)), dust = Math.max(...hs.map(h => h.dust || 0));
    if (rain >= 1) return 'wet'; if (dust >= 200) return 'dusty'; if (wind >= 35) return 'windy'; if (mn <= 8) return 'cold'; if (mx >= 40) return 'hot';
    return (mn >= 12 && mn <= 22 && mx <= 32 && wind < 22) ? 'great' : 'fine';
  }
  function secKashta() {
    const places = ['salmi', 'wafra', 'abdali', 'jahra'].map(id => CITIES.find(c => c.id === id)).filter(Boolean).filter(c => st.data[c.id]);
    const base = Math.floor(A.nowIndex() / 24), days = [0, 1, 2, 3].map(k => base + k).filter(k => k < 10);
    const nm = k => { const ms = Date.parse(D().days[k].date + 'T12:00:00Z'); return new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { weekday: 'short', timeZone: 'UTC' }).format(ms); };
    return `<h3>⛺ ${T('kashta')}</h3><div class="sm">${T('kashtaSub')}</div><table><tr><th>${T('place')}</th>${days.map(k => `<th>${nm(k)}</th>`).join('')}</tr>` +
      places.map(c => `<tr><td>${cname(c)}</td>${days.map(k => { const r = kashtaRate(st.data[c.id], k); return `<td class="k-${r}">${T('k.' + r)}</td>`; }).join('')}</tr>`).join('') + '</table>';
  }

  /* ---------- climate over the years (Open-Meteo archive, ERA5 since 1950) ---------- */
  const climRaw = {}, climErr = {}, climMemo = {};
  let climFrom = 10, climTo = 12, climOpen = false;
  function ensureClimate(c) {
    if (isSample()) return;
    const cur = climRaw[c.id];
    if (cur === 'loading' || (cur && cur !== 'err') || (cur === 'err' && Date.now() - (climErr[c.id] || 0) < 60000)) return;
    climRaw[c.id] = 'loading';
    const endY = new Date().getUTCFullYear() - 1, ctl = new AbortController(), tm = setTimeout(() => ctl.abort(), 60000);
    fetch(`https://archive-api.open-meteo.com/v1/archive?latitude=${c.lat}&longitude=${c.lon}&start_date=1950-01-01&end_date=${endY}-12-31&daily=temperature_2m_max,temperature_2m_mean,precipitation_sum,wind_gusts_10m_max&timezone=auto`, { signal: ctl.signal })
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(j => { const d = j.daily; if (!d || !d.time || !d.time.length) throw new Error('empty'); climRaw[c.id] = { time: d.time, tmax: d.temperature_2m_max, tmean: d.temperature_2m_mean, rain: d.precipitation_sum, gust: d.wind_gusts_10m_max }; render(); })
      .catch(() => { climRaw[c.id] = 'err'; climErr[c.id] = Date.now(); render(); setTimeout(render, 62000); })
      .finally(() => clearTimeout(tm));
  }
  function climYearsOf(raw, from, to) {
    const wrap = from > to, g = new Map();
    for (let i = 0; i < raw.time.length; i++) {
      const t = raw.time[i], m = +t.slice(5, 7), inP = wrap ? (m >= from || m <= to) : (m >= from && m <= to); if (!inP) continue;
      let y = +t.slice(0, 4); if (wrap && m <= to) y--;
      let a = g.get(y); if (!a) { a = { y, n: 0, ts: 0, tn: 0, rain: 0, rd: 0, h45: 0, h50: 0, st: 0 }; g.set(y, a); }
      a.n++; const tm = raw.tmean[i], tx = raw.tmax[i], r = raw.rain[i] || 0, gu = raw.gust[i] || 0;
      if (tm != null) { a.ts += tm; a.tn++; }
      a.rain += r; if (r >= 1) a.rd++; if (tx != null && tx >= 45) a.h45++; if (tx != null && tx >= 50) a.h50++; if (r >= 5 || (r >= 1 && gu >= 50)) a.st++;
    }
    const arr = [...g.values()].sort((p, q) => p.y - q.y), mx = Math.max(...arr.map(a => a.n)); 
    return arr.filter(a => a.n >= mx * 0.9 && a.tn > 0).map(a => ({ y: a.y, temp: a.ts / a.tn, rain: a.rain, rd: a.rd, h45: a.h45, h50: a.h50, st: a.st }));
  }
  function slopePerDecade(ys, k) { const n = ys.length, mx = ys.reduce((a, r) => a + r.y, 0) / n, my = ys.reduce((a, r) => a + r[k], 0) / n; let nu = 0, de = 0; for (const r of ys) { nu += (r.y - mx) * (r[k] - my); de += (r.y - mx) ** 2; } const b = de ? nu / de : 0; return { b: b * 10, a: my - b * mx }; }
  const avgOf = (arr, k) => arr.length ? arr.reduce((a, r) => a + r[k], 0) / arr.length : 0;
  function climChart(ys, k, color, label, dec) {
    const W = 340, H = 64, pl = 2, n = ys.length, vals = ys.map(r => r[k]), mx = Math.max(...vals, 0.0001), mn = Math.min(...vals, 0), lo = k === 'temp' ? Math.min(...vals) - 0.3 : 0, hi = k === 'temp' ? Math.max(...vals) + 0.3 : mx, bw = (W - pl * 2) / n;
    const yv = v => H - 4 - (H - 10) * (v - lo) / ((hi - lo) || 1);
    const tr = slopePerDecade(ys, k), x0 = ys[0].y, x1 = ys[n - 1].y, ty = y => yv(tr.a + tr.b / 10 * y);
    const bars = ys.map((r, i) => `<rect x="${(pl + i * bw + 0.5).toFixed(1)}" y="${yv(r[k]).toFixed(1)}" width="${Math.max(1, bw - 1).toFixed(1)}" height="${Math.max(1, H - 4 - yv(r[k])).toFixed(1)}" fill="${color}" opacity=".55"/>`).join('');
    const line = `<line x1="${pl}" y1="${ty(x0).toFixed(1)}" x2="${W - pl}" y2="${ty(x1).toFixed(1)}" stroke="#fff" stroke-width="2" stroke-dasharray="5 3"/>`;
    return `<div class="sm" style="margin-top:8px"><b>${label}</b></div><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" style="display:block;background:rgba(255,255,255,.05);border-radius:8px">${bars}${line}</svg>` +
      `<div class="sm ltr" style="display:flex;justify-content:space-between"><span>${x0}</span><span>${(+mx.toFixed(dec)).toLocaleString('en')} max · ${(+(k === 'temp' ? Math.min(...vals) : mn).toFixed(dec)).toLocaleString('en')} min</span><span>${x1}</span></div>`;
  }
  function secClimate(c) {
    const head = `<h3>🕰️ ${T('clim')}</h3>`;
    if (isSample()) return head + `<div class="sm">${T('climSample')}</div>`;
    const raw = climRaw[c.id];
    if (!raw || raw === 'loading') return head + `<div class="sm">${T('climLoading')}</div>`;
    if (raw === 'err') return head + `<div class="sm">${T('climFail')}</div>`;
    const mnames = Array.from({ length: 12 }, (_, i) => new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { month: 'long', timeZone: 'UTC' }).format(Date.UTC(2021, i, 15)));
    const sel = (id, v) => `<select id="${id}" style="background:rgba(255,255,255,.14);color:inherit;border:0;border-radius:10px;padding:6px 8px;font-size:13px">${mnames.map((m, i) => `<option value="${i + 1}"${i + 1 === v ? ' selected' : ''} style="color:#000">${m}</option>`).join('')}</select>`;
    const pre = [['pSar', 10, 12], ['pSummer', 6, 9], ['pWinter', 12, 2], ['pAll', 1, 12]];
    const key = c.id + '|' + climFrom + '|' + climTo; let ys = climMemo[key]; if (!ys) { ys = climMemo[key] = climYearsOf(raw, climFrom, climTo); }
    let out = head + `<div class="sm">${T('climSub')}</div><div class="chips" style="margin:6px 0">${pre.map(([k, f, t]) => `<span class="chip${f === climFrom && t === climTo ? '" style="background:rgba(92,200,255,.35)' : ''}" data-cp="${f}-${t}">${T(k)}</span>`).join('')}</div>` +
      `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><span class="sm">${T('climFrom')}</span>${sel('climF', climFrom)}<span class="sm">${T('climTo')}</span>${sel('climT', climTo)}</div>`;
    if (ys.length < 12) return out + `<div class="sm">${T('climFail')}</div>`;
    const n = ys.length, first = ys.slice(0, 10), last = ys.slice(-10), tt = slopePerDecade(ys, 'temp'), bt = Math.abs(tt.b).toFixed(1);
    out += `<div class="row" style="margin-top:8px"><span>${tt.b > 0.05 ? T('climUp', bt) : tt.b < -0.05 ? T('climDown', bt) : T('climFlat')}</span></div>` +
      `<div class="sm ltr">${T('climCmp', avgOf(last, 'temp').toFixed(1), first[0].y + '–' + first[first.length - 1].y, avgOf(first, 'temp').toFixed(1))}</div>` +
      climChart(ys, 'temp', '#ff9a5c', T('climTemp'), 1);
    out += climChart(ys, 'rain', '#5cc8ff', T('climRain'), 0) + `<div class="sm ltr">${T('climRainTrend', Math.round(avgOf(last, 'rain')), Math.round(avgOf(first, 'rain')))}</div>`;
    out += climChart(ys, 'rd', '#7cc4ff', T('climRainDays'), 0);
    out += climChart(ys, 'st', '#b48cff', T('climStorm'), 0) + `<div class="sm ltr">${T('climStormTrend', avgOf(last, 'st').toFixed(1), avgOf(first, 'st').toFixed(1))}</div>`;
    if (ys.some(r => r.h45 > 0)) out += climChart(ys, 'h45', '#ff5c5c', T('climHot'), 0) + `<div class="sm ltr">${T('climHotTrend', avgOf(last, 'h45').toFixed(1), avgOf(first, 'h45').toFixed(1))}</div>`;
    if (ys.some(r => r.h50 > 0)) out += climChart(ys, 'h50', '#ff3030', T('climHot50'), 0);
    const decs = []; for (let d = Math.ceil(ys[0].y / 10) * 10; d <= ys[n - 1].y; d += 10) { const g = ys.filter(r => r.y >= d && r.y < d + 10); if (g.length >= 5) decs.push([d, g]); }
    out += `<table class="ltr" style="margin-top:8px"><tr><th>${T('climDecade')}</th><th>°C</th><th>mm</th><th>45°</th><th>${st.lang === 'ar' ? 'عاصفة' : 'storm'}</th></tr>` +
      decs.map(([d, g]) => `<tr><td>${d}s</td><td>${avgOf(g, 'temp').toFixed(1)}</td><td>${Math.round(avgOf(g, 'rain'))}</td><td>${avgOf(g, 'h45').toFixed(1)}</td><td>${avgOf(g, 'st').toFixed(1)}</td></tr>`).join('') + '</table>';
    out += `<div class="sm">${T('climNote')}</div>`;
    return out;
  }

  /* ---------- spoken summary ---------- */
  function summaryText() {
    const c = city(), d = D(), h = d.hours[hourIdx()], di = dayIdx(), hs = d.hours.slice(di * 24, di * 24 + 24), day = d.days[di];
    const al = A.alertsForDay(di).map(a => a[2]), cn = A.cond(h);
    const parts = [T('sumHello', cname(c)), T('sumNow', degW(Math.round(h.temp)), T('c.' + cn)), T('sumHigh', degW(Math.round(day.tmax)), degW(Math.round(day.tmin)))];
    if (al.includes('a.heavyRain') || hs.some(x => x.precip >= 0.5)) parts.push(T('sumRain'));
    if (al.includes('a.dust') || al.includes('a.dustStorm')) parts.push(T('sumDust'));
    if (al.includes('a.wind')) parts.push(T('sumWind'));
    if (day.tmax >= 44) parts.push(T('sumHot'));
    const p = prayerFor(c, nowMsLocal()), nowH = ((nowMsLocal() % 864e5) / 36e5);
    for (const k of ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']) if (p[k] > nowH) { parts.push(T('sumPrayer', T(k) + ' ' + fmtHM(p[k]))); break; }
    return parts.join(' ');
  }
  let speaking = false;
  GWN.onSpeakEnd = () => { speaking = false; render(); };
  function speak() {
    if (speaking) { if (nat) nat.postMessage({ cmd: 'stopSpeak' }); else speechSynthesis.cancel(); speaking = false; render(); return; }
    const text = summaryText(), lang = st.lang === 'ar' ? 'ar-SA' : 'en-US';
    if (nat) { speaking = true; nat.postMessage({ cmd: 'speak', text, lang }); render(); return; }
    if (!('speechSynthesis' in window)) { showToast('—'); return; }
    const u = new SpeechSynthesisUtterance(text); u.lang = lang; u.rate = 0.95;
    const v = speechSynthesis.getVoices().find(x => x.lang && x.lang.toLowerCase().startsWith(st.lang === 'ar' ? 'ar' : 'en')); if (v) u.voice = v;
    u.onend = u.onerror = () => { speaking = false; render(); }; speaking = true; speechSynthesis.cancel(); speechSynthesis.speak(u); render();
  }

  /* ---------- my location ---------- */
  let me = store.get('gw-me', null), meMsg = '';
  GWN.onNotifyPermission = ok => { if (!ok) showToast(T('notifyDenied')); };
  function applyMe() { if (me && A.mapv && A.mapv.setMe) A.mapv.setMe(me.lat, me.lon); }
  function gotMe(lat, lon) {
    me = { lat, lon }; store.set('gw-me', me); applyMe();
    let best = null, bd = 1e9; CITIES.forEach(c => { const k = distKm(me, c); if (k < bd) { bd = k; best = c; } });
    meMsg = T('myLocNear', cname(best), Math.round(bd)); A.selectCity(best.id); A.setView('map'); setTimeout(() => A.mapv.zoomTo([lon - 0.45, lon + 0.45, lat - 0.3, lat + 0.3]), 50); render();
  }
  GWN.onLocation = (lat, lon) => { clearTimeout(locT); gotMe(lat, lon); };
  GWN.onLocationError = () => { clearTimeout(locT); meMsg = T('myLocFail'); render(); };
  let locT = 0;
  function locate() {
    meMsg = T('myLocBusy'); render(); clearTimeout(locT); locT = setTimeout(() => { meMsg = T('myLocFail'); render(); }, 20000);
    if (nat) { nat.postMessage({ cmd: 'locate' }); return; }
    if (!navigator.geolocation) { clearTimeout(locT); meMsg = T('myLocFail'); render(); return; }
    navigator.geolocation.getCurrentPosition(p => { clearTimeout(locT); gotMe(p.coords.latitude, p.coords.longitude); }, () => { clearTimeout(locT); meMsg = T('myLocFail'); render(); }, { enableHighAccuracy: false, timeout: 15000, maximumAge: 600000 });
  }

  /* ---------- alerts (in-app toast + system notification when allowed) ---------- */
  let notifyOn = store.get('gw-notify', false);
  function setNotify() {
    if (!notifyOn) {
      notifyOn = true; store.set('gw-notify', true);
      if (nat) nat.postMessage({ cmd: 'notifyPermission' });
      else if ('Notification' in window && Notification.permission === 'default') { try { Notification.requestPermission().then(p => { if (p === 'denied') showToast(T('notifyDenied')); }); } catch (e) { } }
      else if ('Notification' in window && Notification.permission === 'denied') showToast(T('notifyDenied'));
      checkAlerts(); notifyOnce(T('notifyOnMsg'));
    } else { notifyOn = false; store.set('gw-notify', false); }
    render();
  }
  function notifyOnce(msg) { try { if (nat) nat.postMessage({ cmd: 'notify', title: 'Gulf Weather', body: msg }); else if ('Notification' in window && Notification.permission === 'granted') new Notification('Gulf Weather', { body: msg }); } catch (e) { } }
  function checkAlerts() {
    if (!notifyOn || !st.data) return; const seen = store.get('gw-seen', {}), ids = [...new Set([st.city, ...store.get('gw-favs', [])])];
    const orig = st.city; let shown = 0;
    ids.forEach(id => {
      const c = CITIES.find(x => x.id === id), d = st.data[id]; if (!c || !d) return;
      const base = Math.floor(A.nowIndex() / 24);
      [base, base + 1].forEach(di => {
        if (di >= d.days.length) return; const al = A.alertsForDayOf(id, di);
        al.filter(a => a[0] === 'r' || a[0] === 'o').forEach(a => {
          const key = id + '|' + d.days[di].date + '|' + a[2]; if (seen[key] || shown >= 2) return; seen[key] = 1; shown++;
          const msg = a[1] + ' ' + cname(c) + ': ' + T(a[2]) + (a[3] ? ' ' + a[3] : '');
          showToast(msg); try { if (nat) nat.postMessage({ cmd: 'notify', title: 'Gulf Weather', body: msg }); else if ('Notification' in window && Notification.permission === 'granted') new Notification('Gulf Weather', { body: msg }); } catch (e) { }
        });
      });
    });
    store.set('gw-seen', seen);
  }

  /* ---------- render ---------- */
  let lastKey = '';
  function render() {
    const d = D(), c = city(); if (!d || !c) return;
    favBtn.textContent = isFav(c.id) ? '★' : '☆'; favBtn.title = isFav(c.id) ? T('favRemove') : T('favAdd');
    xBtn.textContent = '✨ ' + T('xp');
    if (!document.body.classList.contains('xpOpen')) return;
    ensureData(c); ensureClimate(c);
    const favs = store.get('gw-favs', []).map(id => CITIES.find(x => x.id === id)).filter(Boolean), day = dayIdx(), ms = Date.parse(d.days[day].date + 'T12:00:00Z');
    const isToday = day === Math.floor(A.nowIndex() / 24);
    const hasNotif = 'Notification' in window;
    const keepScroll = xp.scrollTop;
    if (climOpen) {
      xp.innerHTML = `<button class="btn" id="xBack">← ${T('xp')}</button>` + secClimate(c);
      xp.querySelectorAll('[data-cp]').forEach(e => e.onclick = () => { const [f, t] = e.dataset.cp.split('-').map(Number); climFrom = f; climTo = t; render(); });
      const cf = $('climF'), ct = $('climT'); if (cf) { cf.onchange = () => { climFrom = +cf.value; render(); }; ct.onchange = () => { climTo = +ct.value; render(); }; }
      $('xBack').onclick = () => { climOpen = false; render(); }; xp.scrollTop = keepScroll; return;
    }
    xp.innerHTML = `<h3>⭐ ${T('fav')}</h3>` + (favs.length ? `<div class="chips">${favs.map(f => `<span class="chip" data-c="${f.id}">${cname(f)}</span>`).join('')}</div>` : `<div class="sm">${T('favNone')}</div>`) +
      `<div style="margin-top:8px"><button class="btn" id="xLoc">📍 ${T('myLocUse')}</button><button class="btn" id="xClim">🕰️ ${T('clim')}</button><button class="btn${speaking ? ' on' : ''}" id="xSpeak">🔊 ${speaking ? T('stopSpeak') : T('speak')}</button><button class="btn${notifyOn ? ' on' : ''}" id="xNot">🔔 ${T('notify')}: ${notifyOn ? T('notifyOn') : T('notifyOff')}</button></div>` +
      (meMsg ? `<div class="sm">${meMsg}</div>` : '') +
      secPrayer(c, ms, isToday) + secYest(c, day) + secAir(c) + secMarine(c) + secKashta();
    xp.scrollTop = keepScroll;
    xp.querySelectorAll('.chip').forEach(e => e.onclick = () => A.selectCity(e.dataset.c));
    $('xClim').onclick = () => { climOpen = true; xp.scrollTop = 0; render(); };
    $('xLoc').onclick = locate; $('xSpeak').onclick = speak; $('xNot').onclick = setNotify;
  }
  A.onRender = () => { const k = st.city + '|' + st.lang + '|' + Math.floor(st.t) + '|' + document.body.classList.contains('xpOpen') + '|' + store.get('gw-favs', []).join(); if (k !== lastKey) { lastKey = k; render(); } };
  A.onData = () => { applyMe(); checkAlerts(); render(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { document.body.classList.remove('xpOpen'); } });
  if (st.data) A.onData();
  render();
})();
