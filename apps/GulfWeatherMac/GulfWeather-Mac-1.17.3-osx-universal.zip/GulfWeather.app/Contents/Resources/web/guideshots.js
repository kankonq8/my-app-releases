/* Gulf Weather - list of screen states the build photographs for the Help guide (kankon.net and in-app Help).
   Used only by the desktop host with --guide-shots; each step: name (file part), js to run, wait in ms. by Kankon · kankon.net */
window.GW_SHOTS = (function () {
  const R = "try{GW_HELP_UI.close()}catch(e){};try{var so=document.getElementById('seasonOv');if(so&&so.classList.contains('on'))document.getElementById('seasonX').click()}catch(e){};try{var ec=document.getElementById('ensoCard');if(ec&&ec.classList.contains('show'))document.getElementById('ensoX').click()}catch(e){};" +
    "document.body.classList.remove('xpOpen');try{document.getElementById('nowBtn').click()}catch(e){};GW_APP.st.kwOn=false;GW_APP.setView('map');GW_APP.mapv.setLayers(Object.assign({},window.__L0||{}));";
  return [
    { name: '03-tour', js: R + "GW_APP.mapv.setLayers({temp:true,wind:true,cloud:false,dust:true,radar:true,sat:true,pres:false,cyc:true,sst:false});window.__L0=window.__L0||Object.assign({},GW_APP.mapv.layers())", wait: 1500 },
    { name: '04-now-card', js: R + "document.getElementById('nowBtn').click()", wait: 2000 },
    { name: '05-timeline', js: R + "var d=document.querySelectorAll('#days .day');if(d[3])d[3].click()", wait: 2000 },
    { name: '06-map-layers', js: R + "GW_APP.mapv.setLayers({temp:true,wind:true,cloud:true,sat:false,pres:true})", wait: 5000 },
    { name: '07-world', js: R + "document.getElementById('wdBtn').click()", wait: 9000 },
    { name: '08-kuwait', js: R + "document.getElementById('kwBtn').click()", wait: 4000 },
    { name: '09-rain-finder', js: R + "document.getElementById('wdBtn').click();setTimeout(function(){document.getElementById('rainBtn').click()},5000)", wait: 11000 },
    { name: '10-elnino', js: R + "document.getElementById('ensoBtn').click()", wait: 5000 },
    { name: '11-sea-temperature', js: "document.getElementById('ensoGo').click()", wait: 8000 },
    { name: '12-insights', js: R + "document.getElementById('xBtn').click()", wait: 3000 },
    { name: '13-history', js: "document.getElementById('xClim').click()", wait: 6000 },
    { name: '14-scene', js: R + "GW_APP.setView('scene')", wait: 5000 },
    { name: '15-seasons', js: R + "document.getElementById('seasonBar').click()", wait: 2000 },
    { name: '16-help', js: R + "GW_HELP_UI.open()", wait: 1500 }
  ];
})();
