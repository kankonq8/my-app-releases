/* Gulf Weather - season banner: current season, days left, and a details window with every season.
   by Kankon · kankon.net */
(function () {
  const A = window.GW_APP, S = window.GW_STRINGS; if (!A) return;
  const st = A.st;
  Object.assign(S.en, {
    seasonWord: '{0} season', seasonFrom: 'from {0} to {1}', seasonLeft: 'Remaining', seasonDays: '{0} days', seasonDay1: '1 day', seasonDay0: 'Last day',
    sWinter: 'Winter', sSpring: 'Spring', sSummer: 'Summer', sAutumn: 'Autumn',
    sDWinter: 'Cool to cold days and nights, the main rain season; the coldest weeks of the year.', sDSpring: 'Mild weather turning warm; thunderstorms, dust and windy days are common.', sDSummer: 'Very hot and dry, often 45° or more; the long hot season.', sDAutumn: 'Heat eases slowly; nights cool down and the first rains and thunderstorms arrive.',
    sTitle: 'Seasons of the year', sNow: 'Now', sLeftN: '{0} left', sStartsIn: 'Starts in {1} ({0})', sNote: 'Dates follow the astronomical seasons (equinoxes and solstices), within a day.', sClose: 'Close', sTapHint: 'Tap for all seasons'
  });
  Object.assign(S.ar, {
    seasonWord: 'موسم {0}', seasonFrom: 'من {0} إلى {1}', seasonLeft: 'المتبقي', seasonDays: '{0} يوم', seasonDay1: 'يوم واحد', seasonDay0: 'آخر يوم',
    sWinter: 'الشتاء', sSpring: 'الربيع', sSummer: 'الصيف', sAutumn: 'الخريف',
    sDWinter: 'أيام وليالي باردة، وهو موسم الأمطار الرئيسي وأبرد أسابيع السنة.', sDSpring: 'جو معتدل يميل للدفا، وتكثر فيه الرعود والغبار والأيام العجاجة.', sDSummer: 'حر شديد وجاف وكثير يوصل 45° وفوق، وهو الموسم الطويل الحار.', sDAutumn: 'الحر يخف شوي شوي، والليالي تبرد وتبدأ أول الأمطار والرعود.',
    sTitle: 'مواسم السنة', sNow: 'الحين', sLeftN: 'باقي {0}', sStartsIn: 'يبدأ بعد {1} ({0})', sNote: 'التواريخ حسب الفصول الفلكية (الاعتدالان والانقلابان) وممكن تختلف بيوم.', sClose: 'إغلاق', sTapHint: 'اضغط لكل المواسم'
  });
  const T = (k, ...a) => A.T(k, ...a);
  const DEF = [
    { k: 'Winter', ic: '❄️', c1: '#2b6cb0', c2: '#1a365d', m: 12, d: 21 },
    { k: 'Spring', ic: '🌸', c1: '#2f9e6e', c2: '#1b5e4b', m: 3, d: 20 },
    { k: 'Summer', ic: '☀️', c1: '#e8821e', c2: '#b3321a', m: 6, d: 21 },
    { k: 'Autumn', ic: '🍂', c1: '#c0782a', c2: '#7a3d12', m: 9, d: 23 }
  ];
  const DAY = 864e5, kuwaitToday = () => { const t = new Date(Date.now() + 3 * 36e5); return Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()); };
  function seasons() {
    const t = kuwaitToday(), y = new Date(t).getUTCFullYear(), out = [];
    for (let yy = y - 1; yy <= y + 1; yy++) DEF.forEach(s => out.push({ s, start: Date.UTC(yy, s.m - 1, s.d) }));
    out.sort((a, b) => a.start - b.start);
    for (let i = 0; i < out.length - 1; i++) out[i].end = out[i + 1].start;
    out.pop();
    const cur = out.find(o => t >= o.start && t < o.end), idx = out.indexOf(cur), res = [];
    res.push(Object.assign({ now: true, left: Math.round((cur.end - t) / DAY), done: (t - cur.start) / (cur.end - cur.start) }, cur));
    for (let i = 1; i <= 3; i++) { const o = out[idx + i]; if (o) res.push(Object.assign({ now: false, until: Math.round((o.start - t) / DAY) }, o)); }
    return res;
  }
  const fmtD = ms => new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { day: 'numeric', month: 'long', timeZone: 'UTC' }).format(ms);
  const days = n => st.lang === 'ar' ? (n === 0 ? T('seasonDay0') : n === 1 ? 'يوم واحد' : n === 2 ? 'يومين' : (n >= 3 && n <= 10) ? n + ' أيام' : n + ' يوم') : (n === 0 ? T('seasonDay0') : n === 1 ? T('seasonDay1') : n + ' days');
  const css = document.createElement('style');
  css.textContent = '#seasonBar{position:fixed;top:64px;left:50%;transform:translateX(-50%);z-index:6;display:flex;align-items:center;gap:14px;padding:8px 18px;border-radius:18px;color:#fff;cursor:pointer;border:1px solid rgba(255,255,255,.22);box-shadow:0 8px 24px rgba(0,0,0,.4);user-select:none;max-width:94vw}' +
    '#seasonBar .ic{font-size:30px;line-height:1}#seasonBar .t{font-size:19px;font-weight:800;line-height:1.2;white-space:nowrap}#seasonBar .d{font-size:13px;font-weight:600;opacity:.92;white-space:nowrap}' +
    '#seasonBar .l{text-align:center;background:rgba(0,0,0,.25);border-radius:12px;padding:3px 12px;margin-inline-start:6px}#seasonBar .l b{display:block;font-size:22px;line-height:1.1}#seasonBar .l span{font-size:11px;opacity:.9}' +
    '#seasonBar .pg{height:4px;border-radius:4px;background:rgba(255,255,255,.28);margin-top:5px;overflow:hidden}#seasonBar .pg i{display:block;height:100%;background:#fff}' +
    '#seasonOv{position:fixed;inset:0;z-index:60;background:rgba(5,10,20,.6);display:none;align-items:center;justify-content:center;padding:16px}#seasonOv.on{display:flex}' +
    '#seasonBox{width:min(560px,100%);max-height:90vh;overflow:auto;background:#12203a;border:1px solid rgba(255,255,255,.15);border-radius:20px;padding:18px;color:#fff;box-shadow:0 20px 60px rgba(0,0,0,.6)}' +
    '#seasonBox h2{margin:0 0 12px;font-size:20px}.sRow{border-radius:16px;padding:12px 14px;margin-bottom:10px;border:1px solid rgba(255,255,255,.15)}.sRow .h{display:flex;align-items:center;gap:10px;font-weight:800;font-size:17px}.sRow .h em{margin-inline-start:auto;font-style:normal;font-size:13px;background:rgba(0,0,0,.28);border-radius:10px;padding:3px 10px;font-weight:700}' +
    '.sRow .r{font-size:13px;opacity:.95;margin-top:4px;font-weight:600}.sRow .x{font-size:12.5px;opacity:.85;margin-top:5px;line-height:1.6}#seasonBox .n{font-size:12px;opacity:.7;margin-top:6px}#seasonBox button{margin-top:10px;border:0;border-radius:12px;padding:9px 18px;font-weight:700;cursor:pointer;background:#fff;color:#12203a}' +
    '@media (max-width:900px){#seasonBar .d{display:none}#seasonBar .t{font-size:16px}}';
  document.head.appendChild(css);
  const bar = document.createElement('div'); bar.id = 'seasonBar'; bar.title = ''; document.body.appendChild(bar);
  const ov = document.createElement('div'); ov.id = 'seasonOv'; ov.innerHTML = '<div id="seasonBox"></div>'; document.body.appendChild(ov);
  ov.onclick = e => { if (e.target === ov) ov.classList.remove('on'); };
  function bg(s) { return 'linear-gradient(100deg,' + s.c1 + ',' + s.c2 + ')'; }
  function render() {
    const L = seasons(), c = L[0];
    bar.style.background = bg(c.s); bar.dir = st.lang === 'ar' ? 'rtl' : 'ltr'; bar.title = T('sTapHint');
    bar.innerHTML = '<div class="ic">' + c.s.ic + '</div><div><div class="t">' + T('seasonWord', T('s' + c.s.k)) + '</div><div class="d">' + T('seasonFrom', fmtD(c.start), fmtD(c.end - DAY)) + '</div><div class="pg"><i style="width:' + Math.round(c.done * 100) + '%"></i></div></div>' +
      '<div class="l"><span>' + T('seasonLeft') + '</span><b>' + c.left + '</b><span>' + (st.lang === 'ar' ? 'يوم' : 'days') + '</span></div>';
    if (ov.classList.contains('on')) box(L);
  }
  function box(L) {
    L = L || seasons();
    ov.firstChild.dir = st.lang === 'ar' ? 'rtl' : 'ltr';
    ov.firstChild.innerHTML = '<h2>' + T('sTitle') + '</h2>' + L.map(o => '<div class="sRow" style="background:' + bg(o.s) + '"><div class="h"><span style="font-size:24px">' + o.s.ic + '</span>' + T('seasonWord', T('s' + o.s.k)) + '<em>' + (o.now ? T('sNow') + ' · ' + T('sLeftN', days(o.left)) : T('sStartsIn', fmtD(o.start), days(o.until))) + '</em></div>' +
      '<div class="r">' + T('seasonFrom', fmtD(o.start), fmtD(o.end - DAY)) + '</div><div class="x">' + T('sD' + o.s.k) + '</div></div>').join('') + '<div class="n">' + T('sNote') + '</div><button id="seasonX">' + T('sClose') + '</button>';
    document.getElementById('seasonX').onclick = () => ov.classList.remove('on');
  }
  bar.onclick = () => { box(); ov.classList.add('on'); };
  let last = '';
  const prev = A.onRender; A.onRender = function () { if (prev) prev.apply(this, arguments); const k = st.lang + '|' + kuwaitToday(); if (k !== last) { last = k; render(); } };
  render(); last = st.lang + '|' + kuwaitToday();
})();
