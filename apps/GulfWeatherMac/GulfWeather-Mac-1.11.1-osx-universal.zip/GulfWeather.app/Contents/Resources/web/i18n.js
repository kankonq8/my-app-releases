/* Gulf Weather strings (en / ar). Same keys in both. */
window.GW_STRINGS = {
  en: {
    appName: 'Gulf Weather', byline: 'by Kankon · kankon.net', dataBy: 'Weather data: Open-Meteo', langBtn: 'العربية',
    live: 'Live', updated: 'Updated {0}', sample: 'Sample data (offline)', cached: 'Saved forecast · {0}', loading: 'Loading forecast…', refresh: 'Refresh',
    chooseCity: 'Choose a city', now: 'Now', play: 'Play', pause: 'Pause', speed: 'Speed', feelsLike: 'Feels like {0}',
    humidity: 'Humidity', wind: 'Wind', gusts: 'Gusts', uv: 'UV index', visibility: 'Visibility', dust: 'Dust', rain: 'Rain', sunrise: 'Sunrise', sunset: 'Sunset',
    kmh: 'km/h', km: 'km', visMore: '10+ km', mm: 'mm', ugm3: 'µg/m³', today: 'Today', tomorrow: 'Tomorrow', tenDays: '10-day forecast', noAlerts: 'No weather alerts',
    'c.clear': 'Clear', 'c.clearNight': 'Clear night', 'c.partly': 'Partly cloudy', 'c.cloudy': 'Cloudy', 'c.overcast': 'Overcast', 'c.fog': 'Fog',
    'c.drizzle': 'Drizzle', 'c.rain': 'Rain', 'c.heavyRain': 'Heavy rain', 'c.thunder': 'Thunderstorm', 'c.dust': 'Dusty', 'c.dustStorm': 'Dust storm', 'c.haze': 'Hazy',
    'uv.low': 'Low', 'uv.mod': 'Moderate', 'uv.high': 'High', 'uv.vhigh': 'Very high', 'uv.ext': 'Extreme',
    'dust.low': 'Low', 'dust.mod': 'Moderate', 'dust.high': 'High', 'dust.vhigh': 'Very high', 'na': '—',
    'a.heatExt': 'Extreme heat', 'a.heat': 'Heat warning', 'a.hot': 'Very hot: drink water', 'a.dustStorm': 'Dust storm: low visibility', 'a.dust': 'Dust / haze',
    'a.wind': 'Strong wind', 'a.thunder': 'Thunderstorm', 'a.heavyRain': 'Heavy rain: flooding risk', 'a.fog': 'Fog: low visibility on roads', 'a.uv': 'Very high UV', 'a.uvExt': 'Extreme UV', 'a.cold': 'Cold night',
    'd.N': 'N', 'd.NE': 'NE', 'd.E': 'E', 'd.SE': 'SE', 'd.S': 'S', 'd.SW': 'SW', 'd.W': 'W', 'd.NW': 'NW',
    alertsFor: 'Alerts · {0}', mapView: 'Map', kwMap: 'Kuwait', kwGov: 'Kuwait governorates', 'base.map': 'Street', 'base.dark': 'Dark', 'base.sat': 'Satellite', kwAreas: 'Other areas', sceneView: '3D view', 'l.temp': 'Temperature', 'l.radar': 'Radar', 'l.sat': 'Satellite', 'l.prec': 'Sat rain', 'l.wind': 'Wind', 'l.cloud': 'Clouds & rain', 'l.dust': 'Dust', legendTemp: 'Temperature °C', legendRain: 'Rain', rainLight: 'Light', rainMod: 'Moderate', rainHeavy: 'Heavy', rainVery: 'Very heavy', mapHint: 'Click a city · scroll to zoom in to streets · drag to move', dragHint: 'Drag the timeline or press Play to watch the weather move'
  },
  ar: {
    appName: 'Gulf Weather', byline: 'من Kankon · kankon.net', dataBy: 'بيانات الطقس: Open-Meteo', langBtn: 'English',
    live: 'مباشر', updated: 'آخر تحديث {0}', sample: 'بيانات تجريبية (بدون إنترنت)', cached: 'توقعات محفوظة · {0}', loading: 'جاري تحميل التوقعات…', refresh: 'تحديث',
    chooseCity: 'اختر المدينة', now: 'الحين', play: 'تشغيل', pause: 'إيقاف', speed: 'السرعة', feelsLike: 'الإحساس {0}',
    humidity: 'الرطوبة', wind: 'الرياح', gusts: 'الهبّات', uv: 'الأشعة فوق البنفسجية', visibility: 'مدى الرؤية', dust: 'الغبار', rain: 'المطر', sunrise: 'الشروق', sunset: 'الغروب',
    kmh: 'كم/س', km: 'كم', visMore: 'أكثر من 10 كم', mm: 'ملم', ugm3: 'µg/m³', today: 'اليوم', tomorrow: 'باچر', tenDays: 'توقعات 10 أيام', noAlerts: 'ما في تنبيهات',
    'c.clear': 'صافي', 'c.clearNight': 'ليل صافي', 'c.partly': 'غائم جزئياً', 'c.cloudy': 'غائم', 'c.overcast': 'غائم كلياً', 'c.fog': 'ضباب',
    'c.drizzle': 'رذاذ', 'c.rain': 'مطر', 'c.heavyRain': 'مطر غزير', 'c.thunder': 'عاصفة رعدية', 'c.dust': 'غبار', 'c.dustStorm': 'عاصفة غبارية', 'c.haze': 'غبار خفيف',
    'uv.low': 'منخفض', 'uv.mod': 'متوسط', 'uv.high': 'عالي', 'uv.vhigh': 'عالي جداً', 'uv.ext': 'شديد',
    'dust.low': 'قليل', 'dust.mod': 'متوسط', 'dust.high': 'عالي', 'dust.vhigh': 'عالي جداً', 'na': '—',
    'a.heatExt': 'حر شديد جداً', 'a.heat': 'تنبيه حر', 'a.hot': 'حر: اشرب ماي', 'a.dustStorm': 'عاصفة غبارية: الرؤية قليلة', 'a.dust': 'غبار',
    'a.wind': 'رياح قوية', 'a.thunder': 'عاصفة رعدية', 'a.heavyRain': 'مطر غزير: احتمال تجمع مياه', 'a.fog': 'ضباب: الرؤية قليلة بالطرق', 'a.uv': 'أشعة UV عالية جداً', 'a.uvExt': 'أشعة UV شديدة', 'a.cold': 'ليل بارد',
    'd.N': 'شمال', 'd.NE': 'شمال شرق', 'd.E': 'شرق', 'd.SE': 'جنوب شرق', 'd.S': 'جنوب', 'd.SW': 'جنوب غرب', 'd.W': 'غرب', 'd.NW': 'شمال غرب',
    alertsFor: 'تنبيهات · {0}', mapView: 'الخريطة', kwMap: 'محافظات الكويت', kwGov: 'محافظات الكويت', 'base.map': 'خريطة', 'base.dark': 'داكن', 'base.sat': 'أقمار صناعية', kwAreas: 'مناطق أخرى', sceneView: 'عرض 3D', 'l.temp': 'الحرارة', 'l.radar': 'الرادار', 'l.sat': 'أقمار صناعية', 'l.prec': 'مطر الأقمار', 'l.wind': 'الرياح', 'l.cloud': 'الغيوم والمطر', 'l.dust': 'الغبار', legendTemp: 'الحرارة °C', legendRain: 'المطر', rainLight: 'خفيف', rainMod: 'متوسط', rainHeavy: 'غزير', rainVery: 'غزير جداً', mapHint: 'اضغط على مدينة · مرر للتكبير · اسحب للتحريك', dragHint: 'اسحب الخط الزمني أو اضغط «تشغيل» وشوف الطقس يتحرك'
  }
};
Object.assign(window.GW_STRINGS.en, {
  allBtn: 'All', 'l.pres': 'Pressure', 'l.cyc': '🌀', cycNear: 'Tropical cyclone {0} is near the Arabian Sea / Gulf region', worldBtn: '🌍', worldTip: 'World map', worldLoading: 'Loading world weather… {0}%', worldFail: 'World weather is not available right now. Trying again soon.',
  searchPlace: 'Search any city in the world…', searching: 'Searching…', noPlace: 'No results', openFc: 'Open forecast', modelTemp: 'Model estimate',
  loadingPlace: 'Loading forecast for {0}…', placeFail: 'Could not load that place. Check the internet and try again.', otherPlaces: 'Other places',
  limitFail: 'The free weather service reached its daily limit. Try again later.', ptName: '{0}, {1}', nN: 'N', nS: 'S', nE: 'E', nW: 'W', worldHint: 'Tap anywhere on the map for a forecast', tapNoData: 'World weather is still loading'
});
Object.assign(window.GW_STRINGS.ar, {
  allBtn: 'الكل', 'l.pres': 'الضغط', 'l.cyc': '🌀', cycNear: 'الإعصار المداري {0} قريب من بحر العرب والخليج', worldBtn: '🌍', worldTip: 'خريطة العالم', worldLoading: 'جاري تحميل طقس العالم… {0}%', worldFail: 'طقس العالم مو متوفر الحين، بنعيد المحاولة بعد شوي.',
  searchPlace: 'ابحث عن أي مدينة في العالم…', searching: 'جاري البحث…', noPlace: 'ما لقينا نتائج', openFc: 'افتح التوقعات', modelTemp: 'تقدير النموذج',
  loadingPlace: 'جاري تحميل توقعات {0}…', placeFail: 'ما قدرنا نحمل هالمكان، تأكد من الإنترنت وجرب مرة ثانية.', otherPlaces: 'أماكن أخرى',
  limitFail: 'خدمة الطقس المجانية وصلت حدها اليومي، جرب بعد شوي.', ptName: '{0}، {1}', nN: 'شمالاً', nS: 'جنوباً', nE: 'شرقاً', nW: 'غرباً', worldHint: 'اضغط على أي مكان في الخريطة لتشوف توقعاته', tapNoData: 'طقس العالم لسا قاعد يتحمل'
});

