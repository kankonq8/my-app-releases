/* Gulf Weather - El Nino card (NOAA CPC ONI + weekly Nino 3.4) and the sea temperature anomaly layer (NASA GIBS MUR).
   The NOAA files have no CORS header, so the Mac app fetches them natively and the Windows app adds the header (see hosts). by Kankon · kankon.net */
(function () {
  const A = window.GW_APP, S = window.GW_STRINGS; if (!A) return;
  const $ = id => document.getElementById(id), T = (k, ...a) => A.T(k, ...a), st = A.st;
  const ONI = 'https://www.cpc.ncep.noaa.gov/data/indices/oni.ascii.txt', WK = 'https://www.cpc.ncep.noaa.gov/data/indices/wksst9120.for';
  Object.assign(S.en, {
    'l.sst': '🌡️🌊', legendSst: 'Sea temperature vs normal °C', ensoBtn: 'El Niño', ensoTitle: 'El Niño / La Niña', ensoLoading: 'Loading the latest El Niño data…', ensoFail: 'Could not load El Niño data. Check the internet and try again.',
    phElNino: 'El Niño', phLaNina: 'La Niña', phNeutral: 'Neutral (normal)', stWeak: 'weak', stModerate: 'moderate', stStrong: 'strong', stVeryStrong: 'very strong',
    ensoOni: 'ONI index ({0} {1})', ensoWeek: 'Niño 3.4 this week ({0})', ensoAbove: '{0}°C above normal', ensoBelow: '{0}°C below normal', ensoChart: 'ONI over the last 24 months (±0.5 is the El Niño / La Niña limit)',
    ensoWhat: 'What it means for the Gulf', ensoSrc: 'Source: NOAA Climate Prediction Center, sea temperature map: NASA GIBS (MUR)', ensoShow: 'Show sea temperature on the map', ensoHide: 'Hide sea temperature from the map', ensoClose: 'Close',
    ensoImpElNino: 'In El Niño years Kuwait and the Gulf often get more winter rain than usual, but not always.', ensoImpLaNina: 'In La Niña years the Gulf winter is often drier than usual, but not always.', ensoImpNeutral: 'In neutral years the winter rain follows the normal pattern.'
  });
  Object.assign(S.ar, {
    'l.sst': '🌡️🌊', legendSst: 'حرارة البحر عن المعدل °C', ensoBtn: 'النينيو', ensoTitle: 'ظاهرة النينيو والنينا', ensoLoading: 'جاري تحميل آخر بيانات النينيو…', ensoFail: 'ما قدرت أحمّل بيانات النينيو. تأكد من النت وجرب مرة ثانية.',
    phElNino: 'نينيو (دفء المحيط)', phLaNina: 'نينا (برودة المحيط)', phNeutral: 'محايد (عادي)', stWeak: 'ضعيف', stModerate: 'متوسط', stStrong: 'قوي', stVeryStrong: 'قوي جداً',
    ensoOni: 'مؤشر ONI ({0} {1})', ensoWeek: 'نينيو 3.4 هذا الأسبوع ({0})', ensoAbove: 'أعلى من المعدل بـ {0} درجة', ensoBelow: 'أقل من المعدل بـ {0} درجة', ensoChart: 'مؤشر ONI لآخر 24 شهر (±0.5 هو حد النينيو والنينا)',
    ensoWhat: 'وش معناها لنا في الخليج', ensoSrc: 'المصدر: مركز التنبؤ المناخي NOAA، وخريطة حرارة البحر: ناسا GIBS (MUR)', ensoShow: 'عرض حرارة البحر على الخريطة', ensoHide: 'إخفاء حرارة البحر من الخريطة', ensoClose: 'إغلاق',
    ensoImpElNino: 'في سنوات النينيو غالباً يجي على الكويت والخليج مطر شتوي أكثر من المعتاد، بس مو دايماً.', ensoImpLaNina: 'في سنوات النينا غالباً يكون شتا الخليج أنشف من المعتاد، بس مو دايماً.', ensoImpNeutral: 'في السنوات المحايدة يمشي مطر الشتا على المعتاد.'
  });
  const MON = { en: ['Dec-Jan-Feb', 'Jan-Feb-Mar', 'Feb-Mar-Apr', 'Mar-Apr-May', 'Apr-May-Jun', 'May-Jun-Jul', 'Jun-Jul-Aug', 'Jul-Aug-Sep', 'Aug-Sep-Oct', 'Sep-Oct-Nov', 'Oct-Nov-Dec', 'Nov-Dec-Jan'], ar: ['ديسمبر-فبراير', 'يناير-مارس', 'فبراير-أبريل', 'مارس-مايو', 'أبريل-يونيو', 'مايو-يوليو', 'يونيو-أغسطس', 'يوليو-سبتمبر', 'أغسطس-أكتوبر', 'سبتمبر-نوفمبر', 'أكتوبر-ديسمبر', 'نوفمبر-يناير'] };
  const SEAS = ['DJF', 'JFM', 'FMA', 'MAM', 'AMJ', 'MJJ', 'JJA', 'JAS', 'ASO', 'SON', 'OND', 'NDJ'];

  /* ---------- fetching (native on Mac, header added by the Windows host) ---------- */
  const nat = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gw, GWN = window.GWNative = window.GWNative || {}, waits = {};
  GWN.onText = (id, b64) => { const w = waits[id]; if (!w) return; delete waits[id]; if (b64 == null) w.rej(new Error('native fetch failed')); else { try { w.res(decodeURIComponent(escape(atob(b64)))); } catch (e) { try { w.res(atob(b64)); } catch (e2) { w.rej(e2); } } } };
  function getText(url) {
    if (nat) return new Promise((res, rej) => { const id = 'f' + Date.now() + Math.random().toString(36).slice(2, 6); waits[id] = { res, rej }; setTimeout(() => { if (waits[id]) { delete waits[id]; rej(new Error('timeout')); } }, 25000); nat.postMessage({ cmd: 'fetchText', url, id }); });
    return fetch(url).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); });
  }
  function parseOni(t) { const out = []; t.split('\n').forEach(l => { const m = l.trim().match(/^([A-Z]{3})\s+(\d{4})\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)$/); if (m && SEAS.includes(m[1])) out.push({ s: m[1], y: +m[2], anom: +m[4] }); }); return out; }
  function parseWk(t) { let last = null; t.split('\n').forEach(l => { const m = l.match(/^\s*(\d{2}[A-Z]{3}\d{4})\s+(.*)$/); if (!m) return; const n = m[2].match(/-?\d+\.\d+/g); if (n && n.length >= 8) last = { d: m[1], sst: +n[4], anom: +n[5] }; }); return last; }
  let cache = null;
  async function load() {
    if (cache && Date.now() - cache.at < 6 * 3600e3) return cache;
    try { const c = JSON.parse(localStorage.getItem('gw-enso') || 'null'); if (c && Date.now() - c.at < 6 * 3600e3) return cache = c; } catch (e) { }
    const [o, w] = await Promise.all([getText(ONI), getText(WK).catch(() => null)]);
    const oni = parseOni(o); if (!oni.length) throw new Error('no ONI');
    cache = { at: Date.now(), oni: oni.slice(-24), wk: w ? parseWk(w) : null };
    try { localStorage.setItem('gw-enso', JSON.stringify(cache)); } catch (e) { }
    return cache;
  }
  const fmt = v => (v > 0 ? '+' : '') + v.toFixed(2);
  function phase(a) { const m = Math.abs(a), s = m >= 2 ? 'stVeryStrong' : m >= 1.5 ? 'stStrong' : m >= 1 ? 'stModerate' : 'stWeak'; return a >= 0.5 ? { k: 'phElNino', s, c: '#ff7a45', imp: 'ensoImpElNino' } : a <= -0.5 ? { k: 'phLaNina', s, c: '#4aa3ff', imp: 'ensoImpLaNina' } : { k: 'phNeutral', s: null, c: '#9fb3c8', imp: 'ensoImpNeutral' }; }

  /* ---------- card ---------- */
  const css = document.createElement('style');
  css.textContent = '#ensoCard{position:fixed;z-index:14;left:50%;top:50%;transform:translate(-50%,-50%);width:min(460px,92vw);max-height:84vh;overflow:auto;padding:16px 18px;display:none;font-size:13.5px}#ensoCard.show{display:block}#ensoCard h3{margin:0 0 10px;font-size:17px}#ensoCard .ph{font-size:24px;font-weight:800;margin:4px 0}#ensoCard .row{display:flex;justify-content:space-between;gap:10px;padding:6px 0;border-top:1px solid rgba(255,255,255,.12)}#ensoCard .sub{color:var(--mut);font-size:11.5px;margin:10px 0 4px}#ensoCard .imp{margin:10px 0;padding:9px 11px;border-radius:12px;background:rgba(255,255,255,.08)}#ensoCard .src{color:var(--mut);font-size:11px;margin-top:8px}#ensoCard .bt{display:flex;gap:8px;margin-top:10px}#ensoCard button{flex:1;padding:8px 10px;border-radius:12px;font-weight:700;font-size:12.5px}#ensoCard .go{background:rgba(255,200,97,.95);color:#2a1d00}';
  document.head.appendChild(css);
  const card = document.createElement('div'); card.id = 'ensoCard'; card.className = 'glass'; document.body.appendChild(card);
  function chart(oni) {
    const W = 420, H = 110, n = oni.length, bw = W / n, y = v => H / 2 - v / 3 * (H / 2 - 6);
    let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}"><line x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}" stroke="rgba(255,255,255,.35)"/><line x1="0" x2="${W}" y1="${y(0.5)}" y2="${y(0.5)}" stroke="rgba(255,122,69,.45)" stroke-dasharray="3 3"/><line x1="0" x2="${W}" y1="${y(-0.5)}" y2="${y(-0.5)}" stroke="rgba(74,163,255,.45)" stroke-dasharray="3 3"/>`;
    oni.forEach((o, i) => { const v = Math.max(-3, Math.min(3, o.anom)), y0 = y(0), y1 = y(v); s += `<rect x="${(i * bw + 1).toFixed(1)}" y="${Math.min(y0, y1).toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${Math.max(1, Math.abs(y1 - y0)).toFixed(1)}" fill="${o.anom >= 0.5 ? '#ff7a45' : o.anom <= -0.5 ? '#4aa3ff' : '#9fb3c8'}"/>`; });
    return s + '</svg>';
  }
  async function open() {
    card.classList.add('show'); card.innerHTML = `<h3>🌊 ${T('ensoTitle')}</h3><div>${T('ensoLoading')}</div><div class="bt"><button id="ensoX">${T('ensoClose')}</button></div>`; $('ensoX').onclick = close;
    try {
      const d = await load(), last = d.oni[d.oni.length - 1], p = phase(last.anom), mon = MON[st.lang === 'ar' ? 'ar' : 'en'][SEAS.indexOf(last.s)], wk = d.wk;
      card.innerHTML = `<h3>🌊 ${T('ensoTitle')}</h3><div class="ph" style="color:${p.c}">${T(p.k)}${p.s ? ' · ' + T(p.s) : ''}</div>` +
        `<div class="row"><span>${T('ensoOni', mon, last.y)}</span><b>${fmt(last.anom)}</b></div>` +
        (wk ? `<div class="row"><span>${T('ensoWeek', wk.d)}</span><b>${wk.sst.toFixed(1)}°C · ${fmt(wk.anom)}</b></div>` : '') +
        `<div class="sub">${T('ensoChart')}</div>${chart(d.oni)}<div class="imp"><b>${T('ensoWhat')}</b><br>${T(p.imp)}</div>` +
        `<div class="bt"><button class="go" id="ensoGo">${T(A.mapv.layers().sst ? 'ensoHide' : 'ensoShow')}</button><button id="ensoX">${T('ensoClose')}</button></div><div class="src">${T('ensoSrc')}</div>`;
      $('ensoX').onclick = close; $('ensoGo').onclick = () => { const on = !A.mapv.layers().sst; close(); if (on) { if (st.view !== 'map') A.setView('map'); A.mapv.zoomTo([-180, 180, -62, 75]); } A.mapv.setLayers({ sst: on }); const bb = $('ensoBtn'); if (bb) bb.classList.toggle('on', on); A.renderView && A.renderView(); };
    } catch (e) { card.innerHTML = `<h3>🌊 ${T('ensoTitle')}</h3><div>${T('ensoFail')}</div><div class="bt"><button id="ensoX">${T('ensoClose')}</button></div>`; $('ensoX').onclick = close; }
  }
  function close() { card.classList.remove('show'); }
  const b = $('ensoBtn'); if (b) b.onclick = open;
  A.renderView && A.renderView();
  window.GW_ENSO = { open, close, parseOni, parseWk, phase };
})();
