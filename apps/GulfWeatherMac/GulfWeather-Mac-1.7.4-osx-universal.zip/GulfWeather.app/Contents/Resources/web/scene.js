/* Gulf Weather - animated 3D scene (Three.js). by Kankon · kankon.net */
(function () {
  const T = THREE;
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const smooth = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
  function mixC(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; }
  function lum(c) { return 0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]; }

  function dot(size, soft) {
    const c = document.createElement('canvas'); c.width = c.height = size;
    const g = c.getContext('2d'); const r = size / 2;
    const gr = g.createRadialGradient(r, r, 0, r, r, r);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(soft, 'rgba(255,255,255,0.6)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, size, size);
    const t = new T.CanvasTexture(c); return t;
  }

  window.createWeatherScene = function (canvas) {
    const renderer = new T.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputEncoding = T.sRGBEncoding;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    const scene = new T.Scene();
    scene.fog = new T.Fog(0xaaccee, 60, 380);
    const camera = new T.PerspectiveCamera(50, 1, 0.1, 1200);
    camera.position.set(0, 6, 24);

    /* ---------- sky ---------- */
    const skyU = {
      top: { value: new T.Color() }, horizon: { value: new T.Color() }, ground: { value: new T.Color(0x6b5236) },
      sunDir: { value: new T.Vector3(0, 1, 0) }, sunCol: { value: new T.Color(1, 0.9, 0.7) },
      sunDisk: { value: 1 }, glow: { value: 1 }, moonDir: { value: new T.Vector3(0, -1, 0) }, moon: { value: 0 }, haze: { value: 0 }
    };
    const sky = new T.Mesh(new T.SphereGeometry(500, 48, 24), new T.ShaderMaterial({
      uniforms: skyU, side: T.BackSide, depthWrite: false, fog: false,
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
      fragmentShader: `uniform vec3 top,horizon,ground,sunCol,sunDir,moonDir; uniform float sunDisk,glow,moon,haze; varying vec3 vD;
        void main(){ vec3 d=normalize(vD); float h=d.y; vec3 c;
          if(h>=0.0){ c=mix(horizon,top,pow(clamp(h,0.0,1.0),0.45+haze*0.6)); } else { c=mix(horizon,ground,clamp(-h*5.0,0.0,1.0)); }
          float s=max(dot(d,normalize(sunDir)),0.0);
          c+=sunCol*(smoothstep(0.9993,0.9997,s)*sunDisk*(1.0-haze*0.7)*6.0 + pow(s,10.0)*glow*0.45 + pow(s,180.0)*glow*1.2);
          float m=max(dot(d,normalize(moonDir)),0.0);
          c+=vec3(0.85,0.9,1.0)*(smoothstep(0.99955,0.99975,m)*1.4 + pow(m,60.0)*0.12)*moon;
          gl_FragColor=vec4(c,1.0); }`
    }));
    scene.add(sky);

    /* stars */
    const starN = 1600, sp = new Float32Array(starN * 3), r0 = rng(7);
    for (let i = 0; i < starN; i++) {
      const th = r0() * Math.PI * 2, ph = Math.acos(r0() * 0.95), R = 450;
      sp[i * 3] = R * Math.sin(ph) * Math.cos(th); sp[i * 3 + 1] = R * Math.cos(ph); sp[i * 3 + 2] = R * Math.sin(ph) * Math.sin(th);
    }
    const starG = new T.BufferGeometry(); starG.setAttribute('position', new T.BufferAttribute(sp, 3));
    const starM = new T.PointsMaterial({ size: 1.6, map: dot(32, 0.25), transparent: true, opacity: 0, depthWrite: false, fog: false, sizeAttenuation: false });
    scene.add(new T.Points(starG, starM));

    /* ---------- lights ---------- */
    const hemi = new T.HemisphereLight(0xbfdfff, 0x8a6a42, 0.6); scene.add(hemi);
    const sun = new T.DirectionalLight(0xfff1dd, 1.6); scene.add(sun); scene.add(sun.target);
    const moonL = new T.DirectionalLight(0x8fa8ff, 0); scene.add(moonL);
    const flashL = new T.AmbientLight(0xd8e4ff, 0); scene.add(flashL);

    /* ---------- terrain: dunes ---------- */
    const rt = rng(42);
    function dune(x, z) {
      let h = 0;
      h += 1.9 * Math.pow(0.5 + 0.5 * Math.sin(x * 0.07 + Math.sin(z * 0.045) * 2.2), 2.2);
      h += 0.9 * Math.pow(0.5 + 0.5 * Math.sin(x * 0.13 - z * 0.09 + 1.3), 2.0);
      h += 0.35 * Math.sin(x * 0.4 + z * 0.3) * Math.sin(z * 0.27);
      const front = smooth(-95, -70, z);           // flatten toward the coast
      return h * (0.25 + 0.75 * front) * 1.1 + lerp(-1.6, 0, smooth(-112, -96, z));
    }
    const tg = new T.PlaneGeometry(420, 170, 210, 90); tg.rotateX(-Math.PI / 2); tg.translate(0, 0, -62);
    const tp = tg.attributes.position, tc = new Float32Array(tp.count * 3);
    for (let i = 0; i < tp.count; i++) {
      const x = tp.getX(i), z = tp.getZ(i), y = dune(x, z); tp.setY(i, y);
      const v = 0.92 + rt() * 0.1 + y * 0.025, beach = smooth(-90, -104, z);
      const c = mixC([0.78 * v, 0.53 * v, 0.29 * v], [0.72, 0.62, 0.45], beach);
      tc[i * 3] = c[0]; tc[i * 3 + 1] = c[1]; tc[i * 3 + 2] = c[2];
    }
    tg.setAttribute('color', new T.BufferAttribute(tc, 3)); tg.computeVertexNormals();
    const terrM = new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, flatShading: true }); scene.add(new T.Mesh(tg, terrM));

    /* ---------- sea (shader: moving waves, sky reflection, sun glitter) ---------- */
    const seaU = {
      time: { value: 0 }, amp: { value: 0.4 }, deep: { value: new T.Color(0x0b4a63) }, shallow: { value: new T.Color(0x2a9db0) }, sky: { value: new T.Color(0x9cc7e8) },
      sunDir: { value: new T.Vector3(0, 1, 0) }, sunCol: { value: new T.Color(1, .9, .7) }, sunI: { value: 1 },
      fogCol: { value: new T.Color(0xaaccee) }, fogNear: { value: 60 }, fogFar: { value: 380 }, cam: { value: new T.Vector3() }
    };
    const seaM = new T.ShaderMaterial({
      uniforms: seaU,
      vertexShader: `uniform float time,amp; varying vec3 vW; varying float vH;
        float h(vec2 p){ return sin(p.x*0.09+time*1.1)*0.5+sin(p.y*0.13-time*0.8+p.x*0.04)*0.5+sin((p.x+p.y)*0.21+time*1.7)*0.25+sin(p.x*0.35-time*2.3)*0.12; }
        void main(){ vec3 p=position; float y=h(p.xz)*amp; p.y+=y; vH=y; vec4 w=modelMatrix*vec4(p,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `uniform vec3 deep,shallow,sky,sunDir,sunCol,fogCol,cam; uniform float time,amp,sunI,fogNear,fogFar; varying vec3 vW; varying float vH;
        float h(vec2 p){ return sin(p.x*0.09+time*1.1)*0.5+sin(p.y*0.13-time*0.8+p.x*0.04)*0.5+sin((p.x+p.y)*0.21+time*1.7)*0.25+sin(p.x*0.35-time*2.3)*0.12+sin(p.x*1.3+p.y*0.9+time*3.1)*0.04+sin(p.x*0.7-p.y*1.7-time*2.2)*0.05; }
        void main(){
          vec2 p=vW.xz; float e=0.3;
          vec3 n=normalize(vec3(-(h(p+vec2(e,0.))-h(p-vec2(e,0.)))*amp/(2.*e)*1.6,1.0,-(h(p+vec2(0.,e))-h(p-vec2(0.,e)))*amp/(2.*e)*1.6));
          vec3 v=normalize(cam-vW); float fr=pow(1.0-max(dot(n,v),0.0),3.0);
          float coast=smoothstep(-118.0,-104.0,vW.z);
          vec3 base=mix(deep,shallow,clamp(vH*0.6+0.5+coast*0.6,0.0,1.0));
          vec3 col=mix(base,sky,clamp(fr*0.85+0.1,0.0,1.0));
          vec3 r=reflect(-v,n); float sp=pow(max(dot(r,normalize(sunDir)),0.0),90.0); float gl=pow(max(dot(r,normalize(sunDir)),0.0),600.0);
          col+=sunCol*(sp*0.35+gl*2.5)*sunI;
          float foam=smoothstep(0.55,0.9,vH+0.45)*0.18+smoothstep(-108.0,-103.0,vW.z)*smoothstep(-100.0,-103.5,vW.z)*0.35*(0.5+0.5*sin(time*1.5+vW.x*0.4));
          col+=vec3(foam);
          float d=length(vW-cam); float f=clamp((d-fogNear)/(fogFar-fogNear),0.0,1.0); col=mix(col,fogCol,f);
          gl_FragColor=vec4(col,1.0); }`
    });
    const sg = new T.PlaneGeometry(900, 300, 220, 70); sg.rotateX(-Math.PI / 2); sg.translate(0, -0.5, -255);
    const sea = new T.Mesh(sg, seaM); scene.add(sea);

    /* ---------- skyline (generic towers on the coast) ---------- */
    function windowTex() {
      const c = document.createElement('canvas'); c.width = 64; c.height = 128; const g = c.getContext('2d');
      g.fillStyle = '#000'; g.fillRect(0, 0, 64, 128); const r = rng(3);
      for (let y = 4; y < 128; y += 6) for (let x = 4; x < 64; x += 8) { if (r() < 0.55) { g.fillStyle = r() < 0.7 ? '#ffd9a0' : '#bfe0ff'; g.fillRect(x, y, 4, 3); } }
      const t = new T.CanvasTexture(c); t.wrapS = t.wrapT = T.RepeatWrapping; return t;
    }
    const wt = windowTex();
    const towerM = new T.MeshStandardMaterial({ color: 0x8c9aa8, roughness: 0.4, metalness: 0.5, emissive: 0xffffff, emissiveMap: wt, emissiveIntensity: 0 });
    const towerM2 = new T.MeshStandardMaterial({ color: 0xd9cbb4, roughness: 0.6, metalness: 0.1, emissive: 0xffffff, emissiveMap: wt, emissiveIntensity: 0 });
    const city = new T.Group(); const rc = rng(11);
    for (let i = 0; i < 30; i++) {
      const w = 2 + rc() * 3, d = 2 + rc() * 3, hh = 5 + Math.pow(rc(), 2) * 26;
      const g = new T.BoxGeometry(w, hh, d); g.translate(0, hh / 2, 0);
      const m = new T.Mesh(g, i % 3 === 0 ? towerM2 : towerM); m.position.set(-75 + i * 4.3 + rc() * 2, -0.3, -100 - rc() * 8); city.add(m);
    }
    // one slim landmark tower with two spheres (generic water-tower style)
    const lmM = new T.MeshStandardMaterial({ color: 0xdfe6ee, roughness: 0.35, metalness: 0.4 });
    const lm = new T.Group();
    const shaft = new T.Mesh(new T.CylinderGeometry(0.35, 0.8, 40, 12), lmM); shaft.position.y = 20; lm.add(shaft);
    const b1 = new T.Mesh(new T.SphereGeometry(3.2, 20, 14), new T.MeshStandardMaterial({ color: 0x2d6ea8, roughness: 0.3, metalness: 0.6 })); b1.position.y = 26; lm.add(b1);
    const b2 = new T.Mesh(new T.SphereGeometry(1.8, 16, 12), b1.material); b2.position.y = 34; lm.add(b2);
    const beacon = new T.Mesh(new T.SphereGeometry(0.35, 8, 6), new T.MeshBasicMaterial({ color: 0xff3030 })); beacon.position.y = 40.5; lm.add(beacon);
    lm.position.set(28, -0.3, -98); city.add(lm);
    const st2 = new T.Group(); const stM = new T.MeshStandardMaterial({ color: 0xb8c6d4, roughness: 0.3, metalness: 0.7, emissive: 0xffffff, emissiveMap: wt, emissiveIntensity: 0 });
    [[3.2, 30], [2.4, 46], [1.6, 60], [0.9, 72], [0.25, 86]].forEach(([r, h], i) => { const g = new T.CylinderGeometry(r * 0.8, r, h, 8); g.translate(0, h / 2, 0); const m = new T.Mesh(g, i < 4 ? stM : lmM); m.position.x = (i % 2 ? 1 : -1) * 0.6; st2.add(m); });
    st2.position.set(30, -0.3, -104); st2.visible = false; city.add(st2);
    const pyr = new T.Group(); const pyM = new T.MeshStandardMaterial({ color: 0xd8b878, roughness: 1, flatShading: true });
    [[-10, 26, 0], [14, 20, -6], [34, 12, -12]].forEach(([x, h, z]) => { const m = new T.Mesh(new T.ConeGeometry(h * 1.25, h, 4), pyM); m.rotation.y = Math.PI / 4; m.position.set(x, h / 2 - 0.2, -92 + z); pyr.add(m); });
    pyr.visible = false; scene.add(pyr);
    scene.add(city);

    /* ---------- palms ---------- */
    const trunkM = new T.MeshStandardMaterial({ color: 0x7a5a3a, roughness: 1, flatShading: true });
    const leafM = new T.MeshStandardMaterial({ color: 0x3f7a2e, roughness: 0.8, side: T.DoubleSide, flatShading: true });
    function leafGeo() {
      const s = new T.Shape(); s.moveTo(0, 0); s.quadraticCurveTo(1.2, 0.5, 4.6, 0); s.quadraticCurveTo(1.2, -0.5, 0, 0);
      const g = new T.ShapeGeometry(s, 6); const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) { const x = p.getX(i); p.setZ(i, -0.11 * x * x); }
      g.rotateX(-Math.PI / 2); g.computeVertexNormals(); return g;
    }
    const lg = leafGeo(); const palms = [];
    function palm(x, z, s, ph) {
      const root = new T.Group(); root.position.set(x, dune(x, z) - 0.1, z); root.scale.setScalar(s);
      const sway = new T.Group(); root.add(sway);
      let y = 0, cur = sway;
      for (let i = 0; i < 7; i++) {
        const seg = new T.Mesh(new T.CylinderGeometry(0.22 - i * 0.012, 0.27 - i * 0.012, 1.2, 7), trunkM); seg.position.y = 0.6;
        const g = new T.Group(); g.position.y = i === 0 ? 0 : 1.15; g.rotation.z = 0.035; g.add(seg); cur.add(g); cur = g; y += 1.15;
      }
      const crown = new T.Group(); crown.position.y = 1.2; cur.add(crown);
      const leaves = [];
      for (let i = 0; i < 9; i++) {
        const l = new T.Mesh(lg, leafM); const a = (i / 9) * Math.PI * 2;
        const holder = new T.Group(); holder.rotation.y = a; l.rotation.z = 0.25 + (i % 2) * 0.2; holder.add(l); crown.add(holder); leaves.push(l);
      }
      scene.add(root); palms.push({ sway, leaves, ph, segs: sway });
    }
    palm(-15, 6, 1.25, 0); palm(-10.5, 1.5, 1.0, 1.7); palm(14, 5, 1.15, 0.8); palm(18.5, -1, 0.9, 2.4); palm(-24, -6, 1.1, 3.1);

    /* ---------- clouds (soft billboard puffs, lit by the sun) ---------- */
    function puffTex(seed) {
      const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'), r = rng(seed);
      g.clearRect(0, 0, 256, 256);
      for (let i = 0; i < 26; i++) {
        const x = 128 + (r() - 0.5) * 120, y = 128 + (r() - 0.5) * 70, rad = 26 + r() * 46, a = 0.1 + r() * 0.16;
        const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, `rgba(255,255,255,${a * 2})`); gr.addColorStop(0.6, `rgba(255,255,255,${a})`); gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
      }
      // shade: lit top, darker flat base
      g.globalCompositeOperation = 'source-atop'; const sh = g.createLinearGradient(0, 40, 0, 220); sh.addColorStop(0, 'rgba(255,255,255,1)'); sh.addColorStop(0.55, 'rgba(228,232,240,1)'); sh.addColorStop(1, 'rgba(150,160,180,1)');
      g.fillStyle = sh; g.fillRect(0, 0, 256, 256);
      const t = new T.CanvasTexture(c); return t;
    }
    const puffs = [puffTex(1), puffTex(2), puffTex(3), puffTex(4)];
    const clouds = []; const rcl = rng(99);
    for (let i = 0; i < 30; i++) {
      const type = i % 6 === 0 ? 'storm' : i % 3 === 0 ? 'strat' : 'cumulus';
      const m = new T.SpriteMaterial({ map: puffs[i % 4], color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, fog: false });
      const g = new T.Group(); const n = type === 'strat' ? 12 : type === 'storm' ? 22 : 16;
      for (let k = 0; k < n; k++) {
        const sp = new T.Sprite(m); const f = k / n;
        if (type === 'strat') { sp.scale.set(70 + rcl() * 40, 22 + rcl() * 10, 1); sp.position.set((rcl() - 0.5) * 120, rcl() * 3, (rcl() - 0.5) * 30); }
        else if (type === 'storm') { const h = rcl(); sp.scale.set(40 + rcl() * 26 - h * 10, 30 + rcl() * 18, 1); sp.position.set((rcl() - 0.5) * 46 * (1.2 - h * 0.5) + (h > 0.75 ? (rcl() - 0.2) * 40 : 0), h * 46, (rcl() - 0.5) * 22); }
        else { const h = Math.pow(rcl(), 1.6); sp.scale.set(36 + rcl() * 24, 24 + rcl() * 14, 1); sp.position.set((rcl() - 0.5) * 80 * (1 - h * 0.5), h * 20, (rcl() - 0.5) * 16); }
        sp.material.rotation = 0; g.add(sp);
      }
      const sc = type === 'strat' ? 1.2 : 1 + rcl() * 0.7; g.scale.setScalar(sc);
      g.position.set(-170 + rcl() * 340, type === 'strat' ? 55 + rcl() * 25 : 38 + rcl() * 30 - (type === 'storm' ? 12 : 0), -60 - rcl() * 190);
      g.userData = { m, rank: rcl(), op: 0, type }; scene.add(g); clouds.push(g);
    }
    clouds.sort((a, b) => a.userData.rank - b.userData.rank);

    /* sun glow (bloom) */
    const glowTex = dot(256, 0.2);
    const sunGlow = new T.Sprite(new T.SpriteMaterial({ map: glowTex, color: 0xffe2a0, transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false, fog: false }));
    sunGlow.scale.set(260, 260, 1); scene.add(sunGlow);
    const sunGlow2 = new T.Sprite(new T.SpriteMaterial({ map: glowTex, color: 0xffb060, transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false, fog: false }));
    sunGlow2.scale.set(700, 380, 1); scene.add(sunGlow2);

    /* dust wall (haboob): big soft sprites that roll toward the viewer */
    const dustTex = dot(256, 0.1); const dustWall = [];
    for (let i = 0; i < 46; i++) {
      const m = new T.SpriteMaterial({ map: puffs[i % 4], color: 0xc89a5e, transparent: true, opacity: 0, depthWrite: false, fog: false });
      const sp = new T.Sprite(m); sp.scale.set(70 + rcl() * 50, 40 + rcl() * 40, 1); sp.position.set(-120 + rcl() * 240, 3 + rcl() * 26, -40 - rcl() * 110); sp.userData = { sx: sp.position.x, ph: rcl() * 6, sp: 0.5 + rcl() }; scene.add(sp); dustWall.push(sp);
    }

    /* ---------- rain ---------- */
    const RN = 12000, rp = new Float32Array(RN * 6), rd = []; const rr = rng(5);
    for (let i = 0; i < RN; i++) rd.push({ x: -50 + rr() * 100, y: rr() * 45, z: -60 + rr() * 80, v: 0.8 + rr() * 0.5, l: 0.8 + rr() * 1.6 });
    const rainG = new T.BufferGeometry(); rainG.setAttribute('position', new T.BufferAttribute(rp, 3));
    const rainM = new T.LineBasicMaterial({ color: 0xd4d8dc, transparent: true, opacity: 0, depthWrite: false });
    const rain = new T.LineSegments(rainG, rainM); rain.frustumCulled = false; scene.add(rain);

    /* rain splashes + ground mist */
    const SN = 1800, spp = new Float32Array(SN * 3);
    const splashG = new T.BufferGeometry(); splashG.setAttribute('position', new T.BufferAttribute(spp, 3));
    const splashM = new T.PointsMaterial({ color: 0xdfeaff, size: 0.9, map: dot(32, 0.3), transparent: true, opacity: 0, depthWrite: false });
    const splash = new T.Points(splashG, splashM); splash.frustumCulled = false; scene.add(splash);

    /* ---------- dust ---------- */
    const DN = 5000, dp = new Float32Array(DN * 3), dd = []; const rdu = rng(17);
    for (let i = 0; i < DN; i++) dd.push({ x: -70 + rdu() * 140, y: Math.pow(rdu(), 1.8) * 22, z: -70 + rdu() * 92, s: 0.6 + rdu() * 0.8, w: rdu() * 6 });
    const dustG = new T.BufferGeometry(); dustG.setAttribute('position', new T.BufferAttribute(dp, 3));
    const dustM = new T.PointsMaterial({ color: 0xd8ae78, size: 0.2, map: dot(32, 0.4), transparent: true, opacity: 0, depthWrite: false });
    const dust = new T.Points(dustG, dustM); dust.frustumCulled = false; scene.add(dust);

    /* ---------- wind streaks ---------- */
    const WN = 90, wp = new Float32Array(WN * 6), wd = []; const rw = rng(23);
    for (let i = 0; i < WN; i++) wd.push({ x: -60 + rw() * 120, y: 1 + rw() * 16, z: -40 + rw() * 55, l: 2 + rw() * 4, s: 0.7 + rw() * 0.6 });
    const windG = new T.BufferGeometry(); windG.setAttribute('position', new T.BufferAttribute(wp, 3));
    const windM = new T.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0 });
    const windL = new T.LineSegments(windG, windM); windL.frustumCulled = false; scene.add(windL);

    /* ---------- lightning bolt ---------- */
    const boltG = new T.BufferGeometry(); boltG.setAttribute('position', new T.BufferAttribute(new Float32Array(40 * 3), 3));
    const boltM = new T.LineBasicMaterial({ color: 0xeef3ff, transparent: true, opacity: 0, fog: false });
    const bolt = new T.Line(boltG, boltM); bolt.frustumCulled = false; scene.add(bolt);
    const bolts = [{ g: boltG }];
    for (let q = 1; q < 3; q++) { const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(new Float32Array(40 * 3), 3)); const l = new T.Line(g, boltM); l.frustumCulled = false; scene.add(l); bolts.push({ g }); }
    function makeBolt(n) {
      for (let q = 0; q < (n || 1); q++) makeBolt1(bolts[q].g);
      for (let q = n || 1; q < 3; q++) bolts[q].g.setDrawRange(0, 0);
      for (let q = 0; q < (n || 1); q++) bolts[q].g.setDrawRange(0, 40);
    }
    function makeBolt1(bg) {
      const a = bg.attributes.position; let x = -60 + Math.random() * 120, y = 34, z = -70 - Math.random() * 60;
      for (let i = 0; i < 40; i++) { a.setXYZ(i, x, y, z); x += (Math.random() - 0.5) * 3; y -= 0.9 + Math.random() * 0.4; z += (Math.random() - 0.5) * 2; if (y < 0) y = 0; }
      a.needsUpdate = true;
    }

    /* ---------- state ---------- */
    const cur = { elev: 0.5, az: 0.5, cloud: 0, rain: 0, dust: 0, fog: 0, wind: 10, wdx: 1, wdz: 0, thunder: 0, heat: 0, night: 0 };
    let target = Object.assign({}, cur);
    let flash = 0, time = 0, mouseX = 0, mouseY = 0;
    window.addEventListener('pointermove', e => { mouseX = e.clientX / window.innerWidth - 0.5; mouseY = e.clientY / window.innerHeight - 0.5; });

    function resize() {
      const w = canvas.clientWidth, h = canvas.clientHeight;
      if (canvas.width !== Math.floor(w * renderer.getPixelRatio()) || canvas.height !== Math.floor(h * renderer.getPixelRatio())) {
        renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
      }
    }

    function skyColors(e) {
      const N = { t: [0.008, 0.016, 0.055], h: [0.035, 0.06, 0.14] };
      const W = { t: [0.13, 0.17, 0.38], h: [0.98, 0.5, 0.26] };
      const D = { t: [0.1, 0.38, 0.8], h: [0.62, 0.8, 0.95] };
      if (e < -0.18) return N;
      if (e < 0) { const k = smooth(-0.18, 0, e); return { t: mixC(N.t, W.t, k), h: mixC(N.h, W.h, k) }; }
      const k = smooth(0, 0.32, e); return { t: mixC(W.t, D.t, k), h: mixC(W.h, D.h, k) };
    }

    function frame(dt) {
      time += dt; resize();
      const k = 1 - Math.pow(0.04, dt);   // smoothing
      for (const key in target) if (typeof target[key] === 'number') cur[key] = lerp(cur[key], target[key], key === 'elev' || key === 'az' ? Math.min(1, k * 3) : k);
      const e = cur.elev, day = smooth(-0.08, 0.2, e), night = 1 - smooth(-0.2, 0.02, e);

      // sun & moon directions (camera looks north: east = +x)
      const ang = Math.PI * clamp(cur.az, 0, 1);
      const sunDir = new T.Vector3(Math.cos(ang) * 0.62, e * 0.75, -0.8).normalize();
      const moonDir = new T.Vector3(-0.35, 0.3 + night * 0.2, -0.85).normalize();

      // sky colors with weather tints
      let s = skyColors(e); let tc = s.t, hc = s.h; const bright = Math.max(0.05, lum(hc));
      const over = Math.min(1, Math.pow(cur.cloud, 1.4) * 0.75 + cur.rain * 0.6, 1) * 1; const overR = cur.rain > 0 ? 0.6 + 0.4 * cur.rain : 0, overF = Math.max(over, overR);
      tc = mixC(tc, [0.5 * bright + 0.03, 0.52 * bright + 0.03, 0.54 * bright + 0.03], overF);
      hc = mixC(hc, [0.6 * bright + 0.04, 0.62 * bright + 0.04, 0.63 * bright + 0.04], overF);
      const dustTint = [0.8 * bright + 0.05, 0.6 * bright + 0.04, 0.36 * bright + 0.02];
      tc = mixC(tc, dustTint, cur.dust * 0.8); hc = mixC(hc, [dustTint[0] * 1.1, dustTint[1] * 1.05, dustTint[2]], cur.dust * 0.95);
      tc = mixC(tc, [0.7 * bright + 0.04, 0.72 * bright + 0.04, 0.75 * bright + 0.04], cur.fog * 0.8);
      hc = mixC(hc, [0.75 * bright + 0.05, 0.77 * bright + 0.05, 0.8 * bright + 0.05], cur.fog * 0.9);
      if (flash > 0) { tc = mixC(tc, [0.85, 0.88, 1], flash * 0.6); hc = mixC(hc, [0.8, 0.84, 1], flash * 0.5); }
      skyU.top.value.setRGB(tc[0], tc[1], tc[2]); skyU.horizon.value.setRGB(hc[0], hc[1], hc[2]);
      skyU.sunDir.value.copy(sunDir); skyU.moonDir.value.copy(moonDir);
      const low = 1 - smooth(0.02, 0.3, e);
      skyU.sunCol.value.setRGB(1, lerp(0.92, 0.62, low), lerp(0.78, 0.38, low));
      const block = clamp(1 - cur.cloud * 0.8 - cur.dust * 0.7 - cur.fog * 0.8 - cur.rain * 0.5, 0, 1);
      skyU.sunDisk.value = smooth(-0.03, 0.02, e) * block; skyU.glow.value = smooth(-0.15, 0.05, e) * (0.4 + 0.6 * block) * (1 + cur.heat * 0.6);
      skyU.moon.value = night * clamp(1 - cur.cloud - cur.dust, 0, 1); skyU.haze.value = Math.max(cur.dust, cur.fog);
      skyU.ground.value.setRGB(hc[0] * lerp(0.7, 0.72, overR), hc[1] * lerp(0.6, 0.7, overR), hc[2] * lerp(0.45, 0.72, overR));
      starM.opacity = night * clamp(1 - cur.cloud * 1.2 - cur.dust * 1.5 - cur.fog, 0, 1) * 0.95;

      // fog
      const fc = mixC(hc, tc, 0.15); scene.fog.color.setRGB(fc[0], fc[1], fc[2]);
      const vis = Math.max(cur.dust, cur.fog * 0.9, cur.rain * 0.7);
      scene.fog.near = lerp(70, 2, vis); scene.fog.far = lerp(420, 45, Math.pow(vis, 0.7));

      // lights
      sun.position.copy(sunDir).multiplyScalar(100); sun.color.setRGB(1, lerp(0.95, 0.66, low), lerp(0.86, 0.45, low));
      sun.intensity = day * 1.5 * (0.25 + 0.75 * block);
      moonL.position.copy(moonDir).multiplyScalar(100); moonL.intensity = night * 0.35 * clamp(1 - cur.cloud, 0.3, 1);
      hemi.color.setRGB(tc[0] + 0.12, tc[1] + 0.12, tc[2] + 0.14); hemi.groundColor.setRGB(0.5 * bright + 0.05, 0.4 * bright + 0.04, 0.28 * bright + 0.03);
      hemi.intensity = 0.22 + day * 0.38 + night * 0.15;
      towerM.emissiveIntensity = night * 1.4 + (1 - day) * 0.3; stM.emissiveIntensity = towerM.emissiveIntensity * 0.6; towerM2.emissiveIntensity = towerM.emissiveIntensity;
      beacon.material.color.setRGB(Math.sin(time * 3) > 0 ? 1 : 0.25, 0.1, 0.1);
      seaU.time.value = time; seaU.amp.value = 0.45 + cur.wind / 38; seaU.cam.value.copy(camera.position);
      seaU.sunDir.value.copy(sunDir); seaU.sunCol.value.setRGB(1, lerp(0.92, 0.6, low), lerp(0.78, 0.35, low)); seaU.sunI.value = smooth(-0.03, 0.05, e) * block;
      seaU.sky.value.setRGB(hc[0], hc[1], hc[2]); seaU.fogCol.value.copy(scene.fog.color); seaU.fogNear.value = scene.fog.near; seaU.fogFar.value = scene.fog.far;
      seaU.deep.value.setRGB(lerp(0.01, 0.04, day) + cur.dust * 0.12, lerp(0.03, 0.27, day) + cur.dust * 0.06, lerp(0.07, 0.38, day));
      seaU.shallow.value.setRGB(lerp(0.03, 0.14, day) + cur.dust * 0.2, lerp(0.08, 0.6, day) + cur.dust * 0.1, lerp(0.12, 0.68, day));
      terrM.color.setScalar(1 - cur.rain * 0.32); terrM.roughness = 0.95 - cur.rain * 0.4;

      // wind vector
      const ws = cur.wind, wx = cur.wdx, wz = cur.wdz;
      // palms sway
      for (const p of palms) {
        const a = Math.min(ws, 80) / 80;
        p.sway.rotation.z = -wx * a * 0.12 + Math.sin(time * (1 + a * 3) + p.ph) * (0.015 + a * 0.06);
        p.sway.rotation.x = wz * a * 0.08 + Math.cos(time * (0.8 + a * 2.5) + p.ph) * (0.01 + a * 0.03);
        p.leaves.forEach((l, i) => { l.rotation.x = Math.sin(time * (2 + a * 8) + i + p.ph) * (0.04 + a * 0.25); });
      }

      // clouds
      const cn = Math.max(cur.cloud, cur.rain > 0 ? Math.min(1, 0.62 + cur.rain * 0.5) : 0, cur.thunder ? 0.95 : 0), litR = 1, litG = lerp(0.98, 0.74, low), litB = lerp(0.96, 0.55, low);
      const dk = Math.min(1, Math.max(cur.rain * 0.95, cur.thunder * 1.0)), shade = lerp(1, 0.42, dk);
      clouds.forEach((g, i) => {
        const ty = g.userData.type;
        const want = ty === 'storm' ? ((cur.thunder > 0.5 || cur.rain > 0.2) ? 1 : 0) : ty === 'strat' ? (cn > 0.5 ? 1 : 0) : ((i / clouds.length) < cn + 0.02 && cn > 0.04 ? 1 : 0);
        g.userData.op = lerp(g.userData.op, want, k * 0.6);
        g.userData.m.opacity = g.userData.op * (ty === 'strat' ? 0.62 + cur.rain * 0.25 : 0.9) * (1 - cur.dust * 0.7);
        const L = lerp(0.1, 1, day), nr = lerp(0.1, litR, day) * shade, ng = lerp(0.12, litG, day) * shade, nb = lerp(0.22, litB, day) * shade;
        g.userData.m.color.setRGB((nr * (1 - cur.dust * 0.1)) + flash * 0.5, (ng * (1 - cur.dust * 0.22)) + flash * 0.5, (nb * (1 - cur.dust * 0.4)) + flash * 0.6);
        g.position.x += (wx * (0.4 + ws * 0.06)) * dt; g.position.z += wz * ws * 0.02 * dt;
        if (g.position.x > 190) g.position.x = -190; if (g.position.x < -190) g.position.x = 190;
        if (g.position.z > -30) g.position.z = -250; if (g.position.z < -250) g.position.z = -30;
        g.visible = g.userData.op > 0.01;
      });
      // sun glow
      sunGlow.position.copy(sunDir).multiplyScalar(420); sunGlow2.position.copy(sunDir).multiplyScalar(430);
      sunGlow.material.opacity = smooth(-0.04, 0.06, e) * block * 0.7; sunGlow2.material.opacity = smooth(-0.1, 0.05, e) * (1 - smooth(0.05, 0.4, e) * 0.7) * block * 0.45;
      sunGlow.material.color.setRGB(1, lerp(0.9, 0.62, low), lerp(0.62, 0.3, low));
      // dust wall
      const dw = clamp(cur.dust * 1.5 - 0.12, 0, 0.75);
      dustWall.forEach(sp => {
        sp.material.opacity = dw * 0.8; sp.visible = dw > 0.01; if (!sp.visible) return;
        sp.material.color.setRGB(lerp(0.2, 0.86, day) * 0.9, lerp(0.15, 0.62, day) * 0.9, lerp(0.1, 0.36, day) * 0.9);
        sp.position.x = sp.userData.sx + Math.sin(time * 0.1 * sp.userData.sp + sp.userData.ph) * 18 + wx * time * 0.0; sp.position.z += (1.5 + ws * 0.08) * sp.userData.sp * dt; if (sp.position.z > -22) sp.position.z = -150;
      });
      // rain splashes on the ground
      const sn = Math.floor(SN * clamp(cur.rain, 0, 1)); splashM.opacity = clamp(cur.rain * 1.8, 0, 0.7);
      for (let i = 0; i < sn; i++) { if (Math.random() < 0.35) { const x = -34 + Math.random() * 68, z = -48 + Math.random() * 56; spp[i * 3] = x; spp[i * 3 + 1] = dune(x, z) + 0.12; spp[i * 3 + 2] = z; } }
      splashG.setDrawRange(0, sn); splashG.attributes.position.needsUpdate = true;

      // rain
      const rn = Math.floor(RN * clamp(cur.rain, 0, 1)); rainM.opacity = clamp(0.12 + cur.rain * 2.2, 0, cur.rain > 0 ? 0.9 : 0);
      const fall = 52, len = 1.6;
      for (let i = 0; i < rn; i++) {
        const d = rd[i]; d.y -= fall * d.v * dt; d.x += wx * ws * 0.12 * dt; d.z += wz * ws * 0.12 * dt;
        if (d.y < 0) { d.y = 40 + Math.random() * 5; d.x = -50 + Math.random() * 100; d.z = -60 + Math.random() * 80; }
        const o = i * 6, sx = wx * ws * 0.004, sz = wz * ws * 0.004;
        rp[o] = d.x; rp[o + 1] = d.y; rp[o + 2] = d.z; rp[o + 3] = d.x - sx * len * 10; rp[o + 4] = d.y + len * d.l; rp[o + 5] = d.z - sz * len * 10;
      }
      rainG.setDrawRange(0, rn * 2); rainG.attributes.position.needsUpdate = true;

      // dust
      dustM.opacity = clamp(cur.dust * 1.1, 0, 0.85); dustM.color.setRGB(lerp(0.85, 0.35, night), lerp(0.68, 0.28, night), lerp(0.47, 0.2, night));
      const dn = Math.floor(DN * clamp(cur.dust * 1.2, 0, 1)), dv = 3 + ws * 0.35;
      for (let i = 0; i < dn; i++) {
        const d = dd[i]; d.x += wx * dv * d.s * dt; d.z += wz * dv * d.s * dt; d.y += Math.sin(time * 2 + d.w) * 0.02;
        if (d.x > 70) d.x = -70; if (d.x < -70) d.x = 70; if (d.z > 22) d.z = -70; if (d.z < -70) d.z = 22;
        dp[i * 3] = d.x; dp[i * 3 + 1] = d.y; dp[i * 3 + 2] = d.z;
      }
      dustG.setDrawRange(0, dn); dustG.attributes.position.needsUpdate = true;

      // wind streaks
      windM.opacity = clamp((ws - 22) / 50, 0, 0.22) * (1 - night * 0.6);
      for (let i = 0; i < WN; i++) {
        const d = wd[i]; const v = (8 + ws * 0.6) * d.s; d.x += wx * v * dt; d.z += wz * v * dt;
        if (d.x > 62) d.x = -62; if (d.x < -62) d.x = 62; if (d.z > 16) d.z = -40; if (d.z < -40) d.z = 16;
        const o = i * 6; wp[o] = d.x; wp[o + 1] = d.y + Math.sin(time * 3 + i) * 0.2; wp[o + 2] = d.z; wp[o + 3] = d.x - wx * d.l; wp[o + 4] = d.y; wp[o + 5] = d.z - wz * d.l;
      }
      windG.attributes.position.needsUpdate = true;

      // lightning
      if (cur.thunder > 0.5 && Math.random() < dt * (0.9 + cur.rain * 1.1)) { flash = 1; makeBolt(Math.random() < 0.5 + cur.rain * 0.4 ? 2 + (Math.random() < 0.35 ? 1 : 0) : 1); }
      flash = Math.max(0, flash - dt * (flash > 0.6 ? 2.2 : 3.5)); if (flash > 0 && flash < 0.75 && Math.random() < (cur.thunder > 0.5 ? 0.2 : 0.08)) flash = 0.95;
      flashL.intensity = flash * 2.6; boltM.opacity = flash > 0.45 ? 1 : 0;

      // camera drift
      camera.position.x = Math.sin(time * 0.05) * 3 + mouseX * 3; camera.position.y = 8.5 + Math.sin(time * 0.07) * 0.4 - mouseY * 1.5;
      camera.lookAt(0, 3.2, -40);
      renderer.render(scene, camera);
    }

    return {
      setTarget(p) {
        target = Object.assign({}, cur, p);
        const a = ((p.windDir || 0) + 180) * Math.PI / 180; target.wdx = Math.sin(a); target.wdz = -Math.cos(a);
      },
      setCountry(c, inland) { lm.visible = c === 'KW'; st2.visible = c === 'AE'; sea.visible = !inland; pyr.visible = c === 'EG'; city.children.forEach(m => { if (m !== lm && m !== st2) m.visible = c !== 'EG'; }); },
      jump() { Object.assign(cur, target); },
      frame
    };
  };
})();
