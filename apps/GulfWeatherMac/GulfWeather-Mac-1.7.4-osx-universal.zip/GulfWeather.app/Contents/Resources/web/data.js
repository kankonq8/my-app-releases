/* Gulf Weather - cities, live data (Open-Meteo, no key) and offline sample. by Kankon · kankon.net */
(function () {
  const COUNTRIES = [
    { id: 'KW', en: 'Kuwait', ar: 'الكويت', flag: 'KW' },
    { id: 'SA', en: 'Saudi Arabia', ar: 'السعودية', flag: 'SA' },
    { id: 'AE', en: 'UAE', ar: 'الإمارات', flag: 'AE' },
    { id: 'QA', en: 'Qatar', ar: 'قطر', flag: 'QA' },
    { id: 'BH', en: 'Bahrain', ar: 'البحرين', flag: 'BH' },
    { id: 'OM', en: 'Oman', ar: 'عُمان', flag: 'OM' },
    { id: 'IQ', en: 'Iraq', ar: 'العراق', flag: 'IQ' },
    { id: 'JO', en: 'Jordan', ar: 'الأردن', flag: 'JO' },
    { id: 'EG', en: 'Egypt', ar: 'مصر', flag: 'EG' },
    { id: 'YE', en: 'Yemen', ar: 'اليمن', flag: 'YE' },
    { id: 'SY', en: 'Syria', ar: 'سوريا', flag: 'SY' },
    { id: 'LB', en: 'Lebanon', ar: 'لبنان', flag: 'LB' },
    { id: 'PS', en: 'Palestine', ar: 'فلسطين', flag: 'PS' },
    { id: 'SD', en: 'Sudan', ar: 'السودان', flag: 'SD' },
    { id: 'LY', en: 'Libya', ar: 'ليبيا', flag: 'LY' },
    { id: 'TN', en: 'Tunisia', ar: 'تونس', flag: 'TN' },
    { id: 'DZ', en: 'Algeria', ar: 'الجزائر', flag: 'DZ' },
    { id: 'MA', en: 'Morocco', ar: 'المغرب', flag: 'MA' },
    { id: 'MR', en: 'Mauritania', ar: 'موريتانيا', flag: 'MR' },
    { id: 'SO', en: 'Somalia', ar: 'الصومال', flag: 'SO' },
    { id: 'DJ', en: 'Djibouti', ar: 'جيبوتي', flag: 'DJ' }
  ];
  // p = map priority (1 shown first), inland = no sea in the 3D view, cl = November climate [max, min, humidity, wind] for the offline sample
  const CITIES = [
    { id: 'kuwait', p: 1, c: 'KW', en: 'Kuwait City', ar: 'مدينة الكويت', lat: 29.3759, lon: 47.9774, tz: 3, cl: [27, 15, 45, 16] },
    { id: 'jahra', p: 3, c: 'KW', en: 'Al Jahra', ar: 'الجهراء', lat: 29.3375, lon: 47.6581, tz: 3, cl: [27, 13, 40, 17] },
    { id: 'hawalli', p: 4, c: 'KW', en: 'Hawalli', ar: 'حولي', lat: 29.3328, lon: 48.0286, tz: 3, cl: [27, 15, 45, 16] },
    { id: 'farwaniya', p: 4, c: 'KW', en: 'Al Farwaniya', ar: 'الفروانية', lat: 29.2775, lon: 47.9585, tz: 3, cl: [27, 14, 42, 16] },
    { id: 'mubarak', p: 4, c: 'KW', en: 'Mubarak Al-Kabeer', ar: 'مبارك الكبير', lat: 29.2120, lon: 48.0600, tz: 3, cl: [27, 16, 48, 16] },
    { id: 'abdali', p: 5, c: 'KW', en: 'Abdali', ar: 'العبدلي', lat: 30.0366, lon: 47.7420, tz: 3, cl: [26, 14, 38, 16] },
    { id: 'salmi', p: 5, c: 'KW', en: 'Al Salmi', ar: 'السالمي', lat: 29.1790, lon: 46.7280, tz: 3, cl: [27, 13, 35, 17] },
    { id: 'wafra', p: 5, c: 'KW', en: 'Al Wafra', ar: 'الوفرة', lat: 28.6370, lon: 47.9370, tz: 3, cl: [27, 15, 42, 16] },
    { id: 'nuwaiseeb', p: 5, c: 'KW', en: 'Nuwaiseeb', ar: 'النويصيب', lat: 28.5890, lon: 48.3550, tz: 3, cl: [27, 16, 52, 16] },
    { id: 'subiya', p: 5, c: 'KW', en: 'Subiya', ar: 'الصبية', lat: 29.6000, lon: 47.8500, tz: 3, cl: [26, 13, 42, 16] },
    { id: 'mutlaa', p: 5, c: 'KW', en: 'Al Mutlaa', ar: 'المطلاع', lat: 29.5200, lon: 47.4500, tz: 3, cl: [27, 13, 40, 17] },
    { id: 'kabd', p: 5, c: 'KW', en: 'Kabd', ar: 'كبد', lat: 29.0500, lon: 47.6000, tz: 3, cl: [27, 13, 36, 17] },
    { id: 'shaqaya', p: 5, c: 'KW', en: 'Al Shaqaya', ar: 'الشقايا', lat: 29.4000, lon: 46.9500, tz: 3, cl: [27, 12, 36, 17] },
    { id: 'ahmadi', p: 3, c: 'KW', en: 'Al Ahmadi', ar: 'الأحمدي', lat: 29.0769, lon: 48.0838, tz: 3, cl: [27, 16, 50, 16] },
    { id: 'riyadh', p: 1, inland: true, c: 'SA', en: 'Riyadh', ar: 'الرياض', lat: 24.7136, lon: 46.6753, tz: 3, cl: [28, 15, 30, 12] },
    { id: 'jeddah', p: 2, c: 'SA', en: 'Jeddah', ar: 'جدة', lat: 21.4858, lon: 39.1925, tz: 3, cl: [33, 24, 62, 13] },
    { id: 'dammam', p: 3, c: 'SA', en: 'Dammam', ar: 'الدمام', lat: 26.4207, lon: 50.0888, tz: 3, cl: [29, 18, 58, 15] },
    { id: 'makkah', p: 3, inland: true, c: 'SA', en: 'Makkah', ar: 'مكة المكرمة', lat: 21.3891, lon: 39.8579, tz: 3, cl: [34, 23, 45, 9] },
    { id: 'madinah', p: 2, inland: true, c: 'SA', en: 'Madinah', ar: 'المدينة المنورة', lat: 24.5247, lon: 39.5692, tz: 3, cl: [30, 18, 28, 11] },
    { id: 'dubai', p: 2, c: 'AE', en: 'Dubai', ar: 'دبي', lat: 25.2048, lon: 55.2708, tz: 4, cl: [31, 22, 60, 13] },
    { id: 'abudhabi', p: 1, c: 'AE', en: 'Abu Dhabi', ar: 'أبوظبي', lat: 24.4539, lon: 54.3773, tz: 4, cl: [31, 21, 60, 14] },
    { id: 'sharjah', p: 3, c: 'AE', en: 'Sharjah', ar: 'الشارقة', lat: 25.3463, lon: 55.4209, tz: 4, cl: [31, 20, 58, 12] },
    { id: 'doha', p: 1, c: 'QA', en: 'Doha', ar: 'الدوحة', lat: 25.2854, lon: 51.531, tz: 3, cl: [30, 21, 58, 15] },
    { id: 'manama', p: 2, c: 'BH', en: 'Manama', ar: 'المنامة', lat: 26.2235, lon: 50.5876, tz: 3, cl: [28, 21, 65, 16] },
    { id: 'muscat', p: 1, c: 'OM', en: 'Muscat', ar: 'مسقط', lat: 23.588, lon: 58.3829, tz: 4, cl: [31, 23, 55, 11] },
    { id: 'salalah', p: 2, c: 'OM', en: 'Salalah', ar: 'صلالة', lat: 17.0151, lon: 54.0924, tz: 4, cl: [30, 21, 60, 10] },
    { id: 'baghdad', p: 1, inland: true, c: 'IQ', en: 'Baghdad', ar: 'بغداد', lat: 33.3152, lon: 44.3661, tz: 3, cl: [24, 10, 45, 12] },
    { id: 'basra', p: 3, c: 'IQ', en: 'Basra', ar: 'البصرة', lat: 30.5081, lon: 47.7835, tz: 3, cl: [27, 14, 45, 14] },
    { id: 'erbil', p: 3, inland: true, c: 'IQ', en: 'Erbil', ar: 'أربيل', lat: 36.1912, lon: 44.0092, tz: 3, cl: [21, 8, 55, 10] },
    { id: 'amman', p: 1, inland: true, c: 'JO', en: 'Amman', ar: 'عمّان', lat: 31.9454, lon: 35.9284, tz: 3, cl: [20, 10, 55, 14] },
    { id: 'aqaba', p: 3, c: 'JO', en: 'Aqaba', ar: 'العقبة', lat: 29.532, lon: 35.0063, tz: 3, cl: [28, 17, 40, 16] },
    { id: 'cairo', p: 1, inland: true, c: 'EG', en: 'Cairo', ar: 'القاهرة', lat: 30.0444, lon: 31.2357, tz: 2, cl: [25, 15, 55, 14] },
    { id: 'alexandria', p: 2, c: 'EG', en: 'Alexandria', ar: 'الإسكندرية', lat: 31.2001, lon: 29.9187, tz: 2, cl: [23, 15, 68, 18] },
    { id: 'aswan', p: 3, inland: true, c: 'EG', en: 'Aswan', ar: 'أسوان', lat: 24.0889, lon: 32.8998, tz: 2, cl: [31, 15, 28, 14] },
    { id: 'sharm', p: 3, c: 'EG', en: 'Sharm El-Sheikh', ar: 'شرم الشيخ', lat: 27.9158, lon: 34.33, tz: 2, cl: [28, 20, 40, 18] },
    { id: 'sanaa', p: 1, inland: true, c: 'YE', en: 'Sanaa', ar: 'صنعاء', lat: 15.3694, lon: 44.191, tz: 3, cl: [23, 7, 35, 10] },
    { id: 'aden', p: 3, c: 'YE', en: 'Aden', ar: 'عدن', lat: 12.7855, lon: 45.0187, tz: 3, cl: [31, 23, 60, 14] },
    { id: 'damascus', p: 1, inland: true, c: 'SY', en: 'Damascus', ar: 'دمشق', lat: 33.5138, lon: 36.2765, tz: 3, cl: [21, 7, 55, 12] },
    { id: 'aleppo', p: 3, inland: true, c: 'SY', en: 'Aleppo', ar: 'حلب', lat: 36.2021, lon: 37.1343, tz: 3, cl: [20, 7, 65, 14] },
    { id: 'beirut', p: 1, c: 'LB', en: 'Beirut', ar: 'بيروت', lat: 33.8938, lon: 35.5018, tz: 2, cl: [24, 16, 65, 14] },
    { id: 'ramallah', p: 2, inland: true, c: 'PS', en: 'Ramallah', ar: 'رام الله', lat: 31.9038, lon: 35.2034, tz: 2, cl: [20, 10, 62, 14] },
    { id: 'gaza', p: 3, c: 'PS', en: 'Gaza', ar: 'غزة', lat: 31.5017, lon: 34.4668, tz: 2, cl: [24, 15, 65, 16] },
    { id: 'khartoum', p: 1, inland: true, c: 'SD', en: 'Khartoum', ar: 'الخرطوم', lat: 15.5007, lon: 32.5599, tz: 2, cl: [35, 20, 20, 12] },
    { id: 'portsudan', p: 3, c: 'SD', en: 'Port Sudan', ar: 'بورتسودان', lat: 19.6158, lon: 37.2164, tz: 2, cl: [32, 24, 55, 14] },
    { id: 'tripoli', p: 1, c: 'LY', en: 'Tripoli', ar: 'طرابلس', lat: 32.8872, lon: 13.1913, tz: 2, cl: [23, 15, 65, 16] },
    { id: 'benghazi', p: 3, c: 'LY', en: 'Benghazi', ar: 'بنغازي', lat: 32.1167, lon: 20.0667, tz: 2, cl: [23, 14, 65, 16] },
    { id: 'tunis', p: 1, c: 'TN', en: 'Tunis', ar: 'تونس', lat: 36.8065, lon: 10.1815, tz: 1, cl: [21, 12, 70, 16] },
    { id: 'algiers', p: 1, c: 'DZ', en: 'Algiers', ar: 'الجزائر العاصمة', lat: 36.7538, lon: 3.0588, tz: 1, cl: [20, 11, 70, 14] },
    { id: 'oran', p: 3, c: 'DZ', en: 'Oran', ar: 'وهران', lat: 35.6971, lon: -0.6308, tz: 1, cl: [21, 11, 65, 14] },
    { id: 'rabat', p: 1, c: 'MA', en: 'Rabat', ar: 'الرباط', lat: 34.0209, lon: -6.8416, tz: 1, cl: [21, 11, 72, 14] },
    { id: 'casablanca', p: 2, c: 'MA', en: 'Casablanca', ar: 'الدار البيضاء', lat: 33.5731, lon: -7.5898, tz: 1, cl: [21, 13, 74, 15] },
    { id: 'marrakesh', p: 3, inland: true, c: 'MA', en: 'Marrakesh', ar: 'مراكش', lat: 31.6295, lon: -7.9811, tz: 1, cl: [23, 9, 55, 12] },
    { id: 'nouakchott', p: 1, c: 'MR', en: 'Nouakchott', ar: 'نواكشوط', lat: 18.0735, lon: -15.9582, tz: 0, cl: [31, 20, 55, 20] },
    { id: 'mogadishu', p: 1, c: 'SO', en: 'Mogadishu', ar: 'مقديشو', lat: 2.0469, lon: 45.3182, tz: 3, cl: [31, 24, 75, 18] },
    { id: 'djibouti', p: 1, c: 'DJ', en: 'Djibouti', ar: 'جيبوتي', lat: 11.5721, lon: 43.1456, tz: 3, cl: [31, 25, 60, 18] }
  ];

  const pad = n => String(n).padStart(2, '0');
  const iso = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:00`;
  const hoursOf = s => { const m = /T(\d\d):(\d\d)/.exec(s); return m ? +m[1] + +m[2] / 60 : 12; };

  // NOAA-style sunrise/sunset, returns local hours
  function sunTimes(lat, lon, tz, y, m, d) {
    const rad = Math.PI / 180, N = Math.floor(275 * m / 9) - Math.floor((m + 9) / 12) * (1 + Math.floor((y - 4 * Math.floor(y / 4) + 2) / 3)) + d - 30;
    function calc(rise) {
      const lh = lon / 15, t = N + ((rise ? 6 : 18) - lh) / 24, M = 0.9856 * t - 3.289;
      let L = M + 1.916 * Math.sin(M * rad) + 0.02 * Math.sin(2 * M * rad) + 282.634; L = (L + 360) % 360;
      let RA = Math.atan(0.91764 * Math.tan(L * rad)) / rad; RA = (RA + 360) % 360;
      RA += Math.floor(L / 90) * 90 - Math.floor(RA / 90) * 90; RA /= 15;
      const sd = 0.39782 * Math.sin(L * rad), cd = Math.cos(Math.asin(sd));
      const ch = (Math.cos(90.833 * rad) - sd * Math.sin(lat * rad)) / (cd * Math.cos(lat * rad));
      let H = rise ? 360 - Math.acos(ch) / rad : Math.acos(ch) / rad; H /= 15;
      const Tm = H + RA - 0.06571 * t - 6.622; return ((Tm - lh + tz) % 24 + 24) % 24;
    }
    return [calc(true), calc(false)];
  }

  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
  function hash(str) { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; }

  // Offline sample: realistic November pattern with a few events to show the animations
  const EVENTS = {
    baghdad: { 3: 'dust', 6: 'rain' }, basra: { 2: 'dust', 3: 'dust' }, erbil: { 5: 'rain', 6: 'rain' }, amman: { 4: 'rain' }, aqaba: { 3: 'haze' }, cairo: { 2: 'haze', 7: 'rain' },
    alexandria: { 2: 'rain', 3: 'thunder' }, aswan: {}, sharm: { 4: 'haze' }, sanaa: { 5: 'thunder' }, aden: { 5: 'cloudy' }, damascus: { 4: 'rain', 5: 'rain' }, aleppo: { 4: 'rain' },
    beirut: { 3: 'thunder', 4: 'rain' }, ramallah: { 4: 'rain' }, gaza: { 3: 'thunder' }, khartoum: { 1: 'dust', 2: 'dust' }, portsudan: { 3: 'haze' }, tripoli: { 6: 'rain' }, benghazi: { 5: 'thunder' },
    tunis: { 6: 'rain' }, algiers: { 6: 'rain', 7: 'thunder' }, oran: { 7: 'rain' }, rabat: { 4: 'rain' }, casablanca: { 4: 'rain' }, marrakesh: { 5: 'cloudy' }, nouakchott: { 2: 'dust', 3: 'dust' }, mogadishu: { 6: 'rain' }, djibouti: { 1: 'haze' },
    kuwait: { 2: 'dust', 5: 'thunder', 6: 'cloudy' }, jahra: { 2: 'dust', 5: 'rain' }, ahmadi: { 2: 'dust', 5: 'thunder' },
    riyadh: { 2: 'dust', 3: 'haze' }, jeddah: { 4: 'thunder', 5: 'cloudy' }, dammam: { 2: 'haze', 5: 'rain' },
    makkah: { 4: 'thunder' }, madinah: { 3: 'dust' }, dubai: { 1: 'fog', 6: 'rain', 7: 'cloudy' }, abudhabi: { 1: 'fog', 6: 'cloudy' },
    sharjah: { 1: 'fog', 6: 'rain' }, doha: { 3: 'haze', 6: 'cloudy' }, manama: { 5: 'rain', 6: 'cloudy' }, muscat: { 7: 'thunder' }, salalah: { 0: 'cloudy', 1: 'cloudy', 8: 'rain' }
  };
  function sample(city, startDate) {
    const r = rng(hash(city.id + '2026')), [tmx, tmn, hum0, wind0] = city.cl, ev = EVENTS[city.id] || {};
    const base = new Date(Date.UTC(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate()));
    const hours = [], days = [];
    for (let di = 0; di < 10; di++) {
      const dd = new Date(base.getTime() + di * 864e5), e = ev[di] || 'clear';
      const [sr, ss] = sunTimes(city.lat, city.lon, city.tz, dd.getUTCFullYear(), dd.getUTCMonth() + 1, dd.getUTCDate());
      const dmax = tmx + (r() - 0.5) * 3 - di * 0.15 + (e === 'dust' ? -1.5 : 0) + (e === 'thunder' || e === 'rain' ? -4 : 0);
      const dmin = tmn + (r() - 0.5) * 2 - di * 0.1;
      let dayCode = 0, psum = 0, wmax = 0, uvmax = 0, dmaxSeen = -99, dminSeen = 99;
      for (let h = 0; h < 24; h++) {
        const t = dd.getTime() + h * 36e5, hf = h;
        const ph = Math.cos(((hf - 15) / 24) * Math.PI * 2); // 1 at 3 PM
        let temp = (dmax + dmin) / 2 + ph * (dmax - dmin) / 2 + (r() - 0.5) * 0.4;
        let hum = hum0 - ph * 18 + (r() - 0.5) * 5;
        let wind = wind0 * (0.7 + 0.5 * Math.max(0, Math.sin((hf - 8) / 24 * Math.PI * 2))) + r() * 4;
        let dir = 300 + (r() - 0.5) * 50, cloud = r() < 0.15 ? 20 + r() * 30 : r() * 10, precip = 0, code = 0, vis = 20000 + r() * 4000, dust = 10 + r() * 30;
        const midday = hf >= 9 && hf <= 18;
        if (e === 'dust') { const peak = Math.exp(-Math.pow((hf - 14) / 4.5, 2)); wind = 22 + peak * 38 + r() * 6; dir = 320 + (r() - 0.5) * 20; vis = 9000 - peak * 8300; dust = 120 + peak * 1600; cloud = 10; }
        if (e === 'haze') { vis = 4500 + r() * 1500; dust = 220 + r() * 120; wind = wind * 1.4; }
        if (e === 'cloudy') { cloud = 60 + r() * 35; }
        if (e === 'rain' && hf >= 10 && hf <= 19) { cloud = 85 + r() * 15; precip = Math.max(0, Math.sin((hf - 10) / 9 * Math.PI)) * (1 + r() * 2); hum += 20; dir = 140 + r() * 40; }
        else if (e === 'rain') cloud = 50 + r() * 30;
        if (e === 'thunder' && hf >= 12 && hf <= 20) { cloud = 95; precip = Math.max(0, Math.sin((hf - 12) / 8 * Math.PI)) * (3 + r() * 5); hum += 25; wind = 25 + r() * 25; dir = 150 + r() * 30; }
        else if (e === 'thunder') cloud = 40 + r() * 40;
        if (e === 'fog' && hf <= 8) { vis = 400 + hf * 300; hum = 92 + r() * 6; }
        hum = Math.max(8, Math.min(100, hum)); if (e === 'thunder' || e === 'rain') temp -= precip * 0.6;
        // code
        if (e === 'thunder' && precip > 0.5) code = 95; else if (precip > 2.5) code = 63; else if (precip > 0.3) code = 61;
        else if (e === 'fog' && vis < 1000) code = 45; else if (cloud > 85) code = 3; else if (cloud > 50) code = 2; else if (cloud > 20) code = 1;
        const isDay = hf + 0.5 > sr && hf + 0.5 < ss ? 1 : 0;
        const uv = isDay ? Math.max(0, Math.sin(Math.PI * (hf + 0.5 - sr) / (ss - sr))) * (city.lat < 22 ? 8.5 : 6.5) * (1 - cloud / 160) : 0;
        const gust = wind * (1.35 + r() * 0.25);
        hours.push({ t: iso(new Date(t)), temp: +temp.toFixed(1), feels: +(temp + (hum > 60 && temp > 26 ? (hum - 60) * 0.12 : 0) - wind * 0.04).toFixed(1), hum: Math.round(hum), wind: +wind.toFixed(1), gust: +gust.toFixed(1), dir: Math.round((dir + 360) % 360), code, cloud: Math.round(Math.min(100, cloud)), precip: +precip.toFixed(1), uv: +uv.toFixed(1), vis: Math.round(vis), dust: Math.round(dust), isDay });
        psum += precip; wmax = Math.max(wmax, wind); uvmax = Math.max(uvmax, uv); dmaxSeen = Math.max(dmaxSeen, temp); dminSeen = Math.min(dminSeen, temp);
        if (midday) dayCode = Math.max(dayCode, code);
      }
      const ds = iso(dd).slice(0, 10), hm = x => `${pad(Math.floor(x))}:${pad(Math.round((x % 1) * 60) % 60)}`;
      days.push({ date: ds, code: e === 'dust' ? 1 : dayCode, tmax: +dmaxSeen.toFixed(1), tmin: +dminSeen.toFixed(1), sunrise: ds + 'T' + hm(sr), sunset: ds + 'T' + hm(ss), uvmax: +uvmax.toFixed(1), precip: +psum.toFixed(1), windmax: +wmax.toFixed(1) });
    }
    return { hours, days, utcOffset: city.tz * 3600, sample: true };
  }

  const HOURLY = 'temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_gusts_10m,wind_direction_10m,weather_code,cloud_cover,precipitation,uv_index,visibility,is_day';
  const DAILY = 'weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,wind_speed_10m_max';

  async function fetchJSON(url, ms) {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), ms || 15000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json(); } finally { clearTimeout(tm); }
  }

  async function fetchLive() {
    const lat = CITIES.map(c => c.lat).join(','), lon = CITIES.map(c => c.lon).join(',');
    const fc = await fetchJSON(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=${HOURLY}&daily=${DAILY}&forecast_days=10&timezone=auto`);
    let aq = null;
    try { aq = await fetchJSON(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&hourly=dust,pm10&forecast_days=7&timezone=auto`); } catch (e) { aq = null; }
    const fcs = Array.isArray(fc) ? fc : [fc], aqs = aq ? (Array.isArray(aq) ? aq : [aq]) : [];
    const out = {};
    CITIES.forEach((c, i) => {
      const f = fcs[i], H = f.hourly, D = f.daily, a = aqs[i] && aqs[i].hourly;
      const dustBy = {}; if (a) a.time.forEach((t, k) => { dustBy[t] = a.dust[k]; });
      const hours = H.time.map((t, k) => ({
        t, temp: H.temperature_2m[k], feels: H.apparent_temperature[k], hum: H.relative_humidity_2m[k], wind: H.wind_speed_10m[k], gust: H.wind_gusts_10m[k],
        dir: H.wind_direction_10m[k], code: H.weather_code[k], cloud: H.cloud_cover[k], precip: H.precipitation[k], uv: H.uv_index[k],
        vis: H.visibility ? H.visibility[k] : null, dust: dustBy[t] != null ? dustBy[t] : null, isDay: H.is_day[k]
      }));
      const days = D.time.map((d, k) => ({ date: d, code: D.weather_code[k], tmax: D.temperature_2m_max[k], tmin: D.temperature_2m_min[k], sunrise: D.sunrise[k], sunset: D.sunset[k], uvmax: D.uv_index_max[k], precip: D.precipitation_sum[k], windmax: D.wind_speed_10m_max[k] }));
      out[c.id] = { hours, days, utcOffset: f.utc_offset_seconds, sample: false };
    });
    return out;
  }

  function sampleAll() { const now = new Date(); const out = {}; CITIES.forEach(c => { out[c.id] = sample(c, new Date(now.getTime() + c.tz * 36e5)); }); return out; }

  window.GW = { COUNTRIES, CITIES, fetchLive, sampleAll, hoursOf, sunTimes };
})();

/* ---------- map grid (3° over the Arab world), times fixed to UTC+3 ---------- */
(function () {
  const STEP = 3, LON0 = -18, LAT0 = 8, LONS = [], LATS = []; for (let x = LON0; x <= 63; x += STEP) LONS.push(x); for (let y = LAT0; y <= 38; y += STEP) LATS.push(y);
  const NX = LONS.length, NY = LATS.length;

  async function fetchChunk(pts) {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${pts.map(p => p[1]).join(',')}&longitude=${pts.map(p => p[0]).join(',')}&hourly=temperature_2m,wind_speed_10m,wind_direction_10m,cloud_cover,precipitation&forecast_days=10&timezone=Asia%2FRiyadh`;
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 40000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); const a = await r.json(); return Array.isArray(a) ? a : [a]; } finally { clearTimeout(tm); }
  }
  async function fetchGrid() {
    const pts = []; LATS.forEach(y => LONS.forEach(x => pts.push([x, y])));
    const parts = []; for (let i = 0; i < pts.length; i += 110) parts.push(pts.slice(i, i + 110));
    const res = await Promise.all(parts.map(fetchChunk)); const a = [].concat(...res);
    const n = a[0].hourly.time.length, P = NX * NY, mk = () => new Float32Array(n * P);
    const g = { NX, NY, LONS, LATS, LON0, LAT0, STEP, n, temp: mk(), u: mk(), v: mk(), cloud: mk(), precip: mk(), dust: null };
    a.forEach((p, i) => { const H = p.hourly; for (let t = 0; t < n; t++) {
      const o = t * P + i, sp = H.wind_speed_10m[t] || 0, dir = (H.wind_direction_10m[t] || 0) * Math.PI / 180;
      g.temp[o] = H.temperature_2m[t]; g.u[o] = -sp * Math.sin(dir); g.v[o] = -sp * Math.cos(dir); g.cloud[o] = H.cloud_cover[t] || 0; g.precip[o] = H.precipitation[t] || 0; } });
    return g;
  }

  // offline sample grid built from the sample city data (inverse-distance blend) + smooth synthetic patterns
  function sampleGrid(cities) {
    const n = 240, P = NX * NY, mk = () => new Float32Array(n * P);
    const g = { NX, NY, LONS, LATS, LON0, LAT0, STEP, n, temp: mk(), u: mk(), v: mk(), cloud: mk(), precip: mk(), dust: mk(), sample: true };
    const C = window.GW.CITIES.map(c => ({ c, d: cities[c.id], sh: c.tz - 3 }));
    for (let t = 0; t < n; t++) {
      for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) {
        const lon = LONS[i], lat = LATS[j], o = t * P + j * NX + i;
        let ws = 0, tt = 0, uu = 0, vv = 0, cc = 0, pp = 0, du = 0;
        C.forEach(({ c, d, sh }) => {
          const k = Math.max(0, Math.min(d.hours.length - 1, t + sh)), h = d.hours[k];
          const dd = Math.hypot((c.lon - lon) * 0.9, c.lat - lat), w = 1 / Math.pow(dd + 1.5, 2.2);
          const a2 = h.dir * Math.PI / 180; ws += w; tt += w * h.temp; uu += w * -h.wind * Math.sin(a2); vv += w * -h.wind * Math.cos(a2); cc += w * h.cloud; pp += w * h.precip; du += w * (h.dust || 30);
        });
        g.temp[o] = tt / ws; g.u[o] = uu / ws; g.v[o] = vv / ws; g.cloud[o] = Math.min(100, cc / ws); g.precip[o] = pp / ws; g.dust[o] = du / ws;
      }
    }
    return g;
  }
  Object.assign(window.GW, { fetchGrid, sampleGrid, GRID: { LONS, LATS, NX, NY, LON0, LAT0, STEP } });
})();
