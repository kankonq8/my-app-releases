/* Gulf Weather - Past and present page: this year against every year since 1950 for the chosen place.
   Uses the monthly totals prepared by extras.js (Open-Meteo archive, ERA5). by Kankon · kankon.net */
(function () {
  const A = window.GW_APP, S = window.GW_STRINGS, C = window.GW_CLIM; if (!A || !C) return;
  const $ = id => document.getElementById(id), st = A.st, CITIES = window.GW.CITIES, T = (k, ...a) => A.T(k, ...a);
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };

  Object.assign(S.en, {
    hist: 'Past and present', histSub: 'This year against every year since 1950 for the chosen place. Data: Open-Meteo archive (ERA5), model averages over a grid area.',
    hPlace: 'Place', hPeriod: 'Period', hYear: 'Year', hVs: 'Compared with', hNormal: 'Average 1991–2020', hRecent: 'Last 10 years', hBack: 'Back', hLoading: 'Loading the history…',
    hFail: 'Could not load the history. Trying again soon.', hLimit: 'The free weather service reached its daily limit on this network. History will be available again tomorrow.', hSample: 'Needs the internet for the history.',
    mTemp: 'Average temperature', mRain: 'Total rain', mRd: 'Rainy days', mH45: 'Days of 45° or more', mStorm: 'Stormy days',
    uC: '°C', uMm: 'mm', uD: 'days', hSoFar: 'so far, months with full data: {0}', hRank: '#{0} of {1} years', hWarm: 'warmest', hCool: 'coolest', hWet: 'wettest', hDry: 'driest',
    hCards: 'The year in numbers', hCharts: 'Year by year', hHint: 'Hover over a bar to see the year. White dashes are the trend. The line is the 10-year average.',
    hProfile: 'Month by month', hProfT: 'Average temperature by month (°C)', hProfR: 'Rain by month (mm)', hNormalS: 'Average 1991–2020',
    hHeat: 'Temperature map: every year, every month', hHeatSub: 'Red months were warmer than the 1991–2020 average for that month, blue months cooler.',
    hRec: 'Records for this period', hRecWarm: 'Warmest years', hRecCool: 'Coolest years', hRecWet: 'Wettest years', hRecHot: 'Most days of 45° or more',
    hDecade: 'By decade', hCompare: 'Year against year', hDiff: 'Difference', hNoData: 'No data for this year yet.', hMonths: 'Months', hTrend: 'Trend', hPerDecade: '{0} per ten years'
  });
  Object.assign(S.ar, {
    hist: 'الماضي والحاضر', histSub: 'السنة الحالية مقابل كل سنة من 1950 للمكان اللي تختاره. البيانات من أرشيف Open-Meteo (ERA5)، وهي معدلات من نموذج مناخي لمساحة كاملة.',
    hPlace: 'المكان', hPeriod: 'الفترة', hYear: 'السنة', hVs: 'مقارنة مع', hNormal: 'معدل 1991–2020', hRecent: 'آخر 10 سنين', hBack: 'رجوع', hLoading: 'جاري تحميل بيانات السنين اللي طافت…',
    hFail: 'ما قدرت أحمّل بيانات السنين اللي طافت. بنعيد المحاولة بعد شوي.', hLimit: 'الخدمة المجانية وصلت حدها اليومي على هالشبكة. بيانات السنين ترجع باجر.', hSample: 'يحتاج إنترنت عشان يجيب بيانات السنين اللي طافت.',
    mTemp: 'معدل الحرارة', mRain: 'مجموع المطر', mRd: 'أيام المطر', mH45: 'أيام 45° وأكثر', mStorm: 'الأيام العاصفة',
    uC: '°C', uMm: 'مم', uD: 'يوم', hSoFar: 'الشهور الكاملة لين الحين: {0}', hRank: 'المركز {0} من {1} سنة', hWarm: 'الأحر', hCool: 'الأبرد', hWet: 'الأكثر مطرًا', hDry: 'الأقل مطرًا',
    hCards: 'السنة بالأرقام', hCharts: 'سنة بسنة', hHint: 'حط الماوس على أي عمود عشان تشوف السنة. الخط الأبيض المتقطع هو الاتجاه، والخط الملون هو معدل كل 10 سنين.',
    hProfile: 'شهر بشهر', hProfT: 'معدل الحرارة لكل شهر (°C)', hProfR: 'المطر لكل شهر (مم)', hNormalS: 'معدل 1991–2020',
    hHeat: 'خريطة الحرارة: كل سنة وكل شهر', hHeatSub: 'الشهور الحمراء كانت أحر من معدل 1991–2020 لنفس الشهر، والزرقاء أبرد.',
    hRec: 'الأرقام القياسية لهالفترة', hRecWarm: 'أحر السنين', hRecCool: 'أبرد السنين', hRecWet: 'أكثر السنين مطرًا', hRecHot: 'أكثر السنين بأيام 45° وأكثر',
    hDecade: 'كل عقد', hCompare: 'سنة مقابل سنة', hDiff: 'الفرق', hNoData: 'ما فيه بيانات لهالسنة للحين.', hMonths: 'الشهور', hTrend: 'الاتجاه', hPerDecade: '{0} كل عشر سنين'
  });

  const css = document.createElement('style');
  css.textContent = `
  #hist{position:fixed;inset:76px 14px 14px;z-index:9;display:none;overflow:auto;padding:16px 20px 28px}
  body.histOpen #hist{display:block}body.histOpen #xp,body.histOpen .alerts,body.histOpen .kwp,body.histOpen #kwPanel{display:none!important}
  #hist h2{margin:0 0 4px;font-size:22px}#hist h3{margin:22px 0 8px;font-size:16px}#hist .sm{font-size:12.5px;color:var(--mut)}
  #hist .hbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:12px 0}
  #hist select,#hist .btn{background:rgba(255,255,255,.14);color:inherit;border:0;border-radius:10px;padding:7px 10px;font-size:13.5px;cursor:pointer}
  #hist select option{color:#000}#hist .chip{padding:6px 12px;border-radius:12px;background:rgba(255,255,255,.12);font-size:13px;cursor:pointer}#hist .chip.on{background:rgba(92,200,255,.4)}
  #hist .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(430px,1fr));gap:14px}#hist .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
  #hist .card{background:rgba(255,255,255,.08);border-radius:14px;padding:11px 13px}#hist .card b{font-size:22px;display:block;margin:2px 0}
  #hist .up{color:#ff9a7a}#hist .down{color:#7cc4ff}#hist table{border-collapse:collapse;font-size:13px;min-width:320px}#hist td,#hist th{padding:5px 10px;text-align:center}#hist th{color:var(--mut)}#hist td:first-child,#hist th:first-child{text-align:start}
  #hist svg polyline,#hist svg line,#hist svg text{pointer-events:none}#hist svg{display:block;width:100%;background:rgba(255,255,255,.05);border-radius:10px}
  #hTip{position:fixed;z-index:40;pointer-events:none;display:none;padding:6px 10px;border-radius:8px;background:rgba(10,20,35,.92);color:#fff;font-size:12.5px;border:1px solid rgba(255,255,255,.25)}`;
  document.head.appendChild(css);
  const hist = document.createElement('section'); hist.id = 'hist'; hist.className = 'glass'; document.body.appendChild(hist);
  const tip = document.createElement('div'); tip.id = 'hTip'; document.body.appendChild(tip);
  const xBtn = $('xBtn'), hBtn = document.createElement('button'); hBtn.id = 'hBtn'; hBtn.className = 'viewBtn glass'; xBtn.after(hBtn);
  const dim = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const cname = c => c[st.lang];
  let from = 10, to = 12, yearA = 'cur', vs = 'normal', yearB = 1990, curRows = null, curState = null;
  const num = (v, d) => (+v.toFixed(d)).toLocaleString('en');
  const MET = [['temp', 'mTemp', 'uC', 1, '#ff9a5c'], ['rain', 'mRain', 'uMm', 0, '#5cc8ff'], ['rd', 'mRd', 'uD', 0, '#7cc4ff'], ['h45', 'mH45', 'uD', 0, '#ff5c5c'], ['st', 'mStorm', 'uD', 0, '#b48cff']];

  hBtn.onclick = () => { document.body.classList.add('histOpen'); document.body.classList.remove('xpOpen'); open_(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') document.body.classList.remove('histOpen'); });
  C.onLoad = id => { if (document.body.classList.contains('histOpen') && id === st.city) render(); };

  function open_() { const c = CITIES.find(x => x.id === st.city); if (!C.isSample()) { C.ensure(c); ensureCur(c); } render(); }
  // current year so far (small request, kept one day)
  function ensureCur(c) {
    const y = new Date().getUTCFullYear(), key = 'gw-clim-cur-' + c.id, saved = store.get(key, null);
    if (saved && saved.y === y && Date.now() - saved.at < 864e5) { curRows = saved.m; curState = 'ok'; return; }
    if (curState === 'loading') return; curState = 'loading'; curRows = null;
    const end = new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10); if (end < y + '-01-02') { curState = 'none'; return; }
    fetch(`https://archive-api.open-meteo.com/v1/archive?latitude=${c.lat}&longitude=${c.lon}&start_date=${y}-01-01&end_date=${end}&daily=temperature_2m_max,temperature_2m_mean,precipitation_sum,wind_gusts_10m_max&timezone=auto`)
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(j => { const d = j.daily; if (!d || !d.time) throw new Error('empty'); const t = d.time.map((x, i) => i).filter(i => d.temperature_2m_mean[i] != null);
        const m = C.monthlyOf({ time: t.map(i => d.time[i]), tmax: t.map(i => d.temperature_2m_max[i]), tmean: t.map(i => d.temperature_2m_mean[i]), rain: t.map(i => d.precipitation_sum[i]), gust: t.map(i => d.wind_gusts_10m_max[i]) });
        curRows = m; curState = 'ok'; store.set(key, { at: Date.now(), y, m }); render(); })
      .catch(() => { curState = 'err'; setTimeout(() => { if (curState === 'err') curState = null; }, 120000); render(); });
  }

  function model(c) {
    const raw = C.get(c.id); if (!Array.isArray(raw)) return null;
    const rows = raw.concat(curRows || []), map = new Map(); rows.forEach(r => map.set(r[0] * 100 + r[1], r));
    const wrap = from > to, months = []; for (let m = from; ; m = m % 12 + 1) { months.push(m); if (m === to) break; }
    const complete = (yy, m) => { const r = map.get(yy * 100 + m); return r && r[2] >= dim(yy, m) * 0.9 && r[3] > 0; };
    const yy_ = (y, m) => wrap && m <= to ? y + 1 : y;
    const vals = (y, ms) => { let n = 0, ts = 0, rain = 0, rd = 0, h45 = 0, st_ = 0; for (const m of ms) { if (!complete(yy_(y, m), m)) return null; const r = map.get(yy_(y, m) * 100 + m); n += r[3]; ts += r[4]; rain += r[5]; rd += r[6]; h45 += r[7]; st_ += r[9]; } return ms.length ? { y, temp: ts / n, rain, rd, h45, st: st_ } : null; };
    const minY = Math.min(...raw.map(r => r[0])), maxY = Math.max(...rows.map(r => r[0])), curY = new Date().getUTCFullYear();
    const years = []; for (let y = minY; y <= maxY; y++) { const v = vals(y, months); if (v) years.push(v); }
    return { map, months, wrap, vals, years, minY, maxY, curY, complete, yy_ };
  }
  const mean = (arr, k) => arr.length ? arr.reduce((a, r) => a + r[k], 0) / arr.length : NaN;
  function slope(ys, k) { const n = ys.length, mx = mean(ys, 'y'), my = mean(ys, k); let nu = 0, de = 0; for (const r of ys) { nu += (r.y - mx) * (r[k] - my); de += (r.y - mx) ** 2; } const b = de ? nu / de : 0; return { b, a: my - b * mx }; }

  function chart(ys, k, color, dec, label, unit, hiA, hiB) {
    const W = 640, H = 170, pl = 6, n = ys.length, vals = ys.map(r => r[k]), isT = k === 'temp';
    const lo = isT ? Math.min(...vals) - 0.4 : 0, hi = isT ? Math.max(...vals) + 0.4 : Math.max(...vals, 1), bw = (W - pl * 2) / n, yv = v => H - 6 - (H - 14) * (v - lo) / ((hi - lo) || 1);
    const tr = slope(ys, k), x0 = ys[0].y, x1 = ys[n - 1].y;
    const bars = ys.map((r, i) => `<rect data-y="${r.y}" data-v="${r[k]}" x="${(pl + i * bw + 0.5).toFixed(1)}" y="${yv(r[k]).toFixed(1)}" width="${Math.max(1, bw - 1).toFixed(1)}" height="${Math.max(1, H - 6 - yv(r[k])).toFixed(1)}" fill="${r.y === hiA ? '#fff' : r.y === hiB ? '#ffd166' : color}" opacity="${r.y === hiA || r.y === hiB ? 1 : .6}"/>`).join('');
    const ma = ys.map((r, i) => { const w = ys.slice(Math.max(0, i - 9), i + 1); return `${(pl + i * bw + bw / 2).toFixed(1)},${yv(mean(w, k)).toFixed(1)}`; }).join(' ');
    const dpd = num(Math.abs(tr.b * 10), isT ? 2 : 1);
    return `<div><div class="sm"><b>${label}</b> · ${T('hTrend')}: <span class="${tr.b > 0 ? 'up' : 'down'}">${T('hPerDecade', (tr.b > 0 ? '+' : '−') + dpd + ' ' + unit)}</span></div>` +
      `<svg viewBox="0 0 ${W} ${H}" data-chart="${k}" data-unit="${unit}" data-dec="${dec}" preserveAspectRatio="none" style="height:${H}px">${bars}<polyline points="${ma}" fill="none" stroke="${color}" stroke-width="2.5"/><line x1="${pl}" y1="${(yv(tr.a + tr.b * x0)).toFixed(1)}" x2="${W - pl}" y2="${(yv(tr.a + tr.b * x1)).toFixed(1)}" stroke="#fff" stroke-width="2" stroke-dasharray="6 4"/></svg>` +
      `<div class="sm ltr" style="display:flex;justify-content:space-between"><span>${x0}</span><span>${num(Math.max(...vals), dec)} / ${num(Math.min(...vals), dec)}</span><span>${x1}</span></div></div>`;
  }
  function lineChart(series, labels, unit, dec, bars) {
    const W = 640, H = 190, pl = 28, pb = 18, all = series.flatMap(s => s.v.filter(v => v != null && !isNaN(v))), lo = bars ? 0 : Math.min(...all) - 1, hi = Math.max(...all) + (bars ? 1 : 1);
    const xv = i => pl + (W - pl - 6) * (i + 0.5) / 12, yv = v => H - pb - (H - pb - 8) * (v - lo) / ((hi - lo) || 1);
    let g = '';
    if (bars) { const k = series.length, bw = (W - pl - 6) / 12 / (k + 1); series.forEach((s, j) => s.v.forEach((v, i) => { if (v == null || isNaN(v)) return; g += `<rect data-t="${s.name}: ${num(v, dec)} ${unit}" x="${(xv(i) - bw * k / 2 + j * bw).toFixed(1)}" y="${yv(v).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${Math.max(1, H - pb - yv(v)).toFixed(1)}" fill="${s.color}"/>`; })); }
    else series.forEach(s => { const pts = s.v.map((v, i) => v == null || isNaN(v) ? null : [xv(i), yv(v)]); g += `<polyline fill="none" stroke="${s.color}" stroke-width="${s.w || 2.5}" ${s.dash ? 'stroke-dasharray="5 4"' : ''} points="${pts.filter(Boolean).map(p => p.join(',')).join(' ')}"/>` + pts.map((p, i) => p ? `<circle data-t="${s.name}: ${num(s.v[i], dec)} ${unit}" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="4" fill="${s.color}"/>` : '').join(''); });
    const ax = labels.map((l, i) => `<text x="${xv(i).toFixed(1)}" y="${H - 4}" fill="#aab" font-size="11" text-anchor="middle">${l}</text>`).join('') + [lo, (lo + hi) / 2, hi].map(v => `<text x="2" y="${yv(v).toFixed(1)}" fill="#aab" font-size="10">${Math.round(v)}</text>`).join('');
    return `<svg viewBox="0 0 ${W} ${H}" style="height:auto">${ax}${g}</svg><div class="sm" style="display:flex;gap:14px;flex-wrap:wrap">${series.map(s => `<span><span style="color:${s.color}">●</span> ${s.name}</span>`).join('')}</div>`;
  }
  function heat(md, months12) {
    const years = []; for (let y = md.minY; y <= md.maxY; y++) years.push(y);
    const norm = Array.from({ length: 12 }, (_, i) => { const a = []; for (let y = 1991; y <= 2020; y++) { const r = md.map.get(y * 100 + i + 1); if (r && r[3] > 0) a.push(r[4] / r[3]); } return a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN; });
    const cw = 14, ch = 7, W = 28 + 12 * 48, H = 16 + years.length * ch;
    let g = ''; years.forEach((y, yi) => months12.forEach((ml, m) => { const r = md.map.get(y * 100 + m + 1); if (!r || r[3] < 15 || isNaN(norm[m])) return; const d = r[4] / r[3] - norm[m], t = Math.max(-1, Math.min(1, d / 3)), col = t >= 0 ? `rgb(${Math.round(60 + 195 * t)},${Math.round(70 - 30 * t)},${Math.round(70 - 30 * t)})` : `rgb(${Math.round(70 + 30 * t)},${Math.round(100 - 40 * t)},${Math.round(150 - 105 * t)})`;
      g += `<rect data-t="${ml} ${y}: ${(d >= 0 ? '+' : '−') + num(Math.abs(d), 1)}°" x="${28 + m * 48}" y="${16 + yi * ch}" width="47" height="${ch - 0.6}" fill="${col}"/>`; }));
    const lab = months12.map((ml, m) => `<text x="${28 + m * 48 + 23}" y="11" fill="#aab" font-size="10" text-anchor="middle">${ml}</text>`).join('') + years.filter(y => y % 10 === 0).map(y => `<text x="2" y="${16 + (y - md.minY) * ch + 6}" fill="#aab" font-size="10">${y}</text>`).join('');
    return `<svg viewBox="0 0 ${W} ${H}" style="height:auto;max-width:760px">${lab}${g}</svg>`;
  }

  function render() {
    if (!document.body.classList.contains('histOpen')) return;
    const c = CITIES.find(x => x.id === st.city); if (!c) return;
    const keep = hist.scrollTop;
    const mn = Array.from({ length: 12 }, (_, i) => new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { month: 'long', timeZone: 'UTC' }).format(Date.UTC(2021, i, 15)));
    const mshort = Array.from({ length: 12 }, (_, i) => new Intl.DateTimeFormat(st.lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { month: 'short', timeZone: 'UTC' }).format(Date.UTC(2021, i, 15)));
    const sel = (id, v) => `<select id="${id}">${mn.map((m, i) => `<option value="${i + 1}"${i + 1 === v ? ' selected' : ''}>${m}</option>`).join('')}</select>`;
    const pre = [['pSar', 10, 12], ['pSummer', 6, 9], ['pWinter', 12, 2], ['pAll', 1, 12]];
    const countries = {}; CITIES.forEach(x => (countries[x.c] = countries[x.c] || []).push(x));
    const head = `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><h2>🕰️ ${T('hist')}</h2><button class="btn" id="hClose">✕ ${T('hBack')}</button></div><div class="sm">${T('histSub')}</div>`;
    const place = `<div class="hbar"><span class="sm">${T('hPlace')}</span><select id="hCity">${CITIES.map(x => `<option value="${x.id}"${x.id === c.id ? ' selected' : ''}>${cname(x)}</option>`).join('')}</select>` +
      pre.map(([k, f, t]) => `<span class="chip${f === from && t === to ? ' on' : ''}" data-hp="${f}-${t}">${T(k)}</span>`).join('') + `<span class="sm">${T('climFrom')}</span>${sel('hFrom', from)}<span class="sm">${T('climTo')}</span>${sel('hTo', to)}</div>`;
    let body;
    if (C.isSample()) body = `<div class="sm">${T('hSample')}</div>`;
    else {
      const raw = C.get(c.id);
      if (raw === 'limit') body = `<div class="sm">${T('hLimit')}</div>`;
      else if (raw === 'err') body = `<div class="sm">${T('hFail')}</div>`;
      else if (!Array.isArray(raw)) body = `<div class="sm">${T('hLoading')}</div>`;
      else body = build(c, mn, mshort);
    }
    hist.innerHTML = head + place + body;
    hist.scrollTop = keep;
    $('hClose').onclick = () => document.body.classList.remove('histOpen');
    $('hCity').onchange = e => { A.selectCity(e.target.value); curRows = null; curState = null; open_(); };
    hist.querySelectorAll('[data-hp]').forEach(e => e.onclick = () => { [from, to] = e.dataset.hp.split('-').map(Number); render(); });
    $('hFrom').onchange = e => { from = +e.target.value; render(); }; $('hTo').onchange = e => { to = +e.target.value; render(); };
    const ya = $('hYearA'); if (ya) { ya.onchange = e => { yearA = e.target.value === 'cur' ? 'cur' : +e.target.value; render(); }; $('hVs').onchange = e => { vs = e.target.value === 'normal' || e.target.value === 'recent' ? e.target.value : 'year'; if (vs === 'year') yearB = +e.target.value; render(); }; }
    hist.querySelectorAll('rect[data-y]').forEach(r => { r.onmousemove = ev => showTip(ev, r.dataset.y + ': ' + num(+r.dataset.v, +r.parentNode.dataset.dec) + ' ' + T(r.parentNode.dataset.unit)); r.onmouseleave = hideTip; });
    hist.querySelectorAll('[data-t]').forEach(r => { r.onmousemove = ev => showTip(ev, r.dataset.t); r.onmouseleave = hideTip; });
  }
  function showTip(ev, t) { tip.textContent = t; tip.style.display = 'block'; tip.style.left = Math.min(innerWidth - 220, ev.clientX + 12) + 'px'; tip.style.top = (ev.clientY + 14) + 'px'; }
  function hideTip() { tip.style.display = 'none'; }

  function build(c, mn, mshort) {
    const md = model(c); if (!md || md.years.length < 15) return `<div class="sm">${T('hFail')}</div>`;
    const { years, vals, months, complete, yy_ } = md, curY = md.curY, ysAll = years.map(r => r.y);
    const aY = yearA === 'cur' ? curY : yearA, yearsList = []; for (let y = md.maxY; y >= md.minY; y--) yearsList.push(y);
    // months of year A with full data (the current year is only partly over)
    const subA = months.filter(m => complete(yy_(aY, m), m)), partial = subA.length < months.length;
    const vA = subA.length ? vals(aY, subA) : null;
    const base = (ms, filt) => years.map(r => r.y).filter(y => y !== aY && filt(y)).map(y => vals(y, ms)).filter(Boolean);
    const normSet = base(subA, y => y >= 1991 && y <= 2020), rec = years.filter(r => r.y !== aY).slice(-10).map(r => vals(r.y, subA)).filter(Boolean);
    let cmpName, cmp;
    if (vs === 'normal') { cmpName = T('hNormal'); cmp = { temp: mean(normSet, 'temp'), rain: mean(normSet, 'rain'), rd: mean(normSet, 'rd'), h45: mean(normSet, 'h45'), st: mean(normSet, 'st') }; }
    else if (vs === 'recent') { cmpName = T('hRecent'); cmp = { temp: mean(rec, 'temp'), rain: mean(rec, 'rain'), rd: mean(rec, 'rd'), h45: mean(rec, 'h45'), st: mean(rec, 'st') }; }
    else { cmpName = String(yearB); cmp = vals(yearB, subA) || {}; }
    const rankSet = years.map(r => r.y).filter(y => y !== aY).map(y => vals(y, subA)).filter(Boolean);
    let out = `<div class="hbar"><span class="sm">${T('hYear')}</span><select id="hYearA"><option value="cur"${yearA === 'cur' ? ' selected' : ''}>${curY}</option>${yearsList.filter(y => y !== curY).map(y => `<option value="${y}"${yearA === y ? ' selected' : ''}>${y}</option>`).join('')}</select>` +
      `<span class="sm">${T('hVs')}</span><select id="hVs"><option value="normal"${vs === 'normal' ? ' selected' : ''}>${T('hNormal')}</option><option value="recent"${vs === 'recent' ? ' selected' : ''}>${T('hRecent')}</option>${yearsList.map(y => `<option value="${y}"${vs === 'year' && yearB === y ? ' selected' : ''}>${y}</option>`).join('')}</select></div>`;
    // cards
    out += `<h3>${T('hCards')} · ${aY}</h3>`;
    if (!vA) out += `<div class="sm">${T('hNoData')}</div>`;
    else {
      if (partial) out += `<div class="sm">${T('hSoFar', subA.map(m => mshort[m - 1]).join(', '))}</div>`;
      out += '<div class="cards">' + MET.map(([k, lk, uk, dec]) => {
        const d = vA[k] - cmp[k], rk = rankSet.filter(r => r[k] > vA[k]).length + 1, tot = rankSet.length + 1;
        const word = k === 'temp' ? (rk <= tot / 2 ? T('hWarm') : T('hCool')) : k === 'rain' ? (rk <= tot / 2 ? T('hWet') : T('hDry')) : '';
        const pos = rk <= tot / 2 ? rk : tot - rk + 1;
        return `<div class="card"><div class="sm">${T(lk)}</div><b>${num(vA[k], dec)} <span class="sm">${T(uk)}</span></b>` + (isNaN(d) ? '' : `<div class="${d > 0 ? 'up' : 'down'} ltr">${d >= 0 ? '+' : '−'}${num(Math.abs(d), dec === 0 && k !== 'rain' ? 1 : dec)} ${T(uk)} · ${cmpName}</div>`) + `<div class="sm">${word ? word + ' #' + pos + ' · ' : ''}${T('hRank', rk, tot)}</div></div>`;
      }).join('') + '</div>';
    }
    // charts
    out += `<h3>${T('hCharts')}</h3><div class="sm">${T('hHint')}</div><div class="grid" style="margin-top:8px">` +
      MET.filter(([k]) => k !== 'h45' || years.some(r => r.h45 > 0)).map(([k, lk, uk, dec, col]) => chart(years, k, col, dec, T(lk), T(uk), aY, vs === 'year' ? yearB : null)).join('') + '</div>';
    // monthly profile
    const prof = (fn) => Array.from({ length: 12 }, (_, i) => fn(i + 1));
    const monthVal = (y, m, k) => { const r = md.map.get(y * 100 + m); if (!r || r[2] < dim(y, m) * 0.9) return null; return k === 'temp' ? r[4] / r[3] : r[5]; };
    const avgM = (y0, y1, m, k) => { const a = []; for (let y = y0; y <= y1; y++) { const v = monthVal(y, m, k); if (v != null) a.push(v); } return a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN; };
    const ly = md.maxY === curY ? curY - 1 : md.maxY;
    const sT = [{ name: T('hNormalS'), color: '#8fb4ff', v: prof(m => avgM(1991, 2020, m, 'temp')) }, { name: T('hRecent'), color: '#ffb35c', v: prof(m => avgM(ly - 9, ly, m, 'temp')), dash: true }, { name: String(aY), color: '#ffffff', v: prof(m => monthVal(aY, m, 'temp')), w: 3 }];
    const sR = [{ name: T('hNormalS'), color: '#8fb4ff', v: prof(m => avgM(1991, 2020, m, 'rain')) }, { name: String(aY), color: '#ffffff', v: prof(m => monthVal(aY, m, 'rain')) }];
    out += `<h3>${T('hProfile')}</h3><div class="grid"><div><div class="sm"><b>${T('hProfT')}</b></div>${lineChart(sT, mshort, '°C', 1, false)}</div><div><div class="sm"><b>${T('hProfR')}</b></div>${lineChart(sR, mshort, T('uMm'), 0, true)}</div></div>`;
    // heat map
    out += `<h3>${T('hHeat')}</h3><div class="sm">${T('hHeatSub')}</div>${heat(md, mshort)}`;
    // records
    const top = (k, desc) => years.slice().sort((a, b) => desc ? b[k] - a[k] : a[k] - b[k]).slice(0, 5);
    const rt = (title, arr, k, dec) => `<div><div class="sm"><b>${title}</b></div><table class="ltr">${arr.map((r, i) => `<tr><td>${i + 1}. ${r.y}</td><td>${num(r[k], dec)}</td></tr>`).join('')}</table></div>`;
    out += `<h3>${T('hRec')}</h3><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">${rt(T('hRecWarm'), top('temp', true), 'temp', 1)}${rt(T('hRecCool'), top('temp', false), 'temp', 1)}${rt(T('hRecWet'), top('rain', true), 'rain', 0)}${years.some(r => r.h45 > 0) ? rt(T('hRecHot'), top('h45', true), 'h45', 0) : ''}</div>`;
    // decades
    const decs = []; for (let d = Math.ceil(ysAll[0] / 10) * 10; d <= ysAll[ysAll.length - 1]; d += 10) { const g = years.filter(r => r.y >= d && r.y < d + 10); if (g.length >= 5) decs.push([d, g]); }
    out += `<h3>${T('hDecade')}</h3><table class="ltr"><tr><th>${T('climDecade')}</th>${MET.map(m => `<th>${T(m[1])}</th>`).join('')}</tr>${decs.map(([d, g]) => `<tr><td>${d}s</td>${MET.map(m => `<td>${num(mean(g, m[0]), m[3] === 0 ? (m[0] === 'rain' ? 0 : 1) : 1)}</td>`).join('')}</tr>`).join('')}</table>`;
    // year against year
    if (vA && vs === 'year') {
      const vB = vals(yearB, subA);
      out += `<h3>${T('hCompare')}: ${aY} / ${yearB}</h3>` + (vB ? `<table class="ltr"><tr><th></th><th>${aY}</th><th>${yearB}</th><th>${T('hDiff')}</th></tr>${MET.map(([k, lk, uk, dec]) => { const d = vA[k] - vB[k]; return `<tr><td>${T(lk)}</td><td>${num(vA[k], dec)}</td><td>${num(vB[k], dec)}</td><td class="${d > 0 ? 'up' : 'down'}">${d >= 0 ? '+' : '−'}${num(Math.abs(d), dec)}</td></tr>`; }).join('')}</table>` : `<div class="sm">${T('hNoData')}</div>`);
    }
    return out;
  }

  const refreshBtn = () => { hBtn.textContent = '🕰️ ' + T('hist'); };
  let lastLang = st.lang; const _r = A.onRender; A.onRender = function () { if (_r) _r.apply(this, arguments); refreshBtn(); if (lastLang !== st.lang) { lastLang = st.lang; if (document.body.classList.contains('histOpen')) render(); } };
  refreshBtn();
  const prevData = A.onData; A.onData = function () { if (prevData) prevData.apply(this, arguments); if (document.body.classList.contains('histOpen')) render(); };
})();
