/* Gulf Weather - animated weather map (temperature, wind flow, clouds & rain, dust). by Kankon · kankon.net */
(function () {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const TSTOPS = [[0, [59, 76, 192]], [10, [79, 154, 216]], [16, [72, 196, 196]], [21, [110, 210, 130]], [25, [190, 226, 100]], [29, [255, 224, 102]], [33, [255, 170, 70]], [37, [255, 112, 60]], [41, [226, 58, 58]], [46, [176, 23, 79]], [52, [110, 14, 92]]];
  function tcol(t) {
    if (t <= TSTOPS[0][0]) return TSTOPS[0][1];
    for (let i = 1; i < TSTOPS.length; i++) if (t <= TSTOPS[i][0]) { const a = TSTOPS[i - 1], b = TSTOPS[i], f = (t - a[0]) / (b[0] - a[0]); return [a[1][0] + (b[1][0] - a[1][0]) * f, a[1][1] + (b[1][1] - a[1][1]) * f, a[1][2] + (b[1][2] - a[1][2]) * f]; }
    return TSTOPS[TSTOPS.length - 1][1];
  }
  // value noise for cloud texture
  const NN = 64, NZ = new Float32Array(NN * NN); { let s = 12345; for (let i = 0; i < NN * NN; i++) { s = (s * 1664525 + 1013904223) >>> 0; NZ[i] = s / 4294967296; } }
  function noise(x, y) {
    const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const g = (a, b) => NZ[((b & 63) * NN) + (a & 63)];
    return (g(xi, yi) * (1 - sx) + g(xi + 1, yi) * sx) * (1 - sy) + (g(xi, yi + 1) * (1 - sx) + g(xi + 1, yi + 1) * sx) * sy;
  }
  const fbm = (x, y) => noise(x, y) * 0.55 + noise(x * 2.1, y * 2.1) * 0.3 + noise(x * 4.3, y * 4.3) * 0.15;

  window.createMapView = function (canvas, M) {
    const ctx = canvas.getContext('2d');
    const trail = document.createElement('canvas'), tctx = trail.getContext('2d');
    const K = M.k, S = M.s, X = lon => (lon - M.b.x0) * K * S, Y = lat => (M.b.y1 - lat) * S;
    const shapes = M.shapes.map(s => ({ c: s.c, p: new Path2D(s.d) })), WB = window.GW_WORLD ? { b: new Path2D(window.GW_WORLD.b), c: new Path2D(window.GW_WORLD.c) } : null;
    const RL = -18, RT = 38, RR = 0.5, RW = 163, RH = 61; // raster over lon -18..63, lat 8..38 (0.5°)
    const rast = { temp: document.createElement('canvas'), cloud: document.createElement('canvas'), dust: document.createElement('canvas') };
    Object.values(rast).forEach(c => { c.width = RW; c.height = RH; });
    let wgrid = null, wsnap = null, wsnapT = -1, wReq = false, WC = (window.GW && window.GW.WORLD_CITIES) || [], vp = { l: -18, r: 63, t: 38, b: 8, world: false };
    const WRL = -180, WRT = 80, WRR = 2, WRW = 181, WRH = 71;
    const wrast = { temp: document.createElement('canvas'), cloud: document.createElement('canvas') };
    Object.values(wrast).forEach(c => { c.width = WRW; c.height = WRH; });
    let grid = null, cities = null, CITIES = [], tm = 0, lastRast = -1, layers = { temp: true, wind: true, cloud: true, dust: true, radar: true, sat: true, prec: true, pres: false, cyc: true, sst: false }, sel = null, lang = 'en';
    let lastRastT = 0, z = 1, ox = 0, oy = 0, W = 0, H = 0, dpr = 1, fitted = false, fitBox = null, time = 0;
    const P = [], PN = 3200;
    function spawn(p) { const b = vp; p.lon = b.l + Math.random() * (b.r - b.l); p.lat = b.b + Math.random() * (b.t - b.b); p.age = Math.floor(Math.random() * 90); p.max = 60 + Math.random() * 70; }
    for (let i = 0; i < PN; i++) { const p = {}; spawn(p); P.push(p); }

    function fit(box) {
      const b = fitBox || { x0: 370, y0: 70, x1: W - 20, y1: H - 300 };
      const lo0 = box ? box[0] : -13, lo1 = box ? box[1] : 60, la0 = box ? box[2] : 10, la1 = box ? box[3] : 37.5;
      const zw = (b.x1 - b.x0) / (X(lo1) - X(lo0)), zh = (b.y1 - b.y0) / (Y(la0) - Y(la1));
      z = Math.max(0.1, Math.min(zw, zh)); ox = (b.x0 + b.x1) / 2 - z * (X(lo0) + X(lo1)) / 2; oy = (b.y0 + b.y1) / 2 - z * (Y(la0) + Y(la1)) / 2;
      clearTrail();
    }
    function resize() {
      const w = canvas.clientWidth, h = canvas.clientHeight, d = Math.min(window.devicePixelRatio || 1, 2);
      if (w !== W || h !== H || d !== dpr) { W = w; H = h; dpr = d; canvas.width = w * d; canvas.height = h * d; trail.width = w * d; trail.height = h * d; if (!fitted) { fit(); fitted = true; } else clearTrail(); }
    }
    function clearTrail() { tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.clearRect(0, 0, trail.width, trail.height); }
    const sx = lon => X(lon) * z + ox, sy = lat => Y(lat) * z + oy;

    // snapshot of all fields at the current time (interpolated), then fast bilinear lookups
    let snap = null, snapT = -1, wet = [], storm = [];
    function makeSnap() {
      const g = grid, P2 = g.NX * g.NY, t0 = clamp(Math.floor(tm), 0, g.n - 1), t1 = Math.min(t0 + 1, g.n - 1), at = clamp(tm - t0, 0, 1);
      const pick = arr => { if (!arr) return null; const o = new Float32Array(P2), a = t0 * P2, b = t1 * P2; for (let i = 0; i < P2; i++) o[i] = arr[a + i] * (1 - at) + arr[b + i] * at; return o; };
      snap = { temp: pick(g.temp), u: pick(g.u), v: pick(g.v), cloud: pick(g.cloud), precip: pick(g.precip), pres: pick(g.pres), dust: pick(g.dust) }; snapT = tm;
      wet = []; storm = [];
      if (wgrid && vp.world) { const w = wgrid, PW = w.NX * w.NY, a0 = clamp(Math.floor(tm), 0, w.n - 1), a1 = Math.min(a0 + 1, w.n - 1), af = clamp(tm - a0, 0, 1), pk = arr => { const o = new Float32Array(PW), a = a0 * PW, b = a1 * PW; for (let i = 0; i < PW; i++) o[i] = arr[a + i] * (1 - af) + arr[b + i] * af; return o; }; wsnap = { temp: pk(w.temp), u: pk(w.u), v: pk(w.v), cloud: pk(w.cloud), precip: pk(w.precip), pres: w.pres ? pk(w.pres) : null }; wsnapT = tm;
        for (let j = 0; j < w.NY; j++) for (let i = 0; i < w.NX; i++) { const lo = w.LON0 + i * w.STEP, la = w.LAT0 + j * w.STEP; if (inArab(lo, la)) continue; const p = wsnap.precip[j * w.NX + i]; if (p > 0.12) { const o = { lon: lo, lat: la, pr: p, st: w.STEP }; wet.push(o); if (p >= 2.5) storm.push(o); } } }
      for (let j = 0; j < g.NY; j++) for (let i = 0; i < g.NX; i++) { const p = snap.precip ? snap.precip[j * g.NX + i] : 0; if (p > 0.12) { const o = { lon: g.LON0 + i * g.STEP, lat: g.LAT0 + j * g.STEP, pr: p, st: g.STEP }; wet.push(o); if (p >= 2.5) storm.push(o); } }
      if (CITIES) CITIES.forEach(c => { const h = cityHour(c, tm); if (h && h.code >= 95) storm.push({ lon: c.lon, lat: c.lat, pr: 3 }); });
    }
    function inArab(lon, lat) { return grid && lon >= grid.LON0 && lon <= grid.LON0 + (grid.NX - 1) * grid.STEP && lat >= grid.LAT0 && lat <= grid.LAT0 + (grid.NY - 1) * grid.STEP; }
    function sampleG(G, arr, lon, lat) {
      const NX = G.NX, ST = 1 / G.STEP; let fx = (lon - G.LON0) * ST, fy = (lat - G.LAT0) * ST;
      if (fx < 0) fx = 0; else if (fx > NX - 1.001) fx = NX - 1.001; if (fy < 0) fy = 0; else if (fy > G.NY - 1.001) fy = G.NY - 1.001;
      const i = fx | 0, j = fy | 0, ax = fx - i, ay = fy - j, o = j * NX + i;
      return (arr[o] * (1 - ax) + arr[o + 1] * ax) * (1 - ay) + (arr[o + NX] * (1 - ax) + arr[o + NX + 1] * ax) * ay;
    }
    // value at any point of the world: the detailed 3 degree grid over the Arab world, the coarse world grid elsewhere
    function val(key, lon, lat) { if (wsnap && wsnap[key] && !inArab(lon, lat)) return sampleG(wgrid, wsnap[key], lon, lat); return sample(snap[key], lon, lat); }
    function sample(arr, lon, lat) {
      const NX = grid.NX; const G = grid, ST = 1 / G.STEP; let fx = (lon - G.LON0) * ST, fy = (lat - G.LAT0) * ST;
      if (fx < 0) fx = 0; else if (fx > NX - 1.001) fx = NX - 1.001; if (fy < 0) fy = 0; else if (fy > grid.NY - 1.001) fy = grid.NY - 1.001;
      const i = fx | 0, j = fy | 0, ax = fx - i, ay = fy - j, o = j * NX + i;
      return (arr[o] * (1 - ax) + arr[o + 1] * ax) * (1 - ay) + (arr[o + NX] * (1 - ax) + arr[o + NX + 1] * ax) * ay;
    }
    function cityHour(c, t) { const d = cities[c.id]; if (!d) return null; const k = clamp(Math.round(t + (c.tz - 3)), 0, d.hours.length - 1); return d.hours[k]; }
    function dustAt(lon, lat, t) {
      if (snap.dust) return sample(snap.dust, lon, lat);
      let ws = 0, s = 0; CITIES.forEach(c => { const h = cityHour(c, t); if (!h || h.dust == null) return; const d = Math.hypot((c.lon - lon) * 0.92, c.lat - lat), w = 1 / Math.pow(d + 0.6, 3); ws += w; s += w * h.dust; });
      const near = Math.min(1, ws * 1.2); return ws ? (s / ws) * near + 25 * (1 - near) : 25;
    }

    function buildRasters() {
      const it = ctxs => ctxs; const tc = rast.temp.getContext('2d'), cc = rast.cloud.getContext('2d'), dc = rast.dust.getContext('2d');
      const ti = tc.createImageData(RW, RH), ci = cc.createImageData(RW, RH), di = dc.createImageData(RW, RH);
      const drift = tm * 0.08 + time * 0.012;
      for (let y = 0; y < RH; y++) {
        const lat = RT - y * RR;
        for (let x = 0; x < RW; x++) {
          const lon = RL + x * RR, o = (y * RW + x) * 4, edge = Math.min(1, Math.min(x, RW - 1 - x, y, RH - 1 - y) / 14);
          if (layers.temp) { const c = tcol(sample(snap.temp, lon, lat)); ti.data[o] = c[0]; ti.data[o + 1] = c[1]; ti.data[o + 2] = c[2]; ti.data[o + 3] = 255 * edge; }
          if (layers.cloud) {
            const cl = sample(snap.cloud, lon, lat) / 100, pr = sample(snap.precip, lon, lat);
            const n = fbm(lon * 0.9 + drift, lat * 0.9 - drift * 0.3);
            const sk = layers.sat ? 0.18 : 1; let a = clamp((cl - 0.12) * 1.3, 0, 1) * (0.35 + 0.75 * n); a = clamp(a * 0.95, 0, 0.9) * sk;
            let r = 255, g = 255, b = 255;
            if (pr > 0.08) { const k = pr; if (k < 1) { r = 80; g = 210; b = 255; } else if (k < 4) { r = 40; g = 120; b = 255; } else if (k < 10) { r = 255; g = 212; b = 0; } else { r = 255; g = 60; b = 60; } a = Math.max(a, clamp(0.45 + pr * 0.08, 0, 0.85) * (0.55 + 0.45 * n)); }
            ci.data[o] = r; ci.data[o + 1] = g; ci.data[o + 2] = b; ci.data[o + 3] = a * 255 * edge;
          }
          if (layers.dust) {
            const du = dustAt(lon, lat, tm), a = clamp((du - 120) / 900, 0, 0.85) * (0.6 + 0.4 * fbm(lon * 1.3 - drift * 1.5, lat * 1.3));
            di.data[o] = 214; di.data[o + 1] = 160; di.data[o + 2] = 88; di.data[o + 3] = a * 255 * edge;
          }
        }
      }
      tc.putImageData(ti, 0, 0); cc.putImageData(ci, 0, 0); dc.putImageData(di, 0, 0);
    }

    function buildWorldRasters() {
      const tc = wrast.temp.getContext('2d'), cc = wrast.cloud.getContext('2d'), ti = tc.createImageData(WRW, WRH), ci = cc.createImageData(WRW, WRH), drift = tm * 0.08 + time * 0.012;
      for (let y = 0; y < WRH; y++) {
        const lat = WRT - y * WRR;
        for (let x = 0; x < WRW; x++) {
          const lon = WRL + x * WRR, o = (y * WRW + x) * 4;
          if (layers.temp) { const c = tcol(val('temp', lon, lat)); ti.data[o] = c[0]; ti.data[o + 1] = c[1]; ti.data[o + 2] = c[2]; ti.data[o + 3] = 255; }
          if (layers.cloud) {
            const cl = val('cloud', lon, lat) / 100, pr = val('precip', lon, lat), n = fbm(lon * 0.28 + drift * 0.5, lat * 0.28 - drift * 0.15);
            let a = clamp((cl - 0.12) * 1.3, 0, 1) * (0.35 + 0.75 * n); a = clamp(a * 0.95, 0, 0.9); let r = 255, g = 255, b = 255;
            if (pr > (layers.sat ? 0.35 : 0.05)) { if (pr < 1) { r = 80; g = 210; b = 255; } else if (pr < 4) { r = 40; g = 120; b = 255; } else if (pr < 10) { r = 255; g = 212; b = 0; } else { r = 255; g = 60; b = 60; } const ramp = clamp((pr - 0.05) / 0.9, 0, 1); a = Math.max(a, ramp * ramp * clamp(0.45 + pr * 0.08, 0, 0.85) * (0.55 + 0.45 * n) * (layers.sat ? 0.6 : 1)); }
            ci.data[o] = r; ci.data[o + 1] = g; ci.data[o + 2] = b; ci.data[o + 3] = a * 255;
          }
        }
      }
      tc.putImageData(ti, 0, 0); cc.putImageData(ci, 0, 0);
    }
    function drawRaster(c, alpha, world) {
      ctx.globalAlpha = alpha; ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
      const x0 = world ? sx(WRL - WRR / 2) : sx(RL - RR / 2), y0 = world ? sy(WRT + WRR / 2) : sy(RT + RR / 2), x1 = world ? sx(WRL + (WRW - 1) * WRR + WRR / 2) : sx(RL + (RW - 1) * RR + RR / 2), y1 = world ? sy(WRT - (WRH - 1) * WRR - WRR / 2) : sy(RT - (RH - 1) * RR - RR / 2);
      ctx.drawImage(c, x0, y0, x1 - x0, y1 - y0); ctx.globalAlpha = 1;
    }

    /* ---------- real map tiles (OpenStreetMap / CARTO / Esri), drawn under the weather layers ---------- */
    const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/';
    const BASES = {
      map: { u: (z, x, y) => `${ESRI}World_Street_Map/MapServer/tile/${z}/${y}/${x}`, att: 'Map © Esri, HERE, Garmin, OpenStreetMap contributors', light: true },
      dark: { u: (z, x, y) => `${ESRI}Canvas/World_Dark_Gray_Base/MapServer/tile/${z}/${y}/${x}`, att: 'Map © Esri, HERE, Garmin, OpenStreetMap contributors', light: false },
      sat: { u: (z, x, y) => `${ESRI}World_Imagery/MapServer/tile/${z}/${y}/${x}`, att: 'Imagery © Esri, Maxar, Earthstar Geographics', light: false }
    };
    let base = 'map'; const tileCache = new Map();
    const mercY = lat => Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360));
    const latOfRow = (ty, n) => Math.atan(Math.sinh(Math.PI * (1 - 2 * ty / n))) * 180 / Math.PI;
    function getTile(b, z, x, y, url) {
      const k = b + '/' + z + '/' + x + '/' + y; let t = tileCache.get(k);
      if (!t) {
        t = { img: new Image(), ok: false, t: time }; t.img.onload = () => { t.ok = true; }; t.img.onerror = () => { t.err = true; };
        t.img.src = url || BASES[b].u(z, x, y, x + y); tileCache.set(k, t);
        if (tileCache.size > 700) { let n = 0; for (const key of tileCache.keys()) { tileCache.delete(key); if (++n > 200) break; } }
      }
      return t;
    }
    function drawTiles() {
      const B = BASES[base]; if (!B) return;
      const lonL = (0 - ox) / z / (K * S) + M.b.x0, lonR = (W - ox) / z / (K * S) + M.b.x0, latT = M.b.y1 - (0 - oy) / z / S, latB = M.b.y1 - (H - oy) / z / S;
      const ppd = (X(1) - X(0)) * z;                                  // screen px per degree of longitude
      const Z = clamp(Math.round(Math.log2(ppd * 360 / 256 * (dpr > 1.5 ? 1.4 : 1))), 2, 17), n = 1 << Z;
      const tx0 = Math.floor((lonL + 180) / 360 * n), tx1 = Math.floor((lonR + 180) / 360 * n);
      const my = lat => (1 - mercY(clamp(lat, -85, 85)) / Math.PI) / 2 * n;
      const ty0 = Math.max(0, Math.floor(my(latT))), ty1 = Math.min(n - 1, Math.floor(my(latB)));
      if ((tx1 - tx0 + 1) * (ty1 - ty0 + 1) > 120) return;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const tt = getTile(base, Z, ((tx % n) + n) % n, ty); if (!tt.ok) continue;
        const l0 = tx / n * 360 - 180, l1 = (tx + 1) / n * 360 - 180, xa = sx(l0), xb = sx(l1), SL = 8;
        for (let i = 0; i < SL; i++) { // piece-wise remap from Mercator rows to the page's linear latitude
          const a = latOfRow(ty + i / SL, n), b = latOfRow(ty + (i + 1) / SL, n), ya = sy(a), yb = sy(b);
          ctx.drawImage(tt.img, 0, i * 256 / SL, 256, 256 / SL, xa - 0.4, ya - 0.4, xb - xa + 0.8, yb - ya + 0.8);
        }
      }
    }

    /* ---------- sea surface temperature anomaly (NASA GIBS MUR, daily, land is transparent) ---------- */
    function drawSst() {
      const lonL = (0 - ox) / z / (K * S) + M.b.x0, lonR = (W - ox) / z / (K * S) + M.b.x0, latT = M.b.y1 - (0 - oy) / z / S, latB = M.b.y1 - (H - oy) / z / S;
      const ppd = (X(1) - X(0)) * z, Z = clamp(Math.round(Math.log2(ppd * 360 / 256)), 2, 6), n = 1 << Z;
      const tx0 = Math.floor((clamp(lonL, -180, 179.9) + 180) / 360 * n), tx1 = Math.floor((clamp(lonR, -180, 179.9) + 180) / 360 * n);
      const my = lat => (1 - mercY(clamp(lat, -85, 85)) / Math.PI) / 2 * n;
      const ty0 = Math.max(0, Math.floor(my(latT))), ty1 = Math.min(n - 1, Math.floor(my(latB)));
      if ((tx1 - tx0 + 1) * (ty1 - ty0 + 1) > 120) return;
      ctx.save(); ctx.globalAlpha = 0.72;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const tt = getTile('sst', Z, tx, ty, 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/GHRSST_L4_MUR_Sea_Surface_Temperature_Anomalies/default/default/GoogleMapsCompatible_Level7/' + Z + '/' + ty + '/' + tx + '.png'); if (!tt.ok) continue;
        const l0 = tx / n * 360 - 180, l1 = (tx + 1) / n * 360 - 180, xa = sx(l0), xb = sx(l1), SL = 8;
        for (let i = 0; i < SL; i++) { const a = latOfRow(ty + i / SL, n), b = latOfRow(ty + (i + 1) / SL, n), ya = sy(a), yb = sy(b); ctx.drawImage(tt.img, 0, i * 256 / SL, 256, 256 / SL, xa - 0.4, ya - 0.4, xb - xa + 0.8, yb - ya + 0.8); }
      }
      ctx.restore();
    }
    /* ---------- rain radar (RainViewer public tiles, last ~2 h, animated) ---------- */
    const rv = { frames: null, host: '', idx: 0, nextAt: 0, busy: false, err: false, kind: 'radar' }, sv = { frames: null, host: '', idx: 0, nextAt: 0, busy: false, err: false, kind: 'sat' };
    async function loadRadar() {
      if (rv.busy || rv.frames) return; rv.busy = true;
      try {
        const r = await fetch('https://api.rainviewer.com/public/weather-maps.json'); if (!r.ok) throw new Error('HTTP ' + r.status);
        const j = await r.json(); rv.host = j.host || 'https://tilecache.rainviewer.com';
        sv.host = rv.host; sv.frames = ((j.satellite && j.satellite.infrared) || []).slice(-12); sv.nowN = 0; sv.idx = 0; sv.err = !sv.frames.length;
        rv.frames = (j.radar.past || []).concat(j.radar.nowcast || []); rv.nowN = (j.radar.nowcast || []).length; rv.idx = Math.max(0, rv.frames.length - 1 - rv.nowN); rv.err = !rv.frames.length;
      } catch (e) { rv.err = true; rv.frames = []; sv.frames = []; } finally { rv.busy = false; }
    }
    function drawRadar() { drawRv(rv, layers.radar); drawSat(); }
    /* ---------- EUMETSAT Meteosat layers (free WMS, last ~3 h, animated): infrared clouds and satellite rain ---------- */
    const EUL = 5, EUT = 42, EUW = -20, EUE = 82;
    const EU = {
      sat: { frames: null, idx: 0, nextAt: 0, layer: 'msg_fes:ir108', style: '', rain: false, en: 'Satellite clouds (EUMETSAT) · ', ar: 'غيوم الأقمار الصناعية (EUMETSAT) · ', y: 198, lag: 50 },
      prec: { frames: null, idx: 0, nextAt: 0, layer: 'msg_iodc:h63', style: 'msg_h60b_h63', rain: true, single: true, e: 85, en: 'Satellite rain (EUMETSAT) · ', ar: 'مطر الأقمار الصناعية (EUMETSAT) · ', y: 220, lag: 60 }
    };
    const m3857 = lat => 6378137 * Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360)), lx3857 = lon => 6378137 * lon * Math.PI / 180;
    function euFrames(E) {
      const step = 15 * 60e3, base = Math.floor((Date.now() - E.lag * 60e3) / step) * step; E.frames = []; E.loadedAt = Date.now();
      const x0 = lx3857(EUW), x1 = lx3857(E.e || EUE), y0 = m3857(EUL), y1 = m3857(EUT), w = 1200, h = Math.round(w * (y1 - y0) / (x1 - x0));
      for (let k = E.single ? 0 : 11; k >= 0; k--) {
        const t = new Date(base - k * step).toISOString().slice(0, 19) + 'Z', img = new Image(), f = { t, img, ok: false };
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          try {
            const cv = document.createElement('canvas'); cv.width = img.width; cv.height = img.height; const c2 = cv.getContext('2d');
            try {
              c2.drawImage(img, 0, 0); const id = c2.getImageData(0, 0, cv.width, cv.height), dd = id.data;
              if (E.rain) { for (let i = 0; i < dd.length; i += 4) { const mn = Math.min(dd[i], dd[i + 1], dd[i + 2]); if (mn > 235) dd[i + 3] = 0; else if (mn > 200) dd[i + 3] = dd[i + 3] * (235 - mn) / 35; } }
              else { for (let i = 0; i < dd.length; i += 4) { const v = (dd[i] + dd[i + 1] + dd[i + 2]) / 765, a = Math.min(1, Math.max(0, (v - 0.4) / 0.4)); dd[i] = 255; dd[i + 1] = 255; dd[i + 2] = 255; dd[i + 3] = a * a * (3 - 2 * a) * 255 * (dd[i + 3] / 255); } }
              c2.putImageData(id, 0, 0); f.cv = cv; f.alpha = true; f.ok = true; return;
            } catch (e2) { c2.setTransform(1, 0, 0, 1, 0, 0); c2.clearRect(0, 0, cv.width, cv.height); }
            if (!E.rain) { c2.fillStyle = '#000'; c2.fillRect(0, 0, cv.width, cv.height); c2.filter = 'brightness(0.9) contrast(3.5)'; if (c2.filter && c2.filter !== 'none') { c2.drawImage(img, 0, 0); c2.filter = 'none'; } else { c2.drawImage(img, 0, 0); c2.globalCompositeOperation = 'multiply'; c2.drawImage(img, 0, 0); c2.globalCompositeOperation = 'lighter'; c2.drawImage(cv, 0, 0); } f.cv = cv; }
          } catch (e) { }
          f.ok = true;
        };
        img.onerror = () => { f.ok = false; };
        img.src = 'https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0&request=GetMap&layers=' + E.layer + '&styles=' + E.style + '&crs=EPSG:3857&bbox=' + [x0, y0, x1, y1].join(',') + '&width=' + w + '&height=' + h + '&format=image/png&transparent=true' + (E.single ? '&_=' + Math.floor(Date.now() / step) : '&time=' + encodeURIComponent(t));
        E.frames.push(f);
      }
    }

    /* ---------- NASA GIBS geostationary infrared clouds for the Americas, Pacific and East Asia (free, no key) ---------- */
    const GIBS = [
      { l: 'GOES-West_ABI_Band13_Clean_Infrared', r: [[-165, -110]] },
      { l: 'GOES-East_ABI_Band13_Clean_Infrared', r: [[-110, -20]] },
      { l: 'Himawari_AHI_Band13_Clean_Infrared', r: [[82, 180], [-180, -165]] }
    ], gtiles = new Map(); let gibsTmp = null;
    function gibsTile(layer, z, x, y) {
      const slot = Math.floor(Date.now() / 600e3), k = layer + '/' + z + '/' + x + '/' + y + '/' + slot; let t = gtiles.get(k);
      if (!t) {
        t = { ok: false }; const img = new Image(); img.crossOrigin = 'anonymous';
        img.onload = () => {
          try {
            const cv = document.createElement('canvas'); cv.width = 256; cv.height = 256; const c2 = cv.getContext('2d'); c2.drawImage(img, 0, 0); const id = c2.getImageData(0, 0, 256, 256), d = id.data;
            for (let i = 0; i < d.length; i += 4) {
              const r = d[i], g2 = d[i + 1], b = d[i + 2], mx = Math.max(r, g2, b), mn = Math.min(r, g2, b), v = (r + g2 + b) / 3;
              let a = clamp((v - 178) / 62, 0, 1); a = a * a * (3 - 2 * a) * 0.75; if (mx - mn > 22) a = 0.85;
              d[i] = 255; d[i + 1] = 255; d[i + 2] = 255; d[i + 3] = a * 255;
            }
            c2.putImageData(id, 0, 0); t.cv = cv; t.ok = true;
          } catch (e) { t.err = true; }
        };
        img.onerror = () => { t.err = true; };
        img.src = 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/' + layer + '/default/GoogleMapsCompatible_Level6/' + z + '/' + y + '/' + x + '.png';
        gtiles.set(k, t); if (gtiles.size > 500) { let n = 0; for (const key of gtiles.keys()) { gtiles.delete(key); if (++n > 150) break; } }
      }
      return t;
    }
    function drawGibs() {
      const lonL = (0 - ox) / z / (K * S) + M.b.x0, lonR = (W - ox) / z / (K * S) + M.b.x0, latT = M.b.y1 - (0 - oy) / z / S, latB = M.b.y1 - (H - oy) / z / S;
      const ppd = (X(1) - X(0)) * z, Z = clamp(Math.round(Math.log2(ppd * 360 / 256)), 1, 6), n = 1 << Z;
      const tx0 = clamp(Math.floor((lonL + 180) / 360 * n), 0, n - 1), tx1 = clamp(Math.floor((lonR + 180) / 360 * n), 0, n - 1), my = lat => (1 - mercY(clamp(lat, -85, 85)) / Math.PI) / 2 * n;
      const ty0 = Math.max(0, Math.floor(my(latT))), ty1 = Math.min(n - 1, Math.floor(my(latB))); if ((tx1 - tx0 + 1) * (ty1 - ty0 + 1) > 70) return;
      let any = false;
      if (!gibsTmp) gibsTmp = document.createElement('canvas'); const T2 = gibsTmp; if (T2.width !== Math.round(W * dpr) || T2.height !== Math.round(H * dpr)) { T2.width = Math.round(W * dpr); T2.height = Math.round(H * dpr); }
      const tx = T2.getContext('2d'); tx.setTransform(1, 0, 0, 1, 0, 0); tx.clearRect(0, 0, T2.width, T2.height); tx.setTransform(dpr, 0, 0, dpr, 0, 0);
      for (const sat of GIBS) for (const [a, b] of sat.r) {
        if (b < lonL || a > lonR) continue;
        const sub = document.createElement('canvas'); sub.width = T2.width; sub.height = T2.height; const sc = sub.getContext('2d'); sc.setTransform(dpr, 0, 0, dpr, 0, 0); let drew = false;
        for (let ty = ty0; ty <= ty1; ty++) for (let tx2 = tx0; tx2 <= tx1; tx2++) {
          const l0 = tx2 / n * 360 - 180, l1 = (tx2 + 1) / n * 360 - 180; if (l1 < a || l0 > b) continue;
          const tt = gibsTile(sat.l, Z, tx2, ty); if (!tt.ok) continue; drew = true;
          const xa = Math.round(sx(l0)), xb = Math.round(sx(l1)), SL = 8;
          for (let i = 0; i < SL; i++) { const ya = Math.round(sy(latOfRow(ty + i / SL, n))), yb = Math.round(sy(latOfRow(ty + (i + 1) / SL, n))); sc.drawImage(tt.cv, 0, i * 256 / SL, 256, 256 / SL, xa, ya, xb - xa, yb - ya); }
        }
        if (!drew) continue; any = true;
        // soft edge toward the neighbouring satellite (the outer world edge stays sharp)
        const fa = sx(a), fb = sx(b), fe = Math.min((fb - fa) / 3, 12 * (X(1) - X(0)) * z), lo = a <= -180 ? 0 : fe, hi = b >= 180 ? 0 : fe;
        sc.globalCompositeOperation = 'destination-in'; const g = sc.createLinearGradient(fa, 0, fb, 0), wd = Math.max(1, fb - fa);
        g.addColorStop(0, lo ? 'rgba(0,0,0,0)' : 'rgba(0,0,0,1)'); g.addColorStop(Math.min(0.49, lo / wd), 'rgba(0,0,0,1)'); g.addColorStop(Math.max(0.51, 1 - hi / wd), 'rgba(0,0,0,1)'); g.addColorStop(1, hi ? 'rgba(0,0,0,0)' : 'rgba(0,0,0,1)');
        sc.setTransform(1, 0, 0, 1, 0, 0); sc.fillStyle = g; sc.save(); sc.scale(dpr, dpr); sc.fillRect(0, 0, W, H); sc.restore();
        tx.setTransform(1, 0, 0, 1, 0, 0); tx.drawImage(sub, 0, 0); tx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
      if (any) { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.shadowColor = 'rgba(10,25,55,0.55)'; ctx.shadowBlur = 8 * dpr; ctx.shadowOffsetX = 2 * dpr; ctx.shadowOffsetY = 3 * dpr; ctx.drawImage(T2, 0, 0); ctx.restore(); }
      if (any) labels.push([lang === 'ar' ? 'غيوم الأقمار الصناعية (NASA) · آخر صورة متوفرة' : 'Satellite clouds (NASA) · latest available image', 264]);
    }
    const labels = [];
    function drawLabels() { ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.font = '700 12px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.textAlign = 'center'; for (const [lab, y] of labels) { const tw = ctx.measureText(lab).width + 20, cx = W / 2 + 120; ctx.fillStyle = 'rgba(12,20,36,.82)'; rr(cx - tw / 2, y, tw, 24, 12); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillText(lab, cx, y + 16); } labels.length = 0; }
    function drawSat() { if (layers.sat) drawGibs(); drawEu(EU.sat, layers.sat); drawEu(EU.prec, layers.radar); }
    function drawEu(E, on) {
      if (!on) return; if (!E.frames || (E.single && Date.now() - E.loadedAt > 15 * 60e3)) euFrames(E);
      const ok = E.frames.filter(f => f.ok); if (!ok.length) return;
      if (time > E.nextAt) { E.idx = (E.idx + 1) % ok.length; E.nextAt = time + (E.idx === ok.length - 1 ? 1.6 : 0.6); }
      const f = ok[Math.min(E.idx, ok.length - 1)], img = f.cv || f.img, ya = m3857(EUL), yb = m3857(EUT), SL = 40;
      if (!E.tmp) E.tmp = document.createElement('canvas'); const T2 = E.tmp; if (T2.width !== Math.round(W * dpr) || T2.height !== Math.round(H * dpr)) { T2.width = Math.round(W * dpr); T2.height = Math.round(H * dpr); }
      const tx = T2.getContext('2d'); tx.setTransform(1, 0, 0, 1, 0, 0); tx.clearRect(0, 0, T2.width, T2.height); tx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const xa = sx(EUW), xb = sx(E.e || EUE);
      for (let i = 0; i < SL; i++) {
        const la = EUT - (EUT - EUL) * i / SL, lb = EUT - (EUT - EUL) * (i + 1) / SL, s0 = (yb - m3857(la)) / (yb - ya) * img.height, s1 = (yb - m3857(lb)) / (yb - ya) * img.height;
        const d0 = sy(la), d1 = sy(lb); tx.drawImage(img, 0, s0, img.width, Math.max(1, s1 - s0), xa, d0 - 0.4, xb - xa, d1 - d0 + 0.8);
      }
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = (f.alpha || E.rain) ? 'source-over' : 'screen'; ctx.globalAlpha = E.rain ? 0.8 : 0.9;
      if (f.alpha && !E.rain) { ctx.shadowColor = 'rgba(10,25,55,0.65)'; ctx.shadowBlur = 9 * dpr; ctx.shadowOffsetX = 3 * dpr; ctx.shadowOffsetY = 4 * dpr; }
      ctx.drawImage(T2, 0, 0); ctx.restore();
      if (window.__gwSatDebug) { window.__gwSatInfo = window.__gwSatInfo || {}; window.__gwSatInfo[E.layer] = { ok: ok.length, w: f.img.width, h: f.img.height, cv: !!f.cv, t: f.t }; }
      const lab = E.single ? (lang === 'ar' ? 'مطر الأقمار الصناعية (EUMETSAT) · آخر صورة' : 'Satellite rain (EUMETSAT) · latest image') : (lang === 'ar' ? E.ar : E.en) + new Intl.DateTimeFormat(lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kuwait' }).format(E.single ? new Date(E.loadedAt) : new Date(f.t));
      labels.push([lab, E.y]);
    }
    function drawRv(rv, on) {
      if (!on) return; if (!rv.frames && !rv.busy) loadRadar(); if (!rv.frames || !rv.frames.length) return;
      if (time > rv.nextAt) { rv.idx = (rv.idx + 1) % rv.frames.length; rv.nextAt = time + (rv.idx === rv.frames.length - 1 ? 1.6 : 0.55); }
      const f = rv.frames[rv.idx];
      const lonL = (0 - ox) / z / (K * S) + M.b.x0, lonR = (W - ox) / z / (K * S) + M.b.x0, latT = M.b.y1 - (0 - oy) / z / S, latB = M.b.y1 - (H - oy) / z / S;
      const ppd = (X(1) - X(0)) * z, Z = clamp(Math.round(Math.log2(ppd * 360 / 256)), 2, 7), n = 1 << Z;
      const tx0 = Math.floor((lonL + 180) / 360 * n), tx1 = Math.floor((lonR + 180) / 360 * n), my = lat => (1 - mercY(clamp(lat, -85, 85)) / Math.PI) / 2 * n;
      const ty0 = Math.max(0, Math.floor(my(latT))), ty1 = Math.min(n - 1, Math.floor(my(latB))); if ((tx1 - tx0 + 1) * (ty1 - ty0 + 1) > 80) return;
      ctx.globalAlpha = rv.kind === 'sat' ? 0.7 : 0.8;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const wx = ((tx % n) + n) % n, tt = getTile('rv' + f.time, Z, wx, ty, rv.kind === 'sat' ? `${rv.host}${f.path}/256/${Z}/${wx}/${ty}/0/0_0.png` : `${rv.host}${f.path}/256/${Z}/${wx}/${ty}/2/1_1.png`); if (!tt.ok) continue;
        const xa = sx(tx / n * 360 - 180), xb = sx((tx + 1) / n * 360 - 180), SL = 8;
        for (let i = 0; i < SL; i++) { const ya = sy(latOfRow(ty + i / SL, n)), yb = sy(latOfRow(ty + (i + 1) / SL, n)); ctx.drawImage(tt.img, 0, i * 256 / SL, 256, 256 / SL, xa - 0.4, ya - 0.4, xb - xa + 0.8, yb - ya + 0.8); }
      }
      ctx.globalAlpha = 1;
      // time label
      const when = new Date(f.time * 1000), isF = rv.nowN && rv.idx >= rv.frames.length - rv.nowN, lab = (rv.kind === 'sat' ? (lang === 'ar' ? 'غيوم الأقمار الصناعية · ' : 'Satellite clouds · ') : (lang === 'ar' ? 'رادار المطر · ' : 'Rain radar · ')) + new Intl.DateTimeFormat(lang === 'ar' ? 'ar-u-nu-latn' : 'en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kuwait' }).format(when) + (isF ? (lang === 'ar' ? ' (توقع)' : ' (forecast)') : '');
      labels.push([lab, rv.kind === 'sat' ? 206 : 176]); const cx = W / 2 + 120;
      if (rv.err) { ctx.fillStyle = '#ffb35c'; ctx.fillText(lang === 'ar' ? 'رادار المطر مو متوفر الحين' : 'Rain radar is not available right now', cx, 170); }
    }
    let meLL = null; function drawMe() {
      if (!meLL) return; const x = sx(meLL.lon), y = sy(meLL.lat); if (x < -20 || x > W + 20 || y < -20 || y > H + 20) return;
      const p = (time % 2) / 2; ctx.beginPath(); ctx.arc(x, y, 8 + p * 18, 0, Math.PI * 2); ctx.fillStyle = `rgba(66,133,244,${0.35 * (1 - p)})`; ctx.fill();
      ctx.beginPath(); ctx.arc(x, y, 8, 0, Math.PI * 2); ctx.fillStyle = '#4285f4'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.stroke();
    }

    let markers = [];
    function drawMarkers() {
      markers = []; ctx.textAlign = 'center';
      const placed = [], obst = ['legend', 'kwPanel', 'alerts', 'now'].map(id => document.getElementById(id)).filter(e => e && getComputedStyle(e).display !== 'none').map(e => { const r = e.getBoundingClientRect(), c = canvas.getBoundingClientRect(); return [r.left - c.left - 4, r.top - c.top - 4, r.width + 8, r.height + 8]; });
      const hit = (a, b) => a[0] < b[0] + b[2] + 2 && a[0] + a[2] + 2 > b[0] && a[1] < b[1] + b[3] + 1 && a[1] + a[3] + 1 > b[1];
      obst.forEach(o => placed.push(o)); const wl = (wsnap && vp.world) ? WC.map(w => Object.assign({}, w, { c: w.cc })) : [], list = CITIES.concat(wl).slice().sort((a, b) => (a.id === sel ? -1 : b.id === sel ? 1 : a.p - b.p));
      list.forEach(c => {
        const h = c.world ? { temp: val('temp', c.lon, c.lat) } : cityHour(c, tm); if (!h) return; const x = sx(c.lon), y = sy(c.lat), isSel = c.id === sel;
        if (x < -40 || x > W + 40 || y < -40 || y > H + 40) return;
        const t = Math.round(h.temp) + '°';
        ctx.font = '700 13px Segoe UI, -apple-system, Tahoma, sans-serif'; const tw = ctx.measureText(t).width + 16;
        ctx.font = (isSel ? '700 ' : '600 ') + '11.5px Segoe UI, -apple-system, Tahoma, sans-serif'; const nw = Math.max(tw, ctx.measureText(c[lang]).width + 6);
        const col = tcol(h.temp), colS = `rgb(${col[0] | 0},${col[1] | 0},${col[2] | 0})`;
        let pill = [x - tw / 2, y - 31, tw, 38], nbox = [x - nw / 2, y + 7, nw, 15], off = null, showName = true;
        if (isSel || !placed.some(q => hit(pill, q))) { placed.push(pill); showName = isSel || !placed.some(q => q !== pill && hit(nbox, q)); if (showName) placed.push(nbox); }
        else {
          if (c.p < 4 || (X(1) - X(0)) * z < 150) return;
          // crowded area: put a compact "Name 24°" label next to the dot with a thin leader line
          ctx.font = '700 12px Segoe UI, -apple-system, Tahoma, sans-serif'; const lbl = c[lang] + '  ' + t, lw = ctx.measureText(lbl).width + 16;
          for (const [dx, dy] of [[0, -34], [0, 34], [lw / 2 + 12, 4], [-lw / 2 - 12, 4], [lw / 2 + 12, -30], [-lw / 2 - 12, -30], [lw / 2 + 12, 38], [-lw / 2 - 12, 38], [0, -62], [0, 62]]) {
            const bx = [x + dx - lw / 2, y + dy - 11, lw, 22]; if (!placed.some(q => hit(bx, q))) { off = { bx, lbl, lw }; placed.push(bx); placed.push([x - 5, y - 5, 10, 10]); break; }
          }
          if (!off) return;
        }
        if (off) {
          const cx = off.bx[0] + off.lw / 2, cy = off.bx[1] + 11;
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(cx, cy); ctx.strokeStyle = 'rgba(20,20,30,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.font = '700 12px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.fillStyle = 'rgba(12,20,36,.88)'; ctx.strokeStyle = colS; ctx.lineWidth = 2;
          rr(off.bx[0], off.bx[1], off.lw, 22, 11); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#fff'; ctx.fillText(off.lbl, cx, cy + 4.5);
          ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.stroke();
          markers.push({ id: c.id, x: cx, y: cy }); return;
        }
        ctx.font = '700 13px Segoe UI, -apple-system, Tahoma, sans-serif';
        ctx.fillStyle = isSel ? '#ffc861' : 'rgba(12,20,36,.82)'; ctx.strokeStyle = colS; ctx.lineWidth = 2;
        rr(x - tw / 2, y - 30, tw, 21, 10); ctx.fill(); ctx.stroke();
        ctx.fillStyle = isSel ? '#2a1d00' : '#fff'; ctx.fillText(t, x, y - 15);
        ctx.beginPath(); ctx.arc(x, y, isSel ? 5 : 3.5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.font = (isSel ? '700 ' : '600 ') + '11.5px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.6)';
        if (showName) { ctx.strokeText(c[lang], x, y + 20); ctx.fillStyle = '#fff'; ctx.fillText(c[lang], x, y + 20); }
        markers.push({ id: c.id, x, y: y - 10 });
      });
    }

    /* ---------- air pressure: isobars (marching squares), highs (H) and lows (L) ---------- */
    const pc = { key: '', t: -99, lv: [], hl: [], step: 4 };
    function buildPressure() {
      if (!snap || !snap.pres) { pc.lv = []; pc.hl = []; return; }
      const key = [vp.l.toFixed(1), vp.r.toFixed(1), vp.t.toFixed(1), vp.b.toFixed(1), vp.world ? 1 : 0].join();
      if (key === pc.key && Math.abs(tm - pc.t) < 0.2) return; pc.key = key; pc.t = tm;
      const L = Math.max(vp.l - 3, -180), R = Math.min(vp.r + 3, 180), T = Math.min(vp.t + 3, 85), B = Math.max(vp.b - 3, -65);
      const dd = clamp((R - L) / 100, 0.35, 2.4), nx = Math.ceil((R - L) / dd) + 1, ny = Math.ceil((T - B) / dd) + 1;
      let f = new Float32Array(nx * ny), g2 = new Float32Array(nx * ny);
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) f[j * nx + i] = val('pres', L + i * dd, B + j * dd);
      for (let pass = 0; pass < 2; pass++) { for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { let sum = 0, c = 0; for (let b = -1; b <= 1; b++) for (let a = -1; a <= 1; a++) { const ii = i + a, jj = j + b; if (ii >= 0 && jj >= 0 && ii < nx && jj < ny) { sum += f[jj * nx + ii]; c++; } } g2[j * nx + i] = sum / c; } const t2 = f; f = g2; g2 = t2; }
      let mn = 1e9, mx = -1e9; for (let i = 0; i < f.length; i++) { if (f[i] < mn) mn = f[i]; if (f[i] > mx) mx = f[i]; }
      const stp = (R - L) > 70 ? 4 : 2; pc.step = stp; pc.lv = [];
      const X0 = i => L + i * dd, Y0 = j => B + j * dd;
      for (let lv = Math.ceil(mn / stp) * stp; lv <= mx; lv += stp) {
        const seg = [];
        for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
          const a = f[j * nx + i], b = f[j * nx + i + 1], c = f[(j + 1) * nx + i + 1], d = f[(j + 1) * nx + i];
          const k = (a >= lv ? 8 : 0) | (b >= lv ? 4 : 0) | (c >= lv ? 2 : 0) | (d >= lv ? 1 : 0); if (k === 0 || k === 15) continue;
          const top = () => [X0(i + (lv - a) / (b - a)), Y0(j)], right = () => [X0(i + 1), Y0(j + (lv - b) / (c - b))], bot = () => [X0(i + (lv - d) / (c - d)), Y0(j + 1)], left = () => [X0(i), Y0(j + (lv - a) / (d - a))];
          const add = (p, q) => seg.push(p[0], p[1], q[0], q[1]);
          switch (k) { case 1: case 14: add(left(), bot()); break; case 2: case 13: add(bot(), right()); break; case 3: case 12: add(left(), right()); break; case 4: case 11: add(top(), right()); break; case 5: add(top(), left()); add(bot(), right()); break; case 6: case 9: add(top(), bot()); break; case 7: case 8: add(top(), left()); break; case 10: add(top(), right()); add(left(), bot()); break; }
        }
        if (seg.length) pc.lv.push({ v: lv, s: seg });
      }
      // highs and lows: local extremes that stand out from their surroundings
      const rc = Math.max(2, Math.round(6 / dd)), cand = [];
      for (let j = rc; j < ny - rc; j++) for (let i = rc; i < nx - rc; i++) {
        const v = f[j * nx + i]; let isMax = true, isMin = true;
        for (let b = -1; b <= 1 && (isMax || isMin); b++) for (let a = -1; a <= 1; a++) { if (!a && !b) continue; const w = f[(j + b) * nx + i + a]; if (w > v) isMax = false; if (w < v) isMin = false; }
        if (!isMax && !isMin) continue;
        let ring = 0, rn = 0; for (let q = 0; q < 12; q++) { const an = q / 12 * 6.2832, ii = Math.round(i + Math.cos(an) * rc), jj = Math.round(j + Math.sin(an) * rc); ring += f[jj * nx + ii]; rn++; }
        const diff = v - ring / rn; if (isMax && diff >= 2.5) cand.push({ lon: X0(i), lat: Y0(j), v, h: true, d: diff }); else if (isMin && diff <= -2.5) cand.push({ lon: X0(i), lat: Y0(j), v, h: false, d: -diff });
      }
      cand.sort((a, b) => b.d - a.d); pc.hl = [];
      for (const c of cand) { if (!pc.hl.some(o => Math.hypot((o.lon - c.lon) * 0.8, o.lat - c.lat) < 11)) pc.hl.push(c); if (pc.hl.length >= 14) break; }
    }
    function drawPressure() {
      buildPressure(); if (!pc.lv.length) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const L of pc.lv) {
        const major = L.v % 20 === 0; ctx.beginPath(); const s = L.s;
        for (let i = 0; i < s.length; i += 4) { ctx.moveTo(sx(s[i]), sy(s[i + 1])); ctx.lineTo(sx(s[i + 2]), sy(s[i + 3])); }
        if (base === 'map') { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = major ? 4.4 : 3.4; ctx.stroke(); ctx.strokeStyle = major ? 'rgba(20,33,60,.95)' : 'rgba(20,33,60,.8)'; ctx.lineWidth = major ? 2.2 : 1.5; ctx.stroke(); } else { ctx.strokeStyle = 'rgba(8,16,34,.45)'; ctx.lineWidth = major ? 4.2 : 3.2; ctx.stroke(); ctx.strokeStyle = major ? 'rgba(255,255,255,1)' : 'rgba(255,255,255,.88)'; ctx.lineWidth = major ? 2 : 1.3; ctx.stroke(); }
      }
      // pressure values on the lines (spaced apart)
      const placed = []; ctx.font = '600 10.5px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.textAlign = 'center';
      for (const L of pc.lv) {
        const s = L.s, n = s.length / 4; for (let q = 0; q < n; q += 7) {
          const i = q * 4, x = (sx(s[i]) + sx(s[i + 2])) / 2, y = (sy(s[i + 1]) + sy(s[i + 3])) / 2; if (x < 60 || x > W - 60 || y < 100 || y > H - 80) continue;
          if (placed.some(p => Math.abs(p[0] - x) < 120 && Math.abs(p[1] - y) < 56)) continue; placed.push([x, y]);
          const t = String(L.v), w = ctx.measureText(t).width + 8; ctx.fillStyle = base === 'map' ? 'rgba(255,255,255,.85)' : 'rgba(12,20,36,.78)'; rr(x - w / 2, y - 8, w, 16, 8); ctx.fill(); ctx.fillStyle = base === 'map' ? '#14213c' : '#fff'; ctx.fillText(t, x, y + 4);
        }
      }
      for (const e of pc.hl) {
        const x = sx(e.lon), y = sy(e.lat); if (x < -40 || x > W + 40 || y < -40 || y > H + 40) continue;
        const col = e.h ? '#2459ff' : '#e0262d', r = 22;
        ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fillStyle = 'rgba(255,255,255,.93)'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = col; ctx.stroke();
        ctx.fillStyle = col; ctx.font = '800 26px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.fillText(e.h ? 'H' : 'L', x, y + 9);
        const nm = lang === 'ar' ? (e.h ? 'مرتفع جوي' : 'منخفض جوي') : (e.h ? 'High' : 'Low'), tx = nm + ' · ' + Math.round(e.v);
        ctx.font = '700 12px Segoe UI, -apple-system, Tahoma, sans-serif'; const w = ctx.measureText(tx).width + 14; ctx.fillStyle = 'rgba(12,20,36,.85)'; rr(x - w / 2, y + r + 4, w, 20, 10); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke(); ctx.fillStyle = '#fff'; ctx.fillText(tx, x, y + r + 18.5);
      }
    }

    /* ---------- tropical cyclones (GDACS, free, worldwide): position, past track, forecast track and cone ---------- */
    const cy = { list: [], at: 0, busy: false, ok: false, told: '' };
    const CYC = { Green: '#35c759', Orange: '#ff9f0a', Red: '#ff3b30' };
    async function loadCyclones() {
      if (cy.busy) return; cy.busy = true; cy.at = Date.now();
      try {
        const d = x => x.toISOString().slice(0, 10), r = await fetch('https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH?eventlist=TC&fromdate=' + d(new Date(Date.now() - 12 * 864e5)) + '&todate=' + d(new Date(Date.now() + 864e5)) + '&alertlevel=Green;Orange;Red');
        if (!r.ok) throw new Error('HTTP ' + r.status); const j = r.status === 204 ? { features: [] } : await r.json(), out = [];
        const cur = (j.features || []).filter(f => { const p = f.properties || {}; return p.iscurrent === 'true' || p.iscurrent === true || (p.todate && Date.now() - Date.parse(p.todate + 'Z') < 12 * 36e5); }).slice(0, 6);
        for (const f of cur) {
          const p = f.properties, o = { name: String(p.eventname || p.name || '').replace(/^Tropical Cyclone /i, ''), level: p.alertlevel || 'Green', wind: p.severitydata ? +p.severitydata.severity : 0, pos: f.geometry && f.geometry.coordinates ? f.geometry.coordinates.slice(0, 2) : null, past: [], fc: [], cones: [] };
          try {
            const g = await (await fetch(p.url.geometry)).json();
            (g.features || []).forEach(q => { const pr = q.properties || {}, c = String(pr.Class || ''), gm = q.geometry;
              if (c.indexOf('Line_') === 0 && gm && gm.type === 'LineString') { const seg = { c: gm.coordinates, k: pr.polygonlabel || 'TS' }; if (pr.forecast === true || pr.forecast === 'true') o.fc.push(seg); else o.past.push(seg); }
              else if (c === 'Poly_Cones' && gm) { (gm.type === 'Polygon' ? [gm.coordinates] : gm.coordinates || []).forEach(poly => o.cones.push(poly[0])); } });
            if (o.past.length) o.pos = o.past[o.past.length - 1].c[1]; else if (o.fc.length) o.pos = o.fc[0].c[0];
          } catch (e2) { }
          if (o.pos) out.push(o);
        }
        cy.list = out; cy.ok = true; if (api.onCyclones) api.onCyclones(out);
      } catch (e) { cy.ok = cy.ok || false; cy.err = true; } finally { cy.busy = false; }
    }
    const CK = { TD: '#8fb8ff', TS: '#ffd24a', HU: '#ff4d3d' };
    function drawCyclones() {
      if (Date.now() - cy.at > 30 * 60e3) loadCyclones();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      if (cy.ok && !cy.list.length) labels.push([lang === 'ar' ? 'الأعاصير المدارية · ما في أعاصير نشطة الحين' : 'Tropical cyclones · none active right now', 242]);
      for (const c of cy.list) {
        const col = CYC[c.level] || CYC.Green;
        ctx.fillStyle = col + '30'; ctx.strokeStyle = col + 'aa'; ctx.lineWidth = 1.2;
        c.cones.forEach(ring => { ctx.beginPath(); ring.forEach((q, i) => { const x = sx(q[0]), y = sy(q[1]); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }); ctx.closePath(); ctx.fill(); ctx.stroke(); });
        const line = (seg, dash) => { ctx.beginPath(); ctx.moveTo(sx(seg.c[0][0]), sy(seg.c[0][1])); ctx.lineTo(sx(seg.c[1][0]), sy(seg.c[1][1])); ctx.setLineDash(dash); ctx.strokeStyle = 'rgba(8,16,34,.6)'; ctx.lineWidth = 5; ctx.stroke(); ctx.strokeStyle = CK[seg.k] || '#fff'; ctx.lineWidth = 2.6; ctx.stroke(); ctx.setLineDash([]); };
        c.past.forEach(q => line(q, [])); c.fc.forEach(q => line(q, [7, 6]));
        const x = sx(c.pos[0]), y = sy(c.pos[1]); if (x < -60 || x > W + 60 || y < -60 || y > H + 60) continue;
        const rot = time * 1.6, r = 17;
        ctx.beginPath(); ctx.arc(x, y, r + 5, 0, 6.2832); ctx.fillStyle = 'rgba(12,20,36,.8)'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = col; ctx.stroke();
        ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.font = '26px "Segoe UI Emoji","Apple Color Emoji",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.fillText('🌀', 0, 9); ctx.restore();
        const cat = c.wind >= 118 ? (lang === 'ar' ? 'إعصار' : 'Hurricane/Typhoon') : c.wind >= 63 ? (lang === 'ar' ? 'عاصفة مدارية' : 'Tropical storm') : (lang === 'ar' ? 'منخفض مداري' : 'Tropical depression');
        const tx = c.name + ' · ' + cat + (c.wind ? ' · ' + Math.round(c.wind) + (lang === 'ar' ? ' كم/س' : ' km/h') : '');
        ctx.font = '700 12px Segoe UI, -apple-system, Tahoma, sans-serif'; ctx.textAlign = 'center'; const w = ctx.measureText(tx).width + 16;
        ctx.fillStyle = 'rgba(12,20,36,.88)'; rr(x - w / 2, y + r + 9, w, 22, 11); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 1.8; ctx.stroke(); ctx.fillStyle = '#fff'; ctx.fillText(tx, x, y + r + 24.5);
      }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

    function frame(dt) {
      resize(); time += dt; if (!grid) return;
      { const l = (0 - ox) / z / (K * S) + M.b.x0, r = (W - ox) / z / (K * S) + M.b.x0, t = M.b.y1 - (0 - oy) / z / S, b = M.b.y1 - (H - oy) / z / S, was = vp.world;
        const need = l < -38 || r > 84 || t > 52 || b < -6;
        vp.world = !!wgrid && need;
        if (need && !wgrid && !wReq && api.onNeedWorld) { wReq = true; api.onNeedWorld(); }
        const L = vp.world ? Math.max(l, -180) : Math.max(l, -18), R = vp.world ? Math.min(r, 180) : Math.min(r, 63), T = vp.world ? Math.min(t, 80) : Math.min(t, 38), B = vp.world ? Math.max(b, -60) : Math.max(b, 8);
        if (R > L && T > B) { vp.l = L; vp.r = R; vp.t = T; vp.b = B; } if (was !== vp.world) { snap = null; lastRast = -1; clearTrail(); } }
      if (!snap || Math.abs(tm - snapT) > 0.01 || (vp.world && !wsnap)) makeSnap();
      if (Math.abs(tm - lastRast) > 0.04 || lastRast < 0 || ((layers.cloud || layers.dust) && time - lastRastT > 0.6)) { buildRasters(); if (vp.world && wsnap) buildWorldRasters(); lastRast = tm; lastRastT = time; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#0b2238'); bg.addColorStop(1, '#071626'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      // land
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      shapes.forEach(s => { ctx.fillStyle = s.c ? '#3a3f48' : '#2b3038'; ctx.fill(s.p); });
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (base !== 'none') drawTiles();
      if (layers.temp && vp.world && wsnap) { ctx.save(); drawRaster(wrast.temp, base === 'none' ? 0.55 : base === 'sat' ? 0.5 : base === 'dark' ? 0.3 : 0.42, true); ctx.restore(); }
      if (layers.temp) { ctx.save(); ctx.globalCompositeOperation = 'source-over'; drawRaster(rast.temp, base === 'none' ? 0.55 : base === 'sat' ? 0.5 : base === 'dark' ? 0.3 : 0.42); ctx.restore(); }
      if (layers.sst) drawSst();
      // borders + coast
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      ctx.lineJoin = 'round';
      const lt = base === 'map'; shapes.forEach(s => { ctx.strokeStyle = lt ? (s.c ? 'rgba(60,40,90,.6)' : 'rgba(60,40,90,.25)') : (s.c ? 'rgba(255,255,255,.75)' : 'rgba(255,255,255,.35)'); ctx.lineWidth = (s.c ? 1.1 : 0.7) / z; ctx.stroke(s.p); });
      if (WB && vp.world) { ctx.save(); const cp = new Path2D(); cp.rect(-1e5, -1e5, 2e5, 2e5); cp.rect(0, 0, M.w, M.h); ctx.clip(cp, 'evenodd'); ctx.lineWidth = 0.8 / z; ctx.strokeStyle = lt ? 'rgba(60,40,90,.45)' : 'rgba(255,255,255,.55)'; ctx.stroke(WB.b); ctx.lineWidth = 1 / z; ctx.strokeStyle = lt ? 'rgba(60,40,90,.75)' : 'rgba(255,255,255,.9)'; ctx.stroke(WB.c); ctx.restore(); }
      if (sel) { const s = shapes.find(q => q.c === (CITIES.find(c => c.id === sel) || {}).c); if (s) { ctx.strokeStyle = 'rgba(255,200,97,.95)'; ctx.lineWidth = 2 / z; ctx.stroke(s.p); } }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (layers.dust) drawRaster(rast.dust, base === 'none' ? 1 : 0.55);
      if (layers.cloud && vp.world && wsnap) drawRaster(wrast.cloud, base === 'none' ? 0.9 : 0.8, true);
      if (layers.cloud) drawRaster(rast.cloud, base === 'none' ? 0.9 : 0.8);
      // wind particles
      if (layers.wind) {
        tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.globalCompositeOperation = 'destination-in'; tctx.fillStyle = 'rgba(0,0,0,0.9)'; tctx.fillRect(0, 0, trail.width, trail.height);
        tctx.globalCompositeOperation = 'source-over'; tctx.setTransform(dpr, 0, 0, dpr, 0, 0); tctx.lineWidth = 1.3; tctx.strokeStyle = 'rgba(255,255,255,.8)'; tctx.beginPath();
        const k = Math.min(dt, 0.05) * 0.028 * clamp(0.5 / z, 1, 5);
        for (const p of P) {
          const u = val('u', p.lon, p.lat), v = val('v', p.lon, p.lat);
          const x0 = sx(p.lon), y0 = sy(p.lat); p.lon += u * k / K; p.lat += v * k; p.age++;
          if (p.age > p.max || p.lon < vp.l || p.lon > vp.r || p.lat < vp.b || p.lat > vp.t) { spawn(p); p.age = 0; continue; }
          tctx.moveTo(x0, y0); tctx.lineTo(sx(p.lon), sy(p.lat));
        }
        tctx.stroke(); ctx.drawImage(trail, 0, 0, W, H);
      }
      if (layers.cloud) drawStorm(dt);
      if (layers.pres) drawPressure();
      if (layers.cyc) drawCyclones();
      if (rainMark) drawRainMark();
      drawRadar(); drawMe(); drawMarkers(); drawLabels();
    }
    /* ---------- falling rain streaks and lightning over the rainy areas ---------- */
    const DR = [], DN = 650, bolts = [];
    function spawnDrop(d) {
      if (wet.length) { const w = wet[(Math.random() * wet.length) | 0], lon = w.lon + (Math.random() - 0.5) * (w.st || 3), lat = w.lat + (Math.random() - 0.5) * (w.st || 3), pr = w.pr; { d.lon = lon; d.lat = lat; d.pr = pr; d.age = Math.random() * 0.5; d.max = 0.45 + Math.random() * 0.3; d.ox = (Math.random() - 0.5) * 14; d.oy = (Math.random() - 0.5) * 14; return true; } }
      d.max = 0; return false;
    }
    for (let i = 0; i < DN; i++) DR.push({ max: 0, age: 0 });
    let nextBolt = 1;
    let rainMark = null;
    function drawRainMark() {
      const m = rainMark; if (time > m.until) { rainMark = null; return; }
      const x0 = sx(m.from.lon), y0 = sy(m.from.lat), x1 = sx(m.to.lon), y1 = sy(m.to.lat), pu = 0.5 + 0.5 * Math.sin(time * 4);
      ctx.save(); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const ang = Math.atan2(y1 - y0, x1 - x0), len = Math.hypot(x1 - x0, y1 - y0), r = 16 + 5 * pu, ex = x1 - Math.cos(ang) * (r + 4), ey = y1 - Math.sin(ang) * (r + 4);
      if (len > r + 20) { ctx.setLineDash([9, 7]); ctx.lineDashOffset = -time * 20; ctx.strokeStyle = 'rgba(10,20,40,.9)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(ex, ey); ctx.stroke(); ctx.strokeStyle = '#7fd8ff'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(ex, ey); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = '#7fd8ff'; ctx.strokeStyle = 'rgba(10,20,40,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(ex + Math.cos(ang) * 4, ey + Math.sin(ang) * 4); ctx.lineTo(ex - Math.cos(ang) * 12 + Math.sin(ang) * 8, ey - Math.sin(ang) * 12 - Math.cos(ang) * 8); ctx.lineTo(ex - Math.cos(ang) * 12 - Math.sin(ang) * 8, ey - Math.sin(ang) * 12 + Math.cos(ang) * 8); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = 'rgba(40,140,255,' + (0.25 + 0.2 * pu).toFixed(2) + ')'; ctx.strokeStyle = '#7fd8ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x1, y1, r, 0, 7); ctx.fill(); ctx.stroke();
      ctx.font = '18px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff'; ctx.fillText('💧', x1, y1 + 1); ctx.restore();
    }
    function drawStorm(dt) {
      if (!snap || !snap.precip) return; const d0 = Math.min(dt, 0.05);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineCap = 'round';
      const zk = clamp(Math.sqrt(z), 1, 4);
      for (const d of DR) {
        d.age += d0; if (d.age > d.max && !spawnDrop(d)) continue;
        const x = sx(d.lon) + d.ox, y = sy(d.lat) + d.oy + d.age / d.max * 18, a = clamp(0.25 + d.pr * 0.1, 0, 0.75) * (1 - d.age / d.max);
        ctx.strokeStyle = 'rgba(190,225,255,' + a.toFixed(2) + ')'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 2.5, y + 6 + Math.min(d.pr, 6)); ctx.stroke();
      }
      // dark rain cloud and wet cells from the city forecasts (the 3 degree grid is too coarse for local storms)
      if (CITIES && cities) CITIES.forEach(c => { const h = cityHour(c, tm); if (!h || !(h.precip > 0.2)) return; const x = sx(c.lon), y = sy(c.lat), r = (46 + Math.min(h.precip, 10) * 4) * zk, g = ctx.createRadialGradient(x, y, 0, x, y, r); const a2 = clamp(0.5 + h.precip * 0.06, 0, 0.85); g.addColorStop(0, 'rgba(45,55,75,' + a2.toFixed(2) + ')'); g.addColorStop(1, 'rgba(45,55,75,0)'); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, 2 * r, 2 * r);
        for (let q = 0; q < 3; q++) { const t2 = (time * 1.6 + q * 0.33 + c.lon) % 1, dx = (Math.sin(q * 12.9 + c.lat) * 0.5) * r, dy0 = (Math.cos(q * 7.3 + c.lon) * 0.5) * r; for (let w = 0; w < 6; w++) { const px = x + dx * (1 + w * 0.3) - w * 3, py = y + dy0 + ((t2 + w * 0.17) % 1) * 22 - 8; ctx.strokeStyle = 'rgba(205,232,255,0.95)'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px - 4, py + 12 + Math.min(h.precip, 6) * 2); ctx.stroke(); } } });
      window.__gwStorm = { wet: wet.length, storm: storm.length, bolts: bolts.length };
      nextBolt -= d0;
      if (nextBolt <= 0) {
        nextBolt = 0.12 + Math.random() * 0.5;
        if (storm.length) { const w = storm[(Math.random() * storm.length) | 0]; bolts.push({ lon: w.lon + (Math.random() - 0.5) * 2, lat: w.lat + (Math.random() - 0.5) * 2, age: 0, seed: Math.random() * 1000 }); }
      }
      for (let i = bolts.length - 1; i >= 0; i--) {
        const b = bolts[i]; b.age += d0; if (b.age > 0.45) { bolts.splice(i, 1); continue; }
        const x = sx(b.lon), y = sy(b.lat), fl = b.age < 0.12 ? 1 : b.age < 0.2 ? 0.3 : b.age < 0.28 ? 0.8 : 0.2 * (1 - b.age);
        const g = ctx.createRadialGradient(x, y, 0, x, y, 90 * zk); g.addColorStop(0, 'rgba(255,255,255,' + (0.95 * fl).toFixed(2) + ')'); g.addColorStop(1, 'rgba(180,200,255,0)'); ctx.fillStyle = g; ctx.fillRect(x - 90 * zk, y - 90 * zk, 180 * zk, 180 * zk);
        if (b.age < 0.28) { ctx.strokeStyle = 'rgba(255,255,255,' + fl.toFixed(2) + ')'; ctx.shadowColor = 'rgba(170,200,255,1)'; ctx.shadowBlur = 14; ctx.lineWidth = 3.6; ctx.beginPath(); let px = x, py = y - 40 * zk; ctx.moveTo(px, py); for (let k = 1; k <= 8; k++) { px += Math.sin(b.seed * k) * 9; py += 10 * zk; ctx.lineTo(px, py); } ctx.stroke(); ctx.shadowBlur = 0; }
      }
    }

    // interaction
    let drag = null, moved = false;
    canvas.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, ox, oy }; moved = false; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 4) moved = true; ox = drag.ox + dx; oy = drag.oy + dy; if (moved) clearTrail(); });
    canvas.addEventListener('pointerup', e => {
      const was = drag; drag = null; if (!was || moved) return;
      const r = canvas.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      let best = null, bd = 28; markers.forEach(m => { const d = Math.hypot(m.x - x, m.y - y); if (d < bd) { bd = d; best = m; } });
      if (best && api.onCity) { api.onCity(best.id); return; }
      if (api.onPick && snap) {
        const lon = (x - ox) / z / (K * S) + M.b.x0, lat = M.b.y1 - (y - oy) / z / S;
        if (lon > -180 && lon < 180 && lat > -60 && lat < 80) { let tp = null; try { tp = val('temp', lon, lat); } catch (e2) { } api.onPick(lon, lat, tp, x, y, inArab(lon, lat) || !!wsnap); }
      }
    });
    canvas.addEventListener('wheel', e => {
      e.preventDefault(); const r = canvas.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, f = Math.exp(-e.deltaY * 0.0015);
      const nz = clamp(z * f, 0.1, 700); ox = x - (x - ox) * (nz / z); oy = y - (y - oy) * (nz / z); z = nz; clearTrail();
    }, { passive: false });

    const api = {
      setWorldGrid(g) { wgrid = g; wsnap = null; snap = null; lastRast = -1; }, worldReady: () => !!wgrid, worldLoading() { return wReq && !wgrid; }, resetWorldReq() { wReq = false; },
      rainFind(lon, lat) {
        const rad = Math.PI / 180, out = [];
        for (const dh of [0, 3, 6]) {
          let best = null;
          [grid, wgrid].forEach(G => { if (!G || !G.precip) return; const PW = G.NX * G.NY, hh = clamp(Math.round(tm) + dh, 0, G.n - 1);
            for (let j = 0; j < G.NY; j++) for (let i = 0; i < G.NX; i++) { const lo = G.LON0 + i * G.STEP, la = G.LAT0 + j * G.STEP; if (G === wgrid && inArab(lo, la)) continue; const p = G.precip[hh * PW + j * G.NX + i]; if (!(p >= 0.3)) continue;
              const dl = (lo - lon) * rad, a = Math.sin((la - lat) * rad / 2) ** 2 + Math.cos(lat * rad) * Math.cos(la * rad) * Math.sin(dl / 2) ** 2, d = 12742 * Math.asin(Math.min(1, Math.sqrt(a)));
              if (!best || d < best.d) { const y = Math.sin(dl) * Math.cos(la * rad), x = Math.cos(lat * rad) * Math.sin(la * rad) - Math.sin(lat * rad) * Math.cos(la * rad) * Math.cos(dl); best = { d, lon: lo, lat: la, pr: p, brg: (Math.atan2(y, x) / rad + 360) % 360 }; } } });
          out.push(best);
        }
        return out;
      },
      setRainMark(from, to) { rainMark = from ? { from, to, until: time + 60 } : null; },
      worldView() { return vp.world; }, onNeedWorld: null, onPick: null, onCyclones: null, cyclones: () => cy.list,
      setData(g, cityData, cityList) { grid = g; cities = cityData; CITIES = cityList; lastRast = -1; snap = null; },
      setTime(t) { tm = clamp(t, 0, grid ? grid.n - 1 : 0); },
      setLayers(l) { Object.assign(layers, l); lastRast = -1; clearTrail(); },
      layers: () => Object.assign({}, layers),
      setBase(b) { base = b; }, base: () => base, bases: () => Object.keys(BASES), attribution: () => (BASES[base] || {}).att || '',
      setMe(lat, lon) { meLL = { lat, lon }; },
      setSelected(id) { sel = id; }, setLang(l) { lang = l; },
      reset() { fit(); }, zoomTo(box) { fit(box); }, setFitBox(b) { fitBox = b; fit(); },
      tempColor: tcol, TSTOPS, frame, onCity: null
    };
    return api;
  };
})();
