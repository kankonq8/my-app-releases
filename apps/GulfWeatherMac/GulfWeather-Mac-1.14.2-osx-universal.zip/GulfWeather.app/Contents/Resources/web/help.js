/* Gulf Weather - in-app Help: ❓ button and F1. Content comes from helpdata.js (English + Arabic). by Kankon · kankon.net */
(function () {
  const A = window.GW_APP, S = window.GW_STRINGS, H = window.GW_HELP; if (!A || !H) return;
  const $ = id => document.getElementById(id), st = A.st;
  Object.assign(S.en, { helpBtn: '❓', helpTip: 'Help (F1)', helpTitle: 'Help', helpContents: 'Contents', helpSearch: 'Search the help…', helpNone: 'Nothing found. Try another word.', helpFaq: 'Questions and answers', helpTrouble: 'If something goes wrong', helpClose: 'Close', helpProblem: 'Problem', helpFix: 'What to do', helpVer: 'Guide for version {0}' });
  Object.assign(S.ar, { helpBtn: '❓', helpTip: 'المساعدة (F1)', helpTitle: 'المساعدة', helpContents: 'المحتويات', helpSearch: 'ابحث في المساعدة…', helpNone: 'لم يُعثر على شيء. جرّب كلمة أخرى.', helpFaq: 'الأسئلة الشائعة', helpTrouble: 'إذا حدثت مشكلة', helpClose: 'إغلاق', helpProblem: 'المشكلة', helpFix: 'الحل', helpVer: 'دليل الإصدار {0}' });
  const T = (k, ...a) => A.T(k, ...a), esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const css = document.createElement('style');
  css.textContent = '#helpBtn{min-width:34px}#helpOv{position:fixed;inset:0;z-index:30;display:none;background:rgba(5,10,20,.55);backdrop-filter:blur(3px);align-items:center;justify-content:center}#helpOv.show{display:flex}' +
    '#helpBox{width:min(980px,96vw);height:min(86vh,760px);display:flex;flex-direction:column;overflow:hidden;padding:0}#helpHead{display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.14)}#helpHead h2{margin:0;font-size:18px;flex:1}' +
    '#helpHead input{flex:0 1 260px;padding:7px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:inherit;font:inherit;font-size:13px}#helpHead button{padding:7px 12px;border-radius:10px;font-weight:700}' +
    '#helpBody{display:flex;flex:1;min-height:0}#helpToc{width:230px;flex:none;overflow:auto;padding:10px;border-inline-end:1px solid rgba(255,255,255,.12)}#helpToc a{display:block;padding:6px 8px;border-radius:8px;color:inherit;text-decoration:none;font-size:13px;opacity:.85;cursor:pointer}#helpToc a:hover,#helpToc a.on{background:rgba(255,255,255,.12);opacity:1}' +
    '#helpMain{flex:1;overflow:auto;padding:14px 20px 24px;font-size:14px;line-height:1.65}#helpMain h3{margin:22px 0 8px;font-size:17px;color:#ffd76a}#helpMain h3:first-child{margin-top:4px}#helpMain h4{margin:14px 0 4px;font-size:14px}#helpMain p{margin:6px 0}#helpMain ul,#helpMain ol{margin:6px 0;padding-inline-start:22px}#helpMain li{margin:3px 0}' +
    '#helpMain table{width:100%;border-collapse:collapse;margin:8px 0;font-size:13px}#helpMain th,#helpMain td{padding:6px 9px;border:1px solid rgba(255,255,255,.14);text-align:start;vertical-align:top}#helpMain th{background:rgba(255,255,255,.1)}#helpMain td:first-child{font-weight:700;white-space:nowrap}' +
    '#helpMain .tip,#helpMain .warn{margin:8px 0;padding:8px 12px;border-radius:10px;border-inline-start:4px solid}#helpMain .tip{background:rgba(80,200,120,.14);border-color:#4cc47c}#helpMain .warn{background:rgba(255,190,70,.15);border-color:#ffbe46}#helpMain .hfoot{margin-top:26px;opacity:.7;font-size:12px}' +
    '@media (max-width:760px){#helpToc{display:none}}';
  document.head.appendChild(css);
  const ov = document.createElement('div'); ov.id = 'helpOv'; ov.innerHTML = '<div class="glass" id="helpBox" role="dialog" aria-modal="true"><div id="helpHead"><h2 id="helpTitle"></h2><input id="helpQ" type="search"><button class="glass" id="helpX"></button></div><div id="helpBody"><nav id="helpToc"></nav><div id="helpMain"></div></div></div>';
  document.body.appendChild(ov);
  const L = () => (st.lang === 'ar' ? 'ar' : 'en');
  function block(b) {
    const l = L();
    if (b.type === 'p') return `<p>${esc(b[l])}</p>`;
    if (b.type === 'steps') return '<ol>' + b[l].map(x => `<li>${esc(x)}</li>`).join('') + '</ol>';
    if (b.type === 'list') return '<ul>' + b[l].map(x => `<li>${esc(x)}</li>`).join('') + '</ul>';
    if (b.type === 'tip' || b.type === 'warn') return `<div class="${b.type}">${b.type === 'tip' ? '💡 ' : '⚠️ '}${esc(b[l])}</div>`;
    if (b.type === 'table') { const r = b[l]; return '<table><thead><tr>' + r[0].map(x => `<th>${esc(x)}</th>`).join('') + '</tr></thead><tbody>' + r.slice(1).map(row => '<tr>' + row.map(x => `<td>${esc(x)}</td>`).join('') + '</tr>').join('') + '</tbody></table>'; }
    return '';
  }
  function secs() {
    const l = L(), out = H.sections.map(s => ({ id: s.id, title: s.title[l], html: s.blocks.map(block).join('') }));
    out.push({ id: 'faq', title: T('helpFaq'), html: H.faq.map(f => `<h4>${esc(f.q[l])}</h4><p>${esc(f.a[l])}</p>`).join('') });
    out.push({ id: 'trouble', title: T('helpTrouble'), html: H.troubleshooting.map(f => `<h4>${esc(f.problem[l])}</h4><p>${esc(f.fix[l])}</p>`).join('') });
    return out;
  }
  function render(q) {
    const all = secs(), qq = (q || '').trim().toLowerCase(), list = qq ? all.filter(s => (s.title + ' ' + s.html.replace(/<[^>]+>/g, ' ')).toLowerCase().includes(qq)) : all;
    $('helpTitle').textContent = '❓ ' + T('helpTitle'); $('helpQ').placeholder = T('helpSearch'); $('helpX').textContent = T('helpClose'); ov.dir = st.lang === 'ar' ? 'rtl' : 'ltr';
    $('helpToc').innerHTML = `<div style="font-size:11px;opacity:.6;margin:2px 8px 6px">${T('helpContents')}</div>` + list.map(s => `<a data-s="${s.id}">${esc(s.title)}</a>`).join('');
    $('helpMain').innerHTML = (list.length ? list.map(s => `<h3 id="hs-${s.id}">${esc(s.title)}</h3>${s.html}`).join('') : `<p>${T('helpNone')}</p>`) + `<div class="hfoot">${esc(T('byline'))} · ${esc(T('helpVer', H.version))}</div>`;
    $('helpToc').querySelectorAll('a').forEach(a => a.onclick = () => { const e = $('hs-' + a.dataset.s); if (e) $('helpMain').scrollTo({ top: e.offsetTop - 10, behavior: 'smooth' }); });
  }
  function open() { render(''); $('helpQ').value = ''; ov.classList.add('show'); $('helpMain').scrollTop = 0; }
  function close() { ov.classList.remove('show'); }
  const b = $('helpBtn'); if (b) { b.title = T('helpTip'); b.onclick = open; }
  $('helpX').onclick = close; ov.onclick = e => { if (e.target === ov) close(); }; $('helpQ').oninput = e => render(e.target.value);
  window.addEventListener('keydown', e => { if (e.key === 'F1') { e.preventDefault(); ov.classList.contains('show') ? close() : open(); } else if (e.key === 'Escape' && ov.classList.contains('show')) { close(); e.stopPropagation(); } }, true);
  const lb = $('langBtn'); if (lb) lb.addEventListener('click', () => setTimeout(() => { if (b) { b.title = T('helpTip'); } if (ov.classList.contains('show')) render($('helpQ').value); }, 60));
  window.GW_HELP_UI = { open, close };
})();
