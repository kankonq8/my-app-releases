// Kankon Markets: AI assistant. The AI key is added once in Kankon Launcher > Settings and shared by every Kankon app
// (OpenAI, Google Gemini or Anthropic Claude, whichever the user chose). This page never sees, stores or logs the key:
// the app window reads the launcher's key file fresh for every call and sends the key only to that provider.
// Every question carries a snapshot of what the app shows right now (prices, analyzer, moves, headlines),
// so answers are about real numbers. By Kankon · kankon.net
(function () {
  const OLDKEY = 'km.aikey';   // earlier versions kept their own key here; removed once a launcher key exists
  const NAMES = { openai: 'OpenAI', gemini: 'Google Gemini', anthropic: 'Anthropic Claude' };
  const DEFMODEL = { anthropic: 'claude-opus-5-5', openai: 'gpt-4.1-mini', gemini: 'gemini-2.5-flash' };
  const SYSTEM = [
    'You are the AI assistant inside Kankon Markets, a desktop app that shows live market prices, charts, a rule-based rise/fall analyzer and news headlines. The user is in Kuwait.',
    'With each question you receive a data snapshot taken from the app at that moment (JSON). Rules:',
    '- Statements about current prices, recent moves and news must come from the snapshot. If the snapshot does not contain what is needed, say so plainly instead of guessing. Never invent prices, dates or events.',
    '- Headlines are titles only. Do not claim details that are not in a title. Mention the source when you rely on a headline.',
    '- You may use general market knowledge to explain possible reasons for a move, but present them as possible reasons, not facts.',
    '- Do not give buy or sell instructions or certain price targets. If asked whether to buy or sell, explain the factors and risks in the data and say that this is not financial advice.',
    '- Be concise: short paragraphs or a few bullet points, under about 250 words unless the user asks for more. Use plain text with simple Markdown only (**bold** and "- " bullets).',
    '- Prices are in the currency field of each market (USD when not stated). Kuwait / Gulf stocks are in KWD, SAR, AED or QAR; Boursa Kuwait prices are already converted from fils to dinars.',
    '- The snapshot may include my_portfolio (what the user owns, valued in KWD) and my_price_alerts. Use them when relevant.',
    '- For a daily brief (daily_brief_data present): start with one line on the overall mood, then one short bullet per market with its move today (and this week when given), then my portfolio change if present, then the 3 most important headlines with their source, then what to watch next. Keep it under about 300 words.',
    '- Reply in clear Modern Standard Arabic when the snapshot says the app language is Arabic or the user writes in Arabic; otherwise reply in English. Write numbers with Western digits.',
  ].join('\n');

  // Saved chats: every conversation is kept on this computer with the date and time of each message.
  const CHATS = 'km.chats', CUR = 'km.chatCur', MAXCHATS = 200;
  const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const store = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  let chats = load(CHATS, []);                 // [{id, t, u, market, msgs:[{role, content, shown, t, err}]}]
  let cur = chats.find(c => c.id === load(CUR, '')) || null;
  let hist = cur ? cur.msgs : [];
  let showHist = false;
  function save() {
    if (!hist.length) return;
    if (!cur) { cur = { id: 'c' + Date.now(), t: Date.now(), market: ctx.name(), msgs: hist }; chats.unshift(cur); }
    cur.u = Date.now();
    chats.sort((a, b) => (b.u || b.t) - (a.u || a.t));
    if (chats.length > MAXCHATS) chats = chats.slice(0, MAXCHATS);
    store(CHATS, chats); store(CUR, cur.id);
  }
  function newChat() { cur = null; hist = []; store(CUR, ''); showHist = false; render(); }
  function openChat(id) { const c = chats.find(x => x.id === id); if (!c) return; cur = c; hist = c.msgs; store(CUR, id); showHist = false; render(); }
  function delChat(id) { chats = chats.filter(x => x.id !== id); store(CHATS, chats); if (cur && cur.id === id) { cur = null; hist = []; store(CUR, ''); } render(); }
  const when = t => t ? new Date(t).toLocaleString(ctx.loc(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
  let busy = false;
  let ctx = null;  // { lang, T, nameOf, snapshot() }
  const $ = id => document.getElementById(id);
  let info = { has: false, provider: '' }, known = false;   // what the launcher's key file says (never the key itself)
  function sync() {
    return KMNative.aiInfo().then(i => {
      const ch = !known || i.has !== info.has || i.provider !== info.provider;
      info = i; known = true;
      if (i.has) { try { localStorage.removeItem(OLDKEY); } catch (e) { } }
      if (ch && ctx) render();
      return i;
    });
  }

  // ---- providers: which model, how to ask, how to read the answer ----
  const verOf = id => { const m = id.match(/(\d+)(?:[.-](\d))?(?!\d)/); return m ? +m[1] + (m[2] ? +m[2] / 10 : 0) : 0; };
  const best = a => a.slice().sort((x, y) => verOf(y) - verOf(x))[0];
  const isText = (p, id) => p === 'openai' ? /^(gpt-[4-9]|o[1-9]|chatgpt)/.test(id) && !/audio|realtime|transcribe|tts|search|image|codex|instruct|embedding/.test(id)
    : p === 'gemini' ? id.startsWith('gemini') && !/image|tts|embedding|audio|live|veo|imagen/.test(id) : id.startsWith('claude');
  function pickModel(p, ids) {
    let t = ids.filter(m => isText(p, m) && !/\d{4}-\d{2}-\d{2}|preview|exp|-\d{3}$/.test(m));
    if (!t.length) t = ids.filter(m => isText(p, m));
    if (p === 'openai') return best(t.filter(m => m.startsWith('gpt-') && m.endsWith('-mini') && !m.includes('nano'))) || best(t.filter(m => m.startsWith('gpt-'))) || DEFMODEL.openai;
    if (p === 'gemini') return best(t.filter(m => /^gemini-[\d.]+-flash$/.test(m))) || best(t.filter(m => m.includes('flash') && !m.includes('lite'))) || DEFMODEL.gemini;
    return ids.includes('claude-opus-5-5') ? 'claude-opus-5-5' : t.find(m => m.startsWith('claude-opus')) || t[0] || DEFMODEL.anthropic;
  }
  // the model is looked up once a week from the provider's own list (so it never goes out of date)
  async function getModel(p, force) {
    const c = load('km.aimodel', {}), e = c[p];
    if (!force && e && Date.now() - e.t < 7 * 864e5) return e.m;
    let m = DEFMODEL[p];
    try {
      const r = await KMNative.ai(p, 'models', '', '');
      if (r.status === 200) {
        const j = JSON.parse(r.body);
        const ids = p === 'gemini' ? (j.models || []).filter(x => (x.supportedGenerationMethods || []).includes('generateContent')).map(x => String(x.name).replace('models/', '')) : (j.data || []).map(x => x.id);
        if (ids.length) m = pickModel(p, ids);
      }
    } catch (e) { }
    c[p] = { m, t: Date.now() }; store('km.aimodel', c);
    return m;
  }
  function buildBody(p, model, messages) {
    if (p === 'openai') return JSON.stringify({ model, max_completion_tokens: 4000, messages: [{ role: 'system', content: SYSTEM }].concat(messages) });
    if (p === 'gemini') return JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })), generationConfig: { maxOutputTokens: 8000 } });
    return JSON.stringify({ model, max_tokens: 16000, system: SYSTEM, messages });
  }
  function parseReply(p, j) {   // -> { text, cut, refused }
    if (p === 'openai') {
      const c = j && j.choices && j.choices[0], m = (c && c.message) || {};
      return { text: String(m.content || '').trim(), cut: !!c && c.finish_reason === 'length', refused: !!m.refusal || (!!c && c.finish_reason === 'content_filter') };
    }
    if (p === 'gemini') {
      const c = j && j.candidates && j.candidates[0];
      const text = c && c.content && c.content.parts ? c.content.parts.map(x => x.text || '').join('').trim() : '';
      const fr = (c && c.finishReason) || '';
      return { text, cut: fr === 'MAX_TOKENS', refused: !text && (!!(j && j.promptFeedback && j.promptFeedback.blockReason) || /SAFETY|PROHIBITED|BLOCKLIST|SPII/.test(fr)) };
    }
    return { text: j && Array.isArray(j.content) ? j.content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim() : '', cut: !!j && j.stop_reason === 'max_tokens', refused: !!j && j.stop_reason === 'refusal' };
  }
  // one question to the provider named in the launcher's file; retried once with a fresh model if the model was not found
  async function call(p, messages) {
    let model = await getModel(p);
    let r = await KMNative.ai(p, 'chat', model, buildBody(p, model, messages));
    if (r.status === 404 || (r.status === 400 && /model/i.test(r.body))) {
      model = await getModel(p, true);
      r = await KMNative.ai(p, 'chat', model, buildBody(p, model, messages));
    }
    return r;
  }
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // tiny Markdown: **bold**, "- " bullets, paragraphs
  function md(s) {
    const lines = esc(s).split('\n');
    let html = '', list = false;
    lines.forEach(l => {
      const b = l.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
      const m = b.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
      if (m) { if (!list) { html += '<ul>'; list = true; } html += `<li>${m[1]}</li>`; return; }
      if (list) { html += '</ul>'; list = false; }
      const h = b.replace(/^#{1,4}\s+/, '');
      if (h.trim()) html += `<p>${h}</p>`;
    });
    if (list) html += '</ul>';
    return html;
  }

  function render() {
    const t = ctx.T();
    $('aiSetup').hidden = !known || info.has; $('aiChat').hidden = !known || !info.has;
    $('aiGuide').href = 'https://kankon.net/#/help/launcher/ai-key' + (document.documentElement.lang === 'ar' ? '?lang=ar' : '');
    if (!info.has) return;
    $('aiFootT').textContent = t.aiFoot.replace('{p}', NAMES[info.provider] || '');
    const box = $('aiMsgs');
    $('aiChat').classList.toggle('hist', showHist);
    $('aiHist').textContent = showHist ? t.aiBack : t.aiHistBtn;
    if (showHist) {
      box.innerHTML = `<div class="hh">${esc(t.aiHistTitle)}</div>` + (chats.length ? chats.map(c => {
        const first = (c.msgs.find(m => m.role === 'user') || {}).shown || '';
        return `<div class="hi ${cur && cur.id === c.id ? 'on' : ''}" data-open="${c.id}"><div class="ht" dir="auto">${esc(first.length > 70 ? first.slice(0, 70) + '…' : first)}</div><small>${esc(c.market || '')} · ${esc(when(c.t))} · ${esc(t.aiCount.replace('{n}', c.msgs.length))}</small><button class="hx" data-del="${c.id}" title="${esc(t.aiDel)}">×</button></div>`;
      }).join('') : `<p class="small">${esc(t.aiHistNone)}</p>`);
      box.scrollTop = 0;
      return;
    }
    const msgs = hist.map(m => m.role === 'user'
      ? `<div class="msg me" dir="auto">${esc(m.shown || m.content)}<div class="mt">${esc(when(m.t))}</div></div>`
      : `<div class="msg bot ${m.err ? 'err' : ''}" dir="auto">${m.err ? esc(m.content) : md(m.content)}<div class="mt">${esc(when(m.t))}</div></div>`).join('');
    box.innerHTML = (hist.length ? '' : `<div class="msg bot hello">${esc(t.aiHello.replace('{name}', ctx.name()))}</div>`) + msgs + (busy ? `<div class="msg bot wait"><i></i><i></i><i></i> ${esc(t.aiThinking)}</div>` : '');
    box.scrollTop = box.scrollHeight;
    $('aiChips').innerHTML = t.aiChips.map((c, i) => `<button data-chip="${i}">${esc(c.replace('{name}', ctx.name()))}</button>`).join('');
    $('aiSend').disabled = busy;
    $('aiBrief').disabled = busy;
    $('aiBriefAuto').checked = !!load('km.briefAuto', false);
  }

  // Daily brief: one answer that sums up all my markets (today's moves, headlines, my portfolio and alerts).
  async function brief(auto) {
    if (busy) return;
    await sync(); if (!info.has) return;
    const t = ctx.T();
    newChat(); busy = true; render();
    let data = null;
    try { data = await ctx.briefData(); } catch (e) { }
    busy = false;
    store('km.briefDay', new Date().toDateString());
    ask(t.aiBriefQ, (auto ? '☀️ ' : '') + t.aiBriefShown, data);
  }
  async function maybeAuto() {
    if (!load('km.briefAuto', false) || load('km.briefDay', '') === new Date().toDateString() || new Date().getHours() < 5) return;
    await sync(); if (!info.has) return;
    brief(true);
  }

  function errText(status, body) {
    const t = ctx.T();
    let msg = '';
    try { const j = JSON.parse(body); msg = (j.error && (j.error.message || (typeof j.error === 'string' ? j.error : ''))) || ''; } catch (e) { }
    if (status === 9001) return t.aiNoKey;
    if (status === 0) return t.aiErrNet;
    if (status === 401 || status === 403 || (status === 400 && /api.?key/i.test(msg))) return t.aiErrKey;
    if (/credit|quota|billing|insufficient|balance/i.test(msg)) return t.aiErrCredit;
    if (status === 429) return t.aiErrLimit;
    if (status >= 500) return t.aiErrBusy;
    return t.aiErrOther + (msg ? ' (' + msg + ')' : ' (HTTP ' + status + ')');
  }

  async function ask(q, shown, extra) {
    q = (q || '').trim(); if (!q || busy) return;
    busy = true;
    await sync();   // the launcher's key file, read fresh before every call
    if (!info.has) { busy = false; render(); return; }
    let snap = {};
    try { snap = ctx.snapshot(); } catch (e) { }
    if (extra) snap.daily_brief_data = extra;
    const prior = hist.filter(m => !m.err).slice(-8).map(m => ({ role: m.role, content: m.content }));
    // keep the history starting with a user turn
    while (prior.length && prior[0].role !== 'user') prior.shift();
    hist.push({ role: 'user', content: q, shown: shown || q, t: Date.now() });
    save(); busy = true; render();
    const messages = prior.concat([{ role: 'user', content: 'App data snapshot (JSON):\n' + JSON.stringify(snap) + '\n\nQuestion: ' + q }]);
    const mine = hist;
    let r = await call(info.provider, messages);
    if (r.status === 9002) { await sync(); r = info.has ? await call(info.provider, messages) : { status: 9001, body: '' }; }   // the provider was changed in the launcher
    busy = false;
    const add = m => { m.t = Date.now(); mine.push(m); };
    if (r.status === 200) {
      let j = null; try { j = JSON.parse(r.body); } catch (e) { }
      const o = parseReply(info.provider, j);
      if (o.refused) add({ role: 'assistant', content: ctx.T().aiRefused, err: true });
      else if (!o.text) add({ role: 'assistant', content: ctx.T().aiErrOther, err: true });
      else add({ role: 'assistant', content: o.text + (o.cut ? '\n\n' + ctx.T().aiCut : '') });
    } else {
      add({ role: 'assistant', content: errText(r.status, r.body), err: true });
    }
    if (r.status === 9001) sync();
    save(); render();
  }

  function init(c) {
    ctx = c;
    $('aiClear').onclick = newChat;
    $('aiBrief').onclick = () => brief(false);
    $('aiBriefAuto').onchange = e => store('km.briefAuto', e.target.checked);
    $('aiHist').onclick = () => { showHist = !showHist; render(); };
    window.addEventListener('focus', sync);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
    $('aiMsgs').onclick = e => {
      const d = e.target.dataset.del; if (d) { delChat(d); e.stopPropagation(); return; }
      const el = e.target.closest('[data-open]'); if (el) openChat(el.dataset.open);
    };
    $('aiSend').onclick = () => { const q = $('aiQ').value; $('aiQ').value = ''; ask(q); };
    $('aiQ').onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('aiSend').onclick(); } };
    $('aiChips').onclick = e => { const i = e.target.dataset.chip; if (i != null) { const s = ctx.T().aiChips[i].replace('{name}', ctx.name()); ask(s, s); } };
    render(); sync();
  }

  window.KMAI = { init, render, ask, brief, maybeAuto, hasKey: () => info.has, provider: () => info.provider };
})();
