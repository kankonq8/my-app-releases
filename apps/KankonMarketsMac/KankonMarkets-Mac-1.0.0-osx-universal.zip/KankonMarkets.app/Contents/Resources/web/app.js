// Kankon Markets: the screen. By Kankon · kankon.net
(function () {
  const $ = id => document.getElementById(id);
  const LS = { get: (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const FIRST = ['gold', 'silver', 'btc', 'kec', 'wti'];
  const DEFAULT_WATCH = FIRST.concat(KM_CATALOG.filter(a => !a.extra && !FIRST.includes(a.id)).map(a => a.id));
  const PERIODS = ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y'];
  const st = {
    lang: LS.get('km.lang', 'en'), watch: LS.get('km.watch', DEFAULT_WATCH), custom: LS.get('km.custom', []),
    sel: LS.get('km.sel', 'gold'), period: LS.get('km.period', '1M'), mode: LS.get('km.mode', 'candle'), ma: LS.get('km.ma', true),
    cat: 'all', quotes: {}, series: null, daily: null, ok: null, at: 0, ready: false,
  };
  const T = () => KM_T[st.lang];
  const all = () => KM_CATALOG.concat(st.custom);
  const byId = id => all().find(a => a.id === id);
  const nameOf = a => (a[st.lang] || a.en)[0], subOf = a => (a[st.lang] || a.en)[1];
  const isUsd = a => a.cat !== 'fx' && a.cat !== 'indices' && a.cat !== 'custom';
  const nf = (v, dp) => isFinite(v) ? v.toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp }) : '—';
  const autoDp = v => v >= 1000 ? 2 : v >= 10 ? 2 : v >= 1 ? 3 : 5;
  const fmtA = (a, v) => (isUsd(a) ? '$' : '') + nf(v, a.dp != null ? a.dp : autoDp(v));
  const sign = v => (v > 0 ? '+' : v < 0 ? '−' : '');
  const cls = v => v > 0 ? 'up' : v < 0 ? 'dn' : 'flat';
  const loc = () => st.lang === 'ar' ? 'ar-KW-u-nu-latn' : 'en-GB';

  // ---------- language ----------
  function applyLang() {
    const t = T();
    document.documentElement.lang = st.lang; document.documentElement.dir = st.lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-t]').forEach(e => { e.textContent = t[e.dataset.t]; });
    $('l-en').className = st.lang === 'en' ? 'on' : ''; $('l-ar').className = st.lang === 'ar' ? 'on' : '';
    $('q').placeholder = t.search;
    $('gl').innerHTML = t.gauge.map(s => `<span>${s}</span>`).join('');
  }
  function setLang(l) { st.lang = l; LS.set('km.lang', l); applyLang(); renderAll(); }

  // ---------- watchlist ----------
  function renderCats() {
    $('cats').innerHTML = KM_CATS.map(c => `<button data-c="${c}" class="${st.cat === c ? 'on' : ''}">${T().cats[c]}</button>`).join('');
  }
  function quoteOf(a) {
    const q = st.quotes[a.id]; if (!q) return null;
    const ch = q.price - q.prev, pct = q.prev ? ch / q.prev * 100 : NaN;
    return { price: q.price, ch, pct, spark: q.candles.map(c => c.c) };
  }
  function renderList() {
    const t = T();
    const ids = st.watch.filter(id => byId(id) && (st.cat === 'all' || byId(id).cat === st.cat));
    let html = '', lastCat = '';
    ids.forEach(id => {
      const a = byId(id), q = quoteOf(a);
      if (st.cat === 'all' && a.cat !== lastCat && a.cat !== 'custom') { /* grouped by order; no headers to keep the list compact */ }
      lastCat = a.cat;
      html += `<div class="asset ${st.sel === id ? 'sel' : ''}" data-id="${id}">
        <div class="ic" style="color:${a.col};background:${a.col}22">${a.ic}</div>
        <div class="nm"><b>${nameOf(a)}</b><small>${subOf(a)}</small></div>
        <canvas data-sp="${id}"></canvas>
        <div class="pr"><b>${q ? fmtA(a, q.price) : '…'}</b><small class="${q ? cls(q.ch) : ''}">${q && isFinite(q.pct) ? sign(q.pct) + Math.abs(q.pct).toFixed(2) + '%' : ''}</small></div>
        <button class="rm" data-rm="${id}" title="${t.remove}">×</button></div>`;
    });
    $('list').innerHTML = html;
    ids.forEach(id => { const q = quoteOf(byId(id)); const c = document.querySelector(`canvas[data-sp="${id}"]`); if (q && c) KMSpark(c, q.spark, q.ch >= 0); });
  }

  // ---------- selected market ----------
  const tfmt = t => {
    const d = new Date(t);
    if (st.period === '1D') return d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
    if (st.period === '1W') return d.toLocaleDateString(loc(), { weekday: 'short' }) + ' ' + d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
    if (st.period === '5Y') return d.toLocaleDateString(loc(), { month: 'short', year: 'numeric' });
    return d.toLocaleDateString(loc(), { day: 'numeric', month: 'short' });
  };
  function renderHead() {
    const a = byId(st.sel), t = T(); if (!a) return;
    $('aName').textContent = nameOf(a); $('aSub').textContent = subOf(a);
    $('aIc').textContent = a.ic; $('aIc').style.cssText = `color:${a.col};background:${a.col}22`;
    const q = quoteOf(a) || (st.series && { price: st.series.price, ch: st.series.price - st.series.prev, pct: (st.series.price / st.series.prev - 1) * 100 });
    $('aPrice').textContent = q ? fmtA(a, q.price) : '—';
    $('aChg').className = 'chg ' + (q ? cls(q.ch) : '');
    $('aChg').textContent = q && isFinite(q.ch) ? `${sign(q.ch)}${nf(Math.abs(q.ch), a.dp != null ? a.dp : autoDp(q.price))} (${sign(q.pct)}${Math.abs(q.pct).toFixed(2)}%)` : '';
    const s = st.quotes[a.id] || st.series;
    $('aTime').textContent = s && s.time ? `${t.vsPrev} · ${new Date(s.time).toLocaleString(loc(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}${s.exchange ? ' · ' + s.exchange : ''}` : '';
    $('tfs').innerHTML = PERIODS.map(p => `<button class="tf ${st.period === p ? 'on' : ''}" data-p="${p}">${p}</button>`).join('');
    document.querySelector('.ctrls').style.visibility = a.src === 'oil' ? 'hidden' : '';
    document.querySelector('.legend').style.display = a.src === 'oil' ? 'none' : '';
    $('mCandle').className = 'tf' + (st.mode === 'candle' ? ' on' : ''); $('mLine').className = 'tf' + (st.mode === 'line' ? ' on' : ''); $('mMa').className = 'tf' + (st.ma ? ' on' : '');
    // stats from today's candles + the year
    const d1 = st.quotes[a.id], yr = st.daily;
    const dc = d1 && d1.candles.length ? d1.candles : [];
    const open = dc.length ? dc[0].o : NaN;
    const hi = d1 && isFinite(d1.dayHigh) ? d1.dayHigh : dc.length ? Math.max(...dc.map(c => c.h)) : NaN;
    const lo = d1 && isFinite(d1.dayLow) ? d1.dayLow : dc.length ? Math.min(...dc.map(c => c.l)) : NaN;
    const ys = yr && yr.candles && yr.candles.length ? yr.candles : [];
    const h52 = ys.length ? Math.max(...ys.map(c => c.h)) : NaN, l52 = ys.length ? Math.min(...ys.map(c => c.l)) : NaN;
    const v = [[t.open, fmtA(a, open)], [t.high, fmtA(a, hi)], [t.low, fmtA(a, lo)], [t.prevClose, fmtA(a, d1 ? d1.prev : NaN)], [t.range52, isFinite(h52) ? fmtA(a, l52) + ' – ' + fmtA(a, h52) : '—']];
    if (a.src === 'oil') { v[0][1] = v[1][1] = v[2][1] = '—'; }
    $('stats').innerHTML = v.map(([k, x]) => `<div class="st"><small>${k}</small><b>${x}</b></div>`).join('');
    let src = a.src === 'oil' ? `${t.src.oil} <span class="warn">${t.kecNote}</span>` : t.src.y;
    if (st.series && st.series.stale) src = `<span class="warn">${t.offline}</span> · ` + src;
    $('src').innerHTML = src;
  }
  function renderChart() {
    const a = byId(st.sel), t = T(), s = st.series;
    const an = st.analysis;
    // For 1M to 6M, take the 20/50-day averages from the year of daily prices, so the lines cover the whole chart.
    let m20 = null, m50 = null;
    if (s && st.daily && ['1M', '3M', '6M'].includes(st.period) && a.src !== 'oil') {
      const dc = st.daily.candles, day = t => new Date(t).toISOString().slice(0, 10), map = {};
      dc.forEach((x, i) => { map[day(x.t)] = [i >= 19 ? KMAnalyzer.sma(dc.map(c => c.c), 20, i + 1) : NaN, i >= 49 ? KMAnalyzer.sma(dc.map(c => c.c), 50, i + 1) : NaN]; });
      m20 = s.candles.map(x => (map[day(x.t)] || [NaN])[0]); m50 = s.candles.map(x => (map[day(x.t)] || [NaN, NaN])[1]);
    }
    chart.set(s ? s.candles : [], {
      m20, m50, line: st.mode === 'line' || a.src === 'oil', dots: a.src === 'oil', ma: st.ma && a.src !== 'oil', fmt: v => fmtA(a, v), tfmt, empty: s ? '' : (st.loadErr ? t.noData : t.loading),
      sup: an && an.enough ? an.sup : NaN, res: an && an.enough ? an.res : NaN,
      tip: (x, m20, m50) => {
        const d = new Date(x.t), when = ['1D', '1W', '1M'].includes(st.period) ? d.toLocaleString(loc(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString(loc(), { day: 'numeric', month: 'short', year: 'numeric' });
        return `<b>${when}</b><br>${t.open} ${fmtA(a, x.o)} · ${t.high} ${fmtA(a, x.h)}<br>${t.low} ${fmtA(a, x.l)} · <b>${fmtA(a, x.c)}</b>` + (st.ma && isFinite(m20) ? `<br><span style="color:#f5c542">MA20 ${fmtA(a, m20)}</span>` : '') + (st.ma && isFinite(m50) ? ` · <span style="color:#b06cff">MA50 ${fmtA(a, m50)}</span>` : '');
      },
    });
  }
  function renderAnalysis() {
    const a = byId(st.sel), t = T(), an = st.analysis;
    const fmt = v => fmtA(a, v);
    if (!an) { $('badge').textContent = '…'; $('badge').className = 'badge'; $('rows').innerHTML = ''; $('an').innerHTML = `<p>${st.loadErr ? t.noData : t.loading}</p>`; $('needle').style.left = '50%'; }
    else {
      const paras = KMAnalyzer.write(an, nameOf(a), st.lang, fmt);
      $('an').innerHTML = [].concat(paras).map(p => `<p>${p}</p>`).join('');
      $('rows').hidden = !an.enough;
      if (!an.enough) { $('badge').textContent = t.na; $('badge').className = 'badge'; $('rows').innerHTML = ''; $('needle').style.left = '50%'; }
      else {
        $('badge').textContent = t.labels[an.label]; $('badge').className = 'badge ' + (an.score >= 15 ? 'up' : an.score <= -15 ? 'dn' : '');
        $('needle').style.left = (50 + an.score / 2) + '%';
        const rows = [
          [t.trend, an.trend >= 0 ? t.trendUp : t.trendDown, an.trend >= 0 ? 'up' : 'dn'],
          [t.rsi, an.rsi.toFixed(1), an.rsi >= 70 ? 'dn' : an.rsi <= 30 ? 'up' : ''],
          [t.ma50, isFinite(an.m50) ? (an.p > an.m50 ? t.above : t.below) : t.na, isFinite(an.m50) ? (an.p > an.m50 ? 'up' : 'dn') : ''],
          [t.ma200, isFinite(an.m200) ? (an.p > an.m200 ? t.above : t.below) : t.na, isFinite(an.m200) ? (an.p > an.m200 ? 'up' : 'dn') : ''],
          [t.support, fmt(an.sup), ''], [t.resistance, isFinite(an.res) ? fmt(an.res) : t.na, ''],
          [t.macd, an.macd > an.signal ? t.positive : t.negative, an.macd > an.signal ? 'up' : 'dn'],
        ];
        $('rows').innerHTML = rows.map(([k, v, c]) => `<div class="row"><span>${k}</span><b class="${c}">${v}</b></div>`).join('');
      }
    }
    // Gold in Kuwait per gram (KWD), from the world gold price and USD/KWD.
    const g = st.quotes.gold, k = st.quotes.kwd;
    const show = st.sel === 'gold' && g && k && isFinite(g.price) && isFinite(k.price);
    $('kwGold').hidden = !show;
    if (show) {
      const g24 = g.price / 31.1034768 * k.price;
      $('karats').innerHTML = [['k24', 1], ['k22', 22 / 24], ['k21', 21 / 24], ['k18', 18 / 24]].map(([n, f]) => `<div><small>${t[n]}</small><b>${nf(g24 * f, 3)} KWD</b></div>`).join('');
    }
  }
  function renderStatus() {
    const t = T();
    const s = $('status');
    if (st.ok === null) { s.className = 'pill'; s.textContent = t.loading; }
    else if (st.ok) { s.className = 'pill live'; s.textContent = t.live; }
    else { s.className = 'pill off'; s.textContent = t.offline; }
    $('upd').textContent = st.at ? `${t.updated} ${new Date(st.at).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' })}` : '';
  }
  function renderAll() { renderCats(); renderList(); renderHead(); renderChart(); renderAnalysis(); renderStatus(); }

  // ---------- loading ----------
  async function pool(items, n, fn) { const q = items.slice(); await Promise.all(Array.from({ length: n }, async () => { while (q.length) await fn(q.shift()); })); }
  async function loadQuotes() {
    const ids = Array.from(new Set(st.watch.concat(['gold', 'kwd']))).filter(byId);
    let good = 0, bad = 0;
    await pool(ids, 5, async id => {
      try { const d = await KMNet.series(byId(id), '1D'); st.quotes[id] = d; d.stale ? bad++ : good++; } catch (e) { bad++; }
    });
    st.ok = good > 0; st.at = Date.now();
    renderList(); renderHead(); renderStatus(); if (st.sel === 'gold') renderAnalysis();
  }
  let loadSeq = 0;
  async function loadSelected() {
    const my = ++loadSeq, a = byId(st.sel);
    if (!a) return;
    st.loadErr = false;
    const cachedS = KMNet.cached(a, a.src === 'oil' ? '1D' : st.period), cachedD = KMNet.cached(a, a.src === 'oil' ? '1D' : '1Y');
    st.series = cachedS; st.daily = cachedD; st.analysis = cachedD ? KMAnalyzer.analyze(cachedD.candles) : null;
    renderHead(); renderChart(); renderAnalysis();
    try {
      const [s, d] = await Promise.all([KMNet.series(a, a.src === 'oil' ? '1D' : st.period), KMNet.series(a, a.src === 'oil' ? '1D' : '1Y')]);
      if (my !== loadSeq) return;
      st.series = s; st.daily = d; st.analysis = KMAnalyzer.analyze(d.candles);
      if (!st.quotes[a.id] && s) st.quotes[a.id] = s;
    } catch (e) { if (my !== loadSeq) return; if (!st.series) st.loadErr = true; }
    renderHead(); renderChart(); renderAnalysis();
    st.ready = true;
  }
  function select(id) { st.sel = id; LS.set('km.sel', id); renderList(); loadSelected(); }

  // ---------- add / remove ----------
  function renderModal() {
    const t = T(), q = $('q').value.trim().toLowerCase();
    const items = all().filter(a => !q || (a.en[0] + ' ' + a.en[1] + ' ' + a.ar[0] + ' ' + (a.sym || '')).toLowerCase().includes(q));
    $('mlist').innerHTML = items.map(a => `<div class="mi"><div class="ic" style="color:${a.col};background:${a.col}22">${a.ic}</div><div class="nm"><b>${nameOf(a)}</b><small>${subOf(a)} · ${T().cats[a.cat] || ''}</small></div>${st.watch.includes(a.id) ? `<span class="in">✓ ${t.added}</span>` : `<button data-add="${a.id}">${t.addBtn}</button>`}</div>`).join('');
  }
  function addWatch(id) { if (!st.watch.includes(id)) { st.watch.push(id); LS.set('km.watch', st.watch); } renderModal(); renderList(); loadQuotes(); }
  async function addCustom() {
    const sym = $('cSym').value.trim().toUpperCase(); $('cErr').textContent = '';
    if (!/^[A-Z0-9^=.\-]{1,20}$/.test(sym)) { $('cErr').textContent = T().notFound; return; }
    const id = 'c:' + sym;
    if (byId(id)) { addWatch(id); return; }
    const a = { id, sym, cat: 'custom', ic: sym.replace(/[^A-Z0-9]/g, '').slice(0, 3), col: '#a9b6d8', en: [sym, 'Yahoo Finance'], ar: [sym, 'Yahoo Finance'] };
    try {
      const d = await KMNet.series(a, '1D');
      if (!d.candles.length && !isFinite(d.price)) throw new Error('empty');
      a.en[1] = a.ar[1] = (d.exchange || 'Yahoo Finance') + (d.currency ? ' · ' + d.currency : '');
      st.custom.push(a); LS.set('km.custom', st.custom); st.quotes[id] = d; $('cSym').value = ''; addWatch(id);
    } catch (e) { $('cErr').textContent = T().notFound; }
  }

  // ---------- events ----------
  const chart = KMChart($('cv'), $('tip'));
  $('l-en').onclick = () => setLang('en'); $('l-ar').onclick = () => setLang('ar');
  $('refresh').onclick = () => { loadQuotes(); loadSelected(); };
  $('cats').onclick = e => { const c = e.target.dataset.c; if (c) { st.cat = c; renderCats(); renderList(); } };
  $('list').onclick = e => {
    const rm = e.target.dataset.rm;
    if (rm) { st.watch = st.watch.filter(x => x !== rm); LS.set('km.watch', st.watch); if (st.sel === rm && st.watch.length) select(st.watch[0]); renderList(); e.stopPropagation(); return; }
    const el = e.target.closest('.asset'); if (el) select(el.dataset.id);
  };
  $('tfs').onclick = e => { const p = e.target.dataset.p; if (p) { st.period = p; LS.set('km.period', p); loadSelected(); } };
  $('mCandle').onclick = () => { st.mode = 'candle'; LS.set('km.mode', st.mode); renderHead(); renderChart(); };
  $('mLine').onclick = () => { st.mode = 'line'; LS.set('km.mode', st.mode); renderHead(); renderChart(); };
  $('mMa').onclick = () => { st.ma = !st.ma; LS.set('km.ma', st.ma); renderHead(); renderChart(); };
  $('addBtn').onclick = () => { $('modal').hidden = false; $('q').value = ''; renderModal(); $('q').focus(); };
  $('mClose').onclick = () => { $('modal').hidden = true; };
  $('modal').onclick = e => { if (e.target.id === 'modal') $('modal').hidden = true; };
  $('q').oninput = renderModal;
  $('mlist').onclick = e => { const id = e.target.dataset.add; if (id) addWatch(id); };
  $('cAdd').onclick = addCustom; $('cSym').onkeydown = e => { if (e.key === 'Enter') addCustom(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') $('modal').hidden = true; });

  // ---------- start ----------
  if (!byId(st.sel)) st.sel = 'gold';
  if (!PERIODS.includes(st.period)) st.period = '1M';
  applyLang(); renderAll();
  // show the last saved prices at once, then load fresh ones
  st.watch.concat(['gold', 'kwd']).forEach(id => { const a = byId(id); const c = a && KMNet.cached(a, '1D'); if (c) st.quotes[id] = c; });
  renderList();
  loadQuotes(); loadSelected();
  setInterval(loadQuotes, 60000);
  setInterval(() => { if (!document.hidden && ['1D', '1W'].includes(st.period)) loadSelected(); }, 120000);
  window.KM_APP = { st, setLang, select, setPeriod: p => { st.period = p; loadSelected(); } };
})();
