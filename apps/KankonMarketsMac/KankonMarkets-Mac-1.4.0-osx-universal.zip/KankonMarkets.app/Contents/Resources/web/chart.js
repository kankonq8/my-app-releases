// Kankon Markets: price chart on a canvas. Candles or line, 20/50 averages, Bollinger Bands, support/resistance,
// RSI / MACD / volume panes, your own drawn lines, comparing two markets, crosshair. By Kankon · kankon.net
(function () {
  // Colours for the dark and the light theme (body.light).
  const DARK = { grid: '#1a2444', axis: '#6f7ea8', up: '#3ddc97', dn: '#ff5d73', ma20: '#f5c542', ma50: '#b06cff', line: '#4f8bff', sup: '#3ddc97', res: '#ff5d73', cross: '#8ea0cc', bb: '#5ad1e8', draw: '#ffb547', cmp: '#ff8fd0', sep: '#24305a', dot: '#fff', tag: '#0b1020' };
  const LIGHT = { grid: '#e6ebf3', axis: '#66729a', up: '#13a86b', dn: '#e0354f', ma20: '#d39a00', ma50: '#8a4de0', line: '#2f6bff', sup: '#13a86b', res: '#e0354f', cross: '#8a93ab', bb: '#139bb5', draw: '#e08a00', cmp: '#d63f9c', sep: '#d5dceb', dot: '#18213a', tag: '#ffffff' };
  const pal = () => document.body.classList.contains('light') ? LIGHT : DARK;
  function KMChart(canvas, tip) {
    const ctx = canvas.getContext('2d');
    let data = [], opt = {}, hover = -1, pend = null, mouse = null, geo = null;
    const C = {};
    const PADR = 74, PADT = 14, PADB = 28, PADL = 10;
    function size() { const r = canvas.getBoundingClientRect(), d = window.devicePixelRatio || 1; canvas.width = Math.max(1, r.width * d); canvas.height = Math.max(1, r.height * d); ctx.setTransform(d, 0, 0, d, 0, 0); return r; }
    function maArr(n, a) { a = a || data.map(x => x.c); const out = []; let s = 0; a.forEach((v, i) => { s += v; if (i >= n) s -= a[i - n]; out.push(i >= n - 1 ? s / n : NaN); }); return out; }
    function emaArr(a, n) { const k = 2 / (n + 1); let e = NaN; return a.map((v, i) => (e = i ? v * k + e * (1 - k) : v)); }
    function bbArr() { const c = data.map(x => x.c), m = maArr(20, c); return m.map((mid, i) => { if (!isFinite(mid)) return [NaN, NaN, NaN]; let s = 0; for (let j = i - 19; j <= i; j++) s += (c[j] - mid) ** 2; const sd = Math.sqrt(s / 20); return [mid + 2 * sd, mid, mid - 2 * sd]; }); }
    function rsiArr() { const c = data.map(x => x.c), out = [NaN]; let g = 0, l = 0; for (let i = 1; i < c.length; i++) { const d = c[i] - c[i - 1]; if (i <= 14) { g += Math.max(d, 0); l += Math.max(-d, 0); out.push(i === 14 ? (l ? 100 - 100 / (1 + g / l) : 100) : NaN); if (i === 14) { g /= 14; l /= 14; } } else { g = (g * 13 + Math.max(d, 0)) / 14; l = (l * 13 + Math.max(-d, 0)) / 14; out.push(l ? 100 - 100 / (1 + g / l) : 100); } } return out; }
    function macdArr() { const c = data.map(x => x.c), e26 = emaArr(c, 26), m = emaArr(c, 12).map((v, i) => v - e26[i]); const s = emaArr(m, 9); return m.map((v, i) => i >= 25 ? [v, s[i], v - s[i]] : [NaN, NaN, NaN]); }
    const nearIdx = t => { let b = 0; for (let i = 0; i < data.length; i++) if (data[i].t <= t) b = i; return b; };

    function draw() {
      Object.assign(C, pal());
      const r = size(), W = r.width, H = r.height;
      ctx.clearRect(0, 0, W, H);
      if (!data.length) { ctx.fillStyle = C.axis; ctx.font = '14px Segoe UI, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(opt.empty || '', W / 2, H / 2); geo = null; return; }
      const ind = opt.ind || {}, cmp = opt.cmp && opt.cmp.vals && opt.cmp.vals.length === data.length ? opt.cmp : null;
      const pctMode = !!cmp, base = data[0].c;
      const val = v => pctMode ? (v / base - 1) * 100 : v;
      const subs = [ind.vol && data.some(x => x.v > 0) ? 'vol' : null, ind.rsi ? 'rsi' : null, ind.macd ? 'macd' : null].filter(Boolean);
      // lower panes together take at most about 45% of the height, so the price chart stays big enough
      const gap = 8, subH = subs.length ? Math.max(28, Math.min(110, ((H - PADT - PADB) * 0.45) / subs.length - gap)) : 0;
      const mainB = H - PADB - subs.length * (subH + gap);
      const m20 = opt.ma && !pctMode ? (opt.m20 || maArr(20)) : [], m50 = opt.ma && !pctMode ? (opt.m50 || maArr(50)) : [];
      const bb = ind.bb && !pctMode ? bbArr() : [];
      let mx = -Infinity, mn = Infinity;
      const lineOnly = opt.line || pctMode;
      data.forEach(x => { mx = Math.max(mx, val(lineOnly ? x.c : x.h)); mn = Math.min(mn, val(lineOnly ? x.c : x.l)); });
      if (cmp) cmp.vals.forEach(v => { if (isFinite(v)) { mx = Math.max(mx, v); mn = Math.min(mn, v); } });
      m20.concat(m50).forEach(v => { if (isFinite(v)) { mx = Math.max(mx, v); mn = Math.min(mn, v); } });
      bb.forEach(b => { if (isFinite(b[0])) { mx = Math.max(mx, b[0]); mn = Math.min(mn, b[2]); } });
      if (!pctMode) [opt.sup, opt.res].forEach(v => { if (isFinite(v) && v < mx * 1.06 && v > mn * 0.94) { mx = Math.max(mx, v); mn = Math.min(mn, v); } });
      if (mx === mn) { mx = mx * 1.001 + 0.001; mn = mn * 0.999 - 0.001; }
      const pad = (mx - mn) * 0.06; mx += pad; mn -= pad;
      const pw = W - PADL - PADR, ph = mainB - PADT, n = data.length, bw = pw / n;
      const X = i => PADL + i * bw + bw / 2, Y = v => PADT + (mx - v) / (mx - mn) * ph;
      geo = { X, Y, bw, mn, mx, ph, mainB, W, pctMode };
      const lab = v => pctMode ? (v > 0 ? '+' : '') + v.toFixed(2) + '%' : opt.fmt(v);
      // grid + price labels
      ctx.font = '11px Segoe UI, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      for (let k = 0; k <= 5; k++) {
        const v = mn + (mx - mn) * k / 5, y = Y(v);
        ctx.strokeStyle = C.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(PADL, y); ctx.lineTo(W - PADR, y); ctx.stroke();
        ctx.fillStyle = C.axis; ctx.fillText(lab(v), W - PADR + 8, y);
      }
      if (pctMode) { ctx.strokeStyle = C.axis; ctx.globalAlpha = .5; ctx.beginPath(); ctx.moveTo(PADL, Y(0)); ctx.lineTo(W - PADR, Y(0)); ctx.stroke(); ctx.globalAlpha = 1; }
      // time labels
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      const step = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(pw / 110))));
      for (let i = 0; i < n; i += step) { ctx.fillStyle = C.axis; ctx.fillText(opt.tfmt(data[i].t), X(i), H - PADB + 8); }
      ctx.save(); ctx.beginPath(); ctx.rect(PADL, PADT, pw, ph); ctx.clip();
      // support / resistance
      if (!pctMode) [[opt.sup, C.sup], [opt.res, C.res]].forEach(([v, col]) => {
        if (!isFinite(v) || v > mx || v < mn) return;
        ctx.save(); ctx.strokeStyle = col; ctx.globalAlpha = .7; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.moveTo(PADL, Y(v)); ctx.lineTo(W - PADR, Y(v)); ctx.stroke(); ctx.restore();
      });
      // Bollinger Bands
      if (bb.length) {
        ctx.beginPath(); let on = false; bb.forEach((b, i) => { if (!isFinite(b[0])) return; on ? ctx.lineTo(X(i), Y(b[0])) : ctx.moveTo(X(i), Y(b[0])); on = true; });
        for (let i = n - 1; i >= 0; i--) if (isFinite(bb[i][2])) ctx.lineTo(X(i), Y(bb[i][2]));
        ctx.closePath(); ctx.fillStyle = 'rgba(90,209,232,.07)'; ctx.fill();
        [0, 2].forEach(k => { ctx.beginPath(); let o = false; bb.forEach((b, i) => { if (!isFinite(b[k])) return; o ? ctx.lineTo(X(i), Y(b[k])) : ctx.moveTo(X(i), Y(b[k])); o = true; }); ctx.strokeStyle = C.bb; ctx.lineWidth = 1.2; ctx.globalAlpha = .85; ctx.stroke(); ctx.globalAlpha = 1; });
      }
      // price
      if (lineOnly || n > 400) {
        const g = ctx.createLinearGradient(0, PADT, 0, mainB); g.addColorStop(0, 'rgba(79,139,255,.30)'); g.addColorStop(1, 'rgba(79,139,255,0)');
        ctx.beginPath(); data.forEach((x, i) => i ? ctx.lineTo(X(i), Y(val(x.c))) : ctx.moveTo(X(i), Y(val(x.c))));
        ctx.strokeStyle = C.line; ctx.lineWidth = 2; ctx.stroke();
        if (!pctMode) { ctx.lineTo(X(n - 1), mainB); ctx.lineTo(X(0), mainB); ctx.closePath(); ctx.fillStyle = g; ctx.fill(); }
        if (opt.dots && !pctMode) data.forEach((x, i) => { ctx.fillStyle = C.line; ctx.beginPath(); ctx.arc(X(i), Y(x.c), 3.5, 0, 7); ctx.fill(); });
      } else {
        data.forEach((x, i) => {
          const col = x.c >= x.o ? C.up : C.dn, cx = X(i);
          ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(Math.round(cx) + .5, Y(x.h)); ctx.lineTo(Math.round(cx) + .5, Y(x.l)); ctx.stroke();
          const top = Y(Math.max(x.o, x.c)), hgt = Math.max(1, Math.abs(Y(x.o) - Y(x.c)));
          ctx.fillStyle = col; ctx.fillRect(cx - Math.max(1, bw * .34), top, Math.max(2, bw * .68), hgt);
        });
      }
      // compared market
      if (cmp) { ctx.beginPath(); let on = false; cmp.vals.forEach((v, i) => { if (!isFinite(v)) return; on ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)); on = true; }); ctx.strokeStyle = C.cmp; ctx.lineWidth = 2; ctx.stroke(); }
      // averages
      [[m20, C.ma20], [m50, C.ma50]].forEach(([a, col]) => {
        ctx.beginPath(); let on = false;
        a.forEach((v, i) => { if (!isFinite(v)) return; on ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)); on = true; });
        if (on) { ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.globalAlpha = .9; ctx.stroke(); ctx.globalAlpha = 1; }
      });
      // my drawn lines
      if (!pctMode) {
        const shapes = (opt.draw || []).slice();
        if (pend && mouse) shapes.push({ k: 't', a: pend, b: mouse, tmp: true });
        shapes.forEach(s => {
          ctx.save(); ctx.strokeStyle = C.draw; ctx.lineWidth = 1.6; if (s.tmp) ctx.setLineDash([4, 4]);
          if (s.k === 'h') { ctx.beginPath(); ctx.moveTo(PADL, Y(s.v)); ctx.lineTo(W - PADR, Y(s.v)); ctx.stroke(); }
          else if (s.k === 't') {
            const ia = nearIdx(s.a.t), ib = nearIdx(s.b.t);
            const xa = s.tmp && s.a.x != null ? s.a.x : X(ia), xb = s.tmp && s.b.x != null ? s.b.x : X(ib);
            if (xa !== xb) { const k = (s.b.v - s.a.v) / (xb - xa); ctx.beginPath(); ctx.moveTo(xa, Y(s.a.v)); const xe = W - PADR; ctx.lineTo(xe, Y(s.a.v + k * (xe - xa))); ctx.stroke(); ctx.fillStyle = C.draw; [[xa, s.a.v], [xb, s.b.v]].forEach(([px, pv]) => { ctx.beginPath(); ctx.arc(px, Y(pv), 3, 0, 7); ctx.fill(); }); }
          }
          ctx.restore();
        });
      }
      ctx.restore();
      // price tags for drawn horizontal lines
      if (!pctMode) (opt.draw || []).forEach(s => { if (s.k !== 'h' || s.v > mx || s.v < mn) return; ctx.fillStyle = C.draw; ctx.fillRect(W - PADR + 2, Y(s.v) - 9, PADR - 4, 18); ctx.fillStyle = C.tag; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = 'bold 10.5px Segoe UI, sans-serif'; ctx.fillText(opt.fmt(s.v), W - PADR + 7, Y(s.v)); });
      // last price tag
      const last = data[n - 1].c, ly = Y(val(last));
      ctx.fillStyle = data[n - 1].c >= (data[n - 2] ? data[n - 2].c : last) ? C.up : C.dn;
      ctx.fillRect(W - PADR + 2, ly - 10, PADR - 4, 20);
      ctx.fillStyle = C.tag; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = 'bold 11px Segoe UI, sans-serif'; ctx.fillText(lab(val(last)), W - PADR + 7, ly);
      if (cmp) { const lv = cmp.vals[n - 1]; if (isFinite(lv)) { ctx.fillStyle = C.cmp; ctx.fillRect(W - PADR + 2, Y(lv) - 10, PADR - 4, 20); ctx.fillStyle = C.tag; ctx.fillText(lab(lv), W - PADR + 7, Y(lv)); } }
      // lower panes: volume, RSI, MACD
      const rs = subs.includes('rsi') ? rsiArr() : null, md = subs.includes('macd') ? macdArr() : null;
      subs.forEach((k, si) => {
        const top = mainB + gap + si * (subH + gap), bot = top + subH;
        ctx.strokeStyle = C.sep; ctx.beginPath(); ctx.moveTo(PADL, top - gap / 2); ctx.lineTo(W - PADR, top - gap / 2); ctx.stroke();
        ctx.font = '10.5px Segoe UI, sans-serif'; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
        if (k === 'vol') {
          const vm = Math.max(...data.map(x => x.v || 0)) || 1;
          data.forEach((x, i) => { const h = (x.v || 0) / vm * (subH - 4); ctx.fillStyle = x.c >= x.o ? 'rgba(61,220,151,.55)' : 'rgba(255,93,115,.55)'; ctx.fillRect(X(i) - Math.max(1, bw * .34), bot - h, Math.max(2, bw * .68), h); });
          ctx.fillStyle = C.axis; ctx.fillText(opt.labels ? opt.labels.vol : 'Volume', PADL + 4, top + 2);
        } else if (k === 'rsi') {
          const yv = v => top + (100 - v) / 100 * subH;
          ctx.fillStyle = 'rgba(176,108,255,.07)'; ctx.fillRect(PADL, yv(70), pw, yv(30) - yv(70));
          [70, 30].forEach(l => { ctx.save(); ctx.strokeStyle = C.axis; ctx.globalAlpha = .5; ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(PADL, yv(l)); ctx.lineTo(W - PADR, yv(l)); ctx.stroke(); ctx.restore(); ctx.fillStyle = C.axis; ctx.textBaseline = 'middle'; ctx.fillText(String(l), W - PADR + 8, yv(l)); });
          ctx.beginPath(); let on = false; rs.forEach((v, i) => { if (!isFinite(v)) return; on ? ctx.lineTo(X(i), yv(v)) : ctx.moveTo(X(i), yv(v)); on = true; }); ctx.strokeStyle = C.ma50; ctx.lineWidth = 1.5; ctx.stroke();
          const lv = rs[n - 1]; ctx.textBaseline = 'top'; ctx.fillStyle = C.axis; ctx.fillText('RSI 14' + (isFinite(lv) ? ' · ' + lv.toFixed(1) : ''), PADL + 4, top + 2);
        } else if (k === 'macd') {
          let a = 0; md.forEach(m => { m.forEach(v => { if (isFinite(v)) a = Math.max(a, Math.abs(v)); }); }); a = a || 1;
          const yv = v => top + subH / 2 - v / a * (subH / 2 - 3);
          md.forEach((m, i) => { if (!isFinite(m[2])) return; ctx.fillStyle = m[2] >= 0 ? 'rgba(61,220,151,.55)' : 'rgba(255,93,115,.55)'; const y0 = yv(0), y1 = yv(m[2]); ctx.fillRect(X(i) - Math.max(1, bw * .3), Math.min(y0, y1), Math.max(2, bw * .6), Math.max(1, Math.abs(y1 - y0))); });
          [[0, C.line], [1, C.ma20]].forEach(([j, col]) => { ctx.beginPath(); let on = false; md.forEach((m, i) => { if (!isFinite(m[j])) return; on ? ctx.lineTo(X(i), yv(m[j])) : ctx.moveTo(X(i), yv(m[j])); on = true; }); ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.stroke(); });
          ctx.fillStyle = C.axis; ctx.fillText('MACD 12, 26, 9', PADL + 4, top + 2);
        }
      });
      // crosshair
      if (hover >= 0 && hover < n) {
        const x = data[hover], cx = X(hover);
        ctx.save(); ctx.strokeStyle = C.cross; ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(cx, PADT); ctx.lineTo(cx, H - PADB); ctx.stroke(); ctx.restore();
        ctx.fillStyle = C.dot; ctx.beginPath(); ctx.arc(cx, Y(val(x.c)), 3.5, 0, 7); ctx.fill();
        let html = opt.tip(x, m20[hover], m50[hover]);
        if (bb.length && isFinite(bb[hover][0])) html += `<br><span style="color:${C.bb}">BB ${opt.fmt(bb[hover][2])} – ${opt.fmt(bb[hover][0])}</span>`;
        if (rs && isFinite(rs[hover])) html += `<br><span style="color:${C.ma50}">RSI ${rs[hover].toFixed(1)}</span>`;
        if (md && isFinite(md[hover][0])) html += ` · MACD ${md[hover][0] > md[hover][1] ? '▲' : '▼'}`;
        if (cmp) html += `<br><span style="color:${C.line}">${opt.cmpName || ''} ${lab(val(x.c))}</span> · <span style="color:${C.cmp}">${cmp.name} ${isFinite(cmp.vals[hover]) ? lab(cmp.vals[hover]) : '—'}</span>`;
        tip.innerHTML = html;
        tip.style.display = 'block';
        const tw = tip.offsetWidth; tip.style.left = Math.min(W - PADR - tw - 6, Math.max(6, cx + 14 > W - PADR - tw ? cx - tw - 14 : cx + 14)) + 'px'; tip.style.top = '14px';
      } else tip.style.display = 'none';
      canvas.style.cursor = opt.drawMode && !pctMode ? 'crosshair' : '';
    }
    function idx(e) { const r = canvas.getBoundingClientRect(); const pw = r.width - PADL - PADR; const i = Math.floor((e.clientX - r.left - PADL) / (pw / data.length)); return i >= 0 && i < data.length ? i : -1; }
    function pt(e) { if (!geo) return null; const r = canvas.getBoundingClientRect(), y = e.clientY - r.top, x = e.clientX - r.left; if (y > geo.mainB) return null; const v = geo.mx - (y - PADT) / geo.ph * (geo.mx - geo.mn); const i = idx(e); return i < 0 ? null : { t: data[i].t, v, x }; }
    canvas.addEventListener('mousemove', e => { hover = idx(e); if (pend) mouse = pt(e); draw(); });
    canvas.addEventListener('mouseleave', () => { hover = -1; mouse = null; draw(); });
    canvas.addEventListener('click', e => {
      if (!opt.drawMode || !geo || geo.pctMode) return;
      const p = pt(e); if (!p) return;
      if (opt.drawMode === 'h') { opt.onDraw && opt.onDraw({ k: 'h', v: p.v }); return; }
      if (!pend) { pend = p; mouse = p; return; }
      const a = { t: pend.t, v: pend.v }, b = { t: p.t, v: p.v }; pend = null; mouse = null;
      if (a.t !== b.t) opt.onDraw && opt.onDraw({ k: 't', a: a.t < b.t ? a : b, b: a.t < b.t ? b : a });
    });
    new ResizeObserver(() => draw()).observe(canvas);
    return { set(d, o) { data = d || []; opt = o; hover = -1; if (!o.drawMode) pend = null; draw(); }, draw };
  }
  // Small line for the watchlist.
  function spark(canvas, vals, up) {
    const d = window.devicePixelRatio || 1, w = canvas.clientWidth || 70, h = canvas.clientHeight || 26;
    canvas.width = w * d; canvas.height = h * d; const ctx = canvas.getContext('2d'); ctx.setTransform(d, 0, 0, d, 0, 0);
    if (!vals || vals.length < 2) return;
    const mx = Math.max(...vals), mn = Math.min(...vals), r = mx - mn || 1;
    ctx.beginPath(); vals.forEach((v, i) => { const x = i / (vals.length - 1) * (w - 2) + 1, y = h - 2 - (v - mn) / r * (h - 4); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    ctx.strokeStyle = up ? pal().up : pal().dn; ctx.lineWidth = 1.5; ctx.stroke();
  }
  window.KMChart = KMChart; window.KMSpark = spark;
})();
