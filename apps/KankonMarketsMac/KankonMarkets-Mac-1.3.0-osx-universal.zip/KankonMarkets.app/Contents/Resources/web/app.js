// Kankon Markets: the screen. By Kankon · kankon.net
(function () {
  const $ = id => document.getElementById(id);
  const LS = { get: (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const FIRST = ['gold', 'silver', 'btc', 'kec', 'wti'];
  const DEFAULT_WATCH = FIRST.concat(KM_CATALOG.filter(a => !a.extra && !FIRST.includes(a.id)).map(a => a.id));
  const PERIODS = ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y'];
  const st = {
    lang: LS.get('km.lang', 'en'), watch: LS.get('km.watch', DEFAULT_WATCH), custom: LS.get('km.custom', []),
    sel: LS.get('km.sel', 'gold'), period: LS.get('km.period', '1M'), mode: LS.get('km.mode', 'candle'), ma: LS.get('km.ma', true),
    cat: 'all', quotes: {}, series: null, daily: null, ok: null, at: 0, ready: false,
    tab: LS.get('km.tab', 'A'), win: LS.get('km.win', 60), news: null, intra: null, newsNext: 0,
    ind: LS.get('km.ind', {}), draws: LS.get('km.draw', {}), drawMode: null, cmp: LS.get('km.cmp', ''), cmpS: null,
  };
  const WINS = [15, 30, 60, 240];
  const T = () => KM_T[st.lang];
  const all = () => KM_CATALOG.concat(st.custom);
  const byId = id => all().find(a => a.id === id);
  const nameOf = a => (a[st.lang] || a.en)[0], subOf = a => (a[st.lang] || a.en)[1];
  const isUsd = a => a.cat !== 'fx' && a.cat !== 'indices' && a.cat !== 'custom';
  const nf = (v, dp) => isFinite(v) ? v.toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp }) : '—';
  const autoDp = v => v >= 1000 ? 2 : v >= 10 ? 2 : v >= 1 ? 3 : 5;
  const fmtA = (a, v) => (isUsd(a) ? '$' : '') + nf(v, a.dp != null ? a.dp : autoDp(v));
  const sign = v => (v > 0 ? '+' : v < 0 ? '−' : '');
  const cls = v => v > 0 ? 'up' : v < 0 ? 'dn' : 'flat';
  const loc = () => st.lang === 'ar' ? 'ar-KW-u-nu-latn' : 'en-GB';

  // ---------- language ----------
  function applyLang() {
    const t = T();
    document.documentElement.lang = st.lang; document.documentElement.dir = st.lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-t]').forEach(e => { e.textContent = t[e.dataset.t]; });
    $('l-en').className = st.lang === 'en' ? 'on' : ''; $('l-ar').className = st.lang === 'ar' ? 'on' : '';
    $('q').placeholder = t.search;
    $('gl').innerHTML = t.gauge.map(s => `<span>${s}</span>`).join('');
    $('split').title = $('splitL').title = t.split;
    $('aBell').title = t.alQuick; $('aBell').textContent = '🔔';
    $('aiQ').placeholder = t.aiChips[0].replace('{name}', nameOf(byId(st.sel) || KM_CATALOG[0]));
  }
  function setLang(l) { st.lang = l; LS.set('km.lang', l); applyLang(); renderAll(); KMAI.render(); KMTools.render(); loadNews(); if (!$('help').hidden) openHelp(); }

  // ---------- watchlist ----------
  function renderCats() {
    $('cats').innerHTML = KM_CATS.map(c => `<button data-c="${c}" class="${st.cat === c ? 'on' : ''}">${T().cats[c]}</button>`).join('');
  }
  function quoteOf(a) {
    const q = st.quotes[a.id]; if (!q) return null;
    const ch = q.price - q.prev, pct = q.prev ? ch / q.prev * 100 : NaN;
    return { price: q.price, ch, pct, spark: q.candles.map(c => c.c) };
  }
  function renderList() {
    const t = T();
    const ids = st.watch.filter(id => byId(id) && (st.cat === 'all' || byId(id).cat === st.cat));
    let html = '', lastCat = '';
    ids.forEach(id => {
      const a = byId(id), q = quoteOf(a);
      if (st.cat === 'all' && a.cat !== lastCat && a.cat !== 'custom') { /* grouped by order; no headers to keep the list compact */ }
      lastCat = a.cat;
      html += `<div class="asset ${st.sel === id ? 'sel' : ''}" data-id="${id}">
        <div class="ic" style="color:${a.col};background:${a.col}22">${a.ic}</div>
        <div class="nm"><b>${nameOf(a)}</b><small>${subOf(a)}</small></div>
        <canvas data-sp="${id}"></canvas>
        <div class="pr"><b>${q ? fmtA(a, q.price) : '…'}</b><small class="${q ? cls(q.ch) : ''}">${q && isFinite(q.pct) ? sign(q.pct) + Math.abs(q.pct).toFixed(2) + '%' : ''}</small></div>
        <button class="rm" data-rm="${id}" title="${t.remove}">×</button></div>`;
    });
    $('list').innerHTML = html;
    ids.forEach(id => { const q = quoteOf(byId(id)); const c = document.querySelector(`canvas[data-sp="${id}"]`); if (q && c) KMSpark(c, q.spark, q.ch >= 0); });
  }

  // ---------- selected market ----------
  const tfmt = t => {
    const d = new Date(t);
    if (st.period === '1D') return d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
    if (st.period === '1W') return d.toLocaleDateString(loc(), { weekday: 'short' }) + ' ' + d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
    if (st.period === '5Y') return d.toLocaleDateString(loc(), { month: 'short', year: 'numeric' });
    return d.toLocaleDateString(loc(), { day: 'numeric', month: 'short' });
  };
  function renderHead() {
    const a = byId(st.sel), t = T(); if (!a) return;
    $('aName').textContent = nameOf(a); $('aSub').textContent = subOf(a);
    $('aIc').textContent = a.ic; $('aIc').style.cssText = `color:${a.col};background:${a.col}22`;
    const q = quoteOf(a) || (st.series && { price: st.series.price, ch: st.series.price - st.series.prev, pct: (st.series.price / st.series.prev - 1) * 100 });
    $('aPrice').textContent = q ? fmtA(a, q.price) : '—';
    $('aChg').className = 'chg ' + (q ? cls(q.ch) : '');
    $('aChg').textContent = q && isFinite(q.ch) ? `${sign(q.ch)}${nf(Math.abs(q.ch), a.dp != null ? a.dp : autoDp(q.price))} (${sign(q.pct)}${Math.abs(q.pct).toFixed(2)}%)` : '';
    const s = st.quotes[a.id] || st.series;
    $('aTime').textContent = s && s.time ? `${t.vsPrev} · ${new Date(s.time).toLocaleString(loc(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}${s.exchange ? ' · ' + s.exchange : ''}` : '';
    $('tfs').innerHTML = PERIODS.map(p => `<button class="tf ${st.period === p ? 'on' : ''}" data-p="${p}">${p}</button>`).join('');
    document.querySelector('.ctrls').style.visibility = a.src === 'oil' ? 'hidden' : '';
    $('mainLeg').style.display = a.src === 'oil' ? 'none' : '';
    $('mCandle').className = 'tf' + (st.mode === 'candle' ? ' on' : ''); $('mLine').className = 'tf' + (st.mode === 'line' ? ' on' : ''); $('mMa').className = 'tf' + (st.ma ? ' on' : '');
    // stats from today's candles + the year
    const d1 = st.quotes[a.id], yr = st.daily;
    const dc = d1 && d1.candles.length ? d1.candles : [];
    const open = dc.length ? dc[0].o : NaN;
    const hi = d1 && isFinite(d1.dayHigh) ? d1.dayHigh : dc.length ? Math.max(...dc.map(c => c.h)) : NaN;
    const lo = d1 && isFinite(d1.dayLow) ? d1.dayLow : dc.length ? Math.min(...dc.map(c => c.l)) : NaN;
    const ys = yr && yr.candles && yr.candles.length ? yr.candles : [];
    const h52 = ys.length ? Math.max(...ys.map(c => c.h)) : NaN, l52 = ys.length ? Math.min(...ys.map(c => c.l)) : NaN;
    const v = [[t.open, fmtA(a, open)], [t.high, fmtA(a, hi)], [t.low, fmtA(a, lo)], [t.prevClose, fmtA(a, d1 ? d1.prev : NaN)], [t.range52, isFinite(h52) ? fmtA(a, l52) + ' – ' + fmtA(a, h52) : '—']];
    if (a.src === 'oil') { v[0][1] = v[1][1] = v[2][1] = '—'; }
    $('stats').innerHTML = v.map(([k, x]) => `<div class="st"><small>${k}</small><b>${x}</b></div>`).join('');
    let src = a.src === 'oil' ? `${t.src.oil} <span class="warn">${t.kecNote}</span>` : t.src.y;
    if (st.series && st.series.stale) src = `<span class="warn">${t.offline}</span> · ` + src;
    $('src').innerHTML = src;
  }
  function renderChart() {
    const a = byId(st.sel), t = T(), s = st.series;
    const an = st.analysis;
    // For 1M to 6M, take the 20/50-day averages from the year of daily prices, so the lines cover the whole chart.
    let m20 = null, m50 = null;
    if (s && st.daily && ['1M', '3M', '6M'].includes(st.period) && a.src !== 'oil') {
      const dc = st.daily.candles, day = t => new Date(t).toISOString().slice(0, 10), map = {};
      dc.forEach((x, i) => { map[day(x.t)] = [i >= 19 ? KMAnalyzer.sma(dc.map(c => c.c), 20, i + 1) : NaN, i >= 49 ? KMAnalyzer.sma(dc.map(c => c.c), 50, i + 1) : NaN]; });
      m20 = s.candles.map(x => (map[day(x.t)] || [NaN])[0]); m50 = s.candles.map(x => (map[day(x.t)] || [NaN, NaN])[1]);
    }
    // compare: the other market as % change from the start of the period, matched by time
    let cmp = null; const b = byId(st.cmp);
    if (s && b && b.id !== a.id && st.cmpS && st.cmpS.id === b.id && st.cmpS.p === st.period && st.cmpS.d.candles.length) {
      const cc = st.cmpS.d.candles; let j = 0, b0 = null;
      const vals = s.candles.map(x => { while (j + 1 < cc.length && cc[j + 1].t <= x.t) j++; if (cc[j].t > x.t) return NaN; if (b0 == null) b0 = cc[j].c; return (cc[j].c / b0 - 1) * 100; });
      cmp = { vals, name: nameOf(b) };
    }
    $('cmpLeg').hidden = !cmp; if (cmp) $('cmpLeg').innerHTML = `<i style="background:#4f8bff"></i>${nameOf(a)} <i style="background:#ff8fd0"></i>${nameOf(b)} <span>(${t.cmpPct})</span>`;
    $('mainLeg').classList.toggle('hideL', !!cmp);
    chart.set(s ? s.candles : [], {
      ind: a.src === 'oil' ? {} : st.ind, cmp, cmpName: nameOf(a), labels: { vol: t.volume },
      draw: st.draws[a.id] || [], drawMode: st.drawMode, onDraw: sh => { (st.draws[a.id] = st.draws[a.id] || []).push(sh); LS.set('km.draw', st.draws); if (sh.k === 'h') { st.drawMode = null; renderTools(); } else { st.drawMode = null; renderTools(); } renderChart(); },
      m20, m50, line: st.mode === 'line' || a.src === 'oil', dots: a.src === 'oil', ma: st.ma && a.src !== 'oil', fmt: v => fmtA(a, v), tfmt, empty: s ? '' : (st.loadErr ? t.noData : t.loading),
      sup: an && an.enough ? an.sup : NaN, res: an && an.enough ? an.res : NaN,
      tip: (x, m20, m50) => {
        const d = new Date(x.t), when = ['1D', '1W', '1M'].includes(st.period) ? d.toLocaleString(loc(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString(loc(), { day: 'numeric', month: 'short', year: 'numeric' });
        return `<b>${when}</b><br>${t.open} ${fmtA(a, x.o)} · ${t.high} ${fmtA(a, x.h)}<br>${t.low} ${fmtA(a, x.l)} · <b>${fmtA(a, x.c)}</b>` + (st.ma && isFinite(m20) ? `<br><span style="color:#f5c542">MA20 ${fmtA(a, m20)}</span>` : '') + (st.ma && isFinite(m50) ? ` · <span style="color:#b06cff">MA50 ${fmtA(a, m50)}</span>` : '');
      },
    });
  }
  // market hours (Kuwait time)
  const kwT = d => { const same = new Date(d).toDateString() === new Date().toDateString(); return new Date(d).toLocaleString(loc(), Object.assign({ timeZone: 'Asia/Kuwait', hour: '2-digit', minute: '2-digit' }, same ? {} : { weekday: 'short' })); };
  function hoursText(h) {
    const t = T(); if (!h) return null;
    if (h.always) return [true, t.hOpen24];
    if (h.daily) return [null, t.hDaily];
    return [h.open, (h.open ? t.hOpenTill : t.hClosedTill).replace('{t}', h.next ? kwT(h.next) : '—')];
  }
  function renderHours() {
    const t = T(), a = byId(st.sel), now = new Date();
    const mine = hoursText(KMHours.forAsset(a, now));
    $('mstat').hidden = !mine; if (mine) { $('mstat').className = 'mstat ' + (mine[0] === true ? 'on' : mine[0] === false ? 'off' : ''); $('mstat').textContent = (mine[0] === true ? '● ' : mine[0] === false ? '○ ' : '') + mine[1]; }
    $('hours').innerHTML = KMHours.GROUPS.map(([k, s]) => { const h = hoursText(KMHours.status(s, now)); return `<div class="hr"><i class="dot ${h[0] ? 'on' : 'off'}"></i><b>${t.hG[k]}</b><small>${h[1]}</small></div>`; }).join('');
  }
  // chart tools row: indicators, drawing, compare
  function renderTools() {
    const t = T(), a = byId(st.sel); if (!a) return;
    const on = k => st.ind[k] ? ' on' : '';
    $('ctools').innerHTML = `<div class="tfs"><button class="tf${on('bb')}" data-ind="bb" title="${t.bbT}">BB</button><button class="tf${on('vol')}" data-ind="vol">${t.volume}</button><button class="tf${on('rsi')}" data-ind="rsi">RSI</button><button class="tf${on('macd')}" data-ind="macd">MACD</button></div>`
      + `<div class="tfs"><button class="tf${st.drawMode === 'h' ? ' on' : ''}" data-dm="h" title="${t.drawH}">― ${t.drawLine}</button><button class="tf${st.drawMode === 't' ? ' on' : ''}" data-dm="t" title="${t.drawT}">╱ ${t.drawTrend}</button>${(st.draws[a.id] || []).length ? `<button class="tf" data-dm="x" title="${t.drawClear}">🗑</button>` : ''}</div>`
      + `<label class="cmpSel">${t.compare}<select id="cmpSel"><option value="">—</option>${all().filter(x => x.id !== a.id).map(x => `<option value="${x.id}" ${st.cmp === x.id ? 'selected' : ''}>${nameOf(x)}</option>`).join('')}</select></label>`;
    $('ctools').style.display = a.src === 'oil' ? 'none' : '';
    $('drawHint').hidden = !st.drawMode; $('drawHint').textContent = st.drawMode === 'h' ? t.drawHintH : st.drawMode === 't' ? t.drawHintT : '';
  }
  async function loadCompare() {
    const b = byId(st.cmp); if (!b || b.id === st.sel) { st.cmpS = null; renderChart(); return; }
    const p = st.period, want = b.src === 'oil' ? '1D' : p;
    try { const d = await KMNet.series(b, want); st.cmpS = { id: b.id, p, d }; } catch (e) { st.cmpS = null; }
    renderChart();
  }
  function renderAnalysis() {
    const a = byId(st.sel), t = T(), an = st.analysis;
    const fmt = v => fmtA(a, v);
    if (!an) { $('badge').textContent = '…'; $('badge').className = 'badge'; $('rows').innerHTML = ''; $('an').innerHTML = `<p>${st.loadErr ? t.noData : t.loading}</p>`; $('needle').style.left = '50%'; }
    else {
      const paras = KMAnalyzer.write(an, nameOf(a), st.lang, fmt);
      $('an').innerHTML = [].concat(paras).map(p => `<p>${p}</p>`).join('');
      $('rows').hidden = !an.enough;
      if (!an.enough) { $('badge').textContent = t.na; $('badge').className = 'badge'; $('rows').innerHTML = ''; $('needle').style.left = '50%'; }
      else {
        $('badge').textContent = t.labels[an.label]; $('badge').className = 'badge ' + (an.score >= 15 ? 'up' : an.score <= -15 ? 'dn' : '');
        $('needle').style.left = (50 + an.score / 2) + '%';
        const rows = [
          [t.trend, an.trend >= 0 ? t.trendUp : t.trendDown, an.trend >= 0 ? 'up' : 'dn'],
          [t.rsi, an.rsi.toFixed(1), an.rsi >= 70 ? 'dn' : an.rsi <= 30 ? 'up' : ''],
          [t.ma50, isFinite(an.m50) ? (an.p > an.m50 ? t.above : t.below) : t.na, isFinite(an.m50) ? (an.p > an.m50 ? 'up' : 'dn') : ''],
          [t.ma200, isFinite(an.m200) ? (an.p > an.m200 ? t.above : t.below) : t.na, isFinite(an.m200) ? (an.p > an.m200 ? 'up' : 'dn') : ''],
          [t.support, fmt(an.sup), ''], [t.resistance, isFinite(an.res) ? fmt(an.res) : t.na, ''],
          [t.macd, an.macd > an.signal ? t.positive : t.negative, an.macd > an.signal ? 'up' : 'dn'],
        ];
        $('rows').innerHTML = rows.map(([k, v, c]) => `<div class="row"><span>${k}</span><b class="${c}">${v}</b></div>`).join('');
      }
    }
    // Gold in Kuwait per gram (KWD), from the world gold price and USD/KWD.
    const g = st.quotes.gold, k = st.quotes.kwd;
    const show = st.sel === 'gold' && g && k && isFinite(g.price) && isFinite(k.price);
    $('kwGold').hidden = !show;
    if (show) {
      const g24 = g.price / 31.1034768 * k.price;
      $('karats').innerHTML = [['k24', 1], ['k22', 22 / 24], ['k21', 21 / 24], ['k18', 18 / 24]].map(([n, f]) => `<div><small>${t[n]}</small><b>${nf(g24 * f, 3)} KWD</b></div>`).join('');
    }
  }
  function renderStatus() {
    const t = T();
    const s = $('status');
    if (st.ok === null) { s.className = 'pill'; s.textContent = t.loading; }
    else if (st.ok) { s.className = 'pill live'; s.textContent = t.live; }
    else { s.className = 'pill off'; s.textContent = t.offline; }
    $('upd').textContent = st.at ? `${t.updated} ${new Date(st.at).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' })}` : '';
  }
  // ---------- right side tabs: Analyzer / News / AI Assistant ----------
  function renderTabs() {
    document.querySelectorAll('#rtabs button').forEach(b => { b.className = b.dataset.tab === st.tab ? 'on' : ''; });
    ['A', 'N', 'C', 'L', 'P', 'K'].forEach(k => { $('pane' + k).hidden = st.tab !== k; });
    KMTools.render();
  }
  const hm = t => new Date(t).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
  function ago(t) {
    const m = Math.max(1, Math.round((Date.now() - t) / 60000));
    try { const rf = new Intl.RelativeTimeFormat(loc(), { numeric: 'always', style: 'short' }); return m < 60 ? rf.format(-m, 'minute') : rf.format(-Math.round(m / 60), 'hour'); }
    catch (e) { return m < 60 ? m + 'm' : Math.round(m / 60) + 'h'; }
  }
  const strip = h => String(h).replace(/<[^>]+>/g, '');
  function renderNews() {
    const a = byId(st.sel), t = T(); if (!a) return;
    const wl = t.winLabel[st.win];
    $('wins').innerHTML = WINS.map(w => `<button class="tf ${st.win === w ? 'on' : ''}" data-w="${w}">${t.wins[w]}</button>`).join('');
    $('mvTitle').textContent = t.mvTitle.replace('{w}', wl);
    let mv;
    if (a.src === 'oil') mv = `<p>${t.mvOil}</p>`;
    else if (!st.intra || st.intra.id !== a.id) mv = `<p>${t.loading}</p>`;
    else {
      const m = KMNews.move(st.intra.d && st.intra.d.candles, st.win);
      mv = m ? KMNews.write(m, nameOf(a), st.lang, v => fmtA(a, v), hm, wl).map(p => `<p>${p}</p>`).join('') : `<p>${t.mvNone}</p>`;
    }
    $('mv').innerHTML = mv;
    const n = st.news;
    if (!n || n.id !== a.id || n.lang !== st.lang) { $('news').innerHTML = `<p class="small">${t.nLoading}</p>`; $('nInfo').textContent = ''; return; }
    const from = Date.now() - st.win * 60000;
    const inWin = n.items.filter(x => x.t >= from), earlier = n.items.filter(x => x.t < from).slice(0, Math.max(4, 10 - inWin.length));
    const item = x => `<a class="ni" href="${x.link.replace(/"/g, '&quot;')}" target="_blank" dir="auto"><b>${x.title.replace(/</g, '&lt;')}</b><small>${(x.source || '').replace(/</g, '&lt;')} · ${ago(x.t)}</small></a>`;
    let html = '';
    if (!n.items.length) html = `<p class="small">${t.nNone.replace('{q}', n.q)}</p>`;
    else {
      html += `<div class="sec">${t.nInWin.replace('{w}', wl)} · ${inWin.length}</div>` + inWin.map(item).join('');
      if (earlier.length) html += `<div class="sec">${t.nEarlier}</div>` + earlier.map(item).join('');
    }
    $('news').innerHTML = html;
    $('nInfo').textContent = t.nInfo.replace('{w}', t.wins[st.win]).replace('{t}', hm(st.newsNext)).replace('{s}', n.source);
  }
  function renderAll() { renderCats(); renderList(); renderHead(); renderHours(); renderTools(); renderChart(); renderAnalysis(); renderStatus(); renderTabs(); renderNews(); }

  // ---------- loading ----------
  async function pool(items, n, fn) { const q = items.slice(); await Promise.all(Array.from({ length: n }, async () => { while (q.length) await fn(q.shift()); })); }
  async function loadQuotes() {
    const ids = Array.from(new Set(st.watch.concat(['gold', 'kwd'], KMTools.need()))).filter(byId);
    let good = 0, bad = 0;
    await pool(ids, 5, async id => {
      try { const d = await KMNet.series(byId(id), '1D'); st.quotes[id] = d; d.stale ? bad++ : good++; } catch (e) { bad++; }
    });
    st.ok = good > 0; st.at = Date.now();
    renderList(); renderHead(); renderStatus(); if (st.sel === 'gold') renderAnalysis();
    KMTools.check(); if (['L', 'P', 'K'].includes(st.tab) && !document.querySelector('.pane.tools:not([hidden]) :focus')) KMTools.render();
  }
  let loadSeq = 0;
  async function loadSelected() {
    const my = ++loadSeq, a = byId(st.sel);
    if (!a) return;
    st.loadErr = false;
    const cachedS = KMNet.cached(a, a.src === 'oil' ? '1D' : st.period), cachedD = KMNet.cached(a, a.src === 'oil' ? '1D' : '1Y');
    st.series = cachedS; st.daily = cachedD; st.analysis = cachedD ? KMAnalyzer.analyze(cachedD.candles) : null;
    renderHead(); renderChart(); renderAnalysis();
    try {
      const [s, d] = await Promise.all([KMNet.series(a, a.src === 'oil' ? '1D' : st.period), KMNet.series(a, a.src === 'oil' ? '1D' : '1Y')]);
      if (my !== loadSeq) return;
      st.series = s; st.daily = d; st.analysis = KMAnalyzer.analyze(d.candles);
      if (!st.quotes[a.id] && s) st.quotes[a.id] = s;
    } catch (e) { if (my !== loadSeq) return; if (!st.series) st.loadErr = true; }
    renderHead(); renderTools(); renderChart(); renderAnalysis();
    st.ready = true;
    if (st.cmp) loadCompare();
  }
  function select(id) { st.sel = id; LS.set('km.sel', id); st.drawMode = null; renderList(); renderHours(); loadSelected(); loadNews(); KMAI.render(); applyLang(); }

  // News + movement: loaded for the selected market, then again every 15 min / 30 min / 1 hour / 4 hours.
  let newsSeq = 0;
  async function loadNews() {
    const my = ++newsSeq, a = byId(st.sel); if (!a) return;
    st.newsNext = Date.now() + st.win * 60000;
    renderNews();
    const lang = st.lang;
    const [n, d] = await Promise.all([
      KMNews.headlines(a, lang).catch(() => ({ items: [], source: 'Google News', q: KMNews.query(a, lang) })),
      KMNet.intraday(a).catch(() => null),
    ]);
    if (my !== newsSeq) return;
    st.news = Object.assign({ id: a.id, lang, at: Date.now() }, n);
    st.intra = { id: a.id, d };
    renderNews();
  }

  // What the AI assistant gets with each question: the numbers on screen right now.
  function snapshot() {
    const a = byId(st.sel), r2 = v => isFinite(v) ? +(+v).toPrecision(7) : null;
    const q = st.quotes[a.id] || st.series || {};
    const an = st.analysis;
    const out = {
      app_language: st.lang === 'ar' ? 'Arabic' : 'English',
      time_now: new Date().toString(),
      selected_market: {
        name: a.en[0], details: a.en[1], symbol: a.sym || 'Kuwait Export Blend (OilPrice.com)', category: a.cat,
        price: r2(q.price), previous_close: r2(q.prev), change_since_prev_close_pct: isFinite(q.price / q.prev) ? +((q.price / q.prev - 1) * 100).toFixed(3) : null,
        day_high: r2(q.dayHigh), day_low: r2(q.dayLow), price_time: q.time ? new Date(q.time).toString() : null,
        source: a.src === 'oil' ? 'OilPrice.com, one end-of-day price per trading day' : 'Yahoo Finance (may be delayed up to 15 minutes)',
      },
    };
    if (an && an.enough) {
      out.analyzer = { label: an.label, score_minus100_to_100: Math.round(an.score), rsi14: r2(an.rsi), sma20: r2(an.m20), sma50: r2(an.m50), sma200: r2(an.m200),
        macd: r2(an.macd), macd_signal: r2(an.signal), trend_20d_pct: r2(an.trend), support: r2(an.sup), resistance: r2(an.res), atr14_pct: r2(an.atr),
        change_1w_pct: r2(an.w1), change_1m_pct: r2(an.m1), change_3m_pct: r2(an.m3), change_1y_pct: r2(an.y1) };
      out.analyzer_text = [].concat(KMAnalyzer.write(an, a.en[0], 'en', v => fmtA(a, v))).map(strip);
    } else if (an) out.analyzer = { note: 'not enough daily history yet', days: an.days };
    if (st.intra && st.intra.id === a.id && st.intra.d) {
      out.recent_moves = {};
      WINS.forEach(w => { const m = KMNews.move(st.intra.d.candles, w); if (m) out.recent_moves['last_' + w + '_min'] = { from: r2(m.start), to: r2(m.end), change_pct: +m.pct.toFixed(3), high: r2(m.hi), low: r2(m.lo), market_closed_now: m.closed, last_price_time: new Date(m.lastT).toString() }; });
    }
    if (st.news && st.news.id === a.id) out.headlines = { source: st.news.source, search: st.news.q, items: st.news.items.slice(0, 15).map(x => ({ time: new Date(x.t).toString(), source: x.source, title: x.title })) };
    out.watchlist = st.watch.filter(byId).map(id => { const b = byId(id), w = st.quotes[id]; return { name: b.en[0], price: w ? r2(w.price) : null, change_today_pct: w && isFinite(w.price / w.prev) ? +((w.price / w.prev - 1) * 100).toFixed(2) : null }; });
    const g = st.quotes.gold, k = st.quotes.kwd;
    if (g && k && isFinite(g.price) && isFinite(k.price)) { const g24 = g.price / 31.1034768 * k.price; out.kuwait_gold_per_gram_kwd = { k24: +g24.toFixed(3), k22: +(g24 * 22 / 24).toFixed(3), k21: +(g24 * 21 / 24).toFixed(3), k18: +(g24 * 18 / 24).toFixed(3) }; }
    const pf = KMTools.snapshot(); if (pf) out.my_portfolio = pf;
    const al = KMTools.alerts.filter(x => x.on); if (al.length) out.my_price_alerts = al.map(x => ({ market: (byId(x.aid) || { en: [x.aid] }).en[0], when: x.kind === 'move' ? 'moves ' + x.v + '% in a day' : 'price ' + x.kind + ' ' + x.v }));
    return out;
  }

  // ---------- add / remove ----------
  function renderModal() {
    const t = T(), q = $('q').value.trim().toLowerCase();
    const items = all().filter(a => !q || (a.en[0] + ' ' + a.en[1] + ' ' + a.ar[0] + ' ' + (a.sym || '')).toLowerCase().includes(q));
    $('mlist').innerHTML = items.map(a => `<div class="mi"><div class="ic" style="color:${a.col};background:${a.col}22">${a.ic}</div><div class="nm"><b>${nameOf(a)}</b><small>${subOf(a)} · ${T().cats[a.cat] || ''}</small></div>${st.watch.includes(a.id) ? `<span class="in">✓ ${t.added}</span>` : `<button data-add="${a.id}">${t.addBtn}</button>`}</div>`).join('');
  }
  function addWatch(id) { if (!st.watch.includes(id)) { st.watch.push(id); LS.set('km.watch', st.watch); } renderModal(); renderList(); loadQuotes(); }
  async function addCustom() {
    const sym = $('cSym').value.trim().toUpperCase(); $('cErr').textContent = '';
    if (!/^[A-Z0-9^=.\-]{1,20}$/.test(sym)) { $('cErr').textContent = T().notFound; return; }
    const id = 'c:' + sym;
    if (byId(id)) { addWatch(id); return; }
    const a = { id, sym, cat: 'custom', ic: sym.replace(/[^A-Z0-9]/g, '').slice(0, 3), col: '#a9b6d8', en: [sym, 'Yahoo Finance'], ar: [sym, 'Yahoo Finance'] };
    try {
      const d = await KMNet.series(a, '1D');
      if (!d.candles.length && !isFinite(d.price)) throw new Error('empty');
      a.en[1] = a.ar[1] = (d.exchange || 'Yahoo Finance') + (d.currency ? ' · ' + d.currency : ''); a.cur = d.currency || '';
      st.custom.push(a); LS.set('km.custom', st.custom); st.quotes[id] = d; $('cSym').value = ''; addWatch(id);
    } catch (e) { $('cErr').textContent = T().notFound; }
  }

  // ---------- events ----------
  const chart = KMChart($('cv'), $('tip'));
  $('l-en').onclick = () => setLang('en'); $('l-ar').onclick = () => setLang('ar');
  $('refresh').onclick = () => { loadQuotes(); loadSelected(); };
  $('cats').onclick = e => { const c = e.target.dataset.c; if (c) { st.cat = c; renderCats(); renderList(); } };
  $('list').onclick = e => {
    const rm = e.target.dataset.rm;
    if (rm) { st.watch = st.watch.filter(x => x !== rm); LS.set('km.watch', st.watch); if (st.sel === rm && st.watch.length) select(st.watch[0]); renderList(); e.stopPropagation(); return; }
    const el = e.target.closest('.asset'); if (el) select(el.dataset.id);
  };
  $('tfs').onclick = e => { const p = e.target.dataset.p; if (p) { st.period = p; LS.set('km.period', p); loadSelected(); } };
  $('mCandle').onclick = () => { st.mode = 'candle'; LS.set('km.mode', st.mode); renderHead(); renderChart(); };
  $('mLine').onclick = () => { st.mode = 'line'; LS.set('km.mode', st.mode); renderHead(); renderChart(); };
  $('mMa').onclick = () => { st.ma = !st.ma; LS.set('km.ma', st.ma); renderHead(); renderChart(); };
  $('ctools').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.ind) { st.ind[b.dataset.ind] = !st.ind[b.dataset.ind]; LS.set('km.ind', st.ind); }
    if (b.dataset.dm === 'x') { delete st.draws[st.sel]; LS.set('km.draw', st.draws); st.drawMode = null; }
    else if (b.dataset.dm) st.drawMode = st.drawMode === b.dataset.dm ? null : b.dataset.dm;
    if (st.drawMode && st.cmp) { st.cmp = ''; LS.set('km.cmp', ''); }
    renderTools(); renderChart();
  };
  $('ctools').onchange = e => { if (e.target.id === 'cmpSel') { st.cmp = e.target.value; LS.set('km.cmp', st.cmp); st.drawMode = null; renderTools(); loadCompare(); } };
  $('addBtn').onclick = () => { $('modal').hidden = false; $('q').value = ''; renderModal(); $('q').focus(); };
  $('mClose').onclick = () => { $('modal').hidden = true; };
  $('modal').onclick = e => { if (e.target.id === 'modal') $('modal').hidden = true; };
  $('q').oninput = renderModal;
  $('mlist').onclick = e => { const id = e.target.dataset.add; if (id) addWatch(id); };
  $('cAdd').onclick = addCustom; $('cSym').onkeydown = e => { if (e.key === 'Enter') addCustom(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { $('modal').hidden = true; if (st.drawMode) { st.drawMode = null; renderTools(); renderChart(); } } });
  function setTab(k) { st.tab = k; LS.set('km.tab', k); renderTabs(); if (k === 'C') KMAI.render(); }
  $('rtabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab); };
  $('wins').onclick = e => { const w = +e.target.dataset.w; if (w) { st.win = w; LS.set('km.win', w); renderNews(); loadNews(); } };
  $('nRefresh').onclick = loadNews;

  // ---------- help ----------
  function openHelp(sec) {
    const list = (window.KM_HELP || {})[st.lang] || [];
    $('hNav').innerHTML = list.map(([id, title]) => `<button data-h="${id}">${title}</button>`).join('');
    $('hBody').innerHTML = list.map(([id, title, html]) => `<section id="h-${id}"><h4>${title}</h4>${html}</section>`).join('');
    $('help').hidden = false;
    const go = id => { const el = document.getElementById('h-' + id); if (el) $('hBody').scrollTop = el.offsetTop - $('hBody').offsetTop; hiNav(id); };
    go(sec || 'start');
  }
  function hiNav(id) { $('hNav').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.h === id)); }
  $('hNav').onclick = e => { const id = e.target.dataset.h; if (!id) return; const el = document.getElementById('h-' + id); if (el) $('hBody').scrollTo({ top: el.offsetTop - $('hBody').offsetTop, behavior: 'smooth' }); hiNav(id); };
  $('hBody').onscroll = () => { let cur = null; $('hBody').querySelectorAll('section').forEach(s => { if (s.offsetTop - $('hBody').offsetTop <= $('hBody').scrollTop + 40) cur = s.id.slice(2); }); if (cur) hiNav(cur); };
  $('helpBtn').onclick = () => openHelp();
  $('aiHelp').onclick = () => openHelp('key');
  $('hClose').onclick = () => { $('help').hidden = true; };
  $('help').onclick = e => { if (e.target === $('help')) $('help').hidden = true; };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') $('help').hidden = true; if (e.key === 'F1') { e.preventDefault(); openHelp(); } });

  // Text size: A− / A+ zoom the whole window; remembered.
  const ZOOMS = [0.8, 0.9, 1, 1.1, 1.25, 1.4, 1.6, 1.8];
  let zi = Math.max(0, ZOOMS.indexOf(LS.get('km.zoom', 1))); if (ZOOMS[zi] == null) zi = 2;
  const setZoom = i => { zi = Math.max(0, Math.min(ZOOMS.length - 1, i)); LS.set('km.zoom', ZOOMS[zi]); KMNative.zoom(ZOOMS[zi]); $('zVal').textContent = Math.round(ZOOMS[zi] * 100) + '%'; };
  $('zIn').onclick = () => setZoom(zi + 1); $('zOut').onclick = () => setZoom(zi - 1);
  $('zVal').ondblclick = () => setZoom(2);
  setZoom(zi);

  // Drag the lines on both sides of the chart to resize the watchlist and the right side (analyzer / news / AI chat).
  (function () {
    const app = $('app');
    function setup(sp, v, key, fromLeftLtr, min, max) {
      const other = () => (v === '--rw' ? document.querySelector('aside') : document.querySelector('.right')).getBoundingClientRect().width;
      const lim = w => Math.round(Math.max(min, Math.min(w, window.innerWidth - other() - 420, max)));
      const apply = w => { if (w) app.style.setProperty(v, lim(w) + 'px'); else app.style.removeProperty(v); if (v === '--lw') app.classList.toggle('narrowL', document.querySelector('aside').getBoundingClientRect().width < 270); };
      apply(LS.get(key, 0));
      let on = false;
      sp.onpointerdown = e => { on = true; sp.setPointerCapture(e.pointerId); sp.classList.add('drag'); document.body.classList.add('resizing'); e.preventDefault(); };
      sp.onpointermove = e => { if (!on) return; const left = fromLeftLtr !== (st.lang === 'ar'); apply(left ? e.clientX : window.innerWidth - e.clientX); };
      sp.onpointerup = () => { if (!on) return; on = false; sp.classList.remove('drag'); document.body.classList.remove('resizing'); LS.set(key, Math.round(sp.parentElement.getBoundingClientRect().width)); };
      sp.ondblclick = () => { LS.set(key, 0); apply(0); };
      window.addEventListener('resize', () => { const w = LS.get(key, 0); if (w) apply(w); });
    }
    setup($('splitL'), '--lw', 'km.lw', true, 220, 600);
    setup($('split'), '--rw', 'km.rw', false, 280, 1100);
  })();

  // ---------- start ----------
  if (!byId(st.sel)) st.sel = 'gold';
  if (!PERIODS.includes(st.period)) st.period = '1M';
  if (!WINS.includes(st.win)) st.win = 60;
  if (!['A', 'N', 'C', 'L', 'P', 'K'].includes(st.tab)) st.tab = 'A';
  // Data for the daily brief: today's change of every market in the watchlist, plus the latest headlines of the first six.
  async function briefData() {
    const ids = st.watch.filter(byId), lang = st.lang;
    const markets = ids.map(id => { const a = byId(id), q = st.quotes[id], dl = KMNet.cached(a, '1Y'); const yc = dl && dl.candles && dl.candles.length > 6 ? dl.candles : null;
      return { name: a.en[0], price: q ? +(+q.price).toPrecision(7) : null, change_today_pct: q && isFinite(q.price / q.prev) ? +((q.price / q.prev - 1) * 100).toFixed(2) : null,
        change_1w_pct: q && yc ? +((q.price / yc[yc.length - 6].c - 1) * 100).toFixed(2) : null, market_hours: (h => h ? (h.always ? 'open 24/7' : h.daily ? 'one price per day' : h.open ? 'open' : 'closed') : null)(KMHours.forAsset(a)) }; });
    const heads = {};
    await Promise.all(ids.slice(0, 6).map(async id => { try { const n = await KMNews.headlines(byId(id), lang); heads[byId(id).en[0]] = n.items.slice(0, 4).map(x => ({ time: new Date(x.t).toString(), source: x.source, title: x.title })); } catch (e) { } }));
    return { note: 'Daily brief requested by the user. Use only this data and the snapshot.', markets, headlines_by_market: heads };
  }
  KMAI.init({ T, loc, name: () => nameOf(byId(st.sel)), snapshot, briefData });
  KMTools.init({ st, T, byId, all, nameOf, fmtA, nf, loc, LS, select, setTab, needQuotes: () => loadQuotes() });
  $('aBell').onclick = () => KMTools.quick(st.sel);
  applyLang(); renderAll();
  // show the last saved prices at once, then load fresh ones
  st.watch.concat(['gold', 'kwd']).forEach(id => { const a = byId(id); const c = a && KMNet.cached(a, '1D'); if (c) st.quotes[id] = c; });
  renderList();
  loadQuotes().then(() => setTimeout(() => KMAI.maybeAuto(), 4000)); loadSelected(); loadNews();
  setInterval(loadQuotes, 60000);
  setInterval(renderHours, 30000);
  setInterval(() => { if (Date.now() >= st.newsNext) loadNews(); else if (st.tab === 'N') renderNews(); }, 30000);
  setInterval(() => { if (!document.hidden && ['1D', '1W'].includes(st.period)) loadSelected(); }, 120000);
  window.KM_APP = { setInd: o => { st.ind = o; renderTools(); renderChart(); }, setCompare: id => { st.cmp = id; renderTools(); loadCompare(); }, st, setLang, openHelp, closeHelp: () => { $('help').hidden = true; }, select, setPeriod: p => { st.period = p; loadSelected(); }, setTab, setWin: w => { st.win = w; renderNews(); loadNews(); }, snapshot };
})();
