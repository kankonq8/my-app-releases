// Kankon Markets: AI assistant (Claude by Anthropic). The user enters their own Anthropic API key; it is kept
// only on this computer (in the app's own storage) and sent only to api.anthropic.com.
// Every question carries a snapshot of what the app shows right now (prices, analyzer, moves, headlines),
// so answers are about real numbers. By Kankon · kankon.net
(function () {
  const MODEL = 'claude-opus-5-5';
  const KEY = 'km.aikey';
  const SYSTEM = [
    'You are the AI assistant inside Kankon Markets, a desktop app that shows live market prices, charts, a rule-based rise/fall analyzer and news headlines. The user is in Kuwait.',
    'With each question you receive a data snapshot taken from the app at that moment (JSON). Rules:',
    '- Statements about current prices, recent moves and news must come from the snapshot. If the snapshot does not contain what is needed, say so plainly instead of guessing. Never invent prices, dates or events.',
    '- Headlines are titles only. Do not claim details that are not in a title. Mention the source when you rely on a headline.',
    '- You may use general market knowledge to explain possible reasons for a move, but present them as possible reasons, not facts.',
    '- Do not give buy or sell instructions or certain price targets. If asked whether to buy or sell, explain the factors and risks in the data and say that this is not financial advice.',
    '- Be concise: short paragraphs or a few bullet points, under about 250 words unless the user asks for more. Use plain text with simple Markdown only (**bold** and "- " bullets).',
    '- The snapshot may include my_portfolio (what the user owns, valued in KWD) and my_price_alerts. Use them when relevant.',
    '- For a daily brief (daily_brief_data present): start with one line on the overall mood, then one short bullet per market with its move today (and this week when given), then my portfolio change if present, then the 3 most important headlines with their source, then what to watch next. Keep it under about 300 words.',
    '- Reply in clear Modern Standard Arabic when the snapshot says the app language is Arabic or the user writes in Arabic; otherwise reply in English. Write numbers with Western digits.',
  ].join('\n');

  // Saved chats: every conversation is kept on this computer with the date and time of each message.
  const CHATS = 'km.chats', CUR = 'km.chatCur', MAXCHATS = 200;
  const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const store = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  let chats = load(CHATS, []);                 // [{id, t, u, market, msgs:[{role, content, shown, t, err}]}]
  let cur = chats.find(c => c.id === load(CUR, '')) || null;
  let hist = cur ? cur.msgs : [];
  let showHist = false;
  function save() {
    if (!hist.length) return;
    if (!cur) { cur = { id: 'c' + Date.now(), t: Date.now(), market: ctx.name(), msgs: hist }; chats.unshift(cur); }
    cur.u = Date.now();
    chats.sort((a, b) => (b.u || b.t) - (a.u || a.t));
    if (chats.length > MAXCHATS) chats = chats.slice(0, MAXCHATS);
    store(CHATS, chats); store(CUR, cur.id);
  }
  function newChat() { cur = null; hist = []; store(CUR, ''); showHist = false; render(); }
  function openChat(id) { const c = chats.find(x => x.id === id); if (!c) return; cur = c; hist = c.msgs; store(CUR, id); showHist = false; render(); }
  function delChat(id) { chats = chats.filter(x => x.id !== id); store(CHATS, chats); if (cur && cur.id === id) { cur = null; hist = []; store(CUR, ''); } render(); }
  const when = t => t ? new Date(t).toLocaleString(ctx.loc(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
  let busy = false;
  let ctx = null;  // { lang, T, nameOf, snapshot() }
  const $ = id => document.getElementById(id);
  const LSget = () => { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } };
  const LSset = v => { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch (e) { } };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // tiny Markdown: **bold**, "- " bullets, paragraphs
  function md(s) {
    const lines = esc(s).split('\n');
    let html = '', list = false;
    lines.forEach(l => {
      const b = l.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
      const m = b.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
      if (m) { if (!list) { html += '<ul>'; list = true; } html += `<li>${m[1]}</li>`; return; }
      if (list) { html += '</ul>'; list = false; }
      const h = b.replace(/^#{1,4}\s+/, '');
      if (h.trim()) html += `<p>${h}</p>`;
    });
    if (list) html += '</ul>';
    return html;
  }

  function render() {
    const t = ctx.T(), key = LSget();
    $('aiSetup').hidden = !!key; $('aiChat').hidden = !key;
    if (!key) return;
    const box = $('aiMsgs');
    $('aiChat').classList.toggle('hist', showHist);
    $('aiHist').textContent = showHist ? t.aiBack : t.aiHistBtn;
    if (showHist) {
      box.innerHTML = `<div class="hh">${esc(t.aiHistTitle)}</div>` + (chats.length ? chats.map(c => {
        const first = (c.msgs.find(m => m.role === 'user') || {}).shown || '';
        return `<div class="hi ${cur && cur.id === c.id ? 'on' : ''}" data-open="${c.id}"><div class="ht" dir="auto">${esc(first.length > 70 ? first.slice(0, 70) + '…' : first)}</div><small>${esc(c.market || '')} · ${esc(when(c.t))} · ${esc(t.aiCount.replace('{n}', c.msgs.length))}</small><button class="hx" data-del="${c.id}" title="${esc(t.aiDel)}">×</button></div>`;
      }).join('') : `<p class="small">${esc(t.aiHistNone)}</p>`);
      box.scrollTop = 0;
      return;
    }
    const msgs = hist.map(m => m.role === 'user'
      ? `<div class="msg me" dir="auto">${esc(m.shown || m.content)}<div class="mt">${esc(when(m.t))}</div></div>`
      : `<div class="msg bot ${m.err ? 'err' : ''}" dir="auto">${m.err ? esc(m.content) : md(m.content)}<div class="mt">${esc(when(m.t))}</div></div>`).join('');
    box.innerHTML = (hist.length ? '' : `<div class="msg bot hello">${esc(t.aiHello.replace('{name}', ctx.name()))}</div>`) + msgs + (busy ? `<div class="msg bot wait"><i></i><i></i><i></i> ${esc(t.aiThinking)}</div>` : '');
    box.scrollTop = box.scrollHeight;
    $('aiChips').innerHTML = t.aiChips.map((c, i) => `<button data-chip="${i}">${esc(c.replace('{name}', ctx.name()))}</button>`).join('');
    $('aiSend').disabled = busy;
    $('aiBrief').disabled = busy;
    $('aiBriefAuto').checked = !!load('km.briefAuto', false);
  }

  // Daily brief: one answer that sums up all my markets (today's moves, headlines, my portfolio and alerts).
  async function brief(auto) {
    if (busy || !LSget()) return;
    const t = ctx.T();
    newChat(); busy = true; render();
    let data = null;
    try { data = await ctx.briefData(); } catch (e) { }
    busy = false;
    store('km.briefDay', new Date().toDateString());
    ask(t.aiBriefQ, (auto ? '☀️ ' : '') + t.aiBriefShown, data);
  }
  function maybeAuto() {
    if (!LSget() || !load('km.briefAuto', false) || load('km.briefDay', '') === new Date().toDateString() || new Date().getHours() < 5) return;
    brief(true);
  }

  function errText(status, body) {
    const t = ctx.T();
    let msg = '';
    try { const j = JSON.parse(body); msg = (j.error && j.error.message) || ''; } catch (e) { }
    if (status === 0) return t.aiErrNet;
    if (status === 401) return t.aiErrKey;
    if (status === 400 && /credit/i.test(msg)) return t.aiErrCredit;
    if (status === 429) return t.aiErrLimit;
    if (status >= 500) return t.aiErrBusy;
    return t.aiErrOther + (msg ? ' (' + msg + ')' : ' (HTTP ' + status + ')');
  }

  async function ask(q, shown, extra) {
    q = (q || '').trim(); if (!q || busy) return;
    const key = LSget(); if (!key) return;
    let snap = {};
    try { snap = ctx.snapshot(); } catch (e) { }
    if (extra) snap.daily_brief_data = extra;
    const prior = hist.filter(m => !m.err).slice(-8).map(m => ({ role: m.role, content: m.content }));
    // keep the history starting with a user turn
    while (prior.length && prior[0].role !== 'user') prior.shift();
    hist.push({ role: 'user', content: q, shown: shown || q, t: Date.now() });
    save(); busy = true; render();
    const messages = prior.concat([{ role: 'user', content: 'App data snapshot (JSON):\n' + JSON.stringify(snap) + '\n\nQuestion: ' + q }]);
    const body = JSON.stringify({ model: MODEL, max_tokens: 16000, system: SYSTEM, messages });
    const mine = hist;
    const r = await KMNative.ai(body, key);
    busy = false;
    const add = m => { m.t = Date.now(); mine.push(m); };
    if (r.status === 200) {
      let j = null; try { j = JSON.parse(r.body); } catch (e) { }
      const txt = j && Array.isArray(j.content) ? j.content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim() : '';
      if (j && j.stop_reason === 'refusal') add({ role: 'assistant', content: ctx.T().aiRefused, err: true });
      else if (!txt) add({ role: 'assistant', content: ctx.T().aiErrOther, err: true });
      else add({ role: 'assistant', content: txt + (j.stop_reason === 'max_tokens' ? '\n\n' + ctx.T().aiCut : '') });
    } else {
      add({ role: 'assistant', content: errText(r.status, r.body), err: true });
    }
    save(); render();
  }

  function init(c) {
    ctx = c;
    $('aiSave').onclick = () => {
      const v = $('aiKey').value.trim();
      if (!/^sk-ant-[A-Za-z0-9_\-]{20,}$/.test(v)) { $('aiKeyErr').textContent = ctx.T().aiKeyBad; return; }
      $('aiKeyErr').textContent = ''; $('aiKey').value = ''; LSset(v); render();
    };
    $('aiKey').onkeydown = e => { if (e.key === 'Enter') $('aiSave').onclick(); };
    $('aiForget').onclick = () => { LSset(''); render(); };   // saved chats stay
    $('aiClear').onclick = newChat;
    $('aiBrief').onclick = () => brief(false);
    $('aiBriefAuto').onchange = e => store('km.briefAuto', e.target.checked);
    $('aiHist').onclick = () => { showHist = !showHist; render(); };
    $('aiMsgs').onclick = e => {
      const d = e.target.dataset.del; if (d) { delChat(d); e.stopPropagation(); return; }
      const el = e.target.closest('[data-open]'); if (el) openChat(el.dataset.open);
    };
    $('aiSend').onclick = () => { const q = $('aiQ').value; $('aiQ').value = ''; ask(q); };
    $('aiQ').onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('aiSend').onclick(); } };
    $('aiChips').onclick = e => { const i = e.target.dataset.chip; if (i != null) { const s = ctx.T().aiChips[i].replace('{name}', ctx.name()); ask(s, s); } };
    render();
  }

  window.KMAI = { init, render, ask, brief, maybeAuto, hasKey: () => !!LSget(), model: MODEL };
})();
