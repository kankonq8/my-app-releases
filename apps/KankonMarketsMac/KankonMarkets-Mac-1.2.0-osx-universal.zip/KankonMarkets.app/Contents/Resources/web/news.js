// Kankon Markets: news headlines and "what happened in the last 15 min / 30 min / 1 hour / 4 hours".
// Headlines come from Google News (Bing News if Google does not answer). The movement summary is
// calculated only from real 5-minute prices (Yahoo Finance); nothing is invented.
(function () {
  // What to search for, per market: [English, Arabic].
  const Q = {
    gold: ['gold price', 'أسعار الذهب'], silver: ['silver price', 'أسعار الفضة'], platinum: ['platinum price', 'أسعار البلاتين'],
    copper: ['copper price', 'أسعار النحاس'], palladium: ['palladium price', 'أسعار البلاديوم'],
    kec: ['Kuwait oil price', 'سعر برميل النفط الكويتي'], wti: ['WTI crude oil price', 'أسعار النفط خام غرب تكساس'],
    brent: ['Brent crude oil price', 'أسعار النفط برنت'], natgas: ['natural gas prices', 'أسعار الغاز الطبيعي'],
    heating: ['heating oil futures', 'أسعار زيت التدفئة'],
    btc: ['bitcoin price', 'سعر البيتكوين'], eth: ['ethereum price', 'سعر الإيثيريوم'], sol: ['solana price', 'سعر سولانا'],
    xrp: ['XRP price', 'سعر XRP'], bnb: ['BNB price', 'سعر BNB'], doge: ['dogecoin price', 'سعر دوجكوين'],
    kwd: ['Kuwaiti dinar dollar', 'الدينار الكويتي الدولار'], eur: ['euro dollar exchange rate', 'سعر اليورو مقابل الدولار'],
    gbp: ['British pound dollar', 'الجنيه الإسترليني الدولار'], jpy: ['Japanese yen dollar', 'الين الياباني الدولار'],
    sar: ['Saudi riyal dollar', 'الريال السعودي الدولار'], aed: ['UAE dirham dollar', 'الدرهم الإماراتي الدولار'],
    egp: ['Egyptian pound dollar', 'الجنيه المصري الدولار'],
    spx: ['S&P 500', 'مؤشر ستاندرد آند بورز 500'], ndx: ['Nasdaq index', 'مؤشر ناسداك'], dji: ['Dow Jones', 'مؤشر داو جونز'],
    nikkei: ['Nikkei 225', 'مؤشر نيكاي'], ftse: ['FTSE 100', 'مؤشر فوتسي 100'],
  };
  const query = (a, lang) => { const q = Q[a.id] || [a.sym || a.en[0], a.sym || a.ar[0]]; return lang === 'ar' ? q[1] : q[0]; };

  const text = (el, tag) => { const x = el.getElementsByTagName(tag)[0]; return x ? x.textContent.trim() : ''; };
  function parse(xml, bing) {
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    return Array.from(doc.getElementsByTagName('item')).map(it => {
      let title = text(it, 'title'), link = text(it, 'link'), source = text(it, 'source');
      const t = Date.parse(text(it, 'pubDate'));
      if (!bing && source && title.endsWith(' - ' + source)) title = title.slice(0, -(source.length + 3));
      if (bing) {
        try { const u = new URL(link).searchParams.get('url'); if (u) link = u; } catch (e) { }
        try { source = source || new URL(link).hostname.replace(/^www\./, ''); } catch (e) { }
      }
      return { title, link, source, t };
    }).filter(x => x.title && x.link && /^https:\/\//.test(x.link) && isFinite(x.t));
  }

  // headlines(asset, lang) -> newest first, last 24 hours (or the newest ones if the day was quiet)
  async function headlines(a, lang) {
    const q = query(a, lang);
    const g = lang === 'ar' ? '&hl=ar&gl=SA&ceid=SA:ar' : '&hl=en-US&gl=US&ceid=US:en';
    let items = [], source = 'Google News';
    try { items = parse(await KMNative.get('https://news.google.com/rss/search?q=' + encodeURIComponent('"' + q + '" when:1d') + g), false); } catch (e) { }
    if (!items.length) {
      try { items = parse(await KMNative.get('https://www.bing.com/news/search?format=rss&q=' + encodeURIComponent(q) + (lang === 'ar' ? '&setlang=ar&cc=SA' : '&setlang=en&cc=US')), true); source = 'Bing News'; } catch (e) { }
    }
    const seen = {};
    items = items.filter(x => { const k = x.title.toLowerCase(); if (seen[k]) return false; seen[k] = 1; return true; }).sort((x, y) => y.t - x.t);
    return { items: items.slice(0, 30), source, query: q };
  }

  // move(candles5m, minutes) -> the price change over the last N minutes of trading.
  function move(cs, mins) {
    if (!cs || cs.length < 2) return null;
    const last = cs[cs.length - 1], from = last.t - mins * 60000;
    let bi = -1;
    for (let i = cs.length - 1; i >= 0; i--) if (cs[i].t <= from) { bi = i; break; }
    if (bi < 0) return null;
    const win = cs.slice(bi + 1);
    const start = cs[bi].c, end = last.c;
    const hi = Math.max(...win.map(c => c.h)), lo = Math.min(...win.map(c => c.l));
    let big = null;
    win.forEach((c, i) => { const p = (i ? win[i - 1].c : start); const d = c.c - p; if (!big || Math.abs(d) > Math.abs(big.d)) big = { d, pct: d / p * 100, t: c.t }; });
    return { mins, start, end, ch: end - start, pct: (end - start) / start * 100, hi, lo, big, lastT: last.t, closed: Date.now() - last.t > 25 * 60000 };
  }

  // write(move, name, lang, fmt, timeFmt, label) -> paragraphs
  function write(m, name, lang, fmt, tf, label) {
    const fmt0 = fmt;
    const ar = lang === 'ar';
    const pc = v => (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(2) + '%';
    const amt = v => (v > 0 ? '+' : v < 0 ? '−' : '') + fmt0(Math.abs(v));
    const out = [];
    if (ar) { const f0 = fmt; fmt = v => `<bdi dir="ltr">${f0(v)}</bdi>`; }
    const flat = Math.abs(m.pct) < 0.05;
    if (ar) {
      out.push(flat
        ? `خلال ${label}، بقي سعر ${name} شبه ثابت عند <b>${fmt(m.end)}</b> (بتغيّر <b><bdi dir="ltr">${pc(m.pct)}</bdi></b>).`
        : `خلال ${label}، ${m.ch > 0 ? 'ارتفع' : 'انخفض'} سعر ${name} بنسبة <b class="${m.ch > 0 ? 'up' : 'dn'}"><bdi dir="ltr">${pc(m.pct)}</bdi></b> (<bdi dir="ltr">${amt(m.ch)}</bdi>)، من ${fmt(m.start)} إلى <b>${fmt(m.end)}</b>.`);
      out.push(`تحرّك السعر في هذه الفترة بين ${fmt(m.lo)} و${fmt(m.hi)}.` + (m.big && Math.abs(m.big.pct) >= 0.05 ? ` وكانت أكبر حركة خلال 5 دقائق <bdi dir="ltr">${pc(m.big.pct)}</bdi> عند الساعة ${tf(m.big.t)}.` : ''));
      if (m.closed) out.push(`<span class="warn">السوق مغلق الآن، وهذه الأرقام تخص آخر فترة تداول حتى الساعة ${tf(m.lastT)}.</span>`);
    } else {
      out.push(flat
        ? `Over the ${label}, ${name} was almost flat at <b>${fmt(m.end)}</b> (<b>${pc(m.pct)}</b>).`
        : `Over the ${label}, ${name} ${m.ch > 0 ? 'rose' : 'fell'} <b class="${m.ch > 0 ? 'up' : 'dn'}">${pc(m.pct)}</b> (${amt(m.ch)}), from ${fmt(m.start)} to <b>${fmt(m.end)}</b>.`);
      out.push(`In this period the price moved between ${fmt(m.lo)} and ${fmt(m.hi)}.` + (m.big && Math.abs(m.big.pct) >= 0.05 ? ` The biggest 5-minute move was ${pc(m.big.pct)} at ${tf(m.big.t)}.` : ''));
      if (m.closed) out.push(`<span class="warn">The market is closed now. These figures cover the last trading period, up to ${tf(m.lastT)}.</span>`);
    }
    return out;
  }

  window.KMNews = { headlines, move, write, query };
})();
