// Kankon Markets: Alerts, My Portfolio and Calculator (right side tabs). Everything is saved only on this computer.
// Values come only from the live prices the app already loads (Yahoo Finance); nothing is invented. By Kankon · kankon.net
(function () {
  let C = null;            // context from app.js: { st, T, byId, all, nameOf, fmtA, nf, loc, LS, select }
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const OZ = 31.1034768, LB_KG = 2.20462262;
  const FX = ['kwd', 'eur', 'gbp', 'jpy', 'sar', 'aed', 'egp'];
  // US dollars for one unit of each currency (from the live rates).
  const CUR = { USD: () => 1, KWD: q => 1 / q.kwd, EUR: q => q.eur, GBP: q => q.gbp, JPY: q => 1 / q.jpy, SAR: q => 1 / q.sar, AED: q => 1 / q.aed, EGP: q => 1 / q.egp };
  let alerts = [], hold = [], fired = [], calc = {};
  const px = id => { const q = C.st.quotes[id]; return q && isFinite(q.price) ? q.price : NaN; };
  const prevPx = id => { const q = C.st.quotes[id]; return q && isFinite(q.prev) ? q.prev : NaN; };
  const rates = () => { const r = {}; FX.forEach(id => r[id] = px(id)); return r; };
  const kwdRate = () => px('kwd');                     // Kuwaiti dinars for 1 US dollar
  const sg = v => v > 0 ? '+' : v < 0 ? '−' : '';
  // KWD amount as HTML: the number stays left-to-right inside Arabic text
  const fmtK = (v, signed) => isFinite(v) ? `<bdi dir="ltr">${signed ? sg(v) : ''}${C.nf(signed ? Math.abs(v) : v, 3)}</bdi> ${C.T().kwd}` : '—';
  const qtyS = v => (+v).toLocaleString('en-US', { maximumFractionDigits: 8 });
  const fmtU = v => isFinite(v) ? '$' + C.nf(v, 2) : '—';
  const pctS = v => isFinite(v) ? (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(2) + '%' : '';
  const cls = v => v > 0 ? 'up' : v < 0 ? 'dn' : '';
  const bdi = s => `<bdi dir="ltr">${s}</bdi>`;
  const save = () => { C.LS.set('km.alerts', alerts); C.LS.set('km.hold', hold); C.LS.set('km.fired', fired); C.LS.set('km.calc', calc); };

  // ---------- units for My Portfolio ----------
  function units(a) {
    const t = C.T();
    if (!a) return [];
    if (a.id === 'gold') return [['g24', t.uG24], ['g22', t.uG22], ['g21', t.uG21], ['g18', t.uG18], ['oz', t.uOz]];
    if (['silver', 'platinum', 'palladium'].includes(a.id)) return [['g', t.uG], ['oz', t.uOz]];
    if (a.id === 'copper') return [['kg', t.uKg], ['lb', t.uLb]];
    if (a.id === 'kwd') return [['u', 'USD']];
    if (a.cat === 'fx') return [['u', (a.en[1] || '').split('/')[a.id === 'eur' || a.id === 'gbp' ? 0 : 1] || '']];
    if (a.cat === 'energy') return [['u', a.id === 'natgas' ? 'MMBtu' : a.id === 'heating' ? t.uGal : t.uBbl]];
    return [['u', t.uUnit]];
  }
  const canHold = a => a && a.cat !== 'indices' && (a.cat !== 'custom' || a.cur === 'USD');
  // value in US dollars of qty units of market a, at price p
  function usdValue(a, qty, unit, p) {
    if (!isFinite(p) || !isFinite(qty)) return NaN;
    const k = { g24: 1, g22: 22 / 24, g21: 21 / 24, g18: 18 / 24, g: 1 };
    if (unit in k) return qty / OZ * p * k[unit];
    if (unit === 'kg') return qty * LB_KG * p;
    if (a.cat === 'fx') {
      if (a.id === 'kwd') return qty;                         // US dollars
      if (a.id === 'eur' || a.id === 'gbp') return qty * p;   // EUR/USD, GBP/USD
      return qty / p;                                          // USD/JPY, USD/SAR ...
    }
    return qty * p;
  }
  function holdingRow(h) {
    const a = C.byId(h.aid); if (!a) return null;
    const p = px(a.id), pp = prevPx(a.id), r = kwdRate();
    const usd = usdValue(a, h.qty, h.unit, p), usdPrev = usdValue(a, h.qty, h.unit, pp);
    const kwd = usd * r, kwdPrev = usdPrev * r;
    const cost = isFinite(h.cost) && h.cost > 0 ? h.cost : NaN;
    return { h, a, usd, kwd, day: kwd - kwdPrev, pl: kwd - cost, plPct: (kwd / cost - 1) * 100, cost };
  }

  // ---------- Alerts ----------
  function check() {
    let changed = false;
    const today = new Date().toDateString();
    alerts.forEach(x => {
      if (!x.on) return;
      const a = C.byId(x.aid); if (!a) return;
      const p = px(a.id), pp = prevPx(a.id); if (!isFinite(p)) return;
      let hit = false, pct = (p / pp - 1) * 100;
      if (x.kind === 'above') hit = p >= x.v;
      else if (x.kind === 'below') hit = p <= x.v;
      else if (x.kind === 'move') hit = isFinite(pct) && Math.abs(pct) >= x.v && x.day !== today;
      if (!hit) return;
      changed = true;
      if (x.kind === 'move') x.day = today; else x.on = false;   // price alerts ring once; a move alert once a day
      const t = C.T(), name = C.nameOf(a);
      const msg = x.kind === 'move'
        ? t.alMsgMove.replace('{name}', name).replace('{pct}', pctS(pct)).replace('{price}', C.fmtA(a, p))
        : t.alMsgPrice.replace('{name}', name).replace('{dir}', x.kind === 'above' ? t.alHitAbove : t.alHitBelow).replace('{v}', C.fmtA(a, x.v)).replace('{price}', C.fmtA(a, p));
      fired.unshift({ t: Date.now(), aid: a.id, msg });
      if (fired.length > 50) fired.length = 50;
      toast(msg);
      KMNative.notify('Kankon Markets', msg);
    });
    if (changed) { save(); render(); }
  }
  function toast(msg) {
    const d = document.createElement('div');
    d.className = 'toast'; d.setAttribute('dir', 'auto');
    d.innerHTML = `<b>🔔</b> <span>${esc(msg)}</span><button>×</button>`;
    d.querySelector('button').onclick = () => d.remove();
    $('toasts').appendChild(d);
    setTimeout(() => d.remove(), 30000);
  }
  function addAlert() {
    const t = C.T(), aid = $('alA').value, kind = $('alK').value, v = parseFloat(String($('alV').value).replace(/,/g, ''));
    if (!C.byId(aid) || !(v > 0)) { $('alErr').textContent = t.alBad; return; }
    $('alErr').textContent = '';
    alerts.unshift({ id: 'a' + Date.now(), aid, kind, v, on: true, t: Date.now() });
    $('alV').value = ''; save(); render(); C.needQuotes();
  }

  // ---------- render ----------
  const opts = (list, sel) => list.map(([v, l]) => `<option value="${esc(v)}" ${v === sel ? 'selected' : ''}>${esc(l)}</option>`).join('');
  const markets = filter => C.all().filter(filter || (() => true)).map(a => [a.id, C.nameOf(a)]);

  function renderAlerts() {
    const t = C.T(), sel = C.st.sel;
    const a0 = C.byId($('alA') && $('alA').value) || C.byId(sel);
    const kind = ($('alK') && $('alK').value) || 'above';
    $('paneL').innerHTML = `
      <div class="card"><h3>${esc(t.alNew)}</h3>
        <div class="frm">
          <label>${esc(t.market)}<select id="alA">${opts(markets(), a0.id)}</select></label>
          <label>${esc(t.alWhen)}<select id="alK">${opts([['above', t.alAbove], ['below', t.alBelow], ['move', t.alMove]], kind)}</select></label>
          <label>${esc(kind === 'move' ? t.alPct : t.alPrice)}<input id="alV" inputmode="decimal" dir="ltr" placeholder="${kind === 'move' ? '2' : esc(isFinite(px(a0.id)) ? (+px(a0.id).toPrecision(6)).toString() : '')}"></label>
          <button class="tf on" id="alAdd">${esc(t.alAddBtn)}</button>
        </div>
        <div class="small">${esc(t.alNow)}: <b>${bdi(isFinite(px(a0.id)) ? C.fmtA(a0, px(a0.id)) : '—')}</b></div>
        <div class="small err" id="alErr"></div>
      </div>
      <div class="card"><h3>${esc(t.alList)}</h3>${alerts.length ? alerts.map(x => {
        const a = C.byId(x.aid); if (!a) return '';
        const what = x.kind === 'move' ? `${t.alMoveL} ${bdi(x.v + '%')}` : `${x.kind === 'above' ? t.alAbove : t.alBelow} ${bdi(C.fmtA(a, x.v))}`;
        return `<div class="li ${x.on ? '' : 'off'}"><div class="nm"><b>${esc(C.nameOf(a))}</b><small>${what} · ${esc(t.alNow)} ${bdi(C.fmtA(a, px(a.id)))}</small></div>
          <button class="mini" data-al-tog="${x.id}">${esc(x.on ? t.alOn : t.alOff)}</button><button class="x sm" data-al-del="${x.id}" title="${esc(t.alDel)}">×</button></div>`;
      }).join('') : `<p class="small">${esc(t.alNone)}</p>`}</div>
      <div class="card"><h3>${esc(t.alFired)}</h3>${fired.length ? fired.slice(0, 15).map(f => `<div class="li"><div class="nm"><small>${esc(new Date(f.t).toLocaleString(C.loc(), { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }))}</small><span dir="auto">${esc(f.msg)}</span></div></div>`).join('') : `<p class="small">${esc(t.alFiredNone)}</p>`}</div>
      <div class="disc">${esc(t.alNote)}</div>`;
    $('alA').onchange = renderAlerts; $('alK').onchange = renderAlerts;
    $('alAdd').onclick = addAlert; $('alV').onkeydown = e => { if (e.key === 'Enter') addAlert(); };
  }

  function renderPortfolio() {
    const t = C.T(), r = kwdRate();
    const rows = hold.map(holdingRow).filter(Boolean);
    const tot = rows.reduce((s, x) => s + (isFinite(x.kwd) ? x.kwd : 0), 0);
    const day = rows.reduce((s, x) => s + (isFinite(x.day) ? x.day : 0), 0);
    const withCost = rows.filter(x => isFinite(x.cost) && isFinite(x.kwd));
    const cost = withCost.reduce((s, x) => s + x.cost, 0), costVal = withCost.reduce((s, x) => s + x.kwd, 0);
    const a0 = C.byId($('pfA') && $('pfA').value) || (canHold(C.byId(C.st.sel)) ? C.byId(C.st.sel) : C.byId('gold'));
    const u0 = ($('pfU') && $('pfU').value) || '';
    const us = units(a0);
    $('paneP').innerHTML = `
      <div class="card tot"><h3>${esc(t.pfTotal)}</h3>
        <div class="big">${rows.length && isFinite(r) ? fmtK(tot) : '—'}</div>
        <div class="small">${bdi(isFinite(r) && rows.length ? fmtU(tot / r) : '')}</div>
        <div class="kv"><span>${esc(t.pfToday)}</span><b class="${cls(day)}">${rows.length ? fmtK(day, true) : '—'}</b></div>
        ${withCost.length ? `<div class="kv"><span>${esc(t.pfPL)}</span><b class="${cls(costVal - cost)}">${fmtK(costVal - cost, true)} ${bdi('(' + pctS((costVal / cost - 1) * 100) + ')')}</b></div>` : ''}
      </div>
      <div class="card"><h3>${esc(t.pfList)}</h3>${rows.length ? rows.map(x => `
        <div class="li"><div class="nm"><b>${esc(C.nameOf(x.a))}</b><small>${bdi(qtyS(x.h.qty))} ${esc((units(x.a).find(u => u[0] === x.h.unit) || ['', ''])[1])} · ${bdi(C.fmtA(x.a, px(x.a.id)))}</small></div>
          <div class="pv"><b>${fmtK(x.kwd)}</b><small class="${cls(x.day)}">${isFinite(x.day) ? bdi(sg(x.day) + C.nf(Math.abs(x.day), 3)) + ' ' + t.pfDay : ''}</small>${isFinite(x.cost) ? `<small class="${cls(x.pl)}">${t.pfPLs} ${bdi(sg(x.pl) + C.nf(Math.abs(x.pl), 3))} ${bdi('(' + pctS(x.plPct) + ')')}</small>` : ''}</div>
          <button class="x sm" data-pf-del="${x.h.id}" title="${esc(t.alDel)}">×</button></div>`).join('') : `<p class="small">${esc(t.pfNone)}</p>`}</div>
      <div class="card"><h3>${esc(t.pfAdd)}</h3>
        <div class="frm">
          <label>${esc(t.market)}<select id="pfA">${opts(markets(canHold), a0.id)}</select></label>
          <label>${esc(t.pfQty)}<input id="pfQ" inputmode="decimal" dir="ltr" placeholder="10"></label>
          <label>${esc(t.pfUnit)}<select id="pfU">${opts(us, us.some(u => u[0] === u0) ? u0 : us[0][0])}</select></label>
          <label>${esc(t.pfCost)}<input id="pfC" inputmode="decimal" dir="ltr" placeholder="${esc(t.pfOptional)}"></label>
          <button class="tf on" id="pfAdd">${esc(t.alAddBtn)}</button>
        </div>
        <div class="small err" id="pfErr"></div>
        <div class="small">${esc(t.pfNote)}</div>
      </div>
      <div class="disc">${esc(t.pfDisc)}</div>`;
    $('pfA').onchange = renderPortfolio;
    $('pfAdd').onclick = () => {
      const aid = $('pfA').value, qty = parseFloat(String($('pfQ').value).replace(/,/g, '')), c = parseFloat(String($('pfC').value).replace(/,/g, ''));
      if (!C.byId(aid) || !(qty > 0)) { $('pfErr').textContent = t.pfBad; return; }
      hold.push({ id: 'h' + Date.now(), aid, qty, unit: $('pfU').value, cost: c > 0 ? c : null, t: Date.now() });
      save(); renderPortfolio(); C.needQuotes();
    };
  }

  function renderCalc() {
    const t = C.T(), q = rates();
    const curs = Object.keys(CUR);
    const amt = calc.amt != null ? calc.amt : 100, from = calc.from || 'KWD', to = calc.to || 'USD';
    const res = amt * CUR[from](q) / CUR[to](q);
    const one = CUR[from](q) / CUR[to](q);
    const g = C.st.quotes.gold, s = C.st.quotes.silver, r = kwdRate();
    const metal = calc.metal || 'gold', grams = calc.g != null ? calc.g : 10, kar = calc.k || 21, make = calc.mk != null ? calc.mk : 0;
    const perOz = metal === 'gold' ? (g && g.price) : (s && s.price);
    const pure = metal === 'gold' ? kar / 24 : 1;
    const perG = perOz / OZ * r * pure;
    const metalVal = perG * grams, makeVal = make * grams;
    const assets = markets(a => canHold(a));
    const ma = C.byId(calc.ma) || C.byId('btc'), mq = calc.mq != null ? calc.mq : 1, mu = calc.mu || units(ma)[0][0];
    const mUsd = usdValue(ma, mq, units(ma).some(u => u[0] === mu) ? mu : units(ma)[0][0], px(ma.id));
    $('paneK').innerHTML = `
      <div class="card"><h3>${esc(t.ckCur)}</h3>
        <div class="frm">
          <label>${esc(t.ckAmt)}<input id="ckA" inputmode="decimal" dir="ltr" value="${amt}"></label>
          <label>${esc(t.ckFrom)}<select id="ckF">${opts(curs.map(c => [c, c + ' · ' + t.curN[c]]), from)}</select></label>
          <button class="mini swap" id="ckS" title="${esc(t.ckSwap)}">⇅</button>
          <label>${esc(t.ckTo)}<select id="ckT">${opts(curs.map(c => [c, c + ' · ' + t.curN[c]]), to)}</select></label>
        </div>
        <div class="res">${bdi(isFinite(res) ? C.nf(res, to === 'KWD' ? 3 : to === 'JPY' ? 0 : 2) + ' ' + to : '—')}</div>
        <div class="small">${bdi(isFinite(one) ? '1 ' + from + ' = ' + C.nf(one, one < 0.01 ? 6 : 4) + ' ' + to : '')}</div>
      </div>
      <div class="card"><h3>${esc(t.ckGold)}</h3>
        <div class="frm">
          <label>${esc(t.ckMetal)}<select id="ckM">${opts([['gold', t.gold], ['silver', t.silver]], metal)}</select></label>
          <label>${esc(t.ckGrams)}<input id="ckG" inputmode="decimal" dir="ltr" value="${grams}"></label>
          ${metal === 'gold' ? `<label>${esc(t.ckKarat)}<select id="ckK">${opts([[24, '24'], [22, '22'], [21, '21'], [18, '18']].map(([v, l]) => [String(v), l]), String(kar))}</select></label>` : ''}
          <label>${esc(t.ckMake)}<input id="ckMk" inputmode="decimal" dir="ltr" value="${make}"></label>
        </div>
        <div class="kv"><span>${esc(t.ckPerG)}</span><b>${fmtK(perG)}</b></div>
        <div class="kv"><span>${esc(t.ckMetalVal)}</span><b>${fmtK(metalVal)}</b></div>
        <div class="kv"><span>${esc(t.ckMakeVal)}</span><b>${fmtK(makeVal)}</b></div>
        <div class="res">${fmtK(metalVal + makeVal)}</div>
        <div class="small">${esc(t.ckGoldNote)}</div>
      </div>
      <div class="card"><h3>${esc(t.ckVal)}</h3>
        <div class="frm">
          <label>${esc(t.market)}<select id="ckVA">${opts(assets, ma.id)}</select></label>
          <label>${esc(t.pfQty)}<input id="ckVQ" inputmode="decimal" dir="ltr" value="${mq}"></label>
          <label>${esc(t.pfUnit)}<select id="ckVU">${opts(units(ma), mu)}</select></label>
        </div>
        <div class="res">${fmtK(mUsd * r)}</div>
        <div class="small">${bdi(fmtU(mUsd))}</div>
      </div>
      <div class="disc">${esc(t.ckNote)}</div>`;
    const num = id => { const v = parseFloat(String($(id).value).replace(/,/g, '')); return isFinite(v) && v >= 0 ? v : 0; };
    const upd = (k, id, f) => { $(id).oninput = $(id).onchange = () => { calc[k] = f ? f($(id).value) : num(id); C.LS.set('km.calc', calc); const fo = document.activeElement && document.activeElement.id; const pos = document.activeElement && document.activeElement.selectionStart; renderCalc(); if (fo && $(fo)) { $(fo).focus(); try { if (pos != null) $(fo).setSelectionRange(pos, pos); } catch (e) { } } }; };
    upd('amt', 'ckA'); upd('from', 'ckF', v => v); upd('to', 'ckT', v => v); upd('metal', 'ckM', v => v); upd('g', 'ckG'); upd('mk', 'ckMk');
    if ($('ckK')) upd('k', 'ckK', v => +v);
    upd('ma', 'ckVA', v => { calc.mu = null; return v; }); upd('mq', 'ckVQ'); upd('mu', 'ckVU', v => v);
    $('ckS').onclick = () => { calc.from = to; calc.to = from; C.LS.set('km.calc', calc); renderCalc(); };
  }

  function render() {
    if (!C) return;
    const k = C.st.tab;
    if (k === 'L') renderAlerts(); else if (k === 'P') renderPortfolio(); else if (k === 'K') renderCalc();
    const n = alerts.filter(x => x.on).length;
    const b = document.querySelector('#rtabs [data-tab="L"]');
    if (b) b.innerHTML = esc(C.T().tabL) + (n ? ` <i class="cnt">${n}</i>` : '');
  }

  function init(ctx) {
    C = ctx;
    alerts = C.LS.get('km.alerts', []); hold = C.LS.get('km.hold', []); fired = C.LS.get('km.fired', []); calc = C.LS.get('km.calc', {});
    $('paneL').onclick = e => {
      const tg = e.target.dataset.alTog, del = e.target.dataset.alDel;
      if (tg) { const x = alerts.find(a => a.id === tg); if (x) { x.on = !x.on; x.day = null; } save(); render(); }
      if (del) { alerts = alerts.filter(a => a.id !== del); save(); render(); }
    };
    $('paneP').onclick = e => { const del = e.target.dataset.pfDel; if (del) { hold = hold.filter(h => h.id !== del); save(); render(); } };
  }
  // Quick alert for the market on screen (bell next to the price).
  function quick(aid) {
    C.setTab('L');
    if ($('alA')) { $('alA').value = aid; renderAlerts(); const p = px(aid); if (isFinite(p)) $('alV').value = (+p.toPrecision(6)).toString(); $('alV').focus(); $('alV').select(); }
  }
  // Markets whose prices the tools need, besides the watchlist.
  const need = () => Array.from(new Set(FX.concat(['gold', 'silver'], alerts.filter(x => x.on).map(x => x.aid), hold.map(h => h.aid), calc.ma ? [calc.ma] : ['btc'])));
  // For the AI assistant: the user's portfolio (only if they have one).
  function snapshot() {
    const rows = hold.map(holdingRow).filter(Boolean);
    if (!rows.length) return null;
    return rows.map(x => ({ market: x.a.en[0], quantity: x.h.qty, unit: x.h.unit, value_kwd: isFinite(x.kwd) ? +x.kwd.toFixed(3) : null, change_today_kwd: isFinite(x.day) ? +x.day.toFixed(3) : null, cost_kwd: isFinite(x.cost) ? x.cost : null }));
  }
  window.KMTools = { init, render, check, need, quick, snapshot, usdValue, units, get alerts() { return alerts; }, get hold() { return hold; } };
})();
