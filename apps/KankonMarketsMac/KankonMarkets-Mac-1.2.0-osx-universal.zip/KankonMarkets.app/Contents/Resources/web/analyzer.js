// Kankon Markets: the rise/fall analyzer. Everything it says comes from the price history (daily candles):
// moving averages, RSI, MACD, trend line, support/resistance and volatility. It does not guess the future.
(function () {
  const sma = (a, n, end = a.length) => end < n ? NaN : a.slice(end - n, end).reduce((s, x) => s + x, 0) / n;
  function emaArr(a, n) { const k = 2 / (n + 1); const out = []; let e = a[0]; a.forEach((x, i) => { e = i ? x * k + e * (1 - k) : x; out.push(e); }); return out; }
  function rsi(c, n = 14) {
    if (c.length <= n) return NaN;
    let g = 0, l = 0;
    for (let i = 1; i <= n; i++) { const d = c[i] - c[i - 1]; d > 0 ? g += d : l -= d; }
    g /= n; l /= n;
    for (let i = n + 1; i < c.length; i++) { const d = c[i] - c[i - 1]; g = (g * (n - 1) + Math.max(d, 0)) / n; l = (l * (n - 1) + Math.max(-d, 0)) / n; }
    return l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  function slopePct(c, n) { // linear regression over the last n closes, as % change across those n days
    const y = c.slice(-n); if (y.length < n) return NaN;
    const mx = (n - 1) / 2, my = y.reduce((s, v) => s + v, 0) / n;
    let num = 0, den = 0; y.forEach((v, i) => { num += (i - mx) * (v - my); den += (i - mx) ** 2; });
    return (num / den) * (n - 1) / my * 100;
  }
  function levels(cs, p) {
    const r = cs.slice(-120), lows = [], highs = [];
    for (let i = 3; i < r.length - 3; i++) {
      const w = r.slice(i - 3, i + 4);
      if (r[i].l === Math.min(...w.map(x => x.l))) lows.push(r[i].l);
      if (r[i].h === Math.max(...w.map(x => x.h))) highs.push(r[i].h);
    }
    const below = lows.filter(v => v < p * 0.998), above = highs.filter(v => v > p * 1.002);
    const sup = below.length ? Math.max(...below) : Math.min(...r.slice(-60).map(x => x.l));
    const res = above.length ? Math.min(...above) : Math.max(...r.slice(-60).map(x => x.h));
    return { sup, res: res > p ? res : NaN };
  }
  function atrPct(cs, n = 14) {
    if (cs.length < n + 1) return NaN;
    let s = 0;
    for (let i = cs.length - n; i < cs.length; i++) { const c = cs[i], pc = cs[i - 1].c; s += Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc)); }
    return s / n / cs[cs.length - 1].c * 100;
  }
  const chg = (c, n) => c.length > n ? (c[c.length - 1] / c[c.length - 1 - n] - 1) * 100 : NaN;

  // cs: daily candles (oldest first). Returns numbers + a score from -100 (strong fall) to +100 (strong rise).
  function analyze(cs) {
    if (!cs || cs.length < 30) return { enough: false, days: cs ? cs.length : 0 };
    const c = cs.map(x => x.c), p = c[c.length - 1];
    const m20 = sma(c, 20), m50 = sma(c, 50), m200 = sma(c, 200);
    const e12 = emaArr(c, 12), e26 = emaArr(c, 26), macd = e12.map((v, i) => v - e26[i]), sig = emaArr(macd, 9);
    const mNow = macd[macd.length - 1], sNow = sig[sig.length - 1], mPrev = macd[macd.length - 2], sPrev = sig[sig.length - 2];
    const cross = (mPrev <= sPrev && mNow > sNow) ? 'up' : (mPrev >= sPrev && mNow < sNow) ? 'down' : '';
    const R = rsi(c), tr = slopePct(c, 20), lv = levels(cs, p), atr = atrPct(cs);
    let s = 0;
    s += p > m20 ? 18 : -18;
    if (isFinite(m50)) s += p > m50 ? 18 : -18;
    if (isFinite(m200)) s += p > m200 ? 14 : -14;
    s += mNow > sNow ? 15 : -15;
    if (isFinite(tr)) s += Math.max(-25, Math.min(25, tr * 4));
    if (R >= 70) s -= 8; else if (R <= 30) s += 8; else s += (R - 50) * 0.5;
    s = Math.round(Math.max(-100, Math.min(100, s)));
    const label = s >= 50 ? 'strongUp' : s >= 15 ? 'up' : s > -15 ? 'side' : s > -50 ? 'down' : 'strongDown';
    return { enough: true, p, m20, m50, m200, rsi: R, macd: mNow, signal: sNow, cross, trend: tr, sup: lv.sup, res: lv.res, atr,
             w1: chg(c, 5), m1: chg(c, 21), m3: chg(c, 63), y1: c.length > 200 ? (p / c[0] - 1) * 100 : NaN, score: s, label, days: cs.length };
  }

  // Written analysis in English or Arabic, built only from the numbers above.
  function write(a, name, lang, fmt) {
    const ar = lang === 'ar';
    const pc = v => (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(1) + '%';
    if (!a.enough) return ar
      ? `تاريخ أسعار ${name} غير كافٍ حتى الآن (عدد الأيام: ${a.days}). يحتاج المحلل 30 يومًا على الأقل.`
      : `There is not enough price history for ${name} yet (${a.days} days). The analyzer needs at least 30 days.`;
    const out = [];
    const above20 = a.p > a.m20, above50 = isFinite(a.m50) ? a.p > a.m50 : null, above200 = isFinite(a.m200) ? a.p > a.m200 : null;
    const trendWord = { strongUp: ar ? 'اتجاه صاعد قوي' : 'a strong uptrend', up: ar ? 'اتجاه صاعد' : 'an uptrend', side: ar ? 'حركة جانبية بدون اتجاه واضح' : 'a sideways move with no clear direction', down: ar ? 'اتجاه هابط' : 'a downtrend', strongDown: ar ? 'اتجاه هابط قوي' : 'a strong downtrend' }[a.label];
    // 1. trend
    let avg;
    if (ar) {
      const parts = [`متوسط 20 يومًا (${fmt(a.m20)})`]; if (above50 !== null) parts.push(`متوسط 50 يومًا (${fmt(a.m50)})`);
      const same = above50 === null || above50 === above20;
      avg = same ? `السعر ${above20 ? 'فوق' : 'تحت'} ${parts.join(' و')}` : `السعر ${above20 ? 'فوق' : 'تحت'} ${parts[0]} لكنه ${above50 ? 'فوق' : 'تحت'} ${parts[1]}`;
      if (above200 !== null) avg += `، و${above200 ? 'فوق' : 'تحت'} متوسط 200 يوم (${fmt(a.m200)})، وهذا يعني أن الاتجاه الطويل ${above200 ? 'صاعد' : 'هابط'}`;
      out.push(`${name} في ${trendWord}. ${avg}. خلال آخر 20 يومًا ${a.trend >= 0 ? 'ارتفع' : 'انخفض'} خط الاتجاه بنسبة ${Math.abs(a.trend).toFixed(1)}%.`);
    } else {
      const parts = [`20-day average (${fmt(a.m20)})`]; if (above50 !== null) parts.push(`50-day average (${fmt(a.m50)})`);
      const same = above50 === null || above50 === above20;
      avg = same ? `The price is ${above20 ? 'above' : 'below'} its ${parts.join(' and ')}` : `The price is ${above20 ? 'above' : 'below'} its ${parts[0]} but ${above50 ? 'above' : 'below'} its ${parts[1]}`;
      if (above200 !== null) avg += `, and ${above200 ? 'above' : 'below'} its 200-day average (${fmt(a.m200)}), so the long-term trend is ${above200 ? 'up' : 'down'}`;
      out.push(`${name} is in ${trendWord}. ${avg}. Over the last 20 days the trend line ${a.trend >= 0 ? 'rose' : 'fell'} ${Math.abs(a.trend).toFixed(1)}%.`);
    }
    // 2. momentum
    const R = a.rsi.toFixed(0);
    const rsiTxt = a.rsi >= 70 ? (ar ? `مؤشر RSI عند ${R}، أي في منطقة التشبع الشرائي، وقد يحدث تصحيح أو توقف للصعود` : `RSI is ${R}, in the overbought zone, so a pullback or pause is common from here`)
      : a.rsi <= 30 ? (ar ? `مؤشر RSI عند ${R}، أي في منطقة التشبع البيعي، وقد يحدث ارتداد أو توقف للنزول` : `RSI is ${R}, in the oversold zone, so a bounce or pause is common from here`)
      : a.rsi >= 50 ? (ar ? `مؤشر RSI عند ${R}، ويدل على قوة شرائية بدون تشبع` : `RSI is ${R}, showing buying strength without being overbought`)
      : (ar ? `مؤشر RSI عند ${R}، ويدل على ضعف في الزخم بدون تشبع بيعي` : `RSI is ${R}, showing weak momentum without being oversold`);
    const macdTxt = a.cross === 'up' ? (ar ? 'وخط MACD قطع خط الإشارة للأعلى اليوم، وهذه إشارة صعود' : 'MACD just crossed above its signal line, a rising signal')
      : a.cross === 'down' ? (ar ? 'وخط MACD قطع خط الإشارة للأسفل اليوم، وهذه إشارة نزول' : 'MACD just crossed below its signal line, a falling signal')
      : a.macd > a.signal ? (ar ? 'وخط MACD فوق خط الإشارة (زخم إيجابي)' : 'MACD is above its signal line (positive momentum)')
      : (ar ? 'وخط MACD تحت خط الإشارة (زخم سلبي)' : 'MACD is below its signal line (negative momentum)');
    out.push(ar ? `${rsiTxt}، ${macdTxt}.` : `${rsiTxt}. ${macdTxt}.`);
    // 3. levels
    const sd = (1 - a.sup / a.p) * 100, rd = (a.res / a.p - 1) * 100;
    if (ar) out.push(isFinite(a.res)
      ? `أقرب دعم عند ${fmt(a.sup)} (أقل بـ ${sd.toFixed(1)}%)، وأقرب مقاومة عند ${fmt(a.res)} (أعلى بـ ${rd.toFixed(1)}%). الإغلاق فوق ${fmt(a.res)} يقوي الصعود، والنزول تحت ${fmt(a.sup)} يقوي الهبوط.`
      : `السعر عند أعلى مستوى في الفترة الأخيرة ولا توجد مقاومة قريبة. أقرب دعم عند ${fmt(a.sup)} (أقل بـ ${sd.toFixed(1)}%)، والنزول تحته يضعف الصعود.`);
    else out.push(isFinite(a.res)
      ? `Nearest support is ${fmt(a.sup)} (${sd.toFixed(1)}% below) and nearest resistance is ${fmt(a.res)} (${rd.toFixed(1)}% above). A close above ${fmt(a.res)} would strengthen the rise; a drop below ${fmt(a.sup)} would strengthen the fall.`
      : `The price is at its highest level of the recent period, with no resistance close above. Nearest support is ${fmt(a.sup)} (${sd.toFixed(1)}% below); a drop below it would weaken the rise.`);
    // 4. performance + volatility
    const perf = ar
      ? `الأداء: أسبوع ${pc(a.w1)}، شهر ${pc(a.m1)}، 3 أشهر ${pc(a.m3)}${isFinite(a.y1) ? `، سنة ${pc(a.y1)}` : ''}. متوسط الحركة اليومية تقريبًا ${a.atr.toFixed(1)}%.`
      : `Performance: 1 week ${pc(a.w1)}, 1 month ${pc(a.m1)}, 3 months ${pc(a.m3)}${isFinite(a.y1) ? `, 1 year ${pc(a.y1)}` : ''}. The average daily move is about ${a.atr.toFixed(1)}%.`;
    out.push(perf);
    return out;
  }
  window.KMAnalyzer = { analyze, write, sma };
})();
