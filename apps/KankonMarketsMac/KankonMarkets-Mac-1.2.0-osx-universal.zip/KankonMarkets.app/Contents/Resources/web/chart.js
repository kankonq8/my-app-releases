// Kankon Markets: price chart on a canvas. Candles or line, 20/50 averages, support/resistance, crosshair.
(function () {
  function KMChart(canvas, tip) {
    const ctx = canvas.getContext('2d');
    let data = [], opt = {}, hover = -1;
    const C = { grid: '#1a2444', axis: '#6f7ea8', up: '#3ddc97', dn: '#ff5d73', ma20: '#f5c542', ma50: '#b06cff', line: '#4f8bff', sup: '#3ddc97', res: '#ff5d73', cross: '#8ea0cc' };
    const PADR = 74, PADT = 14, PADB = 28, PADL = 10;
    function size() { const r = canvas.getBoundingClientRect(), d = window.devicePixelRatio || 1; canvas.width = Math.max(1, r.width * d); canvas.height = Math.max(1, r.height * d); ctx.setTransform(d, 0, 0, d, 0, 0); return r; }
    function maArr(n) { const out = []; let s = 0; data.forEach((x, i) => { s += x.c; if (i >= n) s -= data[i - n].c; out.push(i >= n - 1 ? s / n : NaN); }); return out; }
    function draw() {
      const r = size(), W = r.width, H = r.height;
      ctx.clearRect(0, 0, W, H);
      if (!data.length) { ctx.fillStyle = C.axis; ctx.font = '14px Segoe UI, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(opt.empty || '', W / 2, H / 2); return; }
      const m20 = opt.ma ? (opt.m20 || maArr(20)) : [], m50 = opt.ma ? (opt.m50 || maArr(50)) : [];
      let mx = -Infinity, mn = Infinity;
      data.forEach((x, i) => { mx = Math.max(mx, opt.line ? x.c : x.h); mn = Math.min(mn, opt.line ? x.c : x.l); });
      m20.concat(m50).forEach(v => { if (isFinite(v)) { mx = Math.max(mx, v); mn = Math.min(mn, v); } });
      [opt.sup, opt.res].forEach(v => { if (isFinite(v) && v < mx * 1.06 && v > mn * 0.94) { mx = Math.max(mx, v); mn = Math.min(mn, v); } });
      if (mx === mn) { mx *= 1.001; mn *= 0.999; }
      const pad = (mx - mn) * 0.06; mx += pad; mn -= pad;
      const pw = W - PADL - PADR, ph = H - PADT - PADB, n = data.length, bw = pw / n;
      const X = i => PADL + i * bw + bw / 2, Y = v => PADT + (mx - v) / (mx - mn) * ph;
      // grid + price labels
      ctx.font = '11px Segoe UI, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      for (let k = 0; k <= 5; k++) {
        const v = mn + (mx - mn) * k / 5, y = Y(v);
        ctx.strokeStyle = C.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(PADL, y); ctx.lineTo(W - PADR, y); ctx.stroke();
        ctx.fillStyle = C.axis; ctx.fillText(opt.fmt(v), W - PADR + 8, y);
      }
      // time labels
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      const step = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(pw / 110))));
      for (let i = 0; i < n; i += step) { ctx.fillStyle = C.axis; ctx.fillText(opt.tfmt(data[i].t), X(i), H - PADB + 8); }
      // support / resistance
      [[opt.sup, C.sup], [opt.res, C.res]].forEach(([v, col]) => {
        if (!isFinite(v) || v > mx || v < mn) return;
        ctx.save(); ctx.strokeStyle = col; ctx.globalAlpha = .7; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.moveTo(PADL, Y(v)); ctx.lineTo(W - PADR, Y(v)); ctx.stroke(); ctx.restore();
      });
      // price
      if (opt.line || n > 400) {
        const g = ctx.createLinearGradient(0, PADT, 0, H - PADB); g.addColorStop(0, 'rgba(79,139,255,.35)'); g.addColorStop(1, 'rgba(79,139,255,0)');
        ctx.beginPath(); data.forEach((x, i) => i ? ctx.lineTo(X(i), Y(x.c)) : ctx.moveTo(X(i), Y(x.c)));
        ctx.strokeStyle = C.line; ctx.lineWidth = 2; ctx.stroke();
        ctx.lineTo(X(n - 1), H - PADB); ctx.lineTo(X(0), H - PADB); ctx.closePath(); ctx.fillStyle = g; ctx.fill();
        if (opt.dots) data.forEach((x, i) => { ctx.fillStyle = C.line; ctx.beginPath(); ctx.arc(X(i), Y(x.c), 3.5, 0, 7); ctx.fill(); });
      } else {
        data.forEach((x, i) => {
          const col = x.c >= x.o ? C.up : C.dn, cx = X(i);
          ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(Math.round(cx) + .5, Y(x.h)); ctx.lineTo(Math.round(cx) + .5, Y(x.l)); ctx.stroke();
          const top = Y(Math.max(x.o, x.c)), hgt = Math.max(1, Math.abs(Y(x.o) - Y(x.c)));
          ctx.fillStyle = col; ctx.fillRect(cx - Math.max(1, bw * .34), top, Math.max(2, bw * .68), hgt);
        });
      }
      // averages
      [[m20, C.ma20], [m50, C.ma50]].forEach(([a, col]) => {
        ctx.beginPath(); let on = false;
        a.forEach((v, i) => { if (!isFinite(v)) return; on ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)); on = true; });
        if (on) { ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.globalAlpha = .9; ctx.stroke(); ctx.globalAlpha = 1; }
      });
      // last price tag
      const last = data[n - 1].c, ly = Y(last);
      ctx.fillStyle = data[n - 1].c >= (data[n - 2] ? data[n - 2].c : last) ? C.up : C.dn;
      ctx.fillRect(W - PADR + 2, ly - 10, PADR - 4, 20);
      ctx.fillStyle = '#0b1020'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = 'bold 11px Segoe UI, sans-serif'; ctx.fillText(opt.fmt(last), W - PADR + 7, ly);
      // crosshair
      if (hover >= 0 && hover < n) {
        const x = data[hover], cx = X(hover);
        ctx.save(); ctx.strokeStyle = C.cross; ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(cx, PADT); ctx.lineTo(cx, H - PADB); ctx.stroke(); ctx.restore();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(cx, Y(x.c), 3.5, 0, 7); ctx.fill();
        tip.innerHTML = opt.tip(x, m20[hover], m50[hover]);
        tip.style.display = 'block';
        const tw = tip.offsetWidth; tip.style.left = Math.min(W - PADR - tw - 6, Math.max(6, cx + 14 > W - PADR - tw ? cx - tw - 14 : cx + 14)) + 'px'; tip.style.top = '14px';
      } else tip.style.display = 'none';
    }
    function idx(e) { const r = canvas.getBoundingClientRect(); const pw = r.width - PADL - PADR; const i = Math.floor((e.clientX - r.left - PADL) / (pw / data.length)); return i >= 0 && i < data.length ? i : -1; }
    canvas.addEventListener('mousemove', e => { hover = idx(e); draw(); });
    canvas.addEventListener('mouseleave', () => { hover = -1; draw(); });
    new ResizeObserver(() => draw()).observe(canvas);
    return { set(d, o) { data = d || []; opt = o; hover = -1; draw(); }, draw };
  }
  // Small line for the watchlist.
  function spark(canvas, vals, up) {
    const d = window.devicePixelRatio || 1, w = canvas.clientWidth || 70, h = canvas.clientHeight || 26;
    canvas.width = w * d; canvas.height = h * d; const ctx = canvas.getContext('2d'); ctx.setTransform(d, 0, 0, d, 0, 0);
    if (!vals || vals.length < 2) return;
    const mx = Math.max(...vals), mn = Math.min(...vals), r = mx - mn || 1;
    ctx.beginPath(); vals.forEach((v, i) => { const x = i / (vals.length - 1) * (w - 2) + 1, y = h - 2 - (v - mn) / r * (h - 4); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    ctx.strokeStyle = up ? '#3ddc97' : '#ff5d73'; ctx.lineWidth = 1.5; ctx.stroke();
  }
  window.KMChart = KMChart; window.KMSpark = spark;
})();
