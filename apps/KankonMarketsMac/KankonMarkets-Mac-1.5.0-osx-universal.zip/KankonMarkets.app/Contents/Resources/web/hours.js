// Kankon Markets: market opening hours, shown in Kuwait time. Regular sessions only; public holidays are not included.
// By Kankon · kankon.net
(function () {
  // Each session: [time zone, list of [weekday 0=Sun..6, open "HH:MM", close "HH:MM"] in that zone].
  const NY = 'America/New_York';
  const days = (from, to) => { const a = []; for (let d = from; d <= to; d++) a.push(d); return a; };
  const weekly = (tz, ranges) => ({ tz, ranges });
  // CME Globex futures (gold, silver, oil, gas...): Sunday 18:00 to Friday 17:00 New York time, with a break 17:00-18:00 each day.
  const CME = weekly(NY, [[0, '18:00', '24:00']].concat(days(1, 4).map(d => [d, '00:00', '17:00']), days(1, 4).map(d => [d, '18:00', '24:00']), [[5, '00:00', '17:00']]));
  // Currencies: Sunday 17:00 to Friday 17:00 New York time, around the clock.
  const FX = weekly(NY, [[0, '17:00', '24:00']].concat(days(1, 4).map(d => [d, '00:00', '24:00']), [[5, '00:00', '17:00']]));
  const US = weekly(NY, days(1, 5).map(d => [d, '09:30', '16:00']));
  const JP = weekly('Asia/Tokyo', days(1, 5).map(d => [d, '09:00', '11:30']).concat(days(1, 5).map(d => [d, '12:30', '15:30'])));
  const UK = weekly('Europe/London', days(1, 5).map(d => [d, '08:00', '16:30']));
  const KW = weekly('Asia/Kuwait', days(0, 4).map(d => [d, '09:00', '12:40']));          // Boursa Kuwait, Sunday to Thursday
  const SA = weekly('Asia/Riyadh', days(0, 4).map(d => [d, '10:00', '15:00']));          // Saudi Exchange (Tadawul)
  const AE = weekly('Asia/Dubai', days(1, 5).map(d => [d, '10:00', '15:00']));           // Dubai Financial Market, Monday to Friday
  const QA = weekly('Asia/Qatar', days(0, 4).map(d => [d, '09:30', '13:15']));           // Qatar Stock Exchange
  const GROUPS = [
    ['crypto', 'always'], ['futures', CME], ['fx', FX], ['us', US], ['jp', JP], ['uk', UK], ['kw', KW], ['sa', SA],
  ];
  const groupOf = a => !a ? null : a.cat === 'crypto' ? 'crypto' : a.src === 'oil' ? 'daily' : a.cat === 'metals' || a.cat === 'energy' ? 'futures' : a.cat === 'fx' ? 'fx'
    : a.id === 'nikkei' ? 'jp' : a.id === 'ftse' ? 'uk' : a.cat === 'indices' ? 'us' : a.cat === 'gulf' ? a.ex : a.kw ? 'kw' : null;
  const SCHED = { futures: CME, fx: FX, us: US, jp: JP, uk: UK, kw: KW, sa: SA, ae: AE, qa: QA };
  const fmts = {};
  function local(date, tz) {   // weekday and minutes of the day in that time zone
    const f = fmts[tz] || (fmts[tz] = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }));
    const p = {}; f.formatToParts(date).forEach(x => p[x.type] = x.value);
    return { d: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.weekday), m: (+p.hour % 24) * 60 + +p.minute };
  }
  const mins = s => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  function isOpen(s, date) { const l = local(date, s.tz); return s.ranges.some(([d, o, c]) => d === l.d && l.m >= mins(o) && l.m < mins(c)); }
  // status(schedule) -> {open, next: Date of the next open/close}
  function status(s, now) {
    now = now || new Date();
    if (s === 'always') return { open: true, always: true };
    const open = isOpen(s, now);
    let t = new Date(Math.floor(now.getTime() / 600000) * 600000 + 600000);   // step 10 minutes
    for (let i = 0; i < 7 * 24 * 6 + 12; i++, t = new Date(t.getTime() + 600000)) if (isOpen(s, t) !== open) return { open, next: t };
    return { open };
  }
  function forAsset(a, now) { const g = groupOf(a); if (!g) return null; if (g === 'crypto') return { open: true, always: true }; if (g === 'daily') return { daily: true }; return status(SCHED[g], now); }
  window.KMHours = { GROUPS, status, forAsset, groupOf };
})();
