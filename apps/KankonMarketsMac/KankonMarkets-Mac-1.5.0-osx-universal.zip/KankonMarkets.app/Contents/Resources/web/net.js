// Kankon Markets: getting prices. The app window (Windows or Mac) downloads the data for the page,
// because the price sites do not allow pages to read them directly. In a normal browser it tries fetch().
(function () {
  const waiting = {};
  let seq = 0;
  const win = window.chrome && window.chrome.webview;
  const mac = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.km;
  function done(id, ok, status, body) {
    const w = waiting[id]; if (!w) return; delete waiting[id]; clearTimeout(w.t);
    if (ok) w.res(body); else { const e = new Error('HTTP ' + status); e.body = body; w.rej(e); }
  }
  if (win) win.addEventListener('message', e => { let m = e.data; if (typeof m === 'string') m = JSON.parse(m); if (m && m.id) done(m.id, m.ok, m.status, m.body); });
  window.KMNative = {
    // called by the Mac app (body is base64 so any text is safe)
    _done(id, ok, status, b64) {
      let body = '';
      if (b64) { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); body = new TextDecoder().decode(u); }
      done(id, ok, status, body);
    },
    get(url) {
      if (!win && !mac) return fetch(url).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); });
      return new Promise((res, rej) => {
        const id = 'r' + (++seq);
        waiting[id] = { res, rej, t: setTimeout(() => done(id, false, 'timeout'), 25000) };
        const msg = { cmd: 'get', id, url };
        win ? win.postMessage(JSON.stringify(msg)) : mac.postMessage(msg);
      });
    },
    // AI assistant: the window sends the question to api.anthropic.com with the user's own key.
    // Always resolves with {status, body} so the page can show the API's own error message.
    ai(body, key) {
      if (!win && !mac) return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2026-10-21', 'anthropic-dangerous-direct-browser-access': 'true' }, body })
        .then(async r => ({ status: r.status, body: await r.text() }), e => ({ status: 0, body: '' }));
      return new Promise(res => {
        const id = 'a' + (++seq);
        waiting[id] = { res: b => res({ status: 200, body: b }), rej: e => res({ status: parseInt(String(e.message).replace(/\D/g, ''), 10) || 0, body: e.body || '' }), t: setTimeout(() => done(id, false, 0, ''), 180000) };
        const msg = { cmd: 'ai', id, body, key };
        win ? win.postMessage(JSON.stringify(msg)) : mac.postMessage(msg);
      });
    },
    // Make the whole window bigger or smaller (text, chart, chat). The app window does the zoom.
    zoom(v) {
      if (win) win.postMessage(JSON.stringify({ cmd: 'zoom', id: 'z', zoom: v }));
      else if (mac) mac.postMessage({ cmd: 'zoom', id: 'z', zoom: v });
      else document.body.style.zoom = v;
    },
    // Price alert: a notification from the computer (Windows / Mac), even when the window is behind others.
    notify(title, text) {
      if (win) win.postMessage(JSON.stringify({ cmd: 'notify', id: 'n', title, body: text }));
      else if (mac) mac.postMessage({ cmd: 'notify', id: 'n', title, body: text });
      else if (window.Notification && Notification.permission === 'granted') new Notification(title, { body: text });
    },
    // Mini window: small, always on top of other windows (on = true) or back to the full window.
    mini(on, h) {
      if (win) win.postMessage(JSON.stringify({ cmd: 'mini', id: 'm', on: !!on, h: h || 0 }));
      else if (mac) mac.postMessage({ cmd: 'mini', id: 'm', on: !!on, h: h || 0 });
    },
    // Export: the window asks where to save the file (Save dialog). Resolves with the saved path, or '' if cancelled.
    save(name, b64) {
      if (!win && !mac) {
        const a = document.createElement('a'); a.href = 'data:application/octet-stream;base64,' + b64; a.download = name;
        document.body.appendChild(a); a.click(); a.remove(); return Promise.resolve(name);
      }
      return new Promise(res => {
        const id = 's' + (++seq);
        waiting[id] = { res, rej: () => res(''), t: setTimeout(() => done(id, false, 0, ''), 600000) };
        const msg = { cmd: 'save', id, name, data: b64 };
        win ? win.postMessage(JSON.stringify(msg)) : mac.postMessage(msg);
      });
    },
    native: !!(win || mac),
  };

  // Chart periods: Yahoo range + candle size.
  const RANGES = {
    '1D': ['1d', '15m'], '1W': ['5d', '1h'], '1M': ['1mo', '1d'], '3M': ['3mo', '1d'], '6M': ['6mo', '1d'], '1Y': ['1y', '1d'], '5Y': ['5y', '1wk'],
  };
  const YH = ['https://query1.finance.yahoo.com', 'https://query2.finance.yahoo.com'];

  async function yahoo(sym, range, interval) {
    let last;
    for (const h of YH) {
      try {
        const txt = await KMNative.get(h + '/v8/finance/chart/' + encodeURIComponent(sym) + '?range=' + range + '&interval=' + interval + '&includePrePost=false');
        const j = JSON.parse(txt);
        const r = j.chart && j.chart.result && j.chart.result[0];
        if (!r) throw new Error((j.chart && j.chart.error && j.chart.error.description) || 'no data');
        const q = (r.indicators && r.indicators.quote && r.indicators.quote[0]) || {};
        const ts = r.timestamp || [];
        const c = [];
        for (let i = 0; i < ts.length; i++) {
          const cl = q.close && q.close[i];
          if (cl == null || !isFinite(cl)) continue;
          const o = q.open[i] ?? cl, hi = q.high[i] ?? cl, lo = q.low[i] ?? cl;
          c.push({ t: ts[i] * 1000, o, h: Math.max(hi, o, cl), l: Math.min(lo, o, cl), c: cl, v: (q.volume && q.volume[i]) || 0 });
        }
        const m = r.meta || {};
        return { candles: c, price: m.regularMarketPrice, prev: m.chartPreviousClose ?? m.previousClose, time: (m.regularMarketTime || 0) * 1000,
                 dayHigh: m.regularMarketDayHigh, dayLow: m.regularMarketDayLow, hi52: m.fiftyTwoWeekHigh, lo52: m.fiftyTwoWeekLow,
                 exchange: m.fullExchangeName || m.exchangeName || '', type: m.instrumentType || '', currency: m.currency || '' };
      } catch (e) { last = e; }
    }
    throw last;
  }

  // Kuwait Export Blend: OilPrice.com publishes one price per trading day (end of day). The app keeps every
  // day it has seen on this computer, so the chart grows day by day.
  const OIL_URL = 'https://s3.amazonaws.com/oilprice.com/oilprices/blend_cache.json';
  let oilCache = null, oilAt = 0;
  async function oil(blend) {
    if (!oilCache || Date.now() - oilAt > 5 * 60000) { oilCache = JSON.parse(await KMNative.get(OIL_URL)); oilAt = Date.now(); }
    const b = oilCache[blend];
    if (!b) throw new Error('blend missing');
    const key = 'km.hist.' + blend;
    const hist = JSON.parse(localStorage.getItem(key) || '{}');
    const add = (p) => { const v = parseFloat(p.price); const t = parseInt(p.dateadded, 10) * 1000; if (isFinite(v) && v > 0 && t) hist[new Date(t).toISOString().slice(0, 10)] = v; };
    (b.last_close || []).forEach(add); (b.last_price || []).forEach(add);
    localStorage.setItem(key, JSON.stringify(hist));
    const days = Object.keys(hist).sort();
    const candles = days.map((d, i) => { const c = hist[d]; const o = i ? hist[days[i - 1]] : c; return { t: Date.parse(d + 'T12:00:00Z'), o, h: Math.max(o, c), l: Math.min(o, c), c, v: 0 }; });
    const price = candles.length ? candles[candles.length - 1].c : NaN;
    const prev = candles.length > 1 ? candles[candles.length - 2].c : NaN;
    return { candles, price, prev, time: candles.length ? candles[candles.length - 1].t : 0, exchange: 'OilPrice.com', type: 'DAILY', currency: 'USD', daily: true };
  }

  // Boursa Kuwait sends prices in fils: scale them to dinars (a.scale = 0.001), so every screen shows KWD.
  function scaled(a, d) {
    const k = a.scale; if (!k || !d) return d;
    d.candles = d.candles.map(c => ({ t: c.t, o: c.o * k, h: c.h * k, l: c.l * k, c: c.c * k, v: c.v }));
    ['price', 'prev', 'dayHigh', 'dayLow', 'hi52', 'lo52'].forEach(f => { if (isFinite(d[f])) d[f] *= k; });
    d.currency = a.cur || d.currency; return d;
  }
  const mem = {};
  function save(k, v) { mem[k] = v; try { localStorage.setItem('km.c.' + k, JSON.stringify(v)); } catch (e) { } }
  function load(k) { if (mem[k]) return mem[k]; try { return JSON.parse(localStorage.getItem('km.c.' + k)); } catch (e) { return null; } }

  // series(asset, period) -> {candles, price, prev, ...}; falls back to the last saved copy when offline (stale:true).
  async function series(a, period) {
    const k = a.id + '.' + period;
    try {
      let d;
      if (a.src === 'oil') d = await oil(a.blend);
      else { const [r, i] = RANGES[period]; d = scaled(a, await yahoo(a.sym, r, i)); }
      d.at = Date.now();
      save(k, d);
      return d;
    } catch (e) {
      const old = load(k);
      if (old) { old.stale = true; return old; }
      throw e;
    }
  }
  // 5-minute prices of the last few days (for "what happened in the last 15 min ... 4 hours").
  async function intraday(a) {
    if (a.src === 'oil') return null;
    const d = scaled(a, await yahoo(a.sym, '5d', '5m')); d.at = Date.now(); return d;
  }
  window.KMNet = { series, intraday, RANGES, cached: (a, p) => load(a.id + '.' + p) };
})();
