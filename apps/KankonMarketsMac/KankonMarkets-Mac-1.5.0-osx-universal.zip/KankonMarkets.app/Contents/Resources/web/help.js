// Kankon Markets: Help page (English and Arabic). Opened with the "?" Help button at the top.
// Each section: [id, title, html]. Keep the AI key section complete: people set the key up from here.
window.KM_HELP = {
  en: [
    ['notice', '⚠ Notice', `
<div class="risk"><b>⚠ Notice:</b> Prices and news are for information only and may be delayed or inaccurate. This app and its AI assistant do not give investment advice. Check with a licensed advisor before you buy or sell. You are solely responsible for your decisions.</div>
<p>Data sources: Yahoo Finance (prices), OilPrice.com (Kuwait crude), Google News and Bing News (news), Claude by Anthropic (AI Assistant). Kankon is not linked to these companies.</p>`],
    ['start', 'How to use (quick start)', `
<ol><li>Open Kankon Markets from Kankon Launcher. Prices load by themselves and refresh every minute.</li>
<li>Pick a market from the list on the left, for example Gold or Bitcoin.</li>
<li>Look at the chart in the middle and choose a period (1D to 5Y).</li>
<li>On the right, open <b>Analyzer</b> to see if the market leans to rise or fall, and why.</li>
<li>Open <b>News</b> and choose 15 min, 30 min, 1 hour or 4 hours to see what happened to the price and the latest headlines.</li>
<li>Open <b>AI Assistant</b>, add your own Anthropic API key once (see "Your Anthropic API key" below), then ask anything about the market in English or Arabic.</li>
<li>Use <b>Alerts</b> to be told when a price reaches a number, <b>Portfolio</b> to see what you own in Kuwaiti dinar, and <b>Calculator</b> to convert currencies and price gold.</li>
<li>Make the text bigger with <b>A+</b>, switch language with <b>English / العربية</b>, and drag the lines beside the chart to resize the panels.</li>
<li>Press <b>☀</b> for the light theme, <b>⧉</b> for a small price window that stays on top, and <b>⤓ Image</b> or <b>⤓ CSV</b> under the chart to save the chart or its prices.</li></ol>
<p>Tip: everything you choose (markets, period, tab, sizes, language) is remembered for next time.</p>`],
    ['about', 'What is Kankon Markets', `
<p>Kankon Markets shows live prices, charts, a rise/fall analysis, news and an AI assistant for gold, silver, oil, Bitcoin, currencies and stock indices, all in one window.</p>
<p>It is a prices and analysis app only. It does not buy or sell anything and does not need a trading account. Nothing in the app is financial advice.</p>`],
    ['list', 'The watchlist (left side)', `
<ul><li>Each row shows the market, its live price, today's change and a small chart of the day.</li>
<li>Click a market to open it in the middle.</li>
<li>Use the buttons at the top (All, Metals, Energy, Crypto, Currencies, Indices, Gulf stocks) to filter the list.</li>
<li><b>+ Add market</b> adds more markets (Palladium, Heating Oil, BNB, Dogecoin, UAE Dirham, Egyptian Pound, Nikkei 225, FTSE 100, and more Kuwait and Gulf stocks) or any Yahoo Finance symbol, for example a stock such as AAPL.</li>
<li>Move the mouse over a market and press <b>×</b> to remove it.</li></ul>`],
    ['chart', 'The chart (middle)', `
<ul><li>Choose the period: 1D (one day), 1W, 1M, 3M, 6M, 1Y or 5Y.</li>
<li><b>Candles</b> or <b>Line</b>. Each candle shows the open, high, low and close of one period: green means the price closed higher, red means lower.</li>
<li><b>Averages</b> shows the 20-day (yellow) and 50-day (purple) averages. The dashed lines are the nearest support (green) and resistance (red).</li>
<li>Move the mouse over the chart to see the prices of any point.</li>
<li>Below the chart: today's open, high and low, the previous close and the 52-week range.</li></ul>`],
    ['ctools', 'Chart tools: indicators, lines, compare', `
<ul><li>Under the chart buttons: <b>BB</b> shows Bollinger Bands (the 20-day average with a band of two standard deviations above and below; a price near the edge is stretched). <b>Volume</b>, <b>RSI</b> and <b>MACD</b> open small charts under the price.</li>
<li><b>― Line</b>: click on the chart to place a level line at that price (for example a price you are watching). <b>╱ Trend</b>: click two points to draw a trend line. Your lines are saved for each market. Press 🗑 to delete them, or Esc to cancel drawing.</li>
<li><b>Compare</b>: choose another market to see both as a percent change from the start of the period, on one chart (for example Gold against Silver, or Brent against Kuwait crude).</li></ul>`],
    ['gulf', 'Kuwait and Gulf stocks', `
<ul><li>Press <b>Gulf stocks</b> above the watchlist. National Bank of Kuwait, Kuwait Finance House and Zain are in the list from the start.</li>
<li><b>+ Add market</b> adds more: Boubyan Bank, Gulf Bank, Mabanee, Saudi Aramco, Al Rajhi Bank, SABIC, Emaar Properties (Dubai) and Qatar National Bank.</li>
<li>Boursa Kuwait prices are shown in <b>Kuwaiti dinars (KWD)</b> (the exchange quotes them in fils; 1 KWD = 1,000 fils). Saudi stocks are in SAR, Dubai in AED and Qatar in QAR.</li>
<li>Everything works for them: the chart, the Analyzer, news, alerts, the AI assistant, and My Portfolio (choose the number of shares; Qatar stocks cannot be added to the portfolio yet).</li>
<li>Stock prices from Yahoo Finance can be delayed by up to 15 minutes, and they move only while the exchange is open.</li></ul>`],
    ['export', 'Export: chart picture and CSV', `
<ul><li>Under the chart, <b>⤓ Image</b> saves the chart as a PNG picture, with the market name, the price and the date at the top. It saves the chart as you see it (indicators, lines and the light or dark theme).</li>
<li><b>⤓ CSV</b> saves the prices of the chart period (date, open, high, low, close, volume) as a CSV file that opens in Excel or Numbers.</li>
<li>In the <b>Portfolio</b> tab, <b>⤓ CSV</b> saves what you own with today's values in KWD and USD.</li>
<li>The app asks where to save each file.</li></ul>`],
    ['hours', 'Market hours', `
<ul><li>Next to the time under the price you see if the market is <b>open</b> or <b>closed</b>, and when it closes or opens, in Kuwait time.</li>
<li>The Analyzer tab has a "Market hours" card for crypto, metals and oil, currencies, US, Japan and UK stocks, Boursa Kuwait (Sunday to Thursday, 9:00 to 12:40) and the Saudi Exchange.</li>
<li>These are regular hours. Public holidays are not included.</li></ul>`],
    ['brief', 'Daily brief', `
<ul><li>In the AI Assistant tab press <b>☀️ Daily brief</b>. The assistant writes one short summary of all your markets: the overall mood, each market's move today, your portfolio, the most important headlines and what to watch.</li>
<li>Tick "Write it by itself each morning" to get it automatically the first time you open the app each day (after 5 AM). Each brief is one question to your Anthropic account (about 3 to 6 US cents).</li></ul>`],
    ['analyzer', 'Analyzer tab', `
<p>The Rise / Fall Analyzer reads the last year of daily prices and shows a gauge from strong fall to strong rise, with the trend, RSI, the price against its 50 and 200-day averages, support, resistance and MACD. Below it, a written analysis explains what these numbers mean.</p>
<p>When Gold is selected, the price of a gram of gold in Kuwaiti dinar (24K, 22K, 21K, 18K) is shown. It is calculated from the world gold price and the dollar rate; shops add making charges.</p>
<p>Everything is calculated from past prices. It does not predict the future.</p>`],
    ['news', 'News tab', `
<ul><li>The latest headlines about the selected market, in the app's language (from Google News, or Bing News if Google does not answer). Click a headline to open the full story in your browser.</li>
<li>Choose <b>15 min, 30 min, 1 hour or 4 hours</b>. The app writes what the price did in that time: how much it rose or fell, from which price to which price, its range, and the biggest 5-minute move. This is calculated from real 5-minute prices.</li>
<li>The news and the summary refresh by themselves every period you choose. Press Refresh to update now.</li>
<li>When a market is closed (for example at the weekend), the summary covers the last trading period.</li></ul>`],
    ['ai', 'AI Assistant tab', `
<p>Chat with Claude (by Anthropic) about any market, in Arabic or English, like a normal chat. For example: "Why did gold fall today?", "Explain the analysis in simple words", "Summarize the oil news".</p>
<ul><li>With every question the assistant receives what the app shows at that moment: the prices of your watchlist, the selected market, the analyzer results, the moves of the last 15 minutes to 4 hours and the latest headlines. So it answers about today's real numbers.</li>
<li>It remembers the conversation, so you can ask follow-up questions.</li>
<li>Every chat is saved on this computer with the day, date and time of each message. Press <b>History</b> to open an old chat, continue it or delete it. <b>New chat</b> starts a fresh one.</li>
<li>The assistant does not give buy or sell orders. Its answers are information, not financial advice.</li></ul>
<p>To use it you need your own Anthropic API key. See the next section.</p>`],
    ['alerts', 'Alerts tab (price alerts)', `
<ul><li>Press the <b>bell 🔔</b> next to a price, or open the <b>Alerts</b> tab.</li>
<li>Choose the market and when to alert you: <b>price goes above</b> a number, <b>price goes below</b> a number, or <b>moves more than</b> a percent today (up or down).</li>
<li>Press <b>Add</b>. When it happens, a notification appears on your computer with a sound, and a message appears in the app.</li>
<li>A price alert rings once, then turns <b>Off</b>; press Off to turn it on again. A move alert rings at most once a day. Press × to delete an alert.</li>
<li>"Rang recently" keeps the last alerts with their day and time.</li>
<li>Alerts are checked every minute while Kankon Markets is open (it can be minimized). They do not ring when the app is closed.</li></ul>`],
    ['portfolio', 'Portfolio tab (what I own)', `
<ul><li>Add what you own: the market, the amount and the unit. For gold you can use grams of 24K, 22K, 21K or 18K, or ounces. For currencies, enter the amount of that currency (for example 1,000 euros).</li>
<li>Optionally enter what you paid in total, in Kuwaiti dinar, to see your profit or loss.</li>
<li>The top card shows the total value in Kuwaiti dinar (and US dollars), the change today and the total profit or loss.</li>
<li>Values update with the live prices every minute. Gold by gram is the metal value only, without making charges.</li>
<li>Everything is saved only on this computer. The AI Assistant can see your portfolio when you ask it a question.</li></ul>`],
    ['calc', 'Calculator tab', `
<ul><li><b>Currency converter</b>: US dollar, Kuwaiti dinar, euro, pound, yen, Saudi riyal, UAE dirham and Egyptian pound, with live rates. Press ⇅ to swap.</li>
<li><b>Gold and silver price</b>: enter the weight in grams, the karat and the shop's making charge per gram to see the total in Kuwaiti dinar.</li>
<li><b>Value of any market</b>: for example, what 0.5 Bitcoin or 10 ounces of silver is worth in Kuwaiti dinar.</li></ul>`],
    ['key', 'Your Anthropic API key (step by step)', `
<p><b>What is it?</b> An API key is a private password that lets the app send your questions to Claude. Each person uses their own key, and the cost goes to their own Anthropic account. The app has no key of its own and does not share anyone's key.</p>
<p><b>How to get one:</b></p>
<ol><li>Open <b>console.anthropic.com</b> and create an account (or sign in).</li>
<li>Open <b>Billing</b> and add credit (pay as you go; the minimum is small, for example 5 US dollars).</li>
<li>Open <b>API Keys</b> and press <b>Create Key</b>. If you are asked about "identity federation", choose <b>Continue with an API key</b>.</li>
<li>Name it, for example "Kankon Markets". For <b>Expires</b>, choose a long time or no expiry; a 30-day key stops working after 30 days.</li>
<li>Press <b>Create key</b> and copy the key at once (it starts with <b>sk-ant-</b>). It is shown only once.</li>
<li>In Kankon Markets open the <b>AI Assistant</b> tab, paste the key and press <b>Save</b>.</li></ol>
<p><b>Cost:</b> you pay Anthropic only for what you use. One question costs about 2 to 4 US cents, so 5 dollars is about 150 questions. You can see your usage and set a spending limit in console.anthropic.com.</p>
<p><b>Privacy and safety:</b></p>
<ul><li>The key is saved only on this computer, inside the app's own storage. It is sent only to Anthropic (api.anthropic.com), never to Kankon or anyone else.</li>
<li>Do not send your key to anyone or paste it in a chat or email: anyone with it can use your credit.</li>
<li>To remove it from this computer, press <b>Remove key</b> under the chat. Your saved chats stay.</li>
<li>If you think someone has your key, delete it in console.anthropic.com (API Keys) and create a new one.</li>
<li>Each computer needs the key pasted once (Windows and Mac are separate).</li></ul>
<p><b>If something goes wrong:</b></p>
<ul><li><b>"Anthropic did not accept the API key"</b>: the key is wrong, deleted or expired. Press Remove key and paste a new one.</li>
<li><b>"Your Anthropic credit is used up"</b>: add credit in Billing.</li>
<li><b>"Too many questions"</b>: wait a minute and ask again.</li>
<li><b>"Could not reach Anthropic"</b>: check the internet connection.</li>
<li><b>"Anthropic is busy"</b>: try again after a moment.</li></ul>
<p>A normal Claude subscription (claude.ai, Pro) does not include an API key; the API is a separate account in console.anthropic.com.</p>`],
    ['view', 'Window size and text size', `
<ul><li><b>A− / A+</b> at the top make everything smaller or bigger (80% to 180%). Double-click the percentage to return to 100%.</li>
<li>Drag the thin line on either side of the chart to make the watchlist or the right side (Analyzer, News, AI chat) wider or narrower. Double-click a line to reset it.</li>
<li><b>English / العربية</b> switches the language; Arabic shows the window from right to left.</li>
<li><b>☀ / ☾</b> switches between the dark and the light theme.</li>
<li><b>⧉ Mini window</b> turns the app into a small price list at the top right of the screen that stays on top of other windows, so you can watch prices while you work. Click a market, or <b>⤢ Full</b>, to return to the full window.</li>
<li>The app remembers all these choices.</li></ul>`],
    ['data', 'Where the prices come from', `
<ul><li><b>Yahoo Finance</b>: gold, silver, platinum, copper and oil are futures prices (COMEX and NYMEX); crypto, currencies and indices are market prices. They may be delayed by up to 15 minutes. Prices refresh every minute.</li>
<li><b>Kuwait and Gulf stocks</b>: Yahoo Finance prices from Boursa Kuwait, the Saudi Exchange, the Dubai Financial Market and the Qatar Stock Exchange.</li>
<li><b>Kuwait Crude</b>: there is no free live price. The app shows the official end-of-day price of each trading day from OilPrice.com and keeps every day on your computer, so its chart grows day by day. Its analysis starts after 30 days.</li>
<li>Without internet the app opens with the last saved prices.</li></ul>`],
    ['contact', 'About', `<p>Kankon Markets is made by Kankon · <b>kankon.net</b>. It opens from Kankon Launcher and updates by itself.</p>`],
  ],
  ar: [
    ['notice', '⚠ تنبيه', `
<div class="risk"><b>⚠ تنبيه:</b> الأسعار والأخبار للاطلاع فقط، وقد تكون متأخرة أو غير دقيقة. ولا يقدّم هذا البرنامج ولا مساعده الذكي نصيحة استثمارية، فارجع إلى مستشار مرخّص قبل البيع أو الشراء. وأنت وحدك المسؤول عن قراراتك.</div>
<p>مصادر البيانات: Yahoo Finance (الأسعار)، وOilPrice.com (نفط الكويت)، وGoogle News وBing News (الأخبار)، وClaude من Anthropic (المساعد الذكي). Kankon غير تابع لهذه الشركات ولا مرتبط بها.</p>`],
    ['start', 'طريقة الاستخدام (البداية السريعة)', `
<ol><li>افتح Kankon Markets من Kankon Launcher. تُحمَّل الأسعار تلقائيًا وتُحدَّث كل دقيقة.</li>
<li>اختر سوقًا من القائمة الجانبية، مثل الذهب أو البيتكوين.</li>
<li>شاهد الرسم البياني في الوسط واختر الفترة (من يوم واحد إلى 5 سنوات).</li>
<li>في الجهة الأخرى، افتح <b>المحلل</b> لترى هل يميل السوق إلى الصعود أو النزول، ولماذا.</li>
<li>افتح <b>الأخبار</b> واختر 15 دقيقة أو 30 دقيقة أو ساعة أو 4 ساعات لترى ما حدث للسعر وآخر العناوين.</li>
<li>افتح <b>المساعد الذكي</b>، وأضف مفتاح Anthropic API الخاص بك مرة واحدة (راجع قسم «مفتاح Anthropic API» أدناه)، ثم اسأل أي سؤال عن السوق بالعربية أو الإنجليزية.</li>
<li>استخدم <b>التنبيهات</b> ليخبرك البرنامج عندما يصل السعر إلى رقم معيّن، و<b>محفظتي</b> لترى قيمة ما تملكه بالدينار الكويتي، و<b>الحاسبة</b> لتحويل العملات وحساب سعر الذهب.</li>
<li>كبّر الخط بزر <b>A+</b>، وغيّر اللغة من <b>English / العربية</b>، واسحب الخطوط بجانب الرسم لتغيير حجم الأقسام.</li>
<li>اضغط <b>☀</b> للوضع الفاتح، و<b>⧉</b> لنافذة أسعار صغيرة تبقى فوق النوافذ الأخرى، و<b>⤓ صورة</b> أو <b>⤓ CSV</b> تحت الرسم البياني لحفظ الرسم أو أسعاره.</li></ol>
<p>ملاحظة: يحفظ البرنامج كل اختياراتك (الأسواق والفترة والتبويب والأحجام واللغة) للمرة القادمة.</p>`],
    ['about', 'ما هو Kankon Markets', `
<p>يعرض Kankon Markets الأسعار المباشرة والرسوم البيانية وتحليل الصعود والنزول والأخبار ومساعدًا ذكيًا للذهب والفضة والنفط والبيتكوين والعملات ومؤشرات الأسهم، في نافذة واحدة.</p>
<p>البرنامج للأسعار والتحليل فقط: لا يبيع ولا يشتري شيئًا، ولا يحتاج إلى حساب تداول. ولا شيء فيه يُعدّ نصيحة مالية.</p>`],
    ['list', 'قائمة المتابعة (الجانب)', `
<ul><li>يعرض كل سطر السوق وسعره المباشر وتغيّره اليوم ورسمًا صغيرًا لليوم.</li>
<li>اضغط على أي سوق لفتحه في الوسط.</li>
<li>استخدم الأزرار في الأعلى (الكل، المعادن، الطاقة، العملات الرقمية، العملات، المؤشرات، أسهم الخليج) لتصفية القائمة.</li>
<li>زر <b>+ إضافة سوق</b> يضيف أسواقًا أخرى (البلاديوم، زيت التدفئة، BNB، دوجكوين، الدرهم الإماراتي، الجنيه المصري، نيكاي 225، فوتسي 100، ومزيدًا من أسهم الكويت والخليج) أو أي رمز من Yahoo Finance، مثل سهم AAPL.</li>
<li>مرّر الفأرة على أي سوق واضغط <b>×</b> لحذفه.</li></ul>`],
    ['chart', 'الرسم البياني (الوسط)', `
<ul><li>اختر الفترة: 1D (يوم)، 1W، 1M، 3M، 6M، 1Y أو 5Y.</li>
<li><b>شموع</b> أو <b>خط</b>. كل شمعة تعرض سعر الافتتاح والأعلى والأدنى والإغلاق لفترة واحدة: الأخضر يعني أن السعر أغلق أعلى، والأحمر يعني أنه أغلق أدنى.</li>
<li>زر <b>المتوسطات</b> يعرض متوسط 20 يومًا (أصفر) ومتوسط 50 يومًا (بنفسجي). والخطوط المتقطعة هي أقرب دعم (أخضر) وأقرب مقاومة (أحمر).</li>
<li>حرّك الفأرة على الرسم لترى أسعار أي نقطة.</li>
<li>تحت الرسم: الافتتاح والأعلى والأدنى اليوم، والإغلاق السابق، ونطاق 52 أسبوعًا.</li></ul>`],
    ['ctools', 'أدوات الرسم: المؤشرات والخطوط والمقارنة', `
<ul><li>تحت الرسم البياني: زر <b><bdi dir="ltr">BB</bdi></b> يعرض نطاقات بولينجر (متوسط 20 يومًا مع نطاق بانحرافين معياريين فوقه وتحته، والسعر القريب من حافة النطاق يكون قد ابتعد كثيرًا عن متوسطه). وأزرار <b>الحجم</b> و<b><bdi dir="ltr">RSI</bdi></b> و<b><bdi dir="ltr">MACD</bdi></b> تفتح رسومًا صغيرة تحت رسم السعر.</li>
<li><b>― خط</b>: اضغط على الرسم البياني لوضع خط مستوى عند ذلك السعر (مثلًا سعر تراقبه). <b>╱ اتجاه</b>: اضغط على نقطتين في الرسم البياني لرسم خط اتجاه. تُحفظ خطوطك لكل سوق، واضغط 🗑 لحذفها، أو اضغط Esc لإلغاء الرسم.</li>
<li><b>مقارنة</b>: اختر سوقًا آخر لترى السوقين معًا على رسم واحد بنسبة التغيّر من بداية الفترة (مثلًا الذهب مقابل الفضة، أو برنت مقابل نفط الكويت).</li></ul>`],
    ['gulf', 'أسهم الكويت والخليج', `
<ul><li>اضغط <b>أسهم الخليج</b> فوق قائمة المتابعة. بنك الكويت الوطني وبيت التمويل الكويتي وزين موجودة في القائمة منذ البداية.</li>
<li>زر <b>+ إضافة سوق</b> يضيف المزيد: بنك بوبيان، وبنك الخليج، والمباني، وأرامكو السعودية، ومصرف الراجحي، وسابك، وإعمار العقارية (دبي)، وبنك قطر الوطني.</li>
<li>أسعار بورصة الكويت معروضة <b>بالدينار الكويتي (<bdi dir="ltr">KWD</bdi>)</b> (تعلنها البورصة بالفلس، والدينار الواحد = 1,000 فلس). والأسهم السعودية بالريال <bdi dir="ltr">(SAR)</bdi>، ودبي بالدرهم <bdi dir="ltr">(AED)</bdi>، وقطر بالريال القطري <bdi dir="ltr">(QAR)</bdi>.</li>
<li>وتعمل معها كل الميزات: الرسم البياني، والمحلل، والأخبار، والتنبيهات، والمساعد الذكي، ومحفظتي (اكتب عدد الأسهم، ولا يمكن إضافة أسهم قطر إلى المحفظة حاليًا).</li>
<li>أسعار الأسهم من Yahoo Finance قد تتأخر حتى 15 دقيقة، ولا تتغيّر إلا في أثناء ساعات التداول.</li></ul>`],
    ['export', 'التصدير: صورة الرسم البياني وملف CSV', `
<ul><li>تحت الرسم البياني، زر <b>⤓ صورة</b> يحفظ الرسم البياني صورةً بصيغة PNG يظهر في أعلاها اسم السوق والسعر والتاريخ. وتعرض الصورة الرسم كما تراه (المؤشرات والخطوط والوضع الفاتح أو الداكن).</li>
<li>زر <b>⤓ CSV</b> يحفظ أسعار فترة الرسم البياني (التاريخ، الافتتاح، الأعلى، الأدنى، الإغلاق، الحجم) في ملف CSV يُفتح في Excel أو Numbers.</li>
<li>وفي تبويب <b>محفظتي</b>، زر <b>⤓ CSV</b> يحفظ ما تملكه مع قيمته اليوم بالدينار الكويتي والدولار.</li>
<li>يسألك البرنامج أين تحفظ كل ملف.</li></ul>`],
    ['hours', 'أوقات الأسواق', `
<ul><li>بجانب الوقت تحت السعر ترى حالة السوق: <b>مفتوح</b> أو <b>مغلق</b>، ومتى يغلق أو يفتح، بتوقيت الكويت.</li>
<li>وفي تبويب «المحلل» بطاقة «أوقات الأسواق» للعملات الرقمية والمعادن والنفط والعملات والأسهم الأمريكية واليابانية والبريطانية وبورصة الكويت (من الأحد إلى الخميس، من 9:00 إلى 12:40) والسوق السعودية.</li>
<li>هذه أوقات التداول المعتادة، ولا تشمل العطل الرسمية.</li></ul>`],
    ['brief', 'الملخص اليومي', `
<ul><li>في تبويب المساعد الذكي اضغط <b>☀️ الملخص اليومي</b>. يكتب المساعد ملخصًا قصيرًا لكل أسواقك: المزاج العام، وحركة كل سوق اليوم، ومحفظتك، وأهم العناوين، وما يجب متابعته.</li>
<li>فعّل «اكتبه تلقائيًا كل صباح» ليصلك تلقائيًا أول مرة تفتح فيها البرنامج كل يوم (بعد الساعة 5 صباحًا). كل ملخص يُحسب سؤالًا واحدًا على حسابك في Anthropic (بين 3 و6 سنتات أمريكية تقريبًا).</li></ul>`],
    ['analyzer', 'تبويب المحلل', `
<p>يقرأ محلل الصعود والنزول الأسعار اليومية لآخر سنة، ويعرض مقياسًا من هبوط قوي إلى صعود قوي، مع الاتجاه ومؤشر RSI والسعر مقابل متوسطَي 50 يومًا و200 يوم والدعم والمقاومة وMACD. وتحته تحليل مكتوب يشرح معنى هذه الأرقام.</p>
<p>عند اختيار الذهب يظهر سعر غرام الذهب بالدينار الكويتي (عيار 24 و22 و21 و18)، محسوبًا من سعر الذهب العالمي وسعر الدولار، والمحلات تضيف أجرة الصنعة.</p>
<p>كل شيء محسوب من الأسعار السابقة، ولا يتنبأ بالمستقبل.</p>`],
    ['news', 'تبويب الأخبار', `
<ul><li>آخر العناوين عن السوق المختار بلغة البرنامج (من Google News، أو من Bing News إذا لم يستجب Google). اضغط على أي عنوان لفتح الخبر كاملًا في المتصفح.</li>
<li>اختر <b>15 دقيقة أو 30 دقيقة أو ساعة أو 4 ساعات</b>، فيكتب البرنامج ما حدث للسعر في هذه المدة: مقدار الارتفاع أو الانخفاض، ومن أي سعر إلى أي سعر، ونطاق الحركة، وأكبر حركة خلال 5 دقائق. وكل ذلك محسوب من أسعار حقيقية بفاصل 5 دقائق.</li>
<li>تُحدَّث الأخبار والملخص تلقائيًا حسب الفترة التي تختارها، واضغط «تحديث» للتحديث فورًا.</li>
<li>عندما يكون السوق مغلقًا (في عطلة نهاية الأسبوع مثلًا)، يخص الملخص آخر فترة تداول.</li></ul>`],
    ['ai', 'تبويب المساعد الذكي', `
<p>تحدّث مع Claude من Anthropic عن أي سوق بالعربية أو الإنجليزية، كأي محادثة عادية. مثلًا: «لماذا انخفض الذهب اليوم؟» أو «اشرح التحليل بكلمات بسيطة» أو «لخّص أخبار النفط».</p>
<ul><li>يتلقّى المساعد مع كل سؤال ما يعرضه البرنامج في تلك اللحظة: أسعار قائمتك، والسوق المختار، ونتائج المحلل، وحركة السعر من آخر 15 دقيقة إلى 4 ساعات، وآخر العناوين. فتستند إجاباته إلى أرقام اليوم الحقيقية.</li>
<li>يتذكّر المحادثة، فتستطيع أن تكمل بأسئلة متتابعة.</li>
<li>تُحفظ كل محادثة على هذا الجهاز مع اليوم والتاريخ والساعة لكل رسالة. اضغط <b>السجل</b> لفتح محادثة قديمة أو إكمالها أو حذفها، و<b>محادثة جديدة</b> لبدء محادثة أخرى.</li>
<li>لا يعطي المساعد أوامر شراء أو بيع، وإجاباته معلومات وليست نصيحة مالية.</li></ul>
<p>لاستخدامه تحتاج إلى مفتاح Anthropic API خاص بك. راجع القسم التالي.</p>`],
    ['alerts', 'تبويب التنبيهات (تنبيهات الأسعار)', `
<ul><li>اضغط <b>الجرس 🔔</b> بجانب السعر، أو افتح تبويب <b>التنبيهات</b>.</li>
<li>اختر السوق ومتى تريد التنبيه: عندما <b>يرتفع السعر فوق</b> رقم معيّن، أو <b>ينخفض تحت</b> رقم معيّن، أو <b>يتحرك أكثر من</b> نسبة معيّنة اليوم (صعودًا أو نزولًا).</li>
<li>اضغط <b>إضافة</b>. عند حدوث ذلك يظهر إشعار على جهازك مع صوت، وتظهر رسالة داخل البرنامج.</li>
<li>تنبيه السعر يرنّ مرة واحدة ثم يصبح <b>متوقفًا</b>، واضغط «متوقف» لتفعيله من جديد. وتنبيه الحركة يرنّ مرة واحدة في اليوم على الأكثر. اضغط × لحذف التنبيه.</li>
<li>قسم «تنبيهات رنّت مؤخرًا» يحفظ آخر التنبيهات مع اليوم والوقت.</li>
<li>يتحقق البرنامج من التنبيهات كل دقيقة ما دام Kankon Markets مفتوحًا (ولو كان مصغّرًا)، ولا ترنّ التنبيهات عندما يكون البرنامج مغلقًا.</li></ul>`],
    ['portfolio', 'تبويب محفظتي (ما أملكه)', `
<ul><li>أضف ما تملكه: السوق والكمية والوحدة. للذهب يمكنك اختيار الغرام بعيار 24 أو 22 أو 21 أو 18، أو الأونصة. وللعملات اكتب المبلغ بتلك العملة (مثلًا 1,000 يورو).</li>
<li>يمكنك أيضًا كتابة المبلغ الذي دفعته إجمالًا بالدينار الكويتي لترى ربحك أو خسارتك.</li>
<li>تعرض البطاقة العلوية القيمة الإجمالية بالدينار الكويتي (وبالدولار الأمريكي)، والتغيّر اليوم، وإجمالي الربح أو الخسارة.</li>
<li>تُحدَّث القيم مع الأسعار المباشرة كل دقيقة. قيمة الذهب بالغرام هي قيمة المعدن فقط من دون أجرة الصنعة.</li>
<li>يُحفظ كل شيء على هذا الجهاز فقط، ويستطيع المساعد الذكي رؤية محفظتك عندما تسأله.</li></ul>`],
    ['calc', 'تبويب الحاسبة', `
<ul><li><b>محوّل العملات</b>: الدولار الأمريكي والدينار الكويتي واليورو والجنيه الإسترليني والين الياباني والريال السعودي والدرهم الإماراتي والجنيه المصري، بأسعار مباشرة. اضغط ⇅ للتبديل.</li>
<li><b>سعر الذهب والفضة</b>: اكتب الوزن بالغرام والعيار وأجرة الصنعة لكل غرام لترى الإجمالي بالدينار الكويتي.</li>
<li><b>قيمة أي سوق</b>: مثلًا كم تساوي 0.5 بيتكوين أو 10 أونصات فضة بالدينار الكويتي.</li></ul>`],
    ['key', 'مفتاح Anthropic API (خطوة بخطوة)', `
<p><b>ما هو؟</b> مفتاح API كلمة سرّ خاصة تسمح للبرنامج بإرسال أسئلتك إلى Claude. كل شخص يستخدم مفتاحه الخاص، وتُحسب التكلفة على حسابه في Anthropic. البرنامج لا يحتوي على مفتاح خاص به، ولا يشارك مفتاح أي شخص.</p>
<p><b>طريقة الحصول عليه:</b></p>
<ol><li>افتح <b><bdi dir="ltr">console.anthropic.com</bdi></b> وأنشئ حسابًا (أو سجّل الدخول).</li>
<li>افتح <b><bdi dir="ltr">Billing</bdi></b> وأضف رصيدًا (الدفع حسب الاستخدام، والحد الأدنى بسيط، مثل 5 دولارات).</li>
<li>افتح <b><bdi dir="ltr">API Keys</bdi></b> واضغط <b><bdi dir="ltr">Create Key</bdi></b>. وإذا ظهر لك سؤال عن «<bdi dir="ltr">identity federation</bdi>» فاختر <b><bdi dir="ltr">Continue with an API key</bdi></b>.</li>
<li>سمِّه مثلًا «<bdi dir="ltr">Kankon Markets</bdi>». وفي <b><bdi dir="ltr">Expires</bdi></b> اختر مدة طويلة أو بلا انتهاء، لأن المفتاح الذي مدته 30 يومًا يتوقف عن العمل بعد انتهائها.</li>
<li>اضغط <b><bdi dir="ltr">Create key</bdi></b> وانسخ المفتاح فورًا (يبدأ بـ <b><bdi dir="ltr">sk-ant-</bdi></b>)، فهو لا يظهر إلا مرة واحدة.</li>
<li>في Kankon Markets افتح تبويب <b>المساعد الذكي</b>، والصق المفتاح، واضغط <b>حفظ</b>.</li></ol>
<p><b>التكلفة:</b> تدفع لـ Anthropic مقابل ما تستخدمه فقط. السؤال الواحد يكلّف بين 2 و4 سنتات أمريكية تقريبًا، أي أن 5 دولارات تكفي نحو 150 سؤالًا. ويمكنك متابعة استهلاكك ووضع حدّ للإنفاق في console.anthropic.com.</p>
<p><b>الخصوصية والأمان:</b></p>
<ul><li>يُحفظ المفتاح على هذا الجهاز فقط، داخل مساحة التخزين الخاصة بالبرنامج، ولا يُرسل إلا إلى Anthropic (api.anthropic.com)، ولا يُرسل أبدًا إلى Kankon أو إلى أي جهة أخرى.</li>
<li>لا ترسل مفتاحك لأحد، ولا تلصقه في محادثة أو بريد، لأن من يملكه يستطيع استخدام رصيدك.</li>
<li>لحذفه من هذا الجهاز اضغط <b>حذف المفتاح</b> تحت المحادثة، وتبقى محادثاتك المحفوظة كما هي.</li>
<li>إذا ظننت أن أحدًا حصل على مفتاحك، فاحذفه من console.anthropic.com (صفحة API Keys) وأنشئ مفتاحًا جديدًا.</li>
<li>يحتاج كل جهاز إلى لصق المفتاح مرة واحدة (Windows وMac منفصلان).</li></ul>
<p><b>إذا حدثت مشكلة:</b></p>
<ul><li><b>«لم تقبل Anthropic مفتاح API»</b>: المفتاح خاطئ أو محذوف أو منتهي الصلاحية. اضغط «حذف المفتاح» والصق مفتاحًا جديدًا.</li>
<li><b>«نفد رصيدك في Anthropic»</b>: أضف رصيدًا من Billing.</li>
<li><b>«عدد الأسئلة كبير في وقت قصير»</b>: انتظر دقيقة ثم اسأل مجددًا.</li>
<li><b>«تعذّر الاتصال بـ Anthropic»</b>: تأكد من الاتصال بالإنترنت.</li>
<li><b>«خدمة Anthropic مشغولة الآن»</b>: حاول بعد قليل.</li></ul>
<p>اشتراك Claude العادي (claude.ai أو Pro) لا يتضمن مفتاح API، فحساب API منفصل في console.anthropic.com.</p>`],
    ['view', 'حجم النافذة وحجم الخط', `
<ul><li>زرّا <b>A−</b> و<b>A+</b> في الأعلى يصغّران محتوى النافذة كله أو يكبّرانه (من 80% إلى 180%). انقر على النسبة مرتين للعودة إلى 100%.</li>
<li>اسحب الخط الرفيع على أي جانب من الرسم البياني لتوسيع قائمة المتابعة أو الجهة الأخرى (المحلل والأخبار والمحادثة) أو تضييقها، وانقر على الخط مرتين لإعادة حجمه الأصلي.</li>
<li><b>English / العربية</b> يبدّل اللغة، والعربية تعرض النافذة من اليمين إلى اليسار.</li>
<li>زر <b>☀ / ☾</b> يبدّل بين الوضع الداكن والوضع الفاتح.</li>
<li>زر <b>⧉ النافذة الصغيرة</b> يحوّل البرنامج إلى قائمة أسعار صغيرة في أعلى يمين الشاشة تبقى فوق النوافذ الأخرى، لتتابع الأسعار وأنت تعمل. اضغط على أي سوق، أو على <b>⤢ كاملة</b>، للرجوع إلى النافذة الكاملة.</li>
<li>يتذكّر البرنامج كل هذه الاختيارات.</li></ul>`],
    ['data', 'مصدر الأسعار', `
<ul><li><b><bdi dir="ltr">Yahoo Finance</bdi></b>: الذهب والفضة والبلاتين والنحاس والنفط أسعار عقود آجلة (COMEX وNYMEX)، والعملات الرقمية والعملات والمؤشرات أسعار السوق. وقد تتأخر حتى 15 دقيقة، وتُحدَّث كل دقيقة.</li>
<li><b>أسهم الكويت والخليج</b>: أسعار من Yahoo Finance لبورصة الكويت والسوق السعودية وسوق دبي المالي وبورصة قطر.</li>
<li><b>نفط الكويت</b>: لا يوجد سعر مباشر مجاني، فيعرض البرنامج سعر الإغلاق الرسمي لكل يوم تداول من OilPrice.com ويحفظ كل يوم على جهازك، فيكبر الرسم يومًا بعد يوم، ويبدأ تحليله بعد 30 يومًا.</li>
<li>من دون إنترنت يفتح البرنامج بآخر الأسعار المحفوظة.</li></ul>`],
    ['contact', 'عن البرنامج', `<p>Kankon Markets من Kankon · <b><bdi dir="ltr">kankon.net</bdi></b>. يُفتح من Kankon Launcher ويُحدَّث تلقائيًا.</p>`],
  ],
};
