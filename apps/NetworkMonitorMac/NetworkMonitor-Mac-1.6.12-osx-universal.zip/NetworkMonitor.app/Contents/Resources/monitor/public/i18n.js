// Network Monitor: English and Arabic text for every page.
// English is the default every time a page opens. The language button switches it for this visit only.
// Rules: /mnt/project-files/translator/TRANSLATION.md (same keys in en and ar; missing Arabic falls back to English).
(function () {
  const S = {
    en: {
      appName: 'Network Monitor', lang: 'العربية', loading: 'Loading…', close: 'Close', save: 'Save', now: 'now',
      // top bar
      runsOn: 'Running on {0} · Version {1}', scanNow: 'Scan now', scanning: 'Scanning…', lastScan: 'Last scan {0}', waiting: 'Waiting',
      pdfSave: 'Save as PDF', pdfPrint: 'Print or save as PDF', pdfSaving: 'Making the PDF…', pdfFail: 'Could not make the PDF.',
      exportCsv: 'Export to Excel', freeIps: 'Free IPs', monthly: 'Reports', alerts: 'Alerts', setup: 'Setup',
      theme: 'Dark / light mode', cantConnect: 'Cannot reach the app. Make sure it is running.',
      // networks
      mainNet: 'Main network', localNet: 'Local network', routerAt: 'Router {0}', nOnline: '{0} online',
      partial: 'Partial scan', partialTip: 'Big network: only the part near this PC is scanned', notConnected: 'Not connected',
      noNetwork: 'This PC is not connected to any network',
      // router bar
      homeInternet: 'Whole home internet', fromRouter: 'From the router', fromRouterModel: 'From the router · {0}',
      downNow: 'Download now', upNow: 'Upload now', usedToday: 'Used today', thisMonth: 'This month', downUp: 'Download {0} · Upload {1}',
      // KPIs
      kOnline: 'Devices online now', kOf: 'of {0}', kOffline: '{0} known devices offline now', kNew: 'New devices today',
      kNewHint: 'Not there in the first scan', kRx: 'Download speed on this PC', kTxHint: 'Upload {0}', kLat: 'Average response time',
      kLatHint: 'Reply time of online devices',
      // devices table
      devices: 'Devices on the network', fAll: 'All', fOnline: 'Online', fOffline: 'Offline', fNew: 'New',
      search: 'Search by name, IP or MAC', thDevice: 'Device', thIp: 'IP address', thMac: 'MAC address', thStatus: 'Status',
      thPing: 'Response', thUsage: 'Used today', thAvail: 'Availability', thSeen: 'Last seen', sortUsage: 'Sort by usage',
      firstScan: 'Scanning the network for the first time, it takes about 10 seconds…', online: 'Online', offline: 'Offline',
      noReply: 'No reply', newTag: 'New', important: 'Important device', noMatch: 'No devices match the search', noDevices: 'No devices found yet',
      onRouter: 'On the router', onRouterTip: 'Connected to the router directly or by Wi-Fi, not to the switch, so its usage cannot be counted',
      wholeSwitch: 'Whole switch', wholeSwitchTip: 'Everything between the switch and the router', shared: 'Shared',
      sharedTip: 'More than one device on this port; the number is for all of them', unnamed: 'Unnamed device', router: 'Router', thisPc: 'This PC',
      // device kinds
      kind_router: 'Router', kind_self: 'This PC', kind_pc: 'Computer', kind_vm: 'Virtual machine', kind_phone: 'Phone or tablet',
      kind_storage: 'Storage (NAS)', kind_tv: 'TV / screen', kind_unknown: 'Unknown device',
      // side panels
      topToday: 'Top devices today', nowRate: 'now {0}', yourUsage: 'This PC usage', download: 'Download', upload: 'Upload',
      last10: 'Last 10 minutes', sinceStart: 'Since start: download {0} · upload {1}', collecting: 'Collecting readings…',
      services: 'Services and ports on this PC', servicesNote: 'Each service runs on a port (like FTP, SSH or a website). Numbers are for today since the app started. ↓ download ↑ upload.',
      port: 'Port {0}', appsBytes: 'Top programs today', appsConn: 'Programs using the internet now',
      appsBytesNote: 'Real usage per program since the start of the day (since the app started). Calls, some games and video use a connection type (UDP) that is not counted here.',
      macHidden: 'macOS is hiding the hardware (MAC) addresses of your devices, so makers and switch ports cannot be shown. Open System Settings > Privacy & Security > Location Services, turn on Network Monitor, then reopen the app. Your location is never read.',
      appsBytesNote_mac: 'Real usage per program since the start of the day (since the app started), including calls, games and video.',
      appsConnNote: 'The number is how many connections each program has. To see usage in MB, the app needs administrator rights.',
      noUsage: 'No usage recorded yet', nConn: '{0} connections', ended: 'Program that ended',
      whyTitle: "Why don't I see each device's usage?",
      whyText: 'The internet of other devices goes through the router, not through this PC, so this PC cannot see how much they download. Per-device numbers come from the switch (Setup > Switch) and home totals from the router (Setup > Router). Everything here is a real reading from your network.',
      svc_21: 'FTP (file transfer)', svc_22: 'SSH (remote control)', svc_80: 'Web', svc_443: 'Secure web', svc_445: 'Windows file sharing',
      svc_1434: 'SQL Browser', svc_3389: 'Remote Desktop (RDP)', svc_8080: 'Web (8080)',
      // history
      histNote: 'Last 30 days total: {0} · highest day: {1}. Hover a bar to see the day.', histTip: '{0}: download {1} · upload {2}',
      // alerts
      alertsPhone: 'Alerts also go to your WhatsApp.', alertsHere: 'Alerts show here. To get them on WhatsApp, turn it on in Setup > WhatsApp.',
      noAlerts: 'No alerts yet. Any new device that joins the network, and any important device that goes offline, shows here.',
      a_back: '{0} is back online', a_new: 'New device joined the network: {0}', a_down: '{0} went offline', a_lastSeen: 'Last seen {0}',
      a_report: 'Monthly report {0}', a_noData: 'Not enough data', a_home: 'Home internet: {0}', a_test: 'Alerts are working ✓',
      deviceIp: 'Device {0}',
      // report
      repHome: 'Whole home internet (from the router)', repDays: 'Days with readings', repTop: 'Top devices', repNo: '#',
      repTotal: 'Total', repShare: 'Share', repNoSwitch: 'No switch data for this period.', repApps: 'Top programs on this PC',
      repNote: 'Readings are kept for about 13 months. You also get a summary in Alerts (and on WhatsApp if turned on) every Friday and at the start of each month.',
      // drawer
      onlineNow: 'Online now', offlineSeen: 'Offline, last seen {0}', devName: 'Device name', namePh: 'Type a name you know it by, like: Ahmed\'s phone',
      netName: 'Name on the network: {0}', impOn: '★ Important device: you get an alert if it goes offline', impOff: '☆ Mark as important (alert me if it goes offline)',
      vendor: 'Maker', privateMac: 'Private (random) address', unknownVendor: 'Unknown', network: 'Network', pingNow: 'Response now',
      noPing: 'Does not reply to ping', avgPing: 'Average response', availOf: '{0} of scans', firstSeen: 'First seen', lastSeen: 'Last seen',
      readings: 'Readings', swPort: 'Switch port', swPortRouter: ' (router port: the device is on the router, not the switch)',
      swPortUplink: ' (links the switch to the router)', sharedWith: ' · shared with {0}', dlToday: 'Download today', ulToday: 'Upload today',
      dlRate: 'Download speed now', ulRate: 'Upload speed now', daily30: 'Daily usage (last 30 days)', pingHour: 'Response time (last hour)',
      gapsNote: 'Gaps in the line mean the device was offline then.', yourPc: 'This is your PC',
      yourPcText: 'Its usage and the programs using the internet on it are in the side panel.', devUsage: "This device's usage",
      devUsageRouter: 'This device is on the router directly or by Wi-Fi, not on the switch, so its own usage cannot be counted.',
      devUsageNoSwitch: 'Usage of every device on the switch shows after you connect the switch in Setup > Switch.',
      forget: 'Remove this device from the list',
      // setup
      tabRouter: 'Router', tabSwitch: 'Switch', tabPhone: 'WhatsApp', tabPassword: 'Password', tabStartup: 'Startup',
      setupIntro: 'These settings are saved on this PC only. They are never uploaded or shared.',
      setupLocalOnly: 'Setup can only be changed on the PC the app runs on.',
      rIntro: 'The router gives the whole home internet usage (today, this month, live speed). Huawei home routers (4G/5G CPE, HiLink) are read without a password.',
      rMode: 'Router type', rAuto: 'Automatic (try the gateway)', rHuawei: 'Huawei (HiLink)', rOff: 'Other / don\'t read the router',
      rHost: 'Router address', rHostPh: 'Empty = gateway {0}', rTest: 'Save and test', rOk: 'Connected ✓ {0}', rFail: 'The router did not answer. Check the address, or pick "Other" if it is not a Huawei router.',
      rOffMsg: 'Saved. The router is not read.', rSteps: 'If it does not connect: open the router page in a browser once, sign in, and make sure the "Statistics" page shows numbers. Some routers only share them on the home network (not on a guest network).',
      sIntro: 'A managed switch counts the data on every port. With SNMP (read only) turned on, the app shows how much each device on the switch uses.',
      sHost: 'Switch address (the switch\'s own IP, not this PC)', sHostPh: 'Switch address, like 192.168.1.2', sComm: 'SNMP community (password)', sConnect: 'Connect', sRemove: 'Disconnect',
      sSaved: 'Switch connected ✓ (no need to type the community again)', sTrying: 'Connecting to the switch…', sOk: 'Connected ✓ usage is counted from now.', sRemoved: 'Disconnected.',
      sFail: 'The switch did not answer. Make sure SNMP is on, the community is right, and this PC\'s address is allowed.',
      a_limit: '{0} passed its daily limit', a_limitBody: 'Used {0} today (limit {1} GB)',
      a_outage: 'The internet was down for {0}', a_outageBody: 'From {0} to {1}',
      a_weekly: 'Weekly summary {0} → {1}', a_outages: 'Internet outages: {0} ({1})', a_noOutages: 'No internet outages',
      limT: 'Daily usage alert', limPh: 'GB per day, like 10', limNote: 'You get an alert (and a WhatsApp message if turned on) when this device uses more than this in one day. Leave empty for no alert.',
      limIs: 'Alert above {0} GB a day', limNone: 'No daily alert',
      netT: 'Internet connection', netUp: 'Working', netDown: 'Down since {0}', netChecking: 'Checking…', netToday: 'Outages today', netWeek: 'Last 7 days',
      netNone: 'No outages recorded yet.', netRecent: 'Recent outages', netNote: 'Checked every 15 seconds. Drops shorter than 30 seconds are not counted.',
      sFind: 'Find the switch', sFinding: 'Looking at the devices on the network…', sFoundNone: 'No switch found. Type its address yourself.', sFoundT: 'Found, tap one to use it:',
      sSnmpOk: 'answers SNMP ✓', sFindTip: 'Tip: type the community first, so the search can check which device answers SNMP.',
      legalWarn: 'Warning: Monitor and limit only networks and devices you own or manage with permission. Tell people on your network that it is monitored. Accessing or interfering with other networks or devices without permission may be a crime under Kuwait Law No. 63 of 2015 on Combating Information Technology Crimes. You are solely responsible for how you use this app.', waT: 'WhatsApp', waIntro: 'Get every alert on your WhatsApp, through the free CallMeBot service (personal use). Do these steps once on your phone:', waS1: 'Save {0} in your phone contacts (any name, like CallMeBot).', waS2: 'Open WhatsApp and send that contact exactly this message: {0}', waS3: 'Wait for the reply: it says your API key is activated and shows the key (a number like 1234567).', waS4: 'Type your WhatsApp number with the country code and the key below, then click Save and send a test.', waNote: 'No reply after 2 minutes? Send the same message again after 24 hours. CallMeBot sometimes changes its number; the current one is always on the CallMeBot website. Keep your key private. It is saved only on this computer.', waSite: 'CallMeBot website', waGuide: 'Step-by-step guide', waPhone: 'Your WhatsApp number (with country code)', waKey: 'API key from CallMeBot', waSave: 'Save and send a test', waOff: 'Turn off', waSent: 'Test sent to WhatsApp ✓ (it can take up to a minute)', waRemoved: 'WhatsApp alerts are off.', waBadPhone: 'Type the WhatsApp number with the country code, like +965 5xxx xxxx.', waBadKey: 'Type the API key that CallMeBot sent you.', waKeyWrong: 'CallMeBot says the API key is wrong for this number. Check both, or send the activation message again.', waConn: 'Could not reach CallMeBot. Check that this PC has internet.', waFail: 'Could not send.',
      wkT: 'Weekly summary', wkOn: 'Send a weekly summary to WhatsApp every Friday (9 AM)', wkTest: 'Send one now', wkSent: 'Sent ✓', wkNoPhone: 'Turn on WhatsApp above first.',
      wkFail: 'Could not send. Make sure WhatsApp is saved and this PC has internet.',
      uNote: 'Used today for each device needs a managed switch with SNMP. A home router alone only gives the whole home total (shown above).',
      uNoteFail: 'Used today for each device is off because the switch is not answering.', uNoteBtn: 'Set up the switch',
      stIntro_mac: 'Keep Network Monitor running in the background and start it when you log in to this Mac, so alerts, history and the page for other devices keep working when the app window is closed.',
      stOn_mac: 'Start when I log in (in the background)', stIsOn_mac: 'On ✓ it keeps running in the background and starts when you log in.',
      stFail_mac: 'Could not change it. Open the app from Kankon Launcher and try again.',
      tabPlan: 'Internet plan', planT: 'Internet plan', planUsed: '{0} of {1} ({2}%)', planLeft: '{0} left', planRenew: 'renews in {0} days', planOver: 'Plan used up',
      planWT: 'Internet plan · this month', plStyle: 'Look on the main screen', plStyleA: 'Blue bar', plStyleB: 'Ring', plStyleC: 'Battery', plUnit: 'Show sizes in', plUnitGB: 'Always GB (9,000 GB)', plUnitTB: 'TB (1.1 TB), GB under 1 TB (987 GB)',
      planNoData: 'Waiting for the router readings…',
      plIntro: 'If your internet has a monthly limit, type it here. The app counts the whole home usage from the router and warns you at 80% and when the plan is used up.',
      plGbPh: 'like 500', plGb: 'Plan size (GB a month)', plDay: 'Renews on day (1 to 28)', plSave: 'Save', plOff: 'Remove', plSaved: 'Saved ✓', plRemoved: 'Removed.',
      plNoRouter: 'Saved. It needs the router readings (Setup > Router) to count the home usage.', plBad: 'Type the size in GB and a day from 1 to 28.',
      a_quota: '{0}% of the internet plan used', a_quotaFull: 'The internet plan is used up', a_quotaBody: '{0} of {1} · {2} left · renews in {3} days',
      rDay: 'Daily', rWeek: 'Weekly', rMonth: 'Monthly', rYear: 'Yearly',
      repDevTotal: 'All devices on the switch', repOutages: 'Internet outages', repByDay: 'Usage by day', repByMonth: 'Usage by month',
      byline: 'by Kankon · kankon.net',
      // help (1.4.0)
      help: 'Help', helpTip: 'Help and user guide (F1)', helpFaq: 'Frequently asked questions', helpTrouble: 'If something goes wrong',
      helpProblem: 'Problem', helpFix: 'What to do', helpTipL: 'Tip:', helpWarnL: 'Note:',
      // speed limits + Auto Detect (1.3.0)
      limTitle: 'Speed limits',
      limIntro: 'Set a maximum download and upload speed for the devices plugged into your managed switch. The limit is set on the switch port, so it works for anything plugged into that port, even when this app is closed.',
      detTitle: 'Auto Detect', detRun: 'Search again', detRunning: 'Looking for the router and switches on your network…',
      detNone: 'No router or managed switch was found. Make sure they are on and on the same network as this PC.',
      detSwitch: 'Switch', detYes: 'Speed limits supported', detNo: 'Speed limits not supported',
      limComm: 'SNMP community with ReadWrite access', limTest: 'Save and test', limOff: 'Turn off speed limits', limChange: 'Switch settings',
      limStepsT: 'One time setup on the switch',
      limSteps: 'NETGEAR S350 (GS308T / GS324T / GS324TP …): open the switch page, go to System > SNMP > SNMP V1/V2 > Community Configuration. In the empty row type this PC\'s IP address, mask 255.255.255.255, a community name of your choice, Access Mode ReadWrite, Status Enable, then press Add. Type the same community name here. Only this PC\'s address can use it.',
      limNoSwitch: 'No managed switch found yet. Press "Search again", or type the switch address in Setup > Switch.',
      limNeedComm: 'Switch found. To change speeds the app needs a ReadWrite SNMP community (see the steps below).',
      limTimeout: 'The switch at {0} did not answer. Check the community name and that this PC\'s IP address is the one allowed for it on the switch.',
      limNotSupported: 'This switch ({0}) does not support speed limits from this app. Its other readings still work. You can set limits from the switch\'s own page.',
      limError: 'The switch answered with an error: {0}', limReady: 'Connected to {0}. Choose a limit for a port and press Apply.',
      limTesting: 'Testing the switch…', limPort: 'Port', limDevices: 'Devices on this port', limNow: 'Download limit now', limSet: 'Change',
      spdNone: 'No limit', limMbps: '{0} Mbps', limKbps: '{0} kbps', limPct: '{0}% (about {1} Mbps)',
      limNowUp: 'Upload limit now', limDown: 'Download', limUp: 'Upload', limUpOther: 'Set on the switch page',
      limUpNo: 'Upload limits are not available on this switch.', limUpOtherErr: 'This port already has a rule made on the switch page. Remove it there first.', limFull: 'The switch has no room for another rule.',
      limApply: 'Apply', limApplying: 'Applying…', limDone: 'Done', limFail: 'Not applied ({0})',
      limReadOnly: 'The switch refused: the community is ReadOnly or not allowed for this PC',
      limTimeoutShort: 'The switch did not answer',
      limUplink: 'Line to the router: a limit here slows the whole switch', limEmpty: 'Nothing plugged in',
      spdNote: 'The limits cap the download and upload speed of the device on that port. The upload limit drops anything above it, so uploads settle a little below the number you choose. Devices on Wi-Fi or plugged into the router cannot be limited from the switch. If several devices share a port (for example through a small switch or Wi-Fi access point), they share the limit.',

      sIsPc: '{0} is this PC, not the switch. Type the switch\'s own address (the one you open its settings page with).',
      sThisPc: 'Allow this PC in the switch SNMP settings: {0} (or allow the whole network, like {1}, so every PC works).',
      sStepsT: 'How to turn on SNMP in the switch',
      sSteps: '1) Open the switch page in a browser and sign in. 2) Find SNMP (often under System or Management). 3) Turn on SNMP v1/v2c, read only. 4) Set a community name (like a password, avoid "public"). 5) If there is an allowed hosts list, add this PC\'s IP. 6) Save, then type the same address and community here.',
      pSending: 'Sending…', pLocal: 'You can set this only on the PC the app runs on.',
      pwTitle: 'Page password', pwOn: 'The page is protected. Any other device that opens it must type the password. On this PC it opens without a password.',
      pwOff: 'The page is open to anyone on the network now. Set a password so other devices must type it first.',
      pw1: 'New password (6 characters or more)', pw2: 'Type it again', pwSave: 'Save password', pwRemove: 'Remove protection', logout: 'Sign out',
      pwSaved: 'Password saved.', pwRemoved: 'Protection removed.', pwLocal: 'You can change it only on the PC the app runs on.', pwShort: 'Not saved. Make sure it is 6 characters or more.',
      pwMismatch: 'The two passwords do not match.', pwConfirm: 'Remove the password? The page will be open to anyone on the network.',
      stIntro: 'Keep Network Monitor running in the background and start it with Windows, so alerts, history and the page for other devices keep working when the app window is closed.',
      stOn: 'Start with Windows (in the background)', stIsOn: 'On ✓ it runs in the background and starts with Windows.', stIsOff: 'Off. It runs only while the app window is open.',
      stFail: 'Could not change it. Open the app from Kankon Launcher (it needs administrator rights).', remote: 'Open from another device: {0}',
      // free IPs page
      backToApp: '← Network Monitor', fTitle: 'Free IP addresses on the network',
      fSub: 'Addresses with no device connected right now. You can use them for a new device without a conflict.',
      fNoNet: 'No network connected right now.', fNever: 'No device ever recorded', fWasUsed: 'A device used it before, offline now',
      fAllUsed: 'All addresses are in use right now', fRouter: 'Router {0}', fPartial: 'Partial scan (first /24 only)', fFreeNow: 'Free now',
      fNeverSeen: 'Never used', fUsedNow: 'In use now', fScanned: 'Scanned {0}. An address that any device answers on (even if it blocks ping) counts as used.',
      fAddrs: 'Addresses', fCount: 'Count', fState: 'State', fCantConnect: 'Cannot reach the app.',
      // login page
      lProtected: 'This page is protected. Type the password to sign in.', lPw: 'Password', lSignIn: 'Sign in', lCant: 'Cannot reach the app',
      lTooMany: 'Too many tries. Wait 5 minutes and try again.', lWrong: 'Wrong password',
    },
    ar: {
      appName: 'Network Monitor', lang: 'English', loading: 'جارٍ التحميل…', close: 'إغلاق', save: 'حفظ', now: 'الآن',
      runsOn: 'يعمل على {0} · الإصدار {1}', scanNow: 'افحص الآن', scanning: 'جارٍ الفحص…', lastScan: 'آخر فحص {0}', waiting: 'في الانتظار',
      pdfSave: 'حفظ بصيغة PDF', pdfPrint: 'طباعة أو حفظ بصيغة PDF', pdfSaving: 'جارٍ إعداد ملف PDF…', pdfFail: 'تعذّر إعداد ملف PDF.',
      exportCsv: 'تصدير إلى Excel', freeIps: 'العناوين الشاغرة', monthly: 'التقارير', alerts: 'التنبيهات', setup: 'الإعدادات',
      theme: 'الوضع الداكن/الفاتح', cantConnect: 'تعذّر الاتصال بالبرنامج. تأكد من أنه يعمل.',
      mainNet: 'الشبكة الرئيسية', localNet: 'شبكة محلية', routerAt: 'الراوتر {0}', nOnline: '{0} متصل',
      partial: 'فحص جزئي', partialTip: 'الشبكة كبيرة، لذا يُفحص الجزء القريب من جهازك فقط', notConnected: 'غير متصل',
      noNetwork: 'هذا الحاسوب غير متصل بأي شبكة',
      homeInternet: 'إنترنت المنزل بالكامل', fromRouter: 'من الراوتر', fromRouterModel: 'من الراوتر · {0}',
      downNow: 'التنزيل الآن', upNow: 'الرفع الآن', usedToday: 'استهلاك اليوم', thisMonth: 'هذا الشهر', downUp: 'تنزيل {0} · رفع {1}',
      kOnline: 'الأجهزة المتصلة الآن', kOf: 'من {0}', kOffline: '{0} من الأجهزة المعروفة غير متصلة الآن', kNew: 'أجهزة جديدة اليوم',
      kNewHint: 'لم تكن موجودة في أول فحص', kRx: 'سرعة التنزيل على جهازك', kTxHint: 'الرفع {0}', kLat: 'متوسط زمن الاستجابة',
      kLatHint: 'زمن استجابة الأجهزة المتصلة',
      devices: 'الأجهزة على الشبكة', fAll: 'الكل', fOnline: 'متصل', fOffline: 'غير متصل', fNew: 'جديد',
      search: 'ابحث بالاسم أو IP أو MAC', thDevice: 'الجهاز', thIp: 'عنوان IP', thMac: 'عنوان MAC', thStatus: 'الحالة',
      thPing: 'الاستجابة', thUsage: 'استهلاك اليوم', thAvail: 'نسبة التوفّر', thSeen: 'آخر ظهور', sortUsage: 'رتّب حسب الاستهلاك',
      firstScan: 'جارٍ فحص الشبكة لأول مرة، ويستغرق ذلك نحو 10 ثوانٍ…', online: 'متصل', offline: 'غير متصل',
      noReply: 'لا يستجيب', newTag: 'جديد', important: 'جهاز مهم', noMatch: 'لا توجد أجهزة مطابقة للبحث', noDevices: 'لم يُعثر على أجهزة بعد',
      onRouter: 'على الراوتر', onRouterTip: 'متصل بالراوتر مباشرةً أو عبر Wi-Fi، لا بالمحوّل، لذا لا يمكن حساب استهلاكه',
      wholeSwitch: 'المحوّل بالكامل', wholeSwitchTip: 'كل ما مرّ بين المحوّل والراوتر', shared: 'مشترك',
      sharedTip: 'على المنفذ نفسه أكثر من جهاز، والرقم يشملها كلها', unnamed: 'جهاز بلا اسم', router: 'الراوتر', thisPc: 'هذا الحاسوب',
      kind_router: 'الراوتر', kind_self: 'هذا الحاسوب', kind_pc: 'حاسوب', kind_vm: 'جهاز افتراضي', kind_phone: 'هاتف أو جهاز لوحي',
      kind_storage: 'وحدة تخزين (NAS)', kind_tv: 'تلفاز / شاشة', kind_unknown: 'جهاز غير معروف',
      topToday: 'أكثر الأجهزة استهلاكًا اليوم', nowRate: 'الآن {0}', yourUsage: 'استهلاك جهازك', download: 'تنزيل', upload: 'رفع',
      last10: 'آخر 10 دقائق', sinceStart: 'منذ بدء التشغيل: تنزيل {0} · رفع {1}', collecting: 'جارٍ جمع القراءات…',
      services: 'الخدمات والمنافذ على هذا الحاسوب', servicesNote: 'تعمل كل خدمة على منفذ (مثل FTP أو SSH أو موقع ويب). والرقم هنا لليوم منذ بدء التشغيل. ↓ تنزيل ↑ رفع.',
      port: 'المنفذ {0}', appsBytes: 'أكثر البرامج استهلاكًا اليوم', appsConn: 'البرامج التي تستخدم الإنترنت الآن',
      appsBytesNote: 'الاستهلاك الفعلي لكل برنامج منذ بداية اليوم (منذ تشغيل Network Monitor). وتستخدم المكالمات وبعض الألعاب والفيديو نوع اتصال (UDP) لا يُحسب هنا.',
      macHidden: 'يُخفي macOS العناوين الفعلية (MAC) لأجهزتك، فلا يمكن عرض الشركات المصنّعة ولا منافذ المحوّل. افتح System Settings > Privacy & Security > Location Services، وفعّل Network Monitor، ثم أعد فتح البرنامج. ولا يُقرأ موقعك أبدًا.',
      appsBytesNote_mac: 'الاستهلاك الفعلي لكل برنامج منذ بداية اليوم (منذ تشغيل Network Monitor)، بما في ذلك المكالمات والألعاب والفيديو.',
      appsConnNote: 'الرقم هو عدد اتصالات كل برنامج. ولعرض الاستهلاك بالميغابايت يحتاج البرنامج إلى صلاحيات المسؤول.',
      noUsage: 'لا يوجد استهلاك مسجَّل بعد', nConn: '{0} اتصال', ended: 'برنامج انتهى',
      whyTitle: 'لماذا لا أرى استهلاك كل جهاز؟',
      whyText: 'يمرّ إنترنت الأجهزة الأخرى عبر الراوتر لا عبر هذا الحاسوب، فلا يستطيع معرفة ما تنزّله. ويأتي استهلاك كل جهاز من المحوّل (الإعدادات > المحوّل)، ومجموع المنزل من الراوتر (الإعدادات > الراوتر). وكل ما تراه هنا قراءات حقيقية من شبكتك.',
      svc_21: 'FTP (نقل الملفات)', svc_22: 'SSH (التحكم عن بُعد)', svc_80: 'ويب', svc_443: 'ويب آمن', svc_445: 'مشاركة ملفات Windows',
      svc_1434: 'SQL Browser', svc_3389: 'سطح المكتب البعيد (RDP)', svc_8080: 'ويب (8080)',
      histNote: 'مجموع آخر 30 يومًا: {0} · أعلى يوم: {1}. مرّر الفأرة فوق أي عمود لترى يومه.', histTip: '{0}: تنزيل {1} · رفع {2}',
      alertsPhone: 'تصل التنبيهات إلى WhatsApp أيضًا.', alertsHere: 'تظهر التنبيهات هنا. ولاستلامها على WhatsApp فعّلها من الإعدادات > WhatsApp.',
      noAlerts: 'لا توجد تنبيهات بعد. سيظهر هنا أي جهاز جديد ينضم إلى الشبكة، وأي جهاز مهم ينقطع.',
      a_back: 'عاد {0} متصلًا', a_new: 'انضم جهاز جديد إلى الشبكة: {0}', a_down: 'انقطع {0} (غير متصل)', a_lastSeen: 'آخر ظهور {0}',
      a_report: 'التقرير الشهري {0}', a_noData: 'لا توجد بيانات كافية', a_home: 'إنترنت المنزل: {0}', a_test: 'التنبيهات تعمل ✓',
      deviceIp: 'جهاز {0}',
      repHome: 'إنترنت المنزل بالكامل (من الراوتر)', repDays: 'أيام فيها قراءات', repTop: 'أكثر الأجهزة استهلاكًا', repNo: '#',
      repTotal: 'المجموع', repShare: 'النسبة', repNoSwitch: 'لا توجد بيانات من المحوّل لهذه الفترة.', repApps: 'أكثر البرامج استهلاكًا على هذا الحاسوب',
      repNote: 'تُحفظ القراءات نحو 13 شهرًا. ويصلك ملخّص في التنبيهات (وعلى WhatsApp إذا فعّلته) كل يوم جمعة وفي أول كل شهر.',
      onlineNow: 'متصل الآن', offlineSeen: 'غير متصل، آخر ظهور {0}', devName: 'اسم الجهاز', namePh: 'اكتب اسمًا تعرفه به، مثل: هاتف أحمد',
      netName: 'الاسم على الشبكة: {0}', impOn: '★ جهاز مهم: سيصلك تنبيه إذا انقطع', impOff: '☆ اجعله جهازًا مهمًا (نبّهني إذا انقطع)',
      vendor: 'الشركة المصنّعة', privateMac: 'عنوان خاص (عشوائي)', unknownVendor: 'غير معروفة', network: 'الشبكة', pingNow: 'الاستجابة الآن',
      noPing: 'لا يستجيب لـ ping', avgPing: 'متوسط الاستجابة', availOf: '{0} من الفحوص', firstSeen: 'أول ظهور', lastSeen: 'آخر ظهور',
      readings: 'عدد القراءات', swPort: 'منفذ المحوّل', swPortRouter: ' (منفذ الراوتر: الجهاز متصل بالراوتر لا بالمحوّل)',
      swPortUplink: ' (يصل المحوّل بالراوتر)', sharedWith: ' · مشترك مع {0}', dlToday: 'تنزيل اليوم', ulToday: 'رفع اليوم',
      dlRate: 'سرعة التنزيل الآن', ulRate: 'سرعة الرفع الآن', daily30: 'الاستهلاك اليومي (آخر 30 يومًا)', pingHour: 'زمن الاستجابة (آخر ساعة)',
      gapsNote: 'تعني الفراغات في الخط أن الجهاز كان غير متصل حينها.', yourPc: 'هذا جهازك',
      yourPcText: 'تجد استهلاكه والبرامج التي تستخدم الإنترنت عليه في اللوحة الجانبية.', devUsage: 'استهلاك هذا الجهاز',
      devUsageRouter: 'هذا الجهاز متصل بالراوتر مباشرةً أو عبر Wi-Fi، لا بالمحوّل، لذا لا يمكن حساب استهلاكه وحده.',
      devUsageNoSwitch: 'يظهر استهلاك كل جهاز متصل بالمحوّل بعد ربط المحوّل من الإعدادات > المحوّل.',
      forget: 'إزالة هذا الجهاز من القائمة',
      tabRouter: 'الراوتر', tabSwitch: 'المحوّل', tabPhone: 'WhatsApp', tabPassword: 'كلمة المرور', tabStartup: 'التشغيل',
      setupIntro: 'تُحفظ هذه الإعدادات على هذا الجهاز فقط، ولا تُرفع ولا تُشارك أبدًا.',
      setupLocalOnly: 'لا تُغيَّر الإعدادات إلا من الحاسوب الذي يعمل عليه البرنامج.',
      rIntro: 'يعطيك الراوتر استهلاك إنترنت المنزل بالكامل (اليوم، وهذا الشهر، والسرعة الآن). ويقرأ البرنامج راوترات Huawei المنزلية (4G/5G CPE وHiLink) دون كلمة مرور.',
      rMode: 'نوع الراوتر', rAuto: 'تلقائي (يجرّب البوابة)', rHuawei: 'Huawei (HiLink)', rOff: 'نوع آخر / لا تقرأ الراوتر',
      rHost: 'عنوان الراوتر', rHostPh: 'فارغ = البوابة {0}', rTest: 'حفظ وتجربة', rOk: 'متصل ✓ {0}', rFail: 'لم يستجب الراوتر. تأكد من العنوان، أو اختر «نوع آخر» إذا لم يكن الراوتر من Huawei.',
      rOffMsg: 'تم الحفظ. لن يقرأ البرنامج الراوتر.', rSteps: 'إذا لم يتصل: افتح صفحة الراوتر في المتصفح مرة واحدة، وسجّل الدخول، وتأكد من وجود أرقام في صفحة «Statistics». فبعض الراوترات لا تعطيها إلا على شبكة المنزل (لا شبكة الضيوف).',
      sIntro: 'يحسب المحوّل المُدار البيانات على كل منفذ. وعند تشغيل SNMP (للقراءة فقط) يعرض البرنامج استهلاك كل جهاز متصل بالمحوّل.',
      sHost: 'عنوان المحوّل (عنوان IP للمحوّل نفسه، لا لهذا الجهاز)', sHostPh: 'عنوان المحوّل، مثل 192.168.1.2', sComm: 'اسم SNMP Community', sConnect: 'ربط', sRemove: 'إلغاء الربط',
      sSaved: 'المحوّل مربوط ✓ (لا داعي لكتابة الاسم مرة أخرى)', sTrying: 'جارٍ الاتصال بالمحوّل…', sOk: 'تم الربط ✓ يبدأ حساب الاستهلاك من الآن.', sRemoved: 'تم إلغاء الربط.',
      sFail: 'لم يستجب المحوّل. تأكد من تفعيل SNMP، ومن صحة الاسم، ومن السماح لعنوان هذا الحاسوب.',
      a_limit: 'تجاوز {0} الحد اليومي', a_limitBody: 'استهلك {0} اليوم (الحد {1} GB)',
      a_outage: 'انقطع الإنترنت {0}', a_outageBody: 'من {0} إلى {1}',
      a_weekly: 'الملخّص الأسبوعي {0} → {1}', a_outages: 'انقطاعات الإنترنت: {0} ({1})', a_noOutages: 'لا توجد انقطاعات في الإنترنت',
      limT: 'تنبيه الاستهلاك اليومي', limPh: 'GB في اليوم، مثلًا 10', limNote: 'يصلك تنبيه (وعلى WhatsApp إذا فعّلته) عندما يستهلك هذا الجهاز أكثر من هذا الحد في يوم واحد. اتركه فارغًا إذا لم ترد تنبيهًا.',
      limIs: 'تنبيه عند تجاوز {0} GB في اليوم', limNone: 'لا يوجد تنبيه يومي',
      netT: 'اتصال الإنترنت', netUp: 'يعمل', netDown: 'منقطع منذ {0}', netChecking: 'جارٍ الفحص…', netToday: 'انقطاعات اليوم', netWeek: 'آخر 7 أيام',
      netNone: 'لم يُسجَّل أي انقطاع حتى الآن.', netRecent: 'آخر الانقطاعات', netNote: 'يُفحص الاتصال كل 15 ثانية، ولا يُحسب الانقطاع الأقصر من 30 ثانية.',
      sFind: 'ابحث عن المحوّل', sFinding: 'جارٍ البحث في أجهزة الشبكة…', sFoundNone: 'لم يُعثر على محوّل. اكتب عنوانه بنفسك.', sFoundT: 'عُثر على ما يلي، اضغط أحدها لاستخدامه:',
      sSnmpOk: 'يستجيب لـ SNMP ✓', sFindTip: 'نصيحة: اكتب اسم Community أولًا، ليعرف البحث أي جهاز يستجيب لـ SNMP.',
      legalWarn: 'تحذير: راقب وقيّد فقط الشبكات والأجهزة التي تملكها أو تديرها بإذن. أبلغ مستخدمي شبكتك بأنها مراقَبة. الدخول إلى شبكات أو أجهزة أخرى أو التدخل فيها دون إذن قد يُعد جريمة وفق القانون الكويتي رقم 63 لسنة 2015 بشأن مكافحة جرائم تقنية المعلومات. أنت وحدك المسؤول عن طريقة استخدامك لهذا البرنامج.', waT: 'WhatsApp', waIntro: 'استلم كل التنبيهات على WhatsApp عبر خدمة CallMeBot المجانية (للاستخدام الشخصي). نفّذ هذه الخطوات مرة واحدة من هاتفك:', waS1: 'احفظ الرقم {0} في جهات الاتصال على هاتفك (بأي اسم، مثل CallMeBot).', waS2: 'افتح WhatsApp وأرسل إلى جهة الاتصال هذه الرسالة كما هي تمامًا: {0}', waS3: 'انتظر الرد، وفيه تأكيد تفعيل مفتاح API والمفتاح نفسه (رقم مثل 1234567).', waS4: 'اكتب رقمك في WhatsApp مع رمز الدولة والمفتاح في الأسفل، ثم اضغط «حفظ وإرسال تجربة».', waNote: 'إذا لم يصلك رد خلال دقيقتين فأرسل الرسالة نفسها مجددًا بعد 24 ساعة. قد تغيّر CallMeBot رقمها أحيانًا، والرقم الحالي موجود دائمًا في موقع CallMeBot. احتفظ بالمفتاح سرًّا، فهو يُحفظ على هذا الحاسوب فقط.', waSite: 'موقع CallMeBot', waGuide: 'الشرح خطوة بخطوة', waPhone: 'رقم WhatsApp الخاص بك (مع رمز الدولة)', waKey: 'مفتاح API من CallMeBot', waSave: 'حفظ وإرسال تجربة', waOff: 'إيقاف', waSent: 'أُرسلت رسالة التجربة إلى WhatsApp ✓ (قد تستغرق دقيقة)', waRemoved: 'أُوقفت تنبيهات WhatsApp.', waBadPhone: 'اكتب رقم WhatsApp مع رمز الدولة، مثل ‎+965 5xxx xxxx.', waBadKey: 'اكتب مفتاح API الذي أرسلته إليك CallMeBot.', waKeyWrong: 'تفيد CallMeBot بأن المفتاح غير صحيح لهذا الرقم. تحقّق منهما، أو أرسل رسالة التفعيل مرة أخرى.', waConn: 'تعذّر الوصول إلى CallMeBot. تأكد من اتصال الجهاز بالإنترنت.', waFail: 'تعذّر الإرسال.',
      wkT: 'الملخّص الأسبوعي', wkOn: 'أرسل ملخّصًا أسبوعيًا إلى WhatsApp كل يوم جمعة (9 صباحًا)', wkTest: 'أرسل ملخّصًا الآن', wkSent: 'أُرسل ✓', wkNoPhone: 'فعّل WhatsApp في الأعلى أولًا.',
      wkFail: 'تعذّر الإرسال. تأكد من حفظ إعدادات WhatsApp ومن اتصال الجهاز بالإنترنت.',
      uNote: 'يحتاج استهلاك اليوم لكل جهاز إلى محوّل مُدار يدعم SNMP. أما الراوتر المنزلي وحده فيعطي استهلاك المنزل بالكامل فقط (في الأعلى).',
      uNoteFail: 'توقّف حساب استهلاك اليوم لكل جهاز لأن المحوّل لا يستجيب.', uNoteBtn: 'إعداد المحوّل',
      stIntro_mac: 'اجعل Network Monitor يعمل في الخلفية ويبدأ عند تسجيل الدخول إلى Mac، لتبقى التنبيهات والسجلّ والصفحة الخاصة بالأجهزة الأخرى تعمل حتى إذا أغلقت نافذة البرنامج.',
      stOn_mac: 'التشغيل عند تسجيل الدخول (في الخلفية)', stIsOn_mac: 'يعمل ✓ يبقى في الخلفية ويبدأ عند تسجيل الدخول.',
      stFail_mac: 'تعذّر التغيير. افتح البرنامج من Kankon Launcher وحاول مرة أخرى.',
      tabPlan: 'باقة الإنترنت', planT: 'باقة الإنترنت', planUsed: '{0} من {1} ({2}%)', planLeft: 'المتبقّي {0}', planRenew: 'تتجدّد بعد {0} يوم', planOver: 'نفدت الباقة',
      planWT: 'باقة الإنترنت · هذا الشهر', plStyle: 'الشكل في الشاشة الرئيسية', plStyleA: 'شريط أزرق', plStyleB: 'حلقة', plStyleC: 'بطارية', plUnit: 'وحدة عرض الأحجام', plUnitGB: 'دائمًا GB (9,000 GB)', plUnitTB: 'TB (1.1 TB)، وGB لما دون 1 TB (987 GB)',
      planNoData: 'في انتظار قراءات الراوتر…',
      plIntro: 'إذا كان لباقة الإنترنت لديك حدّ شهري فاكتبه هنا. يحسب البرنامج استهلاك المنزل بالكامل من الراوتر، وينبّهك عند بلوغ 80% وعند نفاد الباقة.',
      plGbPh: 'مثلًا 500', plGb: 'حجم الباقة (GB في الشهر)', plDay: 'يوم التجديد (من 1 إلى 28)', plSave: 'حفظ', plOff: 'حذف', plSaved: 'تم الحفظ ✓', plRemoved: 'تم الحذف.',
      plNoRouter: 'تم الحفظ، لكن البرنامج يحتاج إلى قراءات الراوتر (الإعدادات > الراوتر) ليحسب استهلاك المنزل.', plBad: 'اكتب الحجم بالـ GB، ويومًا من 1 إلى 28.',
      a_quota: 'استهلكت {0}% من باقة الإنترنت', a_quotaFull: 'نفدت باقة الإنترنت', a_quotaBody: '{0} من {1} · المتبقّي {2} · تتجدّد بعد {3} يوم',
      rDay: 'يومي', rWeek: 'أسبوعي', rMonth: 'شهري', rYear: 'سنوي',
      repDevTotal: 'كل الأجهزة على المحوّل', repOutages: 'انقطاعات الإنترنت', repByDay: 'الاستهلاك حسب اليوم', repByMonth: 'الاستهلاك حسب الشهر',
      byline: 'من Kankon · kankon.net',
      // help (1.4.0)
      help: 'المساعدة', helpTip: 'المساعدة ودليل الاستخدام (F1)', helpFaq: 'الأسئلة الشائعة', helpTrouble: 'إذا حدثت مشكلة',
      helpProblem: 'المشكلة', helpFix: 'الحل', helpTipL: 'نصيحة:', helpWarnL: 'تنبيه:',
      // speed limits + Auto Detect (1.3.0)
      limTitle: 'تحديد السرعة',
      limIntro: 'حدّد أقصى سرعة تنزيل ورفع للأجهزة المتصلة بالمحوّل المُدار. ويُحفظ التحديد على منفذ المحوّل نفسه، فيسري على أي جهاز متصل بذلك المنفذ حتى إذا كان البرنامج مغلقًا.',
      detTitle: 'البحث التلقائي', detRun: 'ابحث مرة أخرى', detRunning: 'جارٍ البحث عن الراوتر والمحوّلات في الشبكة…',
      detNone: 'لم يُعثر على راوتر أو محوّل مُدار. تأكد من أنها تعمل وأنها على شبكة هذا الجهاز نفسها.',
      detSwitch: 'محوّل', detYes: 'يدعم تحديد السرعة', detNo: 'لا يدعم تحديد السرعة',
      limComm: 'SNMP community بصلاحية ReadWrite', limTest: 'حفظ وتجربة', limOff: 'أوقف تحديد السرعة', limChange: 'إعدادات المحوّل',
      limStepsT: 'إعداد لمرة واحدة في المحوّل',
      limSteps: 'NETGEAR S350 (GS308T / GS324T / GS324TP …): افتح صفحة المحوّل، وانتقل إلى System > SNMP > SNMP V1/V2 > Community Configuration. في السطر الفارغ اكتب عنوان IP لهذا الجهاز، وMask ‏255.255.255.255، واسم community تختاره، وAccess Mode ‏ReadWrite، وStatus ‏Enable، ثم اضغط Add. واكتب الاسم نفسه هنا. ولن يتمكّن من استخدامه إلا هذا الجهاز.',
      limNoSwitch: 'لم يُعثر على محوّل مُدار حتى الآن. اضغط «ابحث مرة أخرى»، أو اكتب عنوان المحوّل في الإعدادات > المحوّل.',
      limNeedComm: 'عُثر على المحوّل. ولتغيير السرعة يحتاج البرنامج إلى SNMP community بصلاحية ReadWrite (انظر الخطوات أدناه).',
      limTimeout: 'لم يستجب المحوّل على {0}. تأكد من اسم community، ومن أن عنوان IP لهذا الجهاز هو المسموح له في المحوّل.',
      limNotSupported: 'هذا المحوّل ({0}) لا يدعم تحديد السرعة من البرنامج. وتعمل بقية القراءات كالمعتاد، ويمكنك تحديد السرعة من صفحة المحوّل نفسه.',
      limError: 'ردّ المحوّل بخطأ: {0}', limReady: 'متصل بـ {0}. اختر الحد لأي منفذ واضغط «تطبيق».',
      limTesting: 'جارٍ تجربة المحوّل…', limPort: 'المنفذ', limDevices: 'الأجهزة على المنفذ', limNow: 'حد التنزيل الحالي', limSet: 'تغيير',
      spdNone: 'بلا حد', limMbps: '{0} ميغابت/ث', limKbps: '{0} كيلوبت/ث', limPct: '{0}% (نحو {1} ميغابت/ث)',
      limNowUp: 'حد الرفع الحالي', limDown: 'التنزيل', limUp: 'الرفع', limUpOther: 'مضبوط من صفحة المحوّل',
      limUpNo: 'تحديد سرعة الرفع غير متاح في هذا المحوّل.', limUpOtherErr: 'لهذا المنفذ قاعدة أُنشئت من صفحة المحوّل. احذفها من هناك أولًا.', limFull: 'لا يتّسع المحوّل لقاعدة أخرى.',
      limApply: 'تطبيق', limApplying: 'جارٍ التطبيق…', limDone: 'تم', limFail: 'لم يُطبَّق ({0})',
      limReadOnly: 'رفض المحوّل: الـ community للقراءة فقط أو غير مسموح لهذا الجهاز',
      limTimeoutShort: 'لم يستجب المحوّل',
      limUplink: 'خط الراوتر: التحديد هنا يبطّئ المحوّل بالكامل', limEmpty: 'لا يوجد جهاز متصل',
      spdNote: 'يقيّد التحديد سرعة التنزيل والرفع للجهاز المتصل بهذا المنفذ. ويُسقط حد الرفع كل ما يتجاوزه، لذا تستقر سرعة الرفع أقل قليلًا من الرقم الذي تختاره. ولا يمكن تحديد سرعة الأجهزة المتصلة عبر Wi-Fi أو بالراوتر من المحوّل. وإذا كان على المنفذ نفسه أكثر من جهاز (مثلًا عبر محوّل صغير أو نقطة وصول) فإنها تتقاسم الحد نفسه.',

      sIsPc: '{0} هو هذا الجهاز، لا المحوّل. اكتب عنوان المحوّل نفسه (الذي تفتح منه صفحة إعداداته).',
      sThisPc: 'اسمح لهذا الجهاز في إعدادات SNMP في المحوّل: {0} (أو اسمح للشبكة كلها، مثل {1}، ليعمل من أي جهاز).',
      sStepsT: 'طريقة تشغيل SNMP في المحوّل',
      sSteps: '1) افتح صفحة المحوّل في المتصفح وسجّل الدخول. 2) ابحث عن SNMP (غالبًا تحت System أو Management). 3) شغّل SNMP v1/v2c للقراءة فقط. 4) ضع اسم Community (مثل كلمة مرور، ولا تستخدم "public"). 5) إذا وُجدت قائمة بالأجهزة المسموحة، فأضف عنوان IP لهذا الحاسوب. 6) احفظ، ثم اكتب العنوان والاسم نفسيهما هنا.',
      pSending: 'جارٍ الإرسال…', pLocal: 'لا يمكن ضبطها إلا من الحاسوب الذي يعمل عليه البرنامج.',
      pwTitle: 'كلمة مرور الصفحة', pwOn: 'الصفحة محمية: يجب على أي جهاز آخر يفتحها إدخال كلمة المرور. أما من هذا الحاسوب فتُفتح دون كلمة مرور.',
      pwOff: 'الصفحة الآن مفتوحة لأي شخص على الشبكة. ضع كلمة مرور لتطلبها الأجهزة الأخرى قبل الدخول.',
      pw1: 'كلمة المرور الجديدة (6 أحرف أو أكثر)', pw2: 'اكتبها مرة أخرى', pwSave: 'حفظ كلمة المرور', pwRemove: 'إلغاء الحماية', logout: 'تسجيل الخروج',
      pwSaved: 'تم حفظ كلمة المرور.', pwRemoved: 'تم إلغاء الحماية.', pwLocal: 'لا يمكن تغييرها إلا من الحاسوب الذي يعمل عليه البرنامج.', pwShort: 'لم يتم الحفظ. تأكد من أنها 6 أحرف أو أكثر.',
      pwMismatch: 'كلمتا المرور في الخانتين غير متطابقتين.', pwConfirm: 'هل تريد فعلًا إلغاء كلمة المرور؟ ستصبح الصفحة مفتوحة لأي شخص على الشبكة.',
      stIntro: 'اجعل Network Monitor يعمل في الخلفية ويبدأ مع Windows، لتبقى التنبيهات والسجلّ والصفحة الخاصة بالأجهزة الأخرى تعمل حتى إذا أغلقت نافذة البرنامج.',
      stOn: 'التشغيل مع Windows (في الخلفية)', stIsOn: 'يعمل ✓ في الخلفية ويبدأ مع Windows.', stIsOff: 'متوقف. لا يعمل إلا عندما تكون نافذة البرنامج مفتوحة.',
      stFail: 'تعذّر التغيير. افتح البرنامج من Kankon Launcher (يحتاج إلى صلاحيات المسؤول).', remote: 'افتحه من جهاز آخر: {0}',
      backToApp: 'Network Monitor →', fTitle: 'العناوين الشاغرة في الشبكة',
      fSub: 'العناوين التي لا يتصل بها أي جهاز الآن. يمكنك استخدامها لجهاز جديد دون تعارض مع أي جهاز آخر.',
      fNoNet: 'لا توجد شبكة متصلة الآن.', fNever: 'لم يُسجَّل عليها أي جهاز', fWasUsed: 'كان عليها جهاز سابقًا، وهو غير متصل الآن',
      fAllUsed: 'كل العناوين مستخدمة الآن', fRouter: 'الراوتر {0}', fPartial: 'فحص جزئي (أول /24 فقط)', fFreeNow: 'شاغرة الآن',
      fNeverSeen: 'لم تُستخدم قط', fUsedNow: 'مستخدمة الآن', fScanned: 'جرى الفحص من {0}. ويُعدّ مستخدمًا كل عنوان يستجيب عليه أي جهاز (حتى إذا كان يحجب ping).',
      fAddrs: 'العناوين', fCount: 'العدد', fState: 'الحالة', fCantConnect: 'تعذّر الاتصال بالبرنامج.',
      lProtected: 'هذه الصفحة محمية. اكتب كلمة المرور للدخول.', lPw: 'كلمة المرور', lSignIn: 'تسجيل الدخول', lCant: 'تعذّر الاتصال بالبرنامج',
      lTooMany: 'محاولات كثيرة. انتظر 5 دقائق ثم حاول مرة أخرى.', lWrong: 'كلمة المرور غير صحيحة',
    },
  };

  // English unless the page was opened with ?lang=ar (used when moving between pages of the app).
  let lang = new URLSearchParams(location.search).get('lang') === 'ar' ? 'ar' : 'en';
  const listeners = [];

  // On a Mac some lines say "Mac" instead of "Windows": key_mac wins when it exists.
  let mac = false;
  function T(key, ...args) {
    let t = mac ? (S[lang] && S[lang][key + '_mac']) ?? S.en[key + '_mac'] : null;
    if (t == null) t = (S[lang] && S[lang][key]);
    if (t == null) t = S.en[key];
    if (t == null) return key;
    // On a Mac, English lines say "this Mac" instead of "this PC".
    if (mac && lang === 'en') t = t.replace(/\b([Tt]his) PC\b/g, '$1 Mac').replace(/\bthe PC\b/g, 'the Mac');
    return t.replace(/\{(\d)\}/g, (_, i) => String(args[i] ?? ''));
  }

  // Static text: data-i18n (text), data-i18n-ph (placeholder), data-i18n-title (tooltip).
  function apply(root = document) {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = T(el.dataset.i18n); });
    root.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = T(el.dataset.i18nPh); });
    root.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = T(el.dataset.i18nTitle); });
    root.querySelectorAll('a[data-keep-lang]').forEach((a) => {
      const u = new URL(a.getAttribute('href'), location.href);
      if (lang === 'ar') u.searchParams.set('lang', 'ar'); else u.searchParams.delete('lang');
      a.setAttribute('href', u.pathname + u.search);
    });
  }

  function setLang(l) {
    lang = l === 'ar' ? 'ar' : 'en';
    const u = new URL(location.href);
    if (lang === 'ar') u.searchParams.set('lang', 'ar'); else u.searchParams.delete('lang');
    history.replaceState(null, '', u.pathname + u.search + u.hash);
    apply();
    listeners.forEach((fn) => fn(lang));
  }

  window.I18N = {
    T, apply, setLang,
    setMac: (v) => { mac = !!v; apply(); },
    get lang() { return lang; },
    get rtl() { return lang === 'ar'; },
    locale: () => (lang === 'ar' ? 'ar' : 'en-GB'),
    onChange: (fn) => listeners.push(fn),
    toggle: () => setLang(lang === 'ar' ? 'en' : 'ar'),
  };
  document.addEventListener('DOMContentLoaded', () => apply());
})();
