// Minimal SNMP v2c client (read only): GETBULK-based table walk. No external packages.
const dgram = require('dgram');

// ---------- BER encoding
function encLen(n) {
  if (n < 128) return Buffer.from([n]);
  const bytes = [];
  while (n) { bytes.unshift(n & 255); n >>= 8; }
  return Buffer.from([0x80 | bytes.length, ...bytes]);
}
const tlv = (tag, body) => Buffer.concat([Buffer.from([tag]), encLen(body.length), body]);
function encInt(n) {
  const bytes = [];
  do { bytes.unshift(n & 255); n = Math.floor(n / 256); } while (n > 0);
  if (bytes[0] & 0x80) bytes.unshift(0);
  return tlv(0x02, Buffer.from(bytes));
}
function encOid(str) {
  const p = str.split('.').map(Number);
  const out = [40 * p[0] + p[1]];
  for (const n of p.slice(2)) {
    const st = [n & 127];
    let v = Math.floor(n / 128);
    while (v) { st.unshift((v & 127) | 128); v = Math.floor(v / 128); }
    out.push(...st);
  }
  return tlv(0x06, Buffer.from(out));
}

// ---------- BER decoding
function readTlv(buf, pos) {
  const tag = buf[pos];
  let len = buf[pos + 1];
  let off = pos + 2;
  if (len & 0x80) {
    const n = len & 0x7f;
    len = 0;
    for (let i = 0; i < n; i++) len = len * 256 + buf[off + i];
    off += n;
  }
  return { tag, start: off, end: off + len };
}
function decOid(b) {
  const out = [Math.floor(b[0] / 40), b[0] % 40];
  let v = 0;
  for (let i = 1; i < b.length; i++) {
    v = v * 128 + (b[i] & 127);
    if (!(b[i] & 128)) { out.push(v); v = 0; }
  }
  return out.join('.');
}
function decUnsigned(b) {
  let v = 0n;
  for (const x of b) v = (v << 8n) | BigInt(x);
  return Number(v);
}
function decValue(tag, b) {
  switch (tag) {
    case 0x02: { // INTEGER (signed)
      let v = 0;
      for (const x of b) v = v * 256 + x;
      if (b.length && b[0] & 0x80) v -= 2 ** (8 * b.length);
      return v;
    }
    case 0x04: return b; // OCTET STRING (raw bytes)
    case 0x06: return decOid(b);
    case 0x41: case 0x42: case 0x43: case 0x46: return decUnsigned(b); // Counter32/Gauge32/TimeTicks/Counter64
    case 0x80: case 0x81: case 0x82: return undefined; // noSuchObject / noSuchInstance / endOfMibView
    default: return b;
  }
}
function parseResponse(buf) {
  const msg = readTlv(buf, 0);
  let p = msg.start;
  p = readTlv(buf, p).end; // version
  p = readTlv(buf, p).end; // community
  const pdu = readTlv(buf, p);
  let q = pdu.start;
  const reqId = readTlv(buf, q); q = reqId.end;
  const errStat = readTlv(buf, q); q = errStat.end;
  q = readTlv(buf, q).end; // error index
  const vbl = readTlv(buf, q);
  const out = [];
  let r = vbl.start;
  while (r < vbl.end) {
    const vb = readTlv(buf, r);
    const o = readTlv(buf, vb.start);
    const v = readTlv(buf, o.end);
    out.push({ oid: decOid(buf.subarray(o.start, o.end)), type: v.tag, value: decValue(v.tag, buf.subarray(v.start, v.end)) });
    r = vb.end;
  }
  return { reqId: decValue(2, buf.subarray(reqId.start, reqId.end)), error: decValue(2, buf.subarray(errStat.start, errStat.end)), varbinds: out };
}

// ---------- client
class Snmp {
  constructor(host, community, { timeout = 2000, retries = 1 } = {}) {
    this.host = host; this.community = community; this.timeout = timeout; this.retries = retries;
    this.reqId = Math.floor(Math.random() * 1e6);
    this.pending = new Map();
    this.sock = dgram.createSocket('udp4');
    this.sock.on('message', (m) => {
      let res;
      try { res = parseResponse(m); } catch (_) { return; }
      const p = this.pending.get(res.reqId);
      if (p) { this.pending.delete(res.reqId); clearTimeout(p.timer); p.resolve(res); }
    });
    this.sock.on('error', () => {});
    this.sock.unref();
  }
  close() { try { this.sock.close(); } catch (_) {} }

  request(pduTag, oids, a = 0, b = 0) {
    const id = (this.reqId = (this.reqId + 1) % 2147483647);
    const vbs = tlv(0x30, Buffer.concat(oids.map((o) => tlv(0x30, Buffer.concat([encOid(o), Buffer.from([0x05, 0x00])])))));
    const pdu = tlv(pduTag, Buffer.concat([encInt(id), encInt(a), encInt(b), vbs]));
    const msg = tlv(0x30, Buffer.concat([encInt(1), tlv(0x04, Buffer.from(this.community)), pdu]));
    return new Promise((resolve, reject) => {
      let tries = 0;
      const send = () => {
        this.sock.send(msg, 161, this.host);
        const timer = setTimeout(() => {
          if (++tries > this.retries) { this.pending.delete(id); reject(new Error('SNMP timeout')); } else send();
        }, this.timeout);
        this.pending.set(id, { resolve, timer });
      };
      send();
    });
  }

  get(oids) { return this.request(0xa0, oids); }

  // Walk a subtree; returns Map(suffix -> value), suffix = the part of the OID after `base`.
  async walk(base, maxRep = 25) {
    const out = new Map();
    let cur = base;
    for (let guard = 0; guard < 2000; guard++) {
      const res = await this.request(0xa5, [cur], 0, maxRep);
      if (res.error) break;
      let done = false;
      for (const vb of res.varbinds) {
        if (vb.value === undefined || !vb.oid.startsWith(base + '.')) { done = true; break; }
        out.set(vb.oid.slice(base.length + 1), vb.value);
        cur = vb.oid;
      }
      if (done || !res.varbinds.length) break;
    }
    return out;
  }
}

module.exports = { Snmp };
