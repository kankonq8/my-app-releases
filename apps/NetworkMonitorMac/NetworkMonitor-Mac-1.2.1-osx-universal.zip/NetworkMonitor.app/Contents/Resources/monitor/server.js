// Network monitor: finds the devices on the networks this computer is connected to,
// and measures this computer's own traffic and connections.
// Everything shown in the page comes from real readings. Nothing is simulated.

const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const dns = require('dns').promises;
const { exec, execFile } = require('child_process');

// Where this PC's own data and settings live. The installed app passes --data <folder>
// (C:\ProgramData\NetworkMonitor\data); running server.js by hand keeps them next to it.
function argValue(name) { const i = process.argv.indexOf(name); return i > 0 ? process.argv[i + 1] : null; }
const DATA_DIR = argValue('--data') || process.env.NM_DATA_DIR || __dirname;
try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (_) {}
const PORT = Number(argValue('--port') || process.env.PORT) || 8080;
let APP_VERSION = '1.0.0';
try { APP_VERSION = fs.readFileSync(path.join(__dirname, 'VERSION'), 'utf8').trim() || APP_VERSION; } catch (_) {}
const DATA_FILE = path.join(DATA_DIR, 'network-data.json');
const PUBLIC_DIR = path.join(__dirname, 'public');

const SCAN_INTERVAL_MS = 60 * 1000;     // full network scan
const TRAFFIC_INTERVAL_MS = 5 * 1000;   // this PC's traffic counters
const APPS_INTERVAL_MS = 15 * 1000;     // this PC's connections per program
const PING_TIMEOUT_MS = 800;
const PING_CONCURRENCY = 48;
const MAX_HOSTS_PER_NETWORK = 1022;     // larger networks: only the /24 around this PC is pinged
const HISTORY_POINTS = 60;

const IS_WIN = process.platform === 'win32';
const IS_MAC = process.platform === 'darwin';

// When started in the background (no window), write messages to network-monitor.log instead.
if (!process.stdout.isTTY && process.env.NM_LOG !== 'console') {
  const LOG_FILE = path.join(DATA_DIR, 'network-monitor.log');
  try { if (fs.statSync(LOG_FILE).size > 2e6) fs.renameSync(LOG_FILE, LOG_FILE + '.old'); } catch (_) {}
  const write = (lvl, args) => fs.appendFile(LOG_FILE,
    `${new Date().toISOString()} ${lvl} ${args.map((a) => (a instanceof Error ? a.stack : typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}\n`, () => {});
  console.log = (...a) => write('INFO', a);
  console.error = (...a) => write('ERROR', a);
}

// ---------------------------------------------------------------- helpers

function run(cmd, args, timeout = 15000) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 20 * 1024 * 1024 }, (err, stdout) => {
      resolve(String(stdout || ''));
    });
  });
}

function runShell(cmd, timeout = 15000) {
  return new Promise((resolve) => {
    exec(cmd, { timeout, windowsHide: true, maxBuffer: 20 * 1024 * 1024 }, (err, stdout) => {
      resolve(String(stdout || ''));
    });
  });
}

const ipToInt = (ip) => ip.split('.').reduce((n, o) => ((n << 8) >>> 0) + Number(o), 0) >>> 0;
const intToIp = (n) => [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
const maskToPrefix = (mask) => ipToInt(mask).toString(2).replace(/0/g, '').length;
const normMac = (m) => (m || '').toLowerCase().replace(/-/g, ':');

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx]);
    }
  });
  await Promise.all(workers);
  return out;
}

// ---------------------------------------------------------------- local networks

// Default gateways, read from the routing table (numbers only, so it works in any Windows language).
async function getGateways() {
  const gateways = [];
  if (IS_WIN) {
    const out = await run('route', ['print', '-4']);
    const re = /^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+)/gm;
    let m;
    while ((m = re.exec(out))) gateways.push({ gateway: m[1], iface: m[2], metric: Number(m[3]) });
  } else if (IS_MAC) {
    // "default  192.168.1.1  UGScg  en0" (first one is the main route)
    const out = await run('netstat', ['-rn', '-f', 'inet']);
    const ifs = os.networkInterfaces();
    let metric = 0;
    for (const line of out.split('\n')) {
      const p = line.trim().split(/\s+/);
      if (p[0] !== 'default' || !/^\d+\.\d+\.\d+\.\d+$/.test(p[1] || '')) continue;
      const a = (ifs[p[3]] || []).find((x) => x.family === 'IPv4' || x.family === 4);
      gateways.push({ gateway: p[1], iface: a ? a.address : '', metric: metric++ });
    }
  } else {
    const out = await runShell('ip -4 route show default 2>/dev/null');
    const re = /default via (\d+\.\d+\.\d+\.\d+).*?src (\d+\.\d+\.\d+\.\d+)?/g;
    let m;
    while ((m = re.exec(out))) gateways.push({ gateway: m[1], iface: m[2] || '', metric: 0 });
  }
  return gateways;
}

// Every IPv4 network this computer is on, from the OS itself (no text parsing of ipconfig).
async function getLocalNetworks() {
  const gateways = await getGateways();
  const nets = new Map();
  for (const [name, addrs] of Object.entries(os.networkInterfaces())) {
    for (const a of addrs || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal || a.address.startsWith('169.254.')) continue;
      const prefix = maskToPrefix(a.netmask);
      if (prefix >= 31) continue;
      const ipInt = ipToInt(a.address);
      const netInt = (ipInt & ipToInt(a.netmask)) >>> 0;
      const cidr = `${intToIp(netInt)}/${prefix}`;
      const gw = gateways.find((g) => g.iface === a.address) ||
        gateways.find((g) => ((ipToInt(g.gateway) & ipToInt(a.netmask)) >>> 0) === netInt);
      if (!nets.has(cidr)) {
        const size = 2 ** (32 - prefix);
        let start = netInt + 1;
        let end = netInt + size - 2;
        let limited = false;
        if (end - start + 1 > MAX_HOSTS_PER_NETWORK) {
          const block = (ipInt & 0xffffff00) >>> 0;
          start = block + 1;
          end = block + 254;
          limited = true;
        }
        nets.set(cidr, {
          cidr, prefix, netmask: a.netmask,
          start, end, limited,
          gateway: gw ? gw.gateway : null,
          metric: gw ? gw.metric : 9999,
          interfaces: [],
        });
      }
      nets.get(cidr).interfaces.push({ name, ip: a.address, mac: normMac(a.mac) });
    }
  }
  // Main network (the one with the best default route) first.
  return [...nets.values()].sort((x, y) => (x.gateway ? 0 : 1) - (y.gateway ? 0 : 1) || x.metric - y.metric);
}

// ---------------------------------------------------------------- probes

function ping(ip) {
  const args = IS_WIN
    ? ['-n', '1', '-w', String(PING_TIMEOUT_MS), ip]
    : IS_MAC ? ['-c', '1', '-t', '1', ip] : ['-c', '1', '-W', '1', ip];
  const t0 = Date.now();
  return run('ping', args, PING_TIMEOUT_MS + 2000).then((out) => {
    // "TTL=" only appears in a real reply (not in "destination host unreachable"), in every language.
    const alive = /ttl=/i.test(out);
    if (!alive) return { alive: false, ms: null };
    const m = out.match(/[=<]\s*(\d+(?:\.\d+)?)\s*ms/i);
    return { alive: true, ms: m ? Math.round(Number(m[1])) : Math.min(Date.now() - t0, PING_TIMEOUT_MS) };
  });
}

// IP -> MAC from the ARP table. Devices that block ping still show up here once we tried to reach them.
async function readArp() {
  const out = await run('arp', ['-a']);
  const table = new Map();
  // Windows: "192.168.1.1   a0-12-34-00-00-01". macOS: "? (192.168.1.1) at a0:12:34:0:0:1 on en0".
  const re = IS_MAC ? /\((\d+\.\d+\.\d+\.\d+)\) at ([0-9a-f]{1,2}(?::[0-9a-f]{1,2}){5})/gi
    : /(\d+\.\d+\.\d+\.\d+)\s+([0-9a-f]{2}(?:[-:][0-9a-f]{2}){5})/gi;
  let m;
  while ((m = re.exec(out))) {
    const mac = normMac(m[2]).split(':').map((x) => x.padStart(2, '0')).join(':');
    if (mac === 'ff:ff:ff:ff:ff:ff' || mac.startsWith('01:00:5e') || mac === '00:00:00:00:00:00') continue;
    table.set(m[1], mac);
  }
  return table;
}

const nameCache = new Map(); // ip -> { name, at }
async function lookupName(ip) {
  const cached = nameCache.get(ip);
  if (cached && Date.now() - cached.at < 10 * 60 * 1000) return cached.name;
  let name = null;
  try {
    const names = await Promise.race([
      dns.reverse(ip),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 1500)),
    ]);
    if (names && names[0]) name = names[0].split('.')[0];
  } catch (_) { /* no name */ }
  nameCache.set(ip, { name, at: Date.now() });
  return name;
}

// A short list of well-known manufacturer prefixes. Unknown ones are simply left blank.
const VENDORS = {
  '00:50:56': 'VMware', '00:0c:29': 'VMware', '00:05:69': 'VMware',
  '08:00:27': 'VirtualBox', '00:15:5d': 'Hyper-V',
  'b8:27:eb': 'Raspberry Pi', 'dc:a6:32': 'Raspberry Pi', 'e4:5f:01': 'Raspberry Pi',
  '00:e0:4c': 'Realtek',
};
const VIRTUAL = new Set(['VMware', 'VirtualBox', 'Hyper-V']);

function describeMac(mac) {
  if (!mac) return { vendor: null, privateMac: false };
  const vendor = VENDORS[mac.slice(0, 8)] || null;
  // Second bit of the first byte set = "locally administered" (random/private address, typical of phones).
  const privateMac = (parseInt(mac.slice(0, 2), 16) & 2) === 2;
  return { vendor, privateMac };
}

// ---------------------------------------------------------------- state

let state = { version: 2, devices: {}, scans: {}, appDays: {} };
let networks = [];
let scanning = false;
let lastScan = null;
let lastScanMs = null;

function loadData() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (data && data.version === 2) {
      state = { version: 2, devices: data.devices || {}, scans: data.scans || {}, appDays: data.appDays || {}, svcDays: data.svcDays || {}, portDays: data.portDays || {}, alerts: data.alerts || [], lastReportMonth: data.lastReportMonth || null, routerMonths: data.routerMonths || {},
        routerDays: data.routerDays || {}, outages: data.outages || [], lastWeekly: data.lastWeekly || null };
      for (const k of Object.keys(state.routerDays).sort().slice(0, -62)) delete state.routerDays[k];
      for (const k of Object.keys(state.portDays).sort().slice(0, -31)) delete state.portDays[k];
      // keep 31 days of per-program totals
      for (const k of Object.keys(state.appDays).sort().slice(0, -31)) delete state.appDays[k];
      for (const d of Object.values(state.devices)) d.online = false;
      console.log(`Loaded ${Object.keys(state.devices).length} known devices`);
    } else {
      console.log('Old data file found (simulated numbers). Starting a fresh, real record.');
    }
  } catch (_) {
    console.log('Starting a fresh record');
  }
}

let saveTimer = null;
function saveData() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFile(DATA_FILE, JSON.stringify(state, null, 1), (err) => {
      if (err) console.error('Could not save data:', err.message);
    });
  }, 500);
}

function deviceKey(cidr, mac, ip) {
  return `${cidr}|${mac || 'ip:' + ip}`;
}

async function scanNetwork(net) {
  const ips = [];
  for (let n = net.start; n <= net.end; n++) ips.push(intToIp(n));
  const selfIps = new Set(net.interfaces.map((i) => i.ip));

  const pings = await mapLimit(ips, PING_CONCURRENCY, async (ip) => ({ ip, ...(await ping(ip)) }));
  const arp = await readArp();

  const found = new Map(); // ip -> { mac, ms, viaPing }
  for (const p of pings) if (p.alive) found.set(p.ip, { mac: arp.get(p.ip) || null, ms: p.ms, viaPing: true });
  for (const [ip, mac] of arp) {
    const n = ipToInt(ip);
    if (n < net.start || n > net.end || found.has(ip)) continue;
    found.set(ip, { mac, ms: null, viaPing: false }); // answered ARP but blocks ping
  }
  for (const i of net.interfaces) found.set(i.ip, { mac: i.mac, ms: 0, viaPing: true });

  const now = new Date().toISOString();
  state.scans[net.cidr] = (state.scans[net.cidr] || 0) + 1;
  const scanNo = state.scans[net.cidr];
  const seenKeys = new Set();

  await mapLimit([...found.entries()], 16, async ([ip, info]) => {
    const key = deviceKey(net.cidr, info.mac, ip);
    seenKeys.add(key);
    // If this MAC was known under its IP only, merge it.
    const ipOnlyKey = deviceKey(net.cidr, null, ip);
    if (info.mac && state.devices[ipOnlyKey] && !state.devices[key]) {
      state.devices[key] = { ...state.devices[ipOnlyKey], id: key, mac: info.mac };
      delete state.devices[ipOnlyKey];
    }
    const isNewDevice = !state.devices[key];
    const d = state.devices[key] || (state.devices[key] = {
      id: key, cidr: net.cidr, ip, mac: info.mac, firstSeen: now, firstScan: scanNo,
      seenCount: 0, latency: [], customName: null,
    });
    if (d.important && d.offlineAlerted) {
      d.offlineAlerted = false;
      addAlert('back', devParams(d), d.id);
    }
    d.missed = 0;
    // Another device that used to have this IP is no longer at it.
    d.ip = ip;
    d.mac = info.mac || d.mac;
    d.lastSeen = now;
    d.online = true;
    d.pingBlocked = !info.viaPing;
    d.seenCount += 1;
    d.latencyMs = info.ms;
    d.latency.push(info.ms);
    if (d.latency.length > HISTORY_POINTS) d.latency.splice(0, d.latency.length - HISTORY_POINTS);
    d.isSelf = selfIps.has(ip);
    d.isGateway = ip === net.gateway;
    const { vendor, privateMac } = describeMac(d.mac);
    d.vendor = vendor;
    d.privateMac = privateMac;
    const name = d.isSelf ? os.hostname() : await lookupName(ip);
    if (name) d.hostname = name;
    // A device that wasn't there in this network's first scan is a newcomer.
    if (isNewDevice && scanNo > 1) {
      addAlert('new', { ...devParams(d), mac: d.mac ? d.mac.toUpperCase() : null, vendor: d.vendor || null }, d.id);
    }
  });

  for (const d of Object.values(state.devices)) {
    if (d.cidr !== net.cidr || seenKeys.has(d.id)) continue;
    if (d.online) { d.online = false; }
    d.missed = (d.missed || 0) + 1;
    // Two missed scans in a row (about 2 minutes) before we call an important device down.
    if (d.important && d.missed >= 2 && !d.offlineAlerted) {
      d.offlineAlerted = true;
      addAlert('down', { ...devParams(d), lastSeen: d.lastSeen }, d.id);
    }
    d.latency.push(null);
    if (d.latency.length > HISTORY_POINTS) d.latency.splice(0, d.latency.length - HISTORY_POINTS);
    // The IP may now belong to someone else; don't show two online devices with one IP.
  }
}

async function scanAll() {
  if (scanning) return;
  scanning = true;
  const t0 = Date.now();
  try {
    networks = await getLocalNetworks();
    if (networks.length === 0) console.log('No network connection found.');
    for (const net of networks) {
      console.log(`Scanning ${net.cidr}${net.limited ? ' (only the part around this PC)' : ''} ...`);
      await scanNetwork(net);
    }
    lastScan = new Date().toISOString();
    lastScanMs = Date.now() - t0;
    const online = Object.values(state.devices).filter((d) => d.online).length;
    console.log(`Scan done in ${(lastScanMs / 1000).toFixed(1)}s: ${online} devices online`);
    checkMonthlyReport();
    checkWeekly();
    saveData();
  } catch (err) {
    console.error('Scan failed:', err);
  } finally {
    scanning = false;
  }
}

// ---------------------------------------------------------------- alerts (page + phone via ntfy)
const https = require('https');

// Alerts are stored as a kind plus plain values, so the page shows them in the language the
// person picked. Phone notices use the last language picked in the app (settings.noticeLang).
const devParams = (d) => ({ name: d.customName || d.hostname || null, ip: d.ip, gw: !!d.isGateway });

const NOTICE = {
  en: {
    router: 'Router', device: 'Device {0}', appName: 'Network Monitor',
    back: '{0} is back online', new: 'New device joined the network: {0}', down: '{0} went offline',
    lastSeen: 'Last seen {0}', report: 'Monthly report {0}', noData: 'Not enough data', home: 'Home internet: {0}',
    test: 'Alerts are working ✓ You will get a notice when a new device joins or an important device goes offline.',
    limit: '{0} passed its daily limit', limitBody: 'Used {0} today (limit {1} GB)',
    outage: 'The internet was down for {0}', outageBody: 'From {0} to {1}',
    weekly: 'Weekly summary {0} → {1}', outages: 'Internet outages: {0} ({1})', noOutages: 'No internet outages',
  },
  ar: {
    router: 'الراوتر', device: 'جهاز {0}', appName: 'Network Monitor',
    back: '{0} رجع متصل', new: 'جهاز جديد دخل الشبكة: {0}', down: '{0} فصل (غير متصل)',
    lastSeen: 'آخر ظهور {0}', report: 'التقرير الشهري {0}', noData: 'ما فيه بيانات كافية', home: 'إنترنت البيت: {0}',
    test: 'التنبيهات شغالة ✓ بيوصلك تنبيه لما يدخل جهاز جديد أو يفصل جهاز مهم.',
    limit: '{0} تعدى الحد اليومي', limitBody: 'استهلك {0} اليوم (الحد {1} GB)',
    outage: 'النت كان فاصل {0}', outageBody: 'من {0} إلى {1}',
    weekly: 'الملخص الأسبوعي {0} → {1}', outages: 'انقطاعات النت: {0} ({1})', noOutages: 'ما فيه انقطاعات بالنت',
  },
};
function nt(lang, key, ...args) {
  const t = (NOTICE[lang] || NOTICE.en)[key] || NOTICE.en[key] || key;
  return t.replace(/\{(\d)\}/g, (_, i) => String(args[i] ?? ''));
}
const pName = (lang, p) => p.name || (p.gw ? nt(lang, 'router') : nt(lang, 'device', p.ip));

// Title and body of an alert as text, for the phone and the log.
function alertText(a, lang = 'en') {
  const p = a.p;
  if (!p) return { title: a.title || '', body: a.body || '' }; // alerts saved by older versions
  switch (a.kind) {
    case 'back': return { title: nt(lang, 'back', pName(lang, p)), body: p.ip };
    case 'new': return { title: nt(lang, 'new', pName(lang, p)), body: [`IP ${p.ip}`, p.mac && `MAC ${p.mac}`, p.vendor].filter(Boolean).join(' · ') };
    case 'down': return { title: nt(lang, 'down', pName(lang, p)), body: `${nt(lang, 'lastSeen', new Date(p.lastSeen).toLocaleString('en-GB'))} · ${p.ip}` };
    case 'report': {
      const lines = (p.top || []).map((d, i) => `${i + 1}. ${pName(lang, d)}${d.others ? ` (+${d.others})` : ''}: ${fmtBytes(d.total)}`);
      const home = p.home != null ? `\n${nt(lang, 'home', fmtBytes(p.home))}` : '';
      return { title: nt(lang, 'report', p.month), body: (lines.join('\n') || nt(lang, 'noData')) + home };
    }
    case 'test': return { title: nt(lang, 'appName'), body: nt(lang, 'test') };
    case 'limit': return { title: nt(lang, 'limit', pName(lang, p)), body: `${nt(lang, 'limitBody', fmtBytes(p.total), p.limit)} · ${p.ip}` };
    case 'outage': return { title: nt(lang, 'outage', fmtDur(p.sec)), body: nt(lang, 'outageBody', fmtTime(p.start), fmtTime(p.end)) };
    case 'weekly': {
      const lines = (p.top || []).map((d, i) => `${i + 1}. ${pName(lang, d)}${d.others ? ` (+${d.others})` : ''}: ${fmtBytes(d.total)}`);
      if (p.home != null) lines.push(nt(lang, 'home', fmtBytes(p.home)));
      lines.push(p.outages ? nt(lang, 'outages', p.outages, fmtDur(p.outageSec)) : nt(lang, 'noOutages'));
      return { title: nt(lang, 'weekly', p.from.slice(5), p.to.slice(5)), body: lines.join('\n') };
    }
    default: return { title: a.kind, body: '' };
  }
}

function addAlert(kind, params, deviceId) {
  state.alerts = state.alerts || [];
  const a = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), kind, p: params, deviceId: deviceId || null, at: new Date().toISOString(), read: false };
  state.alerts.unshift(a);
  if (state.alerts.length > 200) state.alerts.length = 200;
  const t = alertText(a);
  console.log(`ALERT [${kind}] ${t.title} ${t.body}`);
  pushToPhone(a);
  saveData();
}

// ntfy.sh: free push notifications. The person installs the ntfy app and subscribes to a
// private topic name; we post the alert to that topic. Nothing else is sent anywhere.
function pushToPhone(a, topicOverride) {
  const topic = topicOverride || (typeof settings !== 'undefined' && settings.ntfyTopic);
  if (!topic) return Promise.resolve(false);
  const text = alertText(a, (typeof settings !== 'undefined' && settings.noticeLang) || 'en');
  const enc = (t) => `=?UTF-8?B?${Buffer.from(t, 'utf8').toString('base64')}?=`;
  const tags = { new: 'new', down: 'warning', back: 'white_check_mark', report: 'bar_chart', test: 'bell', limit: 'chart_with_upwards_trend', outage: 'globe_with_meridians', weekly: 'calendar' }[a.kind] || 'bell';
  return new Promise((resolve) => {
    const req = https.request({
      host: 'ntfy.sh', path: '/' + encodeURIComponent(topic), method: 'POST', timeout: 8000,
      headers: { Title: enc(text.title), Tags: tags, Priority: a.kind === 'down' || a.kind === 'limit' ? 'high' : 'default', 'Content-Type': 'text/plain; charset=utf-8' },
    }, (res) => { res.resume(); resolve(res.statusCode === 200); });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(false));
    req.end(text.body || text.title);
  });
}

// ---------------------------------------------------------------- monthly report
function portDevices() {
  // switch port -> devices currently learned on it
  const m = new Map();
  for (const d of Object.values(state.devices)) {
    if (!d.mac) continue;
    const idx = sw.macPort.get(d.mac);
    if (!idx) continue;
    if (!m.has(String(idx))) m.set(String(idx), []);
    m.get(String(idx)).push(d);
  }
  return m;
}

// Usage per device (one entry per switch port) over the given days, biggest first.
function deviceTotals(days) {
  const totals = new Map(); // port -> [down, up]
  for (const day of days) {
    for (const [idx, [rx, tx]] of Object.entries((state.portDays || {})[day] || {})) {
      const t = totals.get(idx) || [0, 0];
      t[0] += rx; t[1] += tx;
      totals.set(idx, t);
    }
  }
  const byPort = portDevices();
  const gw = Object.values(state.devices).find((d) => d.isGateway && d.mac);
  const uplinkIdx = gw && sw.macPort.get(gw.mac) ? String(sw.macPort.get(gw.mac)) : null;
  return [...totals.entries()]
    .filter(([idx]) => idx !== uplinkIdx && byPort.has(idx))
    .map(([idx, [rx, tx]]) => {
      const list = byPort.get(idx);
      const lead = list.find((d) => d.customName || d.hostname) || list[0];
      return { id: lead.id, name: lead.customName || lead.hostname || null, gw: !!lead.isGateway, ip: lead.ip, others: list.length - 1, port: sw.names.get(Number(idx)) || idx, rx, tx, total: rx + tx };
    })
    .filter((x) => x.total > 0)
    .sort((a, b) => b.total - a.total);
}

function buildReport(month) { // month = 'YYYY-MM'
  const days = Object.keys(state.portDays || {}).filter((k) => k.startsWith(month)).sort();
  const devices = deviceTotals(days);
  const apps = {};
  for (const [day, v] of Object.entries(state.appDays || {})) {
    if (!day.startsWith(month)) continue;
    for (const [name, [rx, tx]] of Object.entries(v)) {
      apps[name] = apps[name] || [0, 0];
      apps[name][0] += rx; apps[name][1] += tx;
    }
  }
  return {
    month, days: days.length, from: days[0] || null, to: days[days.length - 1] || null,
    devices: devices.slice(0, 15),
    apps: Object.entries(apps).map(([name, [rx, tx]]) => ({ name, rx, tx, total: rx + tx })).sort((a, b) => b.total - a.total).slice(0, 10),
    router: month === today().slice(0, 7) && router.ok ? { down: router.monthDown, up: router.monthUp } : (state.routerMonths || {})[month] || null,
  };
}

const fmtDur = (sec) => { sec = Math.round(sec || 0); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60); return h ? `${h}h ${m}m` : m ? `${m}m` : `${sec}s`; };
const fmtTime = (iso) => new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const fmtBytes = (n) => { const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; n = n || 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return `${n.toFixed(1)} ${u[i]}`; };

function checkMonthlyReport() {
  const thisMonth = today().slice(0, 7);
  // Keep the router's month totals so last month's figure is still known after the router resets.
  if (router.ok && router.monthDown != null) {
    state.routerMonths = state.routerMonths || {};
    state.routerMonths[thisMonth] = { down: router.monthDown, up: router.monthUp };
  }
  if (!state.lastReportMonth) { state.lastReportMonth = thisMonth; return; }
  if (state.lastReportMonth === thisMonth) return;
  const prev = state.lastReportMonth;
  state.lastReportMonth = thisMonth;
  const r = buildReport(prev);
  addAlert('report', {
    month: prev,
    top: r.devices.slice(0, 5).map((d) => ({ name: d.name, gw: d.gw, ip: d.ip, others: d.others, total: d.total })),
    home: r.router ? r.router.down + r.router.up : null,
  }, null);
}

// ---------------------------------------------------------------- weekly summary (Fridays)
function lastDays(n) { // the n days before today, oldest first
  const out = [];
  for (let i = n; i >= 1; i--) { const d = new Date(); d.setDate(d.getDate() - i); out.push(d.toLocaleDateString('en-CA')); }
  return out;
}
function weeklyParams(days) {
  const set = new Set(days);
  const homeDays = days.map((d) => (state.routerDays || {})[d]).filter((v) => v != null);
  const outs = (state.outages || []).filter((o) => set.has(new Date(o.start).toLocaleDateString('en-CA')));
  return {
    from: days[0], to: days[days.length - 1],
    top: deviceTotals(days).slice(0, 3).map((d) => ({ name: d.name, gw: d.gw, ip: d.ip, others: d.others, total: d.total })),
    home: homeDays.length ? homeDays.reduce((s, v) => s + v, 0) : null,
    outages: outs.length, outageSec: outs.reduce((s, o) => s + o.sec, 0),
  };
}
function checkWeekly() {
  const now = new Date(), day = today();
  if (!state.lastWeekly) { state.lastWeekly = day; return; } // first run: start counting from now
  if (settings.weekly === false || now.getDay() !== 5 || now.getHours() < 9 || state.lastWeekly === day) return;
  state.lastWeekly = day;
  addAlert('weekly', weeklyParams(lastDays(7)), null);
}

// ---------------------------------------------------------------- daily usage limit per device
function checkLimits() {
  const day = today();
  for (const d of Object.values(state.devices)) {
    if (!d.limitGB || d.limitDay === day) continue;
    const u = deviceSwitchUsage(d);
    if (!u || u.rxToday == null) continue;
    const total = u.rxToday + u.txToday;
    if (total >= d.limitGB * 1024 ** 3) {
      d.limitDay = day;
      addAlert('limit', { ...devParams(d), total, limit: d.limitGB }, d.id);
    }
  }
}

// ---------------------------------------------------------------- internet outages
// Every 15 seconds: can we open a connection to a few big public servers? Two misses in a row
// (while the router still answers, so it isn't just this PC's cable) = the internet is down.
// The notice goes out when it comes back, since the phone can't be reached while it is down.
const net = require('net');
const inet = { up: null, fails: 0, firstFail: null, downSince: null };
function tcpCheck(host, port, timeout = 3000) {
  return new Promise((resolve) => {
    const s = net.connect({ host, port, timeout });
    const done = (ok) => { s.destroy(); resolve(ok); };
    s.on('connect', () => done(true)); s.on('timeout', () => done(false)); s.on('error', () => done(false));
  });
}
async function checkInternet() {
  const ok = (await Promise.all([tcpCheck('1.1.1.1', 443), tcpCheck('8.8.8.8', 53), tcpCheck('9.9.9.9', 443)])).some(Boolean);
  if (ok) {
    if (inet.downSince) {
      const end = Date.now(), sec = Math.round((end - inet.downSince) / 1000);
      const o = { start: new Date(inet.downSince).toISOString(), end: new Date(end).toISOString(), sec };
      state.outages = [o, ...(state.outages || [])].slice(0, 300);
      addAlert('outage', o, null);
    }
    Object.assign(inet, { up: true, fails: 0, firstFail: null, downSince: null });
    return;
  }
  const gw = (networks.find((n) => n.gateway) || {}).gateway;
  if (!gw || !(await ping(gw)).alive) { inet.fails = 0; inet.firstFail = null; return; } // this PC is off the network, not the internet
  inet.fails++;
  if (!inet.firstFail) inet.firstFail = Date.now();
  if (inet.fails >= 2) { inet.up = false; if (!inet.downSince) inet.downSince = inet.firstFail; }
}
function internetPayload() {
  const outs = state.outages || [];
  const day = today(), week = new Set([...lastDays(6), day]);
  const sum = (list) => ({ count: list.length, sec: list.reduce((s, o) => s + o.sec, 0) });
  return {
    up: inet.up, downSince: inet.downSince ? new Date(inet.downSince).toISOString() : null,
    today: sum(outs.filter((o) => new Date(o.start).toLocaleDateString('en-CA') === day)),
    week: sum(outs.filter((o) => week.has(new Date(o.start).toLocaleDateString('en-CA')))),
    recent: outs.slice(0, 5),
  };
}

// ---------------------------------------------------------------- find the switch (Setup > Switch)
// Looks at the devices online now: which answer SNMP with the community typed, and which have
// a settings page that looks like a switch. Nothing leaves the local network.
const SWITCH_WORDS = /switch|netgear|prosafe|tp-?link|omada|cisco|d-?link|ubiquiti|unifi|mikrotik|aruba|zyxel|procurve|hpe|tenda|managed/i;
function httpPeek(ip, timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get({ host: ip, port: 80, path: '/', timeout }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; if (body.length > 20000) req.destroy(); });
      const fin = () => resolve({ server: String(res.headers.server || ''), title: ((body.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1] || '').trim().slice(0, 80) });
      res.on('end', fin); res.on('close', fin);
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
  });
}
async function findSwitches(community) {
  const devs = Object.values(state.devices).filter((d) => d.online && !d.isSelf && networks.some((n) => n.cidr === d.cidr));
  const found = [];
  await mapLimit(devs, 16, async (d) => {
    let model = null, snmp = false;
    if (community) {
      const c = new Snmp(d.ip, community, { timeout: 1200, retries: 0 });
      try {
        const r = await c.get([OID.sysDescr]);
        const v = r.varbinds[0] && r.varbinds[0].value;
        snmp = true; model = (Buffer.isBuffer(v) ? v.toString('utf8') : String(v || '')).trim().slice(0, 80) || null;
      } catch (_) {} finally { c.close(); }
    }
    const web = await httpPeek(d.ip);
    const text = [web && web.title, web && web.server, d.vendor, d.hostname, d.customName, model].filter(Boolean).join(' ');
    if (snmp || SWITCH_WORDS.test(text)) {
      found.push({ ip: d.ip, name: d.customName || d.hostname || null, model: model || (web && web.title) || d.vendor || null, snmp, gw: !!d.isGateway });
    }
  });
  return found.sort((a, b) => (b.snmp - a.snmp) || (a.gw - b.gw) || ipToInt(a.ip) - ipToInt(b.ip));
}

// ---------------------------------------------------------------- managed switch (per-device usage)
// A managed switch counts the bytes on every port. With SNMP (read only) turned on in the
// switch, we read those counters and learn which device (MAC) is on which port.
// Port "in" = the device sending (its upload); port "out" = the device receiving (its download).
const { Snmp } = require('./snmp');
const OID = {
  ifName: '1.3.6.1.2.1.31.1.1.1.1',
  ifHCIn: '1.3.6.1.2.1.31.1.1.1.6',
  ifHCOut: '1.3.6.1.2.1.31.1.1.1.10',
  basePortIfIndex: '1.3.6.1.2.1.17.1.4.1.2',
  qFdbPort: '1.3.6.1.2.1.17.7.1.2.2.1.2',
  dFdbPort: '1.3.6.1.2.1.17.4.3.1.2',
  sysDescr: '1.3.6.1.2.1.1.1.0',
};
const sw = {
  ok: false, error: null, model: null, client: null, key: null,
  names: new Map(),      // ifIndex -> port name
  macPort: new Map(),    // mac -> ifIndex
  portMacs: new Map(),   // ifIndex -> count of MACs learned there
  prev: null,            // { at, inO: Map, outO: Map }
  rates: new Map(),      // ifIndex -> { rx, tx } bytes/sec from the device's point of view
  lastFdb: 0,
};

function switchConfig() {
  const c = (typeof settings !== 'undefined' && settings.switch) || null;
  return c && c.host && c.community ? c : null;
}

function macFromSuffix(parts) {
  return parts.map((n) => Number(n).toString(16).padStart(2, '0')).join(':');
}

async function readFdb(client) {
  const bridge = await client.walk(OID.basePortIfIndex);
  let fdb = await client.walk(OID.qFdbPort); // index: vlan.m1.m2.m3.m4.m5.m6
  let qbridge = true;
  if (!fdb.size) { fdb = await client.walk(OID.dFdbPort); qbridge = false; } // index: m1..m6
  const macPort = new Map();
  const portMacs = new Map();
  for (const [suffix, bridgePort] of fdb) {
    const parts = suffix.split('.');
    const mac = macFromSuffix(qbridge ? parts.slice(1) : parts);
    const ifIndex = bridge.get(String(bridgePort)) || bridgePort;
    if (!ifIndex) continue;
    if (!macPort.has(mac)) portMacs.set(ifIndex, (portMacs.get(ifIndex) || 0) + 1);
    macPort.set(mac, ifIndex);
  }
  sw.macPort = macPort;
  sw.portMacs = portMacs;
  const names = await client.walk(OID.ifName);
  sw.names = new Map([...names].map(([k, v]) => [Number(k), Buffer.isBuffer(v) ? v.toString('utf8') : String(v)]));
}

async function sampleSwitch() {
  const cfg = switchConfig();
  if (!cfg) { sw.ok = false; sw.error = null; return; }
  const key = `${cfg.host}|${cfg.community}`;
  if (sw.key !== key) {
    if (sw.client) sw.client.close();
    sw.client = new Snmp(cfg.host, cfg.community, { timeout: 2500, retries: 1 });
    Object.assign(sw, { key, prev: null, lastFdb: 0, model: null });
  }
  const client = sw.client;
  try {
    if (!sw.model) {
      const r = await client.get([OID.sysDescr]);
      const v = r.varbinds[0] && r.varbinds[0].value;
      sw.model = Buffer.isBuffer(v) ? v.toString('utf8').trim().slice(0, 80) : 'Switch';
    }
    if (Date.now() - sw.lastFdb > 60e3) { await readFdb(client); sw.lastFdb = Date.now(); }
    const [inO, outO] = await Promise.all([client.walk(OID.ifHCIn), client.walk(OID.ifHCOut)]);
    const now = Date.now();
    if (sw.prev) {
      const dt = (now - sw.prev.at) / 1000;
      const day = today();
      state.portDays = state.portDays || {};
      const pd = state.portDays[day] || (state.portDays[day] = {});
      for (const [idx, v] of inO) {
        const pIn = sw.prev.inO.get(idx), pOut = sw.prev.outO.get(idx), o = outO.get(idx);
        if (pIn === undefined || pOut === undefined || o === undefined) continue;
        const dIn = Math.max(0, v - pIn), dOut = Math.max(0, o - pOut);
        if (dIn > 1e12 || dOut > 1e12) continue; // counter reset
        const t = pd[idx] || (pd[idx] = [0, 0]); // [device download, device upload]
        t[0] += dOut; t[1] += dIn;
        sw.rates.set(Number(idx), { rx: dOut / dt, tx: dIn / dt });
      }
    }
    sw.prev = { at: now, inO, outO };
    sw.ok = true;
    sw.error = null;
    checkLimits();
  } catch (err) {
    sw.ok = false;
    sw.error = String(err.message || err);
  }
}

function deviceSwitchUsage(d) {
  if (!sw.ok || !d.mac) return null;
  const idx = sw.macPort.get(d.mac);
  if (!idx) return null;
  const gwMac = (Object.values(state.devices).find((x) => x.isGateway && x.online) || {}).mac;
  const uplink = gwMac && sw.macPort.get(gwMac) === idx;
  const day = ((state.portDays || {})[today()] || {})[idx] || [0, 0];
  const rate = sw.rates.get(Number(idx)) || { rx: 0, tx: 0 };
  // Devices learned on the router's port are plugged into the router (or its Wi-Fi), not
  // into the switch, so the switch can't tell their usage apart. The router itself gets the
  // port total: everything the switch's devices sent to / received from the router.
  const behindRouter = !!uplink && !d.isGateway;
  // For the router's port, show it from the home's point of view: what went out to the
  // router is the home's upload, what came back is the home's download.
  if (uplink && d.isGateway) {
    const [a, b] = day;
    const r2 = { rx: rate.tx, tx: rate.rx };
    return {
      port: sw.names.get(Number(idx)) || `Port ${idx}`, shared: sw.portMacs.get(idx) || 1, uplink: true, behindRouter: false,
      rxToday: b, txToday: a, rxRate: r2.rx, txRate: r2.tx,
    };
  }
  return {
    port: sw.names.get(Number(idx)) || `Port ${idx}`,
    shared: sw.portMacs.get(idx) || 1,
    uplink: !!uplink, behindRouter,
    rxToday: behindRouter ? null : day[0], txToday: behindRouter ? null : day[1],
    rxRate: behindRouter ? null : rate.rx, txRate: behindRouter ? null : rate.tx,
  };
}

// ---------------------------------------------------------------- this PC: traffic and programs

// ---------------------------------------------------------------- router (whole home internet)
// Huawei home routers (like the 5G CPE Pro 2) publish their internet counters without a login.
const router = { ok: false, model: null, rxRate: 0, txRate: 0, history: [] };

function xmlVal(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
  return m ? m[1] : null;
}
function httpGetText(url, timeout = 3000, headers = {}) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout, headers }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; if (body.length > 1e5) req.destroy(); });
      res.on('end', () => resolve(res.statusCode === 200 ? body : null));
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
  });
}

// Setup > Router: settings.router = { mode: 'auto' | 'huawei' | 'off', host: '' }.
// auto = try the Huawei counters on the gateway; huawei = same on the address given; off = don't ask the router.
function routerConfig() {
  const c = (typeof settings !== 'undefined' && settings.router) || {};
  const gw = (networks.find((n) => n.gateway) || {}).gateway || null;
  const mode = ['auto', 'huawei', 'off'].includes(c.mode) ? c.mode : 'auto';
  return { mode, host: (c.host || '').trim() || gw, gateway: gw };
}

// Some Huawei firmware wants a session cookie and token even for these read-only pages.
async function huaweiGet(base, page, tok) {
  let x = await httpGetText(`${base}/${page}`, 3000, tok || {});
  if (x && /<error>/i.test(x) && !tok) return null;
  return x;
}
async function huaweiToken(base) {
  const t = await httpGetText(`${base}/webserver/SesTokInfo`);
  if (!t) return null;
  const ses = xmlVal(t, 'SesInfo'), tok = xmlVal(t, 'TokInfo');
  return ses && tok ? { Cookie: ses, __RequestVerificationToken: tok } : null;
}

async function sampleRouter() {
  const cfg = routerConfig();
  router.host = cfg.host;
  if (cfg.mode === 'off' || !cfg.host) { router.ok = false; return; }
  const base = `http://${cfg.host}/api`;
  if (router.base !== base) Object.assign(router, { base, model: null, tok: undefined, history: [] });
  const get = async (page) => {
    let x = await huaweiGet(base, page, router.tok);
    if ((!x || /<error>/i.test(x)) && router.tok !== null) {
      router.tok = await huaweiToken(base); // try once with a session token
      x = router.tok ? await huaweiGet(base, page, router.tok) : x;
    }
    return x && !/<error>/i.test(x) ? x : null;
  };
  if (!router.model) {
    const info = await get('device/basic_information');
    if (info) router.model = xmlVal(info, 'spreadname_en') || xmlVal(info, 'devicename');
  }
  const [t, m] = await Promise.all([get('monitoring/traffic-statistics'), get('monitoring/month_statistics')]);
  if (!t || xmlVal(t, 'CurrentDownloadRate') === null) { router.ok = false; return; }
  router.ok = true;
  router.rxRate = Number(xmlVal(t, 'CurrentDownloadRate')) || 0;
  router.txRate = Number(xmlVal(t, 'CurrentUploadRate')) || 0;
  router.connectedSec = Number(xmlVal(t, 'CurrentConnectTime')) || 0;
  if (m) {
    router.monthDown = Number(xmlVal(m, 'CurrentMonthDownload')) || 0;
    router.monthUp = Number(xmlVal(m, 'CurrentMonthUpload')) || 0;
    router.todayUsed = Number(xmlVal(m, 'CurrentDayUsed')) || 0;
    state.routerDays = state.routerDays || {};
    state.routerDays[today()] = router.todayUsed;
    router.monthSince = xmlVal(m, 'MonthLastClearTime');
  }
  router.history.push({ t: Date.now(), rx: router.rxRate, tx: router.txRate });
  if (router.history.length > 120) router.history.shift();
}

const traffic = { prev: null, rxRate: 0, txRate: 0, rxTotal: 0, txTotal: 0, history: [], perAdapter: {} };

async function readAdapterCounters() {
  if (IS_MAC) {
    // netstat -ibn: the <Link#n> row of each adapter has its byte totals.
    const out = await run('netstat', ['-ibn']);
    const arr = [];
    for (const line of out.split('\n')) {
      const p = line.trim().split(/\s+/);
      if (p.length < 10 || !/^<Link#\d+>$/.test(p[2])) continue;
      const hasMac = /^[0-9a-f]{1,2}(:[0-9a-f]{1,2}){5}$/i.test(p[3]);
      const o = hasMac ? 0 : -1; // the address column is empty on some adapters
      arr.push({ Name: p[0], ReceivedBytes: Number(p[6 + o]) || 0, SentBytes: Number(p[9 + o]) || 0 });
    }
    return arr.length ? arr : null;
  }
  if (!IS_WIN) return null;
  const out = await run('powershell', ['-NoProfile', '-NonInteractive', '-Command',
    'Get-NetAdapterStatistics | Select-Object Name,ReceivedBytes,SentBytes | ConvertTo-Json -Compress']);
  try {
    let arr = JSON.parse(out);
    if (!Array.isArray(arr)) arr = [arr];
    return arr;
  } catch (_) { return null; }
}

async function sampleTraffic() {
  const counters = await readAdapterCounters();
  if (!counters) return;
  const now = Date.now();
  const activeNames = new Set(networks.flatMap((n) => n.interfaces.map((i) => i.name)));
  const cur = {};
  for (const c of counters) {
    if (activeNames.size && !activeNames.has(c.Name)) continue;
    cur[c.Name] = { rx: Number(c.ReceivedBytes) || 0, tx: Number(c.SentBytes) || 0 };
  }
  if (traffic.prev) {
    const dt = (now - traffic.prev.at) / 1000;
    let rx = 0, tx = 0;
    for (const [name, v] of Object.entries(cur)) {
      const p = traffic.prev.counters[name];
      if (!p) continue;
      const drx = Math.max(0, v.rx - p.rx);
      const dtx = Math.max(0, v.tx - p.tx);
      rx += drx; tx += dtx;
      traffic.perAdapter[name] = { rxRate: drx / dt, txRate: dtx / dt };
    }
    traffic.rxRate = rx / dt;
    traffic.txRate = tx / dt;
    traffic.rxTotal += rx;
    traffic.txTotal += tx;
    traffic.history.push({ t: now, rx: traffic.rxRate, tx: traffic.txRate });
    if (traffic.history.length > 120) traffic.history.shift();
  }
  traffic.prev = { at: now, counters: cur };
}

let apps = [];
const pidNames = new Map(); // pid -> program name

async function refreshPidNames() {
  const tl = await run('tasklist', ['/FO', 'CSV', '/NH']);
  for (const line of tl.split(/\r?\n/)) {
    const m = line.match(/^"([^"]+)","(\d+)"/);
    if (m) pidNames.set(m[2], m[1].replace(/\.exe$/i, ''));
  }
}

// Open internet connections per program (works without admin rights).
// macOS: nettop lists the bytes each program has sent and received (no admin rights needed).
const macPrev = new Map(); // "name.pid" -> [in, out]
async function sampleAppsMac() {
  const out = await run('nettop', ['-P', '-L', '1', '-n', '-x', '-J', 'bytes_in,bytes_out'], 20000);
  const seen = new Set();
  const conn = new Map();
  for (const line of out.split('\n')) {
    const p = line.split(',');
    if (p.length < 3 || !/\.\d+$/.test(p[0])) continue;
    const key = p[0], rx = Number(p[1]) || 0, tx = Number(p[2]) || 0;
    const name = key.replace(/\.\d+$/, '').trim() || key;
    seen.add(key);
    const prev = macPrev.get(key);
    macPrev.set(key, [rx, tx]);
    if (prev) { const dr = Math.max(0, rx - prev[0]), dt = Math.max(0, tx - prev[1]); if (dr || dt) addUsage(name, dr, dt); }
    if (rx || tx) conn.set(name, (conn.get(name) || 0) + 1);
  }
  for (const k of [...macPrev.keys()]) if (!seen.has(k)) macPrev.delete(k);
  usage.mode = 'bytes';
  apps = [...conn.entries()].map(([name, connections]) => ({ name, connections }));
}

async function sampleApps() {
  if (IS_MAC) return sampleAppsMac();
  if (!IS_WIN) return;
  const [ns] = await Promise.all([run('netstat', ['-ano', '-p', 'TCP']), refreshPidNames()]);
  flushPending();
  const byApp = new Map();
  for (const line of ns.split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 5 || parts[0] !== 'TCP') continue;
    const remote = parts[2];
    const pid = parts[4];
    if (!/^\d+$/.test(pid) || pid === '0') continue;
    const rip = remote.replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
    // Only real outside connections: skip listening sockets and this PC talking to itself.
    if (rip === '0.0.0.0' || rip === '::' || rip === '*' || rip.startsWith('127.') || rip === '::1') continue;
    const name = pidNames.get(pid) || `PID ${pid}`;
    byApp.set(name, (byApp.get(name) || 0) + 1);
  }
  apps = [...byApp.entries()].map(([name, connections]) => ({ name, connections }));
}

// ---- Real bytes per program (TCP), measured by tcp-usage.ps1. Needs admin rights.
const usage = {
  mode: 'connections',   // 'bytes' once the helper reports data as admin
  live: new Map(),       // name -> [{t, rx, tx}] recent samples for the current speed
  pending: new Map(),    // pid -> [rx, tx] for PIDs we don't have a name for yet
};
const today = () => new Date().toLocaleDateString('en-CA');

function addUsage(name, rx, tx) {
  const day = today();
  state.appDays = state.appDays || {};
  const d = state.appDays[day] || (state.appDays[day] = {});
  const v = d[name] || (d[name] = [0, 0]);
  v[0] += rx; v[1] += tx;
  const now = Date.now();
  const l = usage.live.get(name) || [];
  l.push({ t: now, rx, tx });
  while (l.length && now - l[0].t > 6000) l.shift();
  usage.live.set(name, l);
}

// Traffic per service port on this PC (for example 21 = FTP, 22 = SSH, 8080 = a web app).
function addSvc(port, rx, tx) {
  const day = today();
  state.svcDays = state.svcDays || {};
  const d = state.svcDays[day] || (state.svcDays[day] = {});
  const v = d[port] || (d[port] = [0, 0]);
  v[0] += rx; v[1] += tx;
}

// Addresses in each local network that nothing is using right now.
// "free" = nobody online with it; "never" = no device has ever been recorded with it.
function freeAddresses() {
  return networks.map((net) => {
    const usedNow = new Set();
    const seenEver = new Set();
    for (const d of Object.values(state.devices)) {
      if (d.cidr !== net.cidr) continue;
      seenEver.add(d.ip);
      if (d.online) usedNow.add(d.ip);
    }
    const ranges = [];
    let cur = null;
    for (let n = net.start; n <= net.end; n++) {
      const ip = intToIp(n);
      const offline = seenEver.has(ip) && !usedNow.has(ip);
      if (usedNow.has(ip)) { cur = null; continue; }
      const kind = offline ? 'offline' : 'never';
      if (cur && cur.kind === kind && cur.to === n - 1) { cur.to = n; }
      else { cur = { kind, from: n, to: n }; ranges.push(cur); }
    }
    return {
      cidr: net.cidr, gateway: net.gateway, limited: net.limited,
      scanned: `${intToIp(net.start)} - ${intToIp(net.end)}`,
      usedNow: usedNow.size,
      neverSeen: ranges.filter((r) => r.kind === 'never').reduce((s, r) => s + (r.to - r.from + 1), 0),
      offlineFree: ranges.filter((r) => r.kind === 'offline').reduce((s, r) => s + (r.to - r.from + 1), 0),
      ranges: ranges.map((r) => ({ kind: r.kind, from: intToIp(r.from), to: intToIp(r.to), count: r.to - r.from + 1 })),
    };
  });
}

function servicesPayload() {
  const day = (state.svcDays || {})[today()] || {};
  return Object.entries(day)
    .map(([port, [rx, tx]]) => ({ port: Number(port), rxToday: rx, txToday: tx }))
    .sort((a, b) => (b.rxToday + b.txToday) - (a.rxToday + a.txToday))
    .slice(0, 12);
}


function flushPending() {
  for (const [pid, [rx, tx]] of usage.pending) addUsage(pidNames.get(pid) || '(ended)', rx, tx);
  usage.pending.clear();
}

let namesRefreshQueued = false;
function startUsageHelper() {
  if (!IS_WIN) return;
  const { spawn } = require('child_process');
  const ps = spawn('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', path.join(__dirname, 'tcp-usage.ps1'), '1'], { windowsHide: true });
  let buf = '';
  ps.stdout.on('data', (chunk) => {
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('{')) continue;
      let msg;
      try { msg = JSON.parse(line); } catch (_) { continue; }
      usage.mode = msg.admin ? 'bytes' : 'connections';
      for (const [port, [rx, tx]] of Object.entries(msg.ports || {})) addSvc(port, rx, tx);
      for (const [pid, [rx, tx]] of Object.entries(msg.pids || {})) {
        const name = pidNames.get(pid);
        if (name) { addUsage(name, rx, tx); continue; }
        const p = usage.pending.get(pid) || [0, 0];
        p[0] += rx; p[1] += tx;
        usage.pending.set(pid, p);
        if (!namesRefreshQueued) {
          namesRefreshQueued = true;
          refreshPidNames().then(() => { namesRefreshQueued = false; flushPending(); });
        }
      }
    }
  });
  ps.stderr.on('data', (d) => console.error('Usage helper:', String(d).trim().slice(0, 300)));
  ps.on('exit', (code) => {
    console.error(`Usage helper stopped (code ${code}). Restarting in 30s.`);
    usage.mode = 'connections';
    setTimeout(startUsageHelper, 30000);
  });
}

function appsPayload() {
  const day = (state.appDays || {})[today()] || {};
  const names = new Set([...apps.map((a) => a.name), ...Object.keys(day)]);
  const conn = new Map(apps.map((a) => [a.name, a.connections]));
  const now = Date.now();
  return [...names].map((name) => {
    const live = (usage.live.get(name) || []).filter((x) => now - x.t <= 6000);
    const [rx, tx] = day[name] || [0, 0];
    return {
      name, connections: conn.get(name) || 0,
      rxToday: rx, txToday: tx,
      rxRate: live.reduce((s, x) => s + x.rx, 0) / 6,
      txRate: live.reduce((s, x) => s + x.tx, 0) / 6,
    };
  }).sort((a, b) => (b.rxToday + b.txToday) - (a.rxToday + a.txToday) || b.connections - a.connections)
    .slice(0, 15);
}

// ---------------------------------------------------------------- API

function publicDevice(d) {
  const scans = state.scans[d.cidr] || 1;
  const possible = Math.max(1, scans - (d.firstScan || 1) + 1);
  const lat = d.latency.filter((x) => typeof x === 'number');
  return {
    id: d.id, cidr: d.cidr, ip: d.ip, mac: d.mac,
    name: d.customName || d.hostname || null,
    hostname: d.hostname || null, customName: d.customName || null, important: !!d.important,
    vendor: d.vendor || null, privateMac: !!d.privateMac,
    isSelf: !!d.isSelf, isGateway: !!d.isGateway,
    online: !!d.online, pingBlocked: !!d.pingBlocked,
    latencyMs: d.online ? d.latencyMs : null,
    avgLatencyMs: lat.length ? Math.round(lat.reduce((s, x) => s + x, 0) / lat.length) : null,
    latency: d.latency,
    firstSeen: d.firstSeen, lastSeen: d.lastSeen,
    availability: Math.min(100, Math.round((d.seenCount / possible) * 100)),
    // New = joined after this network's first scan, within the last 24 hours.
    isNew: (d.firstScan || 1) > 1 && Date.now() - new Date(d.firstSeen) < 86400e3,
    usage: deviceSwitchUsage(d),
    limitGB: d.limitGB || null,
  };
}

function getStatePayload() {
  const cidrs = new Set(networks.map((n) => n.cidr));
  const devices = Object.values(state.devices)
    .filter((d) => cidrs.size === 0 || cidrs.has(d.cidr))
    .map(publicDevice)
    .sort((a, b) => ipToInt(a.ip) - ipToInt(b.ip));
  return {
    version: APP_VERSION,
    hostname: os.hostname().replace(/\.local$/i, ''),
    networks: networks.map((n) => ({
      cidr: n.cidr, gateway: n.gateway, limited: n.limited,
      scanned: `${intToIp(n.start)} - ${intToIp(n.end)}`,
      interfaces: n.interfaces.map((i) => ({ name: i.name, ip: i.ip })),
      online: devices.filter((d) => d.cidr === n.cidr && d.online).length,
    })),
    scan: { scanning, lastScan, durationMs: lastScanMs, intervalMs: SCAN_INTERVAL_MS },
    devices,
    unreadAlerts: (state.alerts || []).filter((a) => !a.read).length,
    switch: switchConfig() ? { ok: sw.ok, error: sw.error, model: sw.model, host: switchConfig().host } : null,
    router: router.ok ? {
      model: router.model, rxRate: router.rxRate, txRate: router.txRate,
      todayUsed: router.todayUsed ?? null, monthDown: router.monthDown ?? null, monthUp: router.monthUp ?? null,
      monthSince: router.monthSince || null, history: router.history,
    } : null,
    internet: internetPayload(),
    services: servicesPayload(),
    self: {
      rxRate: traffic.rxRate, txRate: traffic.txRate,
      rxTotal: traffic.rxTotal, txTotal: traffic.txTotal,
      history: traffic.history, apps: appsPayload(), usageMode: usage.mode,
    },
  };
}

function sendJson(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 1e4) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch (_) { resolve({}); } });
  });
}

const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'application/javascript', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png' };

// ---------------------------------------------------------------- start with Windows
// A scheduled task (as SYSTEM, at startup) runs this same server in the background, so the
// page keeps working for other devices even when nobody is signed in.
const TASK_NAME = 'Network Monitor';
const psq = (s) => `'${String(s).replace(/'/g, "''")}'`;
// macOS: a LaunchAgent starts the monitor when the person logs in.
const MAC_AGENT = path.join(os.homedir(), 'Library', 'LaunchAgents', 'net.kankon.networkmonitor.plist');
const xmlEsc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
async function autostartState() {
  if (IS_MAC) { try { return fs.readFileSync(MAC_AGENT, 'utf8').includes(xmlEsc(path.join(__dirname, 'server.js'))); } catch (_) { return false; } }
  if (!IS_WIN) return false;
  const out = await run('schtasks', ['/Query', '/TN', TASK_NAME, '/XML'], 8000);
  return out.includes(__dirname.replace(/[\\/]+$/, '')) || out.includes(path.join(__dirname, 'server.js'));
}
async function setAutostart(on) {
  if (IS_MAC) {
    if (!on) { try { fs.unlinkSync(MAC_AGENT); } catch (_) {} return true; }
    const args = [process.execPath, path.join(__dirname, 'server.js'), '--data', DATA_DIR, '--port', String(PORT)];
    const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>net.kankon.networkmonitor</string>
<key>ProgramArguments</key><array>${args.map((a) => `<string>${xmlEsc(a)}</string>`).join('')}</array>
<key>WorkingDirectory</key><string>${xmlEsc(__dirname)}</string>
<key>RunAtLoad</key><true/>
</dict></plist>
`;
    try { fs.mkdirSync(path.dirname(MAC_AGENT), { recursive: true }); fs.writeFileSync(MAC_AGENT, plist); } catch (e) { console.error('LaunchAgent:', e.message); }
    return autostartState();
  }
  if (!IS_WIN) return false;
  if (!on) { await run('schtasks', ['/Delete', '/TN', TASK_NAME, '/F'], 15000); return true; }
  const args = `"${path.join(__dirname, 'server.js')}" --data "${DATA_DIR}" --port ${PORT}`;
  const ps = [
    `$a = New-ScheduledTaskAction -Execute ${psq(process.execPath)} -Argument ${psq(args)} -WorkingDirectory ${psq(__dirname)};`,
    '$t = New-ScheduledTaskTrigger -AtStartup;',
    '$s = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew;',
    "$p = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest;",
    `Register-ScheduledTask -TaskName ${psq(TASK_NAME)} -Description 'Network Monitor in the background (port ${PORT})' -Action $a -Trigger $t -Settings $s -Principal $p -Force | Out-Null`,
  ].join(' ');
  await run('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], 30000);
  return autostartState();
}

// ---------------------------------------------------------------- page password
// Opening the page on this computer never needs a password. From other devices it does,
// once a password has been set from the page (settings.json, kept out of git).

const crypto = require('crypto');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
let settings = {};
try { settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch (_) { settings = {}; }
if (!settings.secret) settings.secret = crypto.randomBytes(32).toString('hex');
const saveSettings = () => fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
saveSettings();

const SESSION_DAYS = 30;
const isLocal = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);

function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(String(pw), salt, 32).toString('hex')}`;
}
function checkPassword(pw) {
  if (!settings.passwordHash) return false;
  const [salt, hash] = settings.passwordHash.split(':');
  const got = crypto.scryptSync(String(pw), salt, 32);
  return crypto.timingSafeEqual(got, Buffer.from(hash, 'hex'));
}
// Token = expiry.signature. Signed with the secret plus the password hash, so changing
// or removing the password logs every other device out.
function makeToken() {
  const exp = Date.now() + SESSION_DAYS * 86400e3;
  const sig = crypto.createHmac('sha256', settings.secret + (settings.passwordHash || '')).update(String(exp)).digest('hex');
  return `${exp}.${sig}`;
}
function validToken(tok) {
  const [exp, sig] = String(tok || '').split('.');
  if (!exp || !sig || Number(exp) < Date.now()) return false;
  const want = crypto.createHmac('sha256', settings.secret + (settings.passwordHash || '')).update(exp).digest('hex');
  return sig.length === want.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want));
}
function cookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp(`(?:^|;\\s*)${name}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : null;
}
const authed = (req) => isLocal(req) || !settings.passwordHash || validToken(cookie(req, 'nm_auth'));

const loginAttempts = new Map(); // ip -> [timestamps]
function tooManyAttempts(ip) {
  const now = Date.now();
  const list = (loginAttempts.get(ip) || []).filter((t) => now - t < 5 * 60e3);
  loginAttempts.set(ip, list);
  return list.length >= 8;
}

function serveFile(res, name) {
  fs.readFile(path.join(PUBLIC_DIR, name), (err, data) => {
    if (err) { res.writeHead(500); return res.end(`${name} missing`); }
    res.writeHead(200, { 'Content-Type': TYPES['.html'], 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const { pathname } = new URL(req.url, 'http://localhost');

  // Lets the desktop app check that the server on this port is this app, and which version.
  if (req.method === 'GET' && pathname === '/api/ping') {
    return sendJson(res, 200, isLocal(req) ? { app: 'network-monitor', version: APP_VERSION, dir: __dirname } : { app: 'network-monitor' });
  }
  // The Mac app asks an older copy (left running in the background) to stop before it starts its own.
  if (req.method === 'POST' && pathname === '/api/quit') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    sendJson(res, 200, { ok: true });
    setTimeout(() => process.exit(0), 200);
    return;
  }
  if (req.method === 'POST' && pathname === '/api/login') {
    const ip = req.socket.remoteAddress;
    if (tooManyAttempts(ip)) return sendJson(res, 429, { error: 'too many attempts' });
    const { password } = await readBody(req);
    if (!checkPassword(password)) {
      loginAttempts.get(ip).push(Date.now());
      return sendJson(res, 401, { error: 'wrong password' });
    }
    loginAttempts.delete(ip);
    res.setHeader('Set-Cookie', `nm_auth=${makeToken()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_DAYS * 86400}`);
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'POST' && pathname === '/api/logout') {
    res.setHeader('Set-Cookie', 'nm_auth=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');
    return sendJson(res, 200, { ok: true });
  }

  // Shared English/Arabic text, needed by the sign-in page too.
  if (req.method === 'GET' && pathname === '/public/i18n.js') {
    return fs.readFile(path.join(PUBLIC_DIR, 'i18n.js'), (err, data) => {
      if (err) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'application/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(data);
    });
  }

  if (!authed(req)) {
    if (pathname.startsWith('/api/')) return sendJson(res, 401, { error: 'login required' });
    return serveFile(res, 'login.html');
  }

  if (req.method === 'POST' && pathname === '/api/switch') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { host, community } = await readBody(req);
    if (!host || !community) delete settings.switch;
    else settings.switch = { host: String(host).trim(), community: String(community) };
    saveSettings();
    await sampleSwitch();
    return sendJson(res, 200, { ok: sw.ok, error: sw.error, model: sw.model });
  }
  if (req.method === 'GET' && pathname === '/api/setup') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const rc = routerConfig();
    return sendJson(res, 200, {
      router: { mode: rc.mode, host: (settings.router && settings.router.host) || '', gateway: rc.gateway, ok: router.ok, model: router.model || null },
      switch: { host: settings.switch ? settings.switch.host : '', saved: !!settings.switch, ok: sw.ok, error: sw.error, model: sw.model },
      autostart: await autostartState(),
      weekly: settings.weekly !== false,
      thisPcIps: networks.flatMap((n) => n.interfaces.map((i) => i.ip)),
      dataDir: DATA_DIR,
    });
  }
  if (req.method === 'POST' && pathname === '/api/setup/find-switch') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { community } = await readBody(req);
    return sendJson(res, 200, { found: await findSwitches(String(community || '')) });
  }
  if (req.method === 'POST' && pathname === '/api/setup/weekly') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { on, test } = await readBody(req);
    if (on !== undefined) { settings.weekly = !!on; saveSettings(); }
    let sent = null;
    if (test) { const a = { kind: 'weekly', p: weeklyParams(lastDays(7)) }; sent = await pushToPhone(a); }
    return sendJson(res, 200, { on: settings.weekly !== false, sent });
  }
  if (req.method === 'POST' && pathname === '/api/setup/router') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { mode, host } = await readBody(req);
    const h = String(host || '').trim();
    if (h && !/^[A-Za-z0-9.-]{1,253}$/.test(h)) return sendJson(res, 400, { error: 'bad address' });
    settings.router = { mode: ['auto', 'huawei', 'off'].includes(mode) ? mode : 'auto', host: h };
    saveSettings();
    router.ok = false;
    await sampleRouter();
    return sendJson(res, 200, { ok: router.ok, model: router.model || null, host: router.host || null });
  }
  if (req.method === 'POST' && pathname === '/api/autostart') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { on } = await readBody(req);
    const ok = await setAutostart(!!on);
    return sendJson(res, ok ? 200 : 500, { on: await autostartState() });
  }
  if (req.method === 'POST' && pathname === '/api/lang') {
    // Only used for phone notices (the page itself always starts in English).
    const { lang } = await readBody(req);
    if (['en', 'ar'].includes(lang) && settings.noticeLang !== lang) { settings.noticeLang = lang; saveSettings(); }
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'GET' && pathname === '/api/auth') {
    return sendJson(res, 200, { platform: process.platform, passwordSet: !!settings.passwordHash, local: isLocal(req), switchHost: settings.switch ? settings.switch.host : null, ntfyTopic: settings.ntfyTopic || null });
  }
  if (req.method === 'POST' && pathname === '/api/password') {
    // Only this computer, or a device already logged in with the current password, may change it.
    if (!isLocal(req) && !(settings.passwordHash && validToken(cookie(req, 'nm_auth')))) {
      return sendJson(res, 403, { error: 'only from this computer' });
    }
    const { password } = await readBody(req);
    const pw = String(password || '');
    if (pw && pw.length < 6) return sendJson(res, 400, { error: 'too short' });
    settings.passwordHash = pw ? hashPassword(pw) : undefined;
    saveSettings();
    // Keep the device that changed it logged in.
    if (pw && !isLocal(req)) res.setHeader('Set-Cookie', `nm_auth=${makeToken()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_DAYS * 86400}`);
    return sendJson(res, 200, { passwordSet: !!settings.passwordHash });
  }

  if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) return serveFile(res, 'index.html');
  if (req.method === 'GET' && pathname === '/api/state') return sendJson(res, 200, getStatePayload());

  if (req.method === 'POST' && pathname === '/api/scan') {
    scanAll();
    return sendJson(res, 202, { started: true });
  }
  if (req.method === 'POST' && pathname === '/api/devices/name') {
    const { id, name } = await readBody(req);
    const d = state.devices[id];
    if (!d) return sendJson(res, 404, { error: 'not found' });
    d.customName = String(name || '').trim().slice(0, 40) || null;
    saveData();
    return sendJson(res, 200, publicDevice(d));
  }
  if (req.method === 'POST' && pathname === '/api/devices/limit') {
    const { id, gb } = await readBody(req);
    const d = state.devices[id];
    if (!d) return sendJson(res, 404, { error: 'not found' });
    const n = Number(gb);
    d.limitGB = n > 0 && n < 100000 ? Math.round(n * 10) / 10 : null;
    d.limitDay = null;
    saveData();
    checkLimits();
    return sendJson(res, 200, publicDevice(d));
  }
  if (req.method === 'POST' && pathname === '/api/devices/important') {
    const { id, important } = await readBody(req);
    const d = state.devices[id];
    if (!d) return sendJson(res, 404, { error: 'not found' });
    d.important = !!important;
    d.offlineAlerted = false;
    saveData();
    return sendJson(res, 200, publicDevice(d));
  }
  if (req.method === 'GET' && pathname === '/api/device-history') {
    const id = new URL(req.url, 'http://localhost').searchParams.get('id');
    const d = state.devices[id];
    if (!d) return sendJson(res, 404, { error: 'not found' });
    const idx = d.mac && sw.macPort.get(d.mac);
    const out = [];
    for (let i = 29; i >= 0; i--) {
      const day = new Date(Date.now() - i * 86400e3).toLocaleDateString('en-CA');
      const v = idx ? ((state.portDays || {})[day] || {})[idx] : null;
      out.push({ day, rx: v ? v[0] : 0, tx: v ? v[1] : 0 });
    }
    return sendJson(res, 200, { days: out, port: idx ? (sw.names.get(Number(idx)) || idx) : null });
  }
  if (req.method === 'GET' && pathname === '/api/free-ips') {
    return sendJson(res, 200, { networks: freeAddresses() });
  }
  if (req.method === 'GET' && pathname === '/free-ips') return serveFile(res, 'free-ips.html');
  if (req.method === 'GET' && pathname === '/api/alerts') {
    return sendJson(res, 200, { alerts: state.alerts || [], phone: !!settings.ntfyTopic });
  }
  if (req.method === 'POST' && pathname === '/api/alerts/read') {
    for (const a of state.alerts || []) a.read = true;
    saveData();
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'GET' && pathname === '/api/report') {
    const month = new URL(req.url, 'http://localhost').searchParams.get('month') || today().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(month)) return sendJson(res, 400, { error: 'bad month' });
    const months = [...new Set(Object.keys(state.portDays || {}).map((k) => k.slice(0, 7)))].sort().reverse();
    return sendJson(res, 200, { ...buildReport(month), months });
  }
  if (req.method === 'POST' && pathname === '/api/phone') {
    if (!isLocal(req)) return sendJson(res, 403, { error: 'only from this computer' });
    const { topic, test } = await readBody(req);
    const t = String(topic || '').trim();
    if (t && !/^[A-Za-z0-9_-]{6,64}$/.test(t)) return sendJson(res, 400, { error: 'bad topic' });
    if (t) settings.ntfyTopic = t; else delete settings.ntfyTopic;
    saveSettings();
    let sent = null;
    if (t && test) sent = await pushToPhone({ kind: 'test', p: {} });
    return sendJson(res, 200, { topic: settings.ntfyTopic || null, sent });
  }
  if (req.method === 'POST' && pathname === '/api/devices/forget') {
    const { id } = await readBody(req);
    delete state.devices[id];
    saveData();
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'GET' && pathname === '/api/export.csv') {
    const rows = [['Name', 'IP', 'MAC', 'Network', 'Status', 'Ping (ms)', 'Availability %', 'First seen', 'Last seen']];
    for (const d of getStatePayload().devices) {
      rows.push([d.name || '', d.ip, d.mac || '', d.cidr, d.online ? 'online' : 'offline',
        d.latencyMs ?? '', d.availability, d.firstSeen, d.lastSeen]);
    }
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="network-devices-${new Date().toISOString().slice(0, 10)}.csv"`,
    });
    return res.end('﻿' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n'));
  }
  if (req.method === 'GET' && pathname.startsWith('/public/')) {
    const file = path.normalize(path.join(__dirname, pathname));
    if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
    return fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    });
  }
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\nPort ${PORT} is already in use. The app may already be running: open http://localhost:${PORT}`);
    console.error('Or close the other window and run it again.\n');
  } else {
    console.error(err);
  }
  process.exit(1);
});

server.listen(PORT, async () => {
  loadData();
  console.log('\n  Network Monitor ' + APP_VERSION);
  console.log(`  Open on this computer:  http://localhost:${PORT}`);
  networks = await getLocalNetworks();
  for (const n of networks) for (const i of n.interfaces) console.log(`  From another device:    http://${i.ip}:${PORT}   (${i.name})`);
  console.log('');

  sampleTraffic();
  sampleRouter();
  sampleSwitch();
  setInterval(sampleSwitch, 10000);
  setInterval(sampleRouter, TRAFFIC_INTERVAL_MS);
  sampleApps();
  startUsageHelper();
  setInterval(sampleTraffic, TRAFFIC_INTERVAL_MS);
  setInterval(sampleApps, APPS_INTERVAL_MS);
  scanAll();
  setInterval(scanAll, SCAN_INTERVAL_MS);
  checkInternet();
  setInterval(checkInternet, 15000);
});
