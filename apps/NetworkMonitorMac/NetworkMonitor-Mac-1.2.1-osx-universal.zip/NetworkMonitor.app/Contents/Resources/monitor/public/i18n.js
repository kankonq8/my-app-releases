// Network Monitor: English and Arabic text for every page.
// English is the default every time a page opens. The language button switches it for this visit only.
// Rules: /mnt/project-files/translator/TRANSLATION.md (same keys in en and ar; missing Arabic falls back to English).
(function () {
  const S = {
    en: {
      appName: 'Network Monitor', lang: 'العربية', loading: 'Loading…', close: 'Close', save: 'Save', now: 'now',
      // top bar
      runsOn: 'Running on {0} · Version {1}', scanNow: 'Scan now', scanning: 'Scanning…', lastScan: 'Last scan {0}', waiting: 'Waiting',
      exportCsv: 'Export to Excel', freeIps: 'Free IPs', monthly: 'Monthly report', alerts: 'Alerts', setup: 'Setup',
      theme: 'Dark / light mode', cantConnect: 'Cannot reach the app. Make sure it is running.',
      // networks
      mainNet: 'Main network', localNet: 'Local network', routerAt: 'Router {0}', nOnline: '{0} online',
      partial: 'Partial scan', partialTip: 'Big network: only the part near this PC is scanned', notConnected: 'Not connected',
      noNetwork: 'This PC is not connected to any network',
      // router bar
      homeInternet: 'Whole home internet', fromRouter: 'From the router', fromRouterModel: 'From the router · {0}',
      downNow: 'Download now', upNow: 'Upload now', usedToday: 'Used today', thisMonth: 'This month', downUp: 'Download {0} · Upload {1}',
      // KPIs
      kOnline: 'Devices online now', kOf: 'of {0}', kOffline: '{0} known devices offline now', kNew: 'New devices today',
      kNewHint: 'Not there in the first scan', kRx: 'Download speed on this PC', kTxHint: 'Upload {0}', kLat: 'Average response time',
      kLatHint: 'Reply time of online devices',
      // devices table
      devices: 'Devices on the network', fAll: 'All', fOnline: 'Online', fOffline: 'Offline', fNew: 'New',
      search: 'Search by name, IP or MAC', thDevice: 'Device', thIp: 'IP address', thMac: 'MAC address', thStatus: 'Status',
      thPing: 'Response', thUsage: 'Used today', thAvail: 'Availability', thSeen: 'Last seen', sortUsage: 'Sort by usage',
      firstScan: 'Scanning the network for the first time, it takes about 10 seconds…', online: 'Online', offline: 'Offline',
      noReply: 'No reply', newTag: 'New', important: 'Important device', noMatch: 'No devices match the search', noDevices: 'No devices found yet',
      onRouter: 'On the router', onRouterTip: 'Connected to the router directly or by Wi-Fi, not to the switch, so its usage cannot be counted',
      wholeSwitch: 'Whole switch', wholeSwitchTip: 'Everything between the switch and the router', shared: 'Shared',
      sharedTip: 'More than one device on this port; the number is for all of them', unnamed: 'Unnamed device', router: 'Router', thisPc: 'This PC',
      // device kinds
      kind_router: 'Router', kind_self: 'This PC', kind_pc: 'Computer', kind_vm: 'Virtual machine', kind_phone: 'Phone or tablet',
      kind_storage: 'Storage (NAS)', kind_tv: 'TV / screen', kind_unknown: 'Unknown device',
      // side panels
      topToday: 'Top devices today', nowRate: 'now {0}', yourUsage: 'This PC usage', download: 'Download', upload: 'Upload',
      last10: 'Last 10 minutes', sinceStart: 'Since start: download {0} · upload {1}', collecting: 'Collecting readings…',
      services: 'Services and ports on this PC', servicesNote: 'Each service runs on a port (like FTP, SSH or a website). Numbers are for today since the app started. ↓ download ↑ upload.',
      port: 'Port {0}', appsBytes: 'Top programs today', appsConn: 'Programs using the internet now',
      appsBytesNote: 'Real usage per program since the start of the day (since the app started). Calls, some games and video use a connection type (UDP) that is not counted here.',
      appsConnNote: 'The number is how many connections each program has. To see usage in MB, the app needs administrator rights.',
      noUsage: 'No usage recorded yet', nConn: '{0} connections', ended: 'Program that ended',
      whyTitle: "Why don't I see each device's usage?",
      whyText: 'The internet of other devices goes through the router, not through this PC, so this PC cannot see how much they download. Per-device numbers come from the switch (Setup > Switch) and home totals from the router (Setup > Router). Everything here is a real reading from your network.',
      svc_21: 'FTP (file transfer)', svc_22: 'SSH (remote control)', svc_80: 'Web', svc_443: 'Secure web', svc_445: 'Windows file sharing',
      svc_1434: 'SQL Browser', svc_3389: 'Remote Desktop (RDP)', svc_8080: 'Web (8080)',
      // history
      histNote: 'Last 30 days total: {0} · highest day: {1}. Hover a bar to see the day.', histTip: '{0}: download {1} · upload {2}',
      // alerts
      alertsPhone: 'Alerts also go to your phone.', alertsHere: 'Alerts show here. To get them on your phone, turn it on in Setup > Phone alerts.',
      noAlerts: 'No alerts yet. Any new device that joins the network, and any important device that goes offline, shows here.',
      a_back: '{0} is back online', a_new: 'New device joined the network: {0}', a_down: '{0} went offline', a_lastSeen: 'Last seen {0}',
      a_report: 'Monthly report {0}', a_noData: 'Not enough data', a_home: 'Home internet: {0}', a_test: 'Alerts are working ✓',
      deviceIp: 'Device {0}',
      // report
      repHome: 'Whole home internet (from the router)', repDays: 'Days with readings', repTop: 'Top devices', repNo: '#',
      repTotal: 'Total', repShare: 'Share', repNoSwitch: 'No switch data for this month.', repApps: 'Top programs on this PC',
      repNote: 'At the start of each month you get a summary of the month before in Alerts (and on your phone if turned on).',
      // drawer
      onlineNow: 'Online now', offlineSeen: 'Offline, last seen {0}', devName: 'Device name', namePh: 'Type a name you know it by, like: Ahmed\'s phone',
      netName: 'Name on the network: {0}', impOn: '★ Important device: you get an alert if it goes offline', impOff: '☆ Mark as important (alert me if it goes offline)',
      vendor: 'Maker', privateMac: 'Private (random) address', unknownVendor: 'Unknown', network: 'Network', pingNow: 'Response now',
      noPing: 'Does not reply to ping', avgPing: 'Average response', availOf: '{0} of scans', firstSeen: 'First seen', lastSeen: 'Last seen',
      readings: 'Readings', swPort: 'Switch port', swPortRouter: ' (router port: the device is on the router, not the switch)',
      swPortUplink: ' (links the switch to the router)', sharedWith: ' · shared with {0}', dlToday: 'Download today', ulToday: 'Upload today',
      dlRate: 'Download speed now', ulRate: 'Upload speed now', daily30: 'Daily usage (last 30 days)', pingHour: 'Response time (last hour)',
      gapsNote: 'Gaps in the line mean the device was offline then.', yourPc: 'This is your PC',
      yourPcText: 'Its usage and the programs using the internet on it are in the side panel.', devUsage: "This device's usage",
      devUsageRouter: 'This device is on the router directly or by Wi-Fi, not on the switch, so its own usage cannot be counted.',
      devUsageNoSwitch: 'Usage of every device on the switch shows after you connect the switch in Setup > Switch.',
      forget: 'Remove this device from the list',
      // setup
      tabRouter: 'Router', tabSwitch: 'Switch', tabPhone: 'Phone alerts', tabPassword: 'Password', tabStartup: 'Startup',
      setupIntro: 'These settings are saved on this PC only. They are never uploaded or shared.',
      setupLocalOnly: 'Setup can only be changed on the PC the app runs on.',
      rIntro: 'The router gives the whole home internet usage (today, this month, live speed). Huawei home routers (4G/5G CPE, HiLink) are read without a password.',
      rMode: 'Router type', rAuto: 'Automatic (try the gateway)', rHuawei: 'Huawei (HiLink)', rOff: 'Other / don\'t read the router',
      rHost: 'Router address', rHostPh: 'Empty = gateway {0}', rTest: 'Save and test', rOk: 'Connected ✓ {0}', rFail: 'The router did not answer. Check the address, or pick "Other" if it is not a Huawei router.',
      rOffMsg: 'Saved. The router is not read.', rSteps: 'If it does not connect: open the router page in a browser once, sign in, and make sure the "Statistics" page shows numbers. Some routers only share them on the home network (not on a guest network).',
      sIntro: 'A managed switch counts the data on every port. With SNMP (read only) turned on, the app shows how much each device on the switch uses.',
      sHost: 'Switch address (the switch\'s own IP, not this PC)', sHostPh: 'Switch address, like 192.168.1.2', sComm: 'SNMP community (password)', sConnect: 'Connect', sRemove: 'Disconnect',
      sSaved: 'Switch connected ✓ (no need to type the community again)', sTrying: 'Connecting to the switch…', sOk: 'Connected ✓ usage is counted from now.', sRemoved: 'Disconnected.',
      sFail: 'The switch did not answer. Make sure SNMP is on, the community is right, and this PC\'s address is allowed.',
      a_limit: '{0} passed its daily limit', a_limitBody: 'Used {0} today (limit {1} GB)',
      a_outage: 'The internet was down for {0}', a_outageBody: 'From {0} to {1}',
      a_weekly: 'Weekly summary {0} → {1}', a_outages: 'Internet outages: {0} ({1})', a_noOutages: 'No internet outages',
      limT: 'Daily usage alert', limPh: 'GB per day, like 10', limNote: 'You get an alert (and a phone notice if phone alerts are on) when this device uses more than this in one day. Leave empty for no alert.',
      limIs: 'Alert above {0} GB a day', limNone: 'No daily alert',
      netT: 'Internet connection', netUp: 'Working', netDown: 'Down since {0}', netChecking: 'Checking…', netToday: 'Outages today', netWeek: 'Last 7 days',
      netNone: 'No outages recorded yet.', netRecent: 'Recent outages', netNote: 'Checked every 15 seconds. Drops shorter than 30 seconds are not counted.',
      sFind: 'Find the switch', sFinding: 'Looking at the devices on the network…', sFoundNone: 'No switch found. Type its address yourself.', sFoundT: 'Found, tap one to use it:',
      sSnmpOk: 'answers SNMP ✓', sFindTip: 'Tip: type the community first, so the search can check which device answers SNMP.',
      wkT: 'Weekly summary', wkOn: 'Send a weekly summary to the phone every Friday (9 AM)', wkTest: 'Send one now', wkSent: 'Sent ✓', wkNoPhone: 'Turn on phone alerts above first.',
      wkFail: 'Could not send. Make sure phone alerts are saved and this PC has internet.',
      uNote: 'Used today for each device needs a managed switch with SNMP. A home router alone only gives the whole home total (shown above).',
      uNoteFail: 'Used today for each device is off because the switch is not answering.', uNoteBtn: 'Set up the switch',
      stIntro_mac: 'Keep Network Monitor running in the background and start it when you log in to this Mac, so alerts, history and the page for other devices keep working when the app window is closed.',
      stOn_mac: 'Start when I log in (in the background)', stIsOn_mac: 'On ✓ it keeps running in the background and starts when you log in.',
      stFail_mac: 'Could not change it. Open the app from Kankon Launcher and try again.',
      byline: 'by Kankon · kankon.net',
      sIsPc: '{0} is this PC, not the switch. Type the switch\'s own address (the one you open its settings page with).',
      sThisPc: 'Allow this PC in the switch SNMP settings: {0} (or allow the whole network, like {1}, so every PC works).',
      sStepsT: 'How to turn on SNMP in the switch',
      sSteps: '1) Open the switch page in a browser and sign in. 2) Find SNMP (often under System or Management). 3) Turn on SNMP v1/v2c, read only. 4) Set a community name (like a password, avoid "public"). 5) If there is an allowed hosts list, add this PC\'s IP. 6) Save, then type the same address and community here.',
      pIntroSteps: '1) Install the ntfy app from the App Store or Google Play. 2) Pick a secret name here (English letters and numbers, 6 or more) and press Save. 3) In the app press + and type the same name.',
      pPh: 'like home-net-8241', pSave: 'Save and send a test', pOff: 'Turn off', pSending: 'Sending…', pBad: 'The name must be English letters and numbers only, 6 or more.',
      pOffMsg: 'Phone alerts turned off.', pOk: 'Saved ✓ Did the test reach your phone? If not, check you typed the same name in the app.',
      pFail: 'Saved, but the test could not be sent. Make sure this PC is connected to the internet.', pLocal: 'You can set this only on the PC the app runs on.',
      pwTitle: 'Page password', pwOn: 'The page is protected. Any other device that opens it must type the password. On this PC it opens without a password.',
      pwOff: 'The page is open to anyone on the network now. Set a password so other devices must type it first.',
      pw1: 'New password (6 characters or more)', pw2: 'Type it again', pwSave: 'Save password', pwRemove: 'Remove protection', logout: 'Sign out',
      pwSaved: 'Password saved.', pwRemoved: 'Protection removed.', pwLocal: 'You can change it only on the PC the app runs on.', pwShort: 'Not saved. Make sure it is 6 characters or more.',
      pwMismatch: 'The two passwords do not match.', pwConfirm: 'Remove the password? The page will be open to anyone on the network.',
      stIntro: 'Keep Network Monitor running in the background and start it with Windows, so alerts, history and the page for other devices keep working when the app window is closed.',
      stOn: 'Start with Windows (in the background)', stIsOn: 'On ✓ it runs in the background and starts with Windows.', stIsOff: 'Off. It runs only while the app window is open.',
      stFail: 'Could not change it. Open the app from Apps Launcher (it needs administrator rights).', remote: 'Open from another device: {0}',
      // free IPs page
      backToApp: '← Network Monitor', fTitle: 'Free IP addresses on the network',
      fSub: 'Addresses with no device connected right now. You can use them for a new device without a conflict.',
      fNoNet: 'No network connected right now.', fNever: 'No device ever recorded', fWasUsed: 'A device used it before, offline now',
      fAllUsed: 'All addresses are in use right now', fRouter: 'Router {0}', fPartial: 'Partial scan (first /24 only)', fFreeNow: 'Free now',
      fNeverSeen: 'Never used', fUsedNow: 'In use now', fScanned: 'Scanned {0}. An address that any device answers on (even if it blocks ping) counts as used.',
      fAddrs: 'Addresses', fCount: 'Count', fState: 'State', fCantConnect: 'Cannot reach the app.',
      // login page
      lProtected: 'This page is protected. Type the password to sign in.', lPw: 'Password', lSignIn: 'Sign in', lCant: 'Cannot reach the app',
      lTooMany: 'Too many tries. Wait 5 minutes and try again.', lWrong: 'Wrong password',
    },
    ar: {
      appName: 'Network Monitor', lang: 'English', loading: 'جاري التحميل…', close: 'إغلاق', save: 'حفظ', now: 'الآن',
      runsOn: 'يشتغل على {0} · الإصدار {1}', scanNow: 'فحص الآن', scanning: 'جاري الفحص…', lastScan: 'آخر فحص {0}', waiting: 'في الانتظار',
      exportCsv: 'تصدير إلى Excel', freeIps: 'الـ IPs الفاضية', monthly: 'التقرير الشهري', alerts: 'التنبيهات', setup: 'الإعدادات',
      theme: 'الوضع الليلي/النهاري', cantConnect: 'تعذر الاتصال بالبرنامج. تأكد إنه شغال.',
      mainNet: 'الشبكة الرئيسية', localNet: 'شبكة محلية', routerAt: 'الراوتر {0}', nOnline: '{0} متصل',
      partial: 'فحص جزئي', partialTip: 'الشبكة كبيرة، يتم فحص الجزء القريب من جهازك بس', notConnected: 'غير متصل',
      noNetwork: 'هذا الكمبيوتر غير متصل بأي شبكة',
      homeInternet: 'إنترنت البيت كامل', fromRouter: 'من الراوتر', fromRouterModel: 'من الراوتر · {0}',
      downNow: 'تنزيل الآن', upNow: 'رفع الآن', usedToday: 'استهلاك اليوم', thisMonth: 'هذا الشهر', downUp: 'تنزيل {0} · رفع {1}',
      kOnline: 'الأجهزة المتصلة الآن', kOf: 'من {0}', kOffline: '{0} جهاز معروف غير متصل الآن', kNew: 'أجهزة جديدة اليوم',
      kNewHint: 'ما كانت موجودة في أول فحص', kRx: 'سرعة التنزيل على جهازك', kTxHint: 'الرفع {0}', kLat: 'متوسط زمن الاستجابة',
      kLatHint: 'زمن رد الأجهزة المتصلة',
      devices: 'الأجهزة على الشبكة', fAll: 'الكل', fOnline: 'متصل', fOffline: 'غير متصل', fNew: 'جديد',
      search: 'ابحث بالاسم أو IP أو MAC', thDevice: 'الجهاز', thIp: 'عنوان IP', thMac: 'عنوان MAC', thStatus: 'الحالة',
      thPing: 'الاستجابة', thUsage: 'الاستهلاك اليوم', thAvail: 'نسبة التواجد', thSeen: 'آخر ظهور', sortUsage: 'رتب حسب الاستهلاك',
      firstScan: 'جاري فحص الشبكة لأول مرة، يأخذ حوالي 10 ثواني…', online: 'متصل', offline: 'غير متصل',
      noReply: 'لا يرد', newTag: 'جديد', important: 'جهاز مهم', noMatch: 'ما فيه أجهزة تطابق البحث', noDevices: 'ما لقينا أجهزة بعد',
      onRouter: 'على الراوتر', onRouterTip: 'متوصل بالراوتر مباشرة أو بالواي فاي، مو بالسويتش، فما نقدر نحسب استهلاكه',
      wholeSwitch: 'كل السويتش', wholeSwitchTip: 'كل اللي مر بين السويتش والراوتر', shared: 'مشترك',
      sharedTip: 'نفس المنفذ عليه أكثر من جهاز، الرقم لهم كلهم', unnamed: 'جهاز بدون اسم', router: 'الراوتر', thisPc: 'هذا الكمبيوتر',
      kind_router: 'الراوتر', kind_self: 'هذا الكمبيوتر', kind_pc: 'كمبيوتر', kind_vm: 'جهاز افتراضي', kind_phone: 'جوال أو تابلت',
      kind_storage: 'وحدة تخزين (NAS)', kind_tv: 'تلفزيون / شاشة', kind_unknown: 'جهاز غير معروف',
      topToday: 'أكثر الأجهزة استهلاكاً اليوم', nowRate: 'الآن {0}', yourUsage: 'استهلاك جهازك', download: 'تنزيل', upload: 'رفع',
      last10: 'آخر 10 دقائق', sinceStart: 'من بداية التشغيل: تنزيل {0} · رفع {1}', collecting: 'جاري جمع القراءات…',
      services: 'الخدمات والمنافذ على هذا الكمبيوتر', servicesNote: 'كل خدمة تشتغل على منفذ (مثل FTP أو SSH أو موقع). الرقم هنا اليوم من وقت التشغيل. ↓ تنزيل ↑ رفع.',
      port: 'منفذ {0}', appsBytes: 'البرامج الأكثر استهلاكاً اليوم', appsConn: 'البرامج اللي تستخدم الإنترنت الحين',
      appsBytesNote: 'استهلاك حقيقي لكل برنامج من بداية اليوم (من وقت تشغيل البرنامج). المكالمات وبعض الألعاب والفيديو تستخدم نوع اتصال (UDP) ما ينحسب هنا.',
      appsConnNote: 'الرقم هو عدد اتصالات كل برنامج. عشان تشوف الاستهلاك بالميغا، البرنامج يحتاج صلاحيات المسؤول.',
      noUsage: 'ما فيه استهلاك مسجل بعد', nConn: '{0} اتصال', ended: 'برنامج انتهى',
      whyTitle: 'ليش ما أشوف استهلاك كل جهاز؟',
      whyText: 'إنترنت الأجهزة الثانية يمر عبر الراوتر، مو عبر هذا الكمبيوتر، فما يقدر يشوف كم تحمّل. استهلاك كل جهاز يجي من السويتش (الإعدادات > Switch) ومجموع البيت يجي من الراوتر (الإعدادات > Router). كل اللي تشوفه هنا قراءات حقيقية من شبكتك.',
      svc_21: 'FTP (نقل ملفات)', svc_22: 'SSH (تحكم عن بعد)', svc_80: 'ويب', svc_443: 'ويب آمن', svc_445: 'مشاركة ملفات Windows',
      svc_1434: 'SQL Browser', svc_3389: 'سطح مكتب بعيد (RDP)', svc_8080: 'ويب (8080)',
      histNote: 'مجموع آخر 30 يوم: {0} · أعلى يوم: {1}. مرر على أي عمود يطلع لك اليوم.', histTip: '{0}: تنزيل {1} · رفع {2}',
      alertsPhone: 'التنبيهات توصل جوالك كمان.', alertsHere: 'التنبيهات تطلع هنا. عشان توصل جوالك، فعّلها من الإعدادات > تنبيهات الجوال.',
      noAlerts: 'ما فيه تنبيهات بعد. بيطلع هنا أي جهاز جديد يدخل الشبكة، وأي جهاز مهم يفصل.',
      a_back: '{0} رجع متصل', a_new: 'جهاز جديد دخل الشبكة: {0}', a_down: '{0} فصل (غير متصل)', a_lastSeen: 'آخر ظهور {0}',
      a_report: 'التقرير الشهري {0}', a_noData: 'ما فيه بيانات كافية', a_home: 'إنترنت البيت: {0}', a_test: 'التنبيهات شغالة ✓',
      deviceIp: 'جهاز {0}',
      repHome: 'إنترنت البيت كامل (من الراوتر)', repDays: 'أيام فيها قراءات', repTop: 'أكثر الأجهزة استهلاكاً', repNo: '#',
      repTotal: 'المجموع', repShare: 'النسبة', repNoSwitch: 'ما فيه بيانات من السويتش لهذا الشهر.', repApps: 'أكثر البرامج استهلاكاً على هذا الكمبيوتر',
      repNote: 'أول كل شهر يجيك ملخص الشهر اللي قبله في التنبيهات (وعلى جوالك إذا فعّلته).',
      onlineNow: 'متصل الآن', offlineSeen: 'غير متصل، آخر ظهور {0}', devName: 'اسم الجهاز', namePh: 'اكتب اسم تعرفه فيه، مثل: جوال أحمد',
      netName: 'الاسم على الشبكة: {0}', impOn: '★ جهاز مهم: بنبهك إذا فصل', impOff: '☆ علّمه كجهاز مهم (نبهني إذا فصل)',
      vendor: 'الشركة المصنعة', privateMac: 'عنوان خاص (عشوائي)', unknownVendor: 'غير معروفة', network: 'الشبكة', pingNow: 'الاستجابة الآن',
      noPing: 'لا يرد على ping', avgPing: 'متوسط الاستجابة', availOf: '{0} من الفحوصات', firstSeen: 'أول ظهور', lastSeen: 'آخر ظهور',
      readings: 'عدد القراءات', swPort: 'منفذ السويتش', swPortRouter: ' (منفذ الراوتر: الجهاز متوصل بالراوتر مو بالسويتش)',
      swPortUplink: ' (يوصل السويتش بالراوتر)', sharedWith: ' · مشترك مع {0}', dlToday: 'تنزيل اليوم', ulToday: 'رفع اليوم',
      dlRate: 'سرعة التنزيل الآن', ulRate: 'سرعة الرفع الآن', daily30: 'الاستهلاك اليومي (آخر 30 يوم)', pingHour: 'زمن الاستجابة (آخر ساعة)',
      gapsNote: 'الفراغات في الخط تعني إن الجهاز كان غير متصل وقتها.', yourPc: 'هذا جهازك',
      yourPcText: 'استهلاكه والبرامج اللي تستخدم الإنترنت عليه تلقاها في اللوحة الجانبية.', devUsage: 'استهلاك هذا الجهاز',
      devUsageRouter: 'هذا الجهاز متوصل بالراوتر مباشرة أو بالواي فاي، مو بالسويتش، فما نقدر نحسب استهلاكه لحاله.',
      devUsageNoSwitch: 'يطلع استهلاك كل جهاز متوصل بالسويتش بعد ما تربط السويتش من الإعدادات > Switch.',
      forget: 'إزالة هذا الجهاز من القائمة',
      tabRouter: 'Router', tabSwitch: 'Switch', tabPhone: 'تنبيهات الجوال', tabPassword: 'كلمة السر', tabStartup: 'التشغيل',
      setupIntro: 'هذي الإعدادات تنحفظ على هذا الجهاز بس، وما تنرفع ولا تنشارك أبداً.',
      setupLocalOnly: 'الإعدادات تتغير من الكمبيوتر اللي شغال عليه البرنامج بس.',
      rIntro: 'الراوتر يعطيك استهلاك إنترنت البيت كامل (اليوم، هذا الشهر، والسرعة الحين). راوترات Huawei المنزلية (4G/5G CPE و HiLink) يقرأها البرنامج بدون كلمة سر.',
      rMode: 'نوع الراوتر', rAuto: 'تلقائي (يجرب البوابة)', rHuawei: 'Huawei (HiLink)', rOff: 'غيره / لا تقرأ الراوتر',
      rHost: 'عنوان الراوتر', rHostPh: 'فاضي = البوابة {0}', rTest: 'حفظ وتجربة', rOk: 'متصل ✓ {0}', rFail: 'الراوتر ما رد. تأكد من العنوان، أو اختر «غيره» إذا ما كان راوتر Huawei.',
      rOffMsg: 'تم الحفظ. البرنامج ما بيقرأ الراوتر.', rSteps: 'إذا ما اتصل: افتح صفحة الراوتر في المتصفح مرة، وسجل دخول، وتأكد إن صفحة «Statistics» فيها أرقام. بعض الراوترات تعطيها بس على شبكة البيت (مو شبكة الضيوف).',
      sIntro: 'السويتش المُدار يحسب البيانات على كل منفذ. لما تشغّل SNMP (قراءة بس)، البرنامج يعرض كم يستهلك كل جهاز متوصل بالسويتش.',
      sHost: 'عنوان السويتش (IP السويتش نفسه، مو هذا الجهاز)', sHostPh: 'عنوان السويتش، مثل 192.168.1.2', sComm: 'كلمة SNMP (Community)', sConnect: 'ربط', sRemove: 'فك الربط',
      sSaved: 'السويتش مربوط ✓ (ما تحتاج تكتب الكلمة مرة ثانية)', sTrying: 'جاري الاتصال بالسويتش…', sOk: 'تم الربط ✓ الاستهلاك يبدأ ينحسب من الحين.', sRemoved: 'تم فك الربط.',
      sFail: 'السويتش ما رد. تأكد إن SNMP مفعّل، وإن الكلمة صحيحة، وإن عنوان هذا الكمبيوتر مسموح فيه.',
      a_limit: '{0} تعدى الحد اليومي', a_limitBody: 'استهلك {0} اليوم (الحد {1} GB)',
      a_outage: 'النت كان فاصل {0}', a_outageBody: 'من {0} إلى {1}',
      a_weekly: 'الملخص الأسبوعي {0} → {1}', a_outages: 'انقطاعات النت: {0} ({1})', a_noOutages: 'ما فيه انقطاعات بالنت',
      limT: 'تنبيه الاستهلاك اليومي', limPh: 'GB باليوم، مثلاً 10', limNote: 'يجيك تنبيه (وإشعار على الجوال إذا مفعّل) لما يستهلك هذا الجهاز أكثر من هذا الحد في يوم واحد. خله فاضي إذا ما تبي تنبيه.',
      limIs: 'تنبيه فوق {0} GB باليوم', limNone: 'ما فيه تنبيه يومي',
      netT: 'اتصال الإنترنت', netUp: 'شغال', netDown: 'فاصل من {0}', netChecking: 'جاري الفحص…', netToday: 'انقطاعات اليوم', netWeek: 'آخر 7 أيام',
      netNone: 'ما انسجل أي انقطاع للحين.', netRecent: 'آخر الانقطاعات', netNote: 'يفحص كل 15 ثانية. الانقطاع أقل من 30 ثانية ما ينحسب.',
      sFind: 'دوّر على السويتش', sFinding: 'جاري البحث في أجهزة الشبكة…', sFoundNone: 'ما لقيت سويتش. اكتب عنوانه بنفسك.', sFoundT: 'لقيت، اضغط على واحد عشان تستخدمه:',
      sSnmpOk: 'يرد على SNMP ✓', sFindTip: 'نصيحة: اكتب الـCommunity أول، عشان البحث يعرف أي جهاز يرد على SNMP.',
      wkT: 'الملخص الأسبوعي', wkOn: 'أرسل ملخص أسبوعي على الجوال كل جمعة (9 الصبح)', wkTest: 'أرسل واحد الحين', wkSent: 'انرسل ✓', wkNoPhone: 'فعّل تنبيهات الجوال فوق أول.',
      wkFail: 'ما قدرت أرسل. تأكد إن تنبيهات الجوال محفوظة وإن الجهاز فيه نت.',
      uNote: 'استهلاك اليوم لكل جهاز يحتاج سويتش مُدار مع SNMP. الراوتر المنزلي بروحه يعطي استهلاك البيت كامل بس (فوق).',
      uNoteFail: 'استهلاك اليوم لكل جهاز واقف لأن السويتش ما يرد.', uNoteBtn: 'إعداد السويتش',
      stIntro_mac: 'خل Network Monitor يشتغل بالخلفية ويبدأ لما تسجل دخول على الماك، عشان التنبيهات والسجل والصفحة للأجهزة الثانية تظل شغالة حتى لو سكرت نافذة البرنامج.',
      stOn_mac: 'التشغيل عند تسجيل الدخول (بالخلفية)', stIsOn_mac: 'شغال ✓ يظل شغال بالخلفية ويبدأ لما تسجل دخول.',
      stFail_mac: 'تعذر التغيير. افتح البرنامج من اللانشر وجرب مرة ثانية.',
      byline: 'من Kankon · kankon.net',
      sIsPc: '{0} هو هذا الجهاز، مو السويتش. اكتب عنوان السويتش نفسه (اللي تفتح منه صفحة إعداداته).',
      sThisPc: 'اسمح لهذا الجهاز في إعدادات SNMP بالسويتش: {0} (أو اسمح للشبكة كاملة، مثل {1}، عشان أي جهاز يشتغل).',
      sStepsT: 'طريقة تشغيل SNMP في السويتش',
      sSteps: '1) افتح صفحة السويتش في المتصفح وسجل دخول. 2) دوّر SNMP (غالباً تحت System أو Management). 3) شغّل SNMP v1/v2c للقراءة بس. 4) حط اسم Community (مثل كلمة سر، لا تستخدم "public"). 5) إذا فيه قائمة أجهزة مسموحة، أضف IP هذا الكمبيوتر. 6) احفظ، وبعدين اكتب نفس العنوان والكلمة هنا.',
      pIntroSteps: '1) نزّل تطبيق ntfy من App Store أو Google Play. 2) اختر اسم سري هنا (حروف إنجليزية وأرقام، 6 أو أكثر) واضغط «حفظ». 3) في التطبيق اضغط + واكتب نفس الاسم.',
      pPh: 'مثلاً home-net-8241', pSave: 'حفظ وإرسال تجربة', pOff: 'إيقاف', pSending: 'جاري الإرسال…', pBad: 'الاسم لازم يكون حروف إنجليزية وأرقام بس، 6 أو أكثر.',
      pOffMsg: 'تم إيقاف تنبيهات الجوال.', pOk: 'تم الحفظ ✓ وصلت رسالة التجربة لجوالك؟ إذا ما وصلت تأكد إنك كتبت نفس الاسم في التطبيق.',
      pFail: 'تم الحفظ، بس تعذر إرسال التجربة. تأكد إن الكمبيوتر متصل بالإنترنت.', pLocal: 'تقدر تضبطها من الكمبيوتر اللي شغال عليه البرنامج بس.',
      pwTitle: 'كلمة سر الصفحة', pwOn: 'الصفحة محمية. أي جهاز ثاني يفتحها لازم يكتب كلمة السر. من هذا الكمبيوتر تفتح بدون كلمة سر.',
      pwOff: 'الصفحة الحين مفتوحة لأي أحد على الشبكة. حط كلمة سر عشان الأجهزة الثانية تطلبها قبل الدخول.',
      pw1: 'كلمة السر الجديدة (6 حروف أو أكثر)', pw2: 'اكتبها مرة ثانية', pwSave: 'حفظ كلمة السر', pwRemove: 'إلغاء الحماية', logout: 'تسجيل الخروج',
      pwSaved: 'تم حفظ كلمة السر.', pwRemoved: 'تم إلغاء الحماية.', pwLocal: 'تقدر تغيرها من الكمبيوتر اللي شغال عليه البرنامج بس.', pwShort: 'ما تم الحفظ. تأكد إنها 6 حروف أو أكثر.',
      pwMismatch: 'كلمة السر مو نفسها في الخانتين.', pwConfirm: 'أكيد تبي تلغي كلمة السر؟ الصفحة بتصير مفتوحة لأي أحد على الشبكة.',
      stIntro: 'خل Network Monitor يشتغل بالخلفية ويبدأ مع الويندوز، عشان التنبيهات والسجل والصفحة للأجهزة الثانية تظل شغالة حتى لو سكرت نافذة البرنامج.',
      stOn: 'التشغيل مع الويندوز (بالخلفية)', stIsOn: 'شغال ✓ يشتغل بالخلفية ويبدأ مع الويندوز.', stIsOff: 'مطفي. يشتغل بس لما تكون نافذة البرنامج مفتوحة.',
      stFail: 'تعذر التغيير. افتح البرنامج من اللانشر (يحتاج صلاحيات المسؤول).', remote: 'تفتحه من جهاز ثاني: {0}',
      backToApp: 'Network Monitor →', fTitle: 'الـ IPs الفاضية في الشبكة',
      fSub: 'العناوين اللي ما فيها أي جهاز متصل الحين. تقدر تستخدمها لجهاز جديد بدون ما تتعارض مع أحد.',
      fNoNet: 'ما فيه شبكة متصلة الحين.', fNever: 'ما انسجل عليها جهاز أبداً', fWasUsed: 'جهاز كان عليها قبل، غير متصل الحين',
      fAllUsed: 'كل العناوين مستخدمة الحين', fRouter: 'الراوتر {0}', fPartial: 'فحص جزئي (أول /24 بس)', fFreeNow: 'فاضية الحين',
      fNeverSeen: 'ما انسجلت أبداً', fUsedNow: 'مستخدمة الحين', fScanned: 'تم الفحص من {0}. العنوان اللي يرد عليه أي جهاز (حتى لو يقفل الـ ping) يعتبر مستخدم.',
      fAddrs: 'العناوين', fCount: 'العدد', fState: 'الوضع', fCantConnect: 'تعذر الاتصال بالبرنامج.',
      lProtected: 'هذي الصفحة محمية. اكتب كلمة السر للدخول.', lPw: 'كلمة السر', lSignIn: 'تسجيل الدخول', lCant: 'تعذر الاتصال بالبرنامج',
      lTooMany: 'محاولات كثيرة. انتظر 5 دقائق وجرب مرة ثانية.', lWrong: 'كلمة السر غير صحيحة',
    },
  };

  // English unless the page was opened with ?lang=ar (used when moving between pages of the app).
  let lang = new URLSearchParams(location.search).get('lang') === 'ar' ? 'ar' : 'en';
  const listeners = [];

  // On a Mac some lines say "Mac" instead of "Windows": key_mac wins when it exists.
  let mac = false;
  function T(key, ...args) {
    let t = mac ? (S[lang] && S[lang][key + '_mac']) ?? S.en[key + '_mac'] : null;
    if (t == null) t = (S[lang] && S[lang][key]);
    if (t == null) t = S.en[key];
    if (t == null) return key;
    return t.replace(/\{(\d)\}/g, (_, i) => String(args[i] ?? ''));
  }

  // Static text: data-i18n (text), data-i18n-ph (placeholder), data-i18n-title (tooltip).
  function apply(root = document) {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = T(el.dataset.i18n); });
    root.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = T(el.dataset.i18nPh); });
    root.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = T(el.dataset.i18nTitle); });
    root.querySelectorAll('a[data-keep-lang]').forEach((a) => {
      const u = new URL(a.getAttribute('href'), location.href);
      if (lang === 'ar') u.searchParams.set('lang', 'ar'); else u.searchParams.delete('lang');
      a.setAttribute('href', u.pathname + u.search);
    });
  }

  function setLang(l) {
    lang = l === 'ar' ? 'ar' : 'en';
    const u = new URL(location.href);
    if (lang === 'ar') u.searchParams.set('lang', 'ar'); else u.searchParams.delete('lang');
    history.replaceState(null, '', u.pathname + u.search + u.hash);
    apply();
    listeners.forEach((fn) => fn(lang));
  }

  window.I18N = {
    T, apply, setLang,
    setMac: (v) => { mac = !!v; apply(); },
    get lang() { return lang; },
    get rtl() { return lang === 'ar'; },
    locale: () => (lang === 'ar' ? 'ar' : 'en-GB'),
    onChange: (fn) => listeners.push(fn),
    toggle: () => setLang(lang === 'ar' ? 'en' : 'ar'),
  };
  document.addEventListener('DOMContentLoaded', () => apply());
})();
