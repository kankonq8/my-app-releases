// Speed limits and Auto Detect.
// Auto Detect looks at the devices online now and works out which one is the router and which
// are managed switches (from their web page and, if a community is known, SNMP sysObjectID).
// Each supported model has an adapter that knows how to set a speed limit on it. Models without
// an adapter are listed as "not supported" and nothing is ever sent to them.
const http = require('http');

// Known models. `limit`: what the adapter can limit ('port' = per switch port, 'device' = per device).
const MODELS = [
  { id: 'netgear-s350', kind: 'switch', vendor: 'NETGEAR', limit: 'port',
    match: (i) => /GS3\d\dT\w*\b.*S350|S350 Series/i.test(i.text) || /^1\.3\.6\.1\.4\.1\.4526\.100\.4\./.test(i.oid || '') },
  { id: 'netgear-smart', kind: 'switch', vendor: 'NETGEAR', limit: null,
    match: (i) => /netgear|prosafe/i.test(i.text) },
  { id: 'huawei-cpe', kind: 'router', vendor: 'Huawei', limit: null,
    match: (i) => /huawei|hilink|emui webui|CPE Pro/i.test(i.text) },
  { id: 'tplink', kind: 'switch', vendor: 'TP-Link', limit: null, match: (i) => /tp-?link|omada|easy smart/i.test(i.text) },
  { id: 'cisco', kind: 'switch', vendor: 'Cisco', limit: null, match: (i) => /cisco/i.test(i.text) },
  { id: 'mikrotik', kind: 'router', vendor: 'MikroTik', limit: null, match: (i) => /mikrotik|routeros/i.test(i.text) },
  { id: 'ubiquiti', kind: 'switch', vendor: 'Ubiquiti', limit: null, match: (i) => /ubiquiti|unifi|edgeswitch/i.test(i.text) },
  { id: 'dlink', kind: 'switch', vendor: 'D-Link', limit: null, match: (i) => /d-?link/i.test(i.text) },
  { id: 'zyxel', kind: 'switch', vendor: 'Zyxel', limit: null, match: (i) => /zyxel/i.test(i.text) },
];

function httpGet(ip, path = '/', timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get({ host: ip, port: 80, path, timeout }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; if (body.length > 60000) req.destroy(); });
      const fin = () => resolve({ status: res.statusCode, headers: res.headers, body });
      res.on('end', fin); res.on('close', fin);
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
  });
}

// Short product name from a page: the NETGEAR login page carries the full product line.
function productName(body) {
  const m = body.match(/(GS\d{3}\w*\s+S\d{3}[^<"\n]{0,80})/i) || body.match(/<title[^>]*>([^<]*)<\/title>/i);
  return m ? m[1].replace(/\s+/g, ' ').trim().slice(0, 90) : null;
}

async function identify(ip, extra = {}) {
  let web = await httpGet(ip, '/');
  // Follow one redirect (many devices send / to their login page).
  if (web && web.status >= 300 && web.status < 400 && web.headers.location) {
    const loc = String(web.headers.location).replace(/^https?:\/\/[^/]+/i, '');
    if (loc.startsWith('/')) web = (await httpGet(ip, loc)) || web;
  }
  let hilink = null;
  if (extra.isGateway) {
    const b = await httpGet(ip, '/api/device/basic_information');
    if (b && /<response>/i.test(b.body)) hilink = b.body;
  }
  const body = (web && web.body) || '';
  const info = {
    ip,
    text: [productName(body), web && web.headers.server, hilink, extra.sysDescr, extra.vendor, extra.hostname].filter(Boolean).join(' '),
    oid: extra.sysObjectID || null,
  };
  const model = MODELS.find((m) => m.match(info));
  let name = productName(body);
  if (hilink) name = (hilink.match(/<devicename>([^<]*)</i) || hilink.match(/<name>([^<]*)</i) || [])[1] || name;
  return {
    ip,
    kind: extra.isGateway ? 'router' : model ? model.kind : null,
    vendor: model ? model.vendor : null,
    model: (name || extra.sysDescr || '').trim().slice(0, 90) || null,
    adapter: model && model.limit ? model.id : null,
    limit: model ? model.limit : null,
  };
}

module.exports = { MODELS, identify, httpGet, productName };
