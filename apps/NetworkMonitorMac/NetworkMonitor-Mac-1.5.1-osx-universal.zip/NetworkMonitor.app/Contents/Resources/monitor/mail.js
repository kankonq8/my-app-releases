// Sends one email through the user's own mail account (SMTP), with no extra packages.
// Port 465 = TLS from the start, any other port = plain then STARTTLS. Login with AUTH LOGIN.
const net = require('net');
const tls = require('tls');
const os = require('os');

// Known providers, so the user only types the email address and an app password.
const PROVIDERS = [
  [/@(gmail|googlemail)\.com$/i, 'smtp.gmail.com', 465],
  [/@(outlook|hotmail|live|msn)\.[a-z.]+$/i, 'smtp-mail.outlook.com', 587],
  [/@(yahoo|ymail)\.[a-z.]+$/i, 'smtp.mail.yahoo.com', 465],
  [/@(icloud|me|mac)\.com$/i, 'smtp.mail.me.com', 587],
  [/@zoho\.[a-z.]+$/i, 'smtp.zoho.com', 465],
];
function guessServer(email) {
  for (const [re, host, port] of PROVIDERS) if (re.test(email || '')) return { host, port };
  return null;
}

const b64 = (s) => Buffer.from(String(s), 'utf8').toString('base64');
const encWord = (s) => /^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`;

/** cfg = { host, port, user, pass, from, to }, msg = { subject, text }. Resolves { ok, error }. */
function sendMail(cfg, msg, timeoutMs = 20000) {
  return new Promise((resolve) => {
    let sock, buf = '', step = 0, done = false, secure = Number(cfg.port) === 465;
    const finish = (ok, error) => { if (done) return; done = true; clearTimeout(timer); try { sock.end(); } catch (_) {} resolve({ ok, error: error || null }); };
    const timer = setTimeout(() => finish(false, 'timeout'), timeoutMs);
    const send = (line) => sock.write(line + '\r\n');
    const id = (os.hostname() || 'localhost').replace(/[^A-Za-z0-9.-]/g, '') || 'localhost';
    const body = [
      `From: ${encWord('Network Monitor')} <${cfg.from}>`,
      `To: <${cfg.to}>`,
      `Subject: ${encWord(msg.subject)}`,
      `Date: ${new Date().toUTCString()}`,
      `Message-ID: <${Date.now()}.${Math.random().toString(36).slice(2)}@networkmonitor.kankon.net>`,
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=utf-8',
      'Content-Transfer-Encoding: base64',
      '',
      b64(msg.text).replace(/.{76}/g, '$&\r\n'),
    ].join('\r\n');
    // Each step: what reply code we expect, then what to send next.
    const steps = [
      [220, () => send(`EHLO ${id}`)],
      [250, () => { if (!secure) { send('STARTTLS'); } else { step = 4; send('AUTH LOGIN'); } }],
      [220, () => { // STARTTLS accepted: upgrade the same socket
        const plain = sock; plain.removeAllListeners('data');
        sock = tls.connect({ socket: plain, servername: cfg.host }, () => { secure = true; send(`EHLO ${id}`); });
        wire(); }],
      [250, () => send('AUTH LOGIN')],
      [334, () => send(b64(cfg.user))],
      [334, () => send(b64(cfg.pass))],
      [235, () => send(`MAIL FROM:<${cfg.from}>`)],
      [250, () => send(`RCPT TO:<${cfg.to}>`)],
      [250, () => send('DATA')],
      [354, () => send(body.replace(/^\./gm, '..') + '\r\n.')],
      [250, () => { send('QUIT'); finish(true); }],
    ];
    function onLine(line) {
      if (/^\d{3}-/.test(line)) return; // more lines of the same reply
      const code = parseInt(line, 10);
      const [want, next] = steps[step] || [];
      if (code !== want) {
        const why = step === 5 || step === 6 || code === 535 || code === 534 ? 'login' : step === 2 ? 'starttls' : 'server';
        return finish(false, `${why}: ${line.slice(0, 200)}`);
      }
      step++;
      next();
    }
    function wire() {
      sock.on('data', (d) => { buf += d.toString('utf8'); let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); onLine(l); } });
      sock.on('error', (e) => finish(false, 'connect: ' + (e.code || e.message)));
      sock.on('close', () => finish(false, 'closed'));
    }
    sock = secure ? tls.connect({ host: cfg.host, port: Number(cfg.port), servername: cfg.host }) : net.connect({ host: cfg.host, port: Number(cfg.port) });
    wire();
  });
}

module.exports = { sendMail, guessServer };
