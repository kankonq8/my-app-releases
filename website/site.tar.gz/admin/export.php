<?php
require_once dirname(__DIR__) . '/auth-lib.php';
$db = auth_db(); $c = $_COOKIE['kadm'] ?? '';
$st = $db->prepare('SELECT 1 FROM admin_sessions WHERE token_hash=? AND expires>?'); $st->execute([auth_h($c), time()]);
if (!preg_match('/^[a-f0-9]{64}$/', $c) || !$st->fetchColumn()) { http_response_code(403); exit; }
header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="kankon-users.csv"');
echo "\xEF\xBB\xBF" . "email,joined,last_login,platform,launcher,status\n";
foreach ($db->query('SELECT * FROM users ORDER BY id') as $u) {
    $f = fn($s) => '"' . str_replace('"', '""', ltrim((string)$s, "=+-@")) . '"';
    echo implode(',', [$f($u['email']), gmdate('c', (int)$u['created_at']), $u['last_login'] ? gmdate('c', (int)$u['last_login']) : '', $f($u['platform']), $f($u['launcher_version']), $f($u['status'])]) . "\n";
}
