<?php
// Kankon admin dashboard: https://kankon.net/admin/  (admin only; sign-in by emailed code to admin_email in auth-config.php)
require_once dirname(__DIR__) . '/auth-lib.php';
require_once dirname(__DIR__) . '/mail-lib.php';

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'");
header('X-Robots-Tag: noindex, nofollow');

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function dt($t) { return $t ? gmdate('Y-m-d H:i', (int)$t + 3 * 3600) : '-'; } // Kuwait time (UTC+3)

$cfg = auth_cfg();
$adminEmail = strtolower($cfg['admin_email'] ?? '');
$db = auth_db();
$now = time();
$ip = auth_ip();
$msg = '';
$cookie = $_COOKIE['kadm'] ?? '';
$logged = false;
if (preg_match('/^[a-f0-9]{64}$/', $cookie)) {
    $st = $db->prepare('SELECT 1 FROM admin_sessions WHERE token_hash=? AND expires>?'); $st->execute([auth_h($cookie), $now]);
    $logged = (bool)$st->fetchColumn();
}
$csrf = $logged ? hash_hmac('sha256', $cookie, $cfg['pepper'] ?? '') : '';

function page($body) {
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kankon Admin</title><style>'
       . 'body{font-family:Segoe UI,Arial,sans-serif;background:#0f1f3d;color:#1a2233;margin:0;padding:24px}'
       . '.c{background:#fff;border-radius:12px;padding:20px;max-width:1100px;margin:auto}h1{margin:0 0 14px;font-size:20px}'
       . 'table{border-collapse:collapse;width:100%;font-size:14px}th,td{border-bottom:1px solid #e3e6ee;padding:8px;text-align:left}th{background:#f5f7fb}'
       . 'input,button{font-size:14px;padding:7px 10px;border-radius:6px;border:1px solid #b9c1d4}button{background:#2d5bd6;color:#fff;border:0;cursor:pointer}button.r{background:#c0392b}'
       . '.s{display:flex;gap:14px;margin:0 0 16px}.s div{background:#f5f7fb;border-radius:8px;padding:10px 16px}.s b{display:block;font-size:22px}.m{color:#2d5bd6;margin:8px 0}'
       . '</style></head><body><div class="c">' . $body . '</div></body></html>';
    exit;
}

if (!$logged) {
    $step = 'email';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $adminEmail !== '') {
        if (isset($_POST['send'])) {
            if (auth_rate('adm-send-' . $ip, 5, 3600)) {
                $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                $db->prepare('REPLACE INTO codes(email,code_hash,expires,attempts) VALUES(?,?,?,0)')->execute(['admin:' . $adminEmail, auth_h('admin|' . $code), $now + CODE_TTL]);
                send_mail($adminEmail, 'Kankon admin code: ' . $code, kankon_mail_wrap('Admin sign-in', '<p style="font-size:32px;letter-spacing:6px;font-weight:700;text-align:center">' . $code . '</p><p>Valid for 10 minutes.</p>'));
                $msg = 'A code was sent to the admin email.';
            } else $msg = 'Too many requests. Try later.';
            $step = 'code';
        } elseif (isset($_POST['code'])) {
            $step = 'code';
            $code = preg_replace('/\D/', '', $_POST['code']);
            if (auth_rate('adm-ver-' . $ip, 10, 3600)) {
                $st = $db->prepare('SELECT * FROM codes WHERE email=?'); $st->execute(['admin:' . $adminEmail]);
                $c = $st->fetch(PDO::FETCH_ASSOC);
                if ($c && $c['expires'] > $now && $c['attempts'] < 5) {
                    $db->prepare('UPDATE codes SET attempts=attempts+1 WHERE email=?')->execute(['admin:' . $adminEmail]);
                    if (hash_equals($c['code_hash'], auth_h('admin|' . $code))) {
                        $db->prepare('DELETE FROM codes WHERE email=?')->execute(['admin:' . $adminEmail]);
                        $tok = auth_rand(32);
                        $db->prepare('INSERT INTO admin_sessions(token_hash,expires) VALUES(?,?)')->execute([auth_h($tok), $now + 12 * 3600]);
                        setcookie('kadm', $tok, ['expires' => $now + 12 * 3600, 'path' => '/admin', 'secure' => true, 'httponly' => true, 'samesite' => 'Strict']);
                        header('Location: /admin/'); exit;
                    }
                }
                $msg = 'Wrong or expired code.';
            } else $msg = 'Too many attempts.';
        }
    }
    $f = '<h1>Kankon Admin</h1>';
    if ($adminEmail === '') $f .= '<p>Admin email is not configured.</p>';
    elseif ($step === 'code') $f .= '<form method="post"><p>Enter the 6-digit code:</p><input name="code" maxlength="6" autofocus> <button>Sign in</button></form>';
    else $f .= '<form method="post"><p>Send a sign-in code to the admin email.</p><button name="send" value="1">Send code</button></form>';
    page($f . '<p class="m">' . e($msg) . '</p>');
}

// ---- logged in ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf'] ?? '')) { http_response_code(403); page('Bad request.'); }
    $id = (int)($_POST['id'] ?? 0);
    if (isset($_POST['logout'])) { $db->prepare('DELETE FROM admin_sessions WHERE token_hash=?')->execute([auth_h($cookie)]); setcookie('kadm', '', ['expires' => 1, 'path' => '/admin']); header('Location: /admin/'); exit; }
    if ($id && isset($_POST['suspend'])) { $db->prepare("UPDATE users SET status='suspended' WHERE id=?")->execute([$id]); $db->prepare('DELETE FROM sessions WHERE user_id=?')->execute([$id]); $msg = 'Account suspended.'; }
    if ($id && isset($_POST['activate'])) { $db->prepare("UPDATE users SET status='active' WHERE id=?")->execute([$id]); $msg = 'Account reactivated.'; }
    if ($id && isset($_POST['delete'])) { foreach (['sessions','usage'] as $t) $db->prepare("DELETE FROM $t WHERE user_id=?")->execute([$id]); $db->prepare('UPDATE devices SET user_id=NULL WHERE user_id=?')->execute([$id]); $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]); $msg = 'Account and data deleted.'; }
}

$users = $db->query("SELECT u.*, (SELECT group_concat(app || ' (' || n || ')', ', ') FROM usage WHERE user_id=u.id) apps FROM users u ORDER BY COALESCE(last_login,0) DESC LIMIT 1000")->fetchAll(PDO::FETCH_ASSOC);
$total = (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
$d7 = (int)$db->query('SELECT COUNT(*) FROM users WHERE last_login>' . ($now - 7 * 86400))->fetchColumn();
$trials = (int)$db->query('SELECT COUNT(*) FROM devices WHERE user_id IS NULL')->fetchColumn();
$q = strtolower(trim($_GET['q'] ?? ''));
$h = '<h1>Kankon Admin</h1><div class="s"><div><b>' . $total . '</b>Registered</div><div><b>' . $d7 . '</b>Active (7 days)</div><div><b>' . $trials . '</b>Trial devices</div></div>';
$h .= '<p class="m">' . e($msg) . '</p><form method="get"><input name="q" placeholder="Search email" value="' . e($q) . '"> <button>Search</button></form> <form method="post" style="display:inline"><input type="hidden" name="csrf" value="' . e($csrf) . '"><button name="logout" value="1">Log out</button></form>';
$h .= '<p><a href="/admin/export.php">Download CSV</a></p><table><tr><th>Email</th><th>Joined</th><th>Last login</th><th>Platform</th><th>Launcher</th><th>Apps used</th><th>Status</th><th></th></tr>';
foreach ($users as $u) {
    if ($q !== '' && strpos($u['email'], $q) === false) continue;
    $a = $u['status'] === 'active' ? '<button name="suspend" value="1" class="r">Suspend</button>' : '<button name="activate" value="1">Reactivate</button>';
    $h .= '<tr><td>' . e($u['email']) . '</td><td>' . dt($u['created_at']) . '</td><td>' . dt($u['last_login']) . '</td><td>' . e($u['platform']) . '</td><td>' . e($u['launcher_version']) . '</td><td>' . e($u['apps']) . '</td><td>' . e($u['status']) . '</td>'
        . '<td><form method="post"><input type="hidden" name="csrf" value="' . e($csrf) . '"><input type="hidden" name="id" value="' . (int)$u['id'] . '">' . $a . '</form></td></tr>';
}
page($h . '</table><p class="m">Times are Kuwait time. Deleting an account is done per request (privacy policy); contact support to delete.</p>');
