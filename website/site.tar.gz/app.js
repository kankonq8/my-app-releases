/* kankon.net: renders all pages from data.js. Site version below: raise it (and VERSION) on every site update. */
const SITE_VERSION = "1.13.0";
const K = window.KANKON;

const UI = {
  en: {
    langBtn: "العربية", navLauncher: "Launcher", navUpdates: "Updates", navAI: "AI", siteVer: "Site version",
    picksTitle: "Best games to play", picksSub: "Top games chosen by Kankon in three styles. Links go to the official game websites.", freeTag: "Free", paid: "Paid", aiOpen2: "Official website", picksNote: "These games are made by their own companies. Kankon only links to their official pages.", kankonGames: "In Kankon Launcher",
    aiTitle: "AI programs", aiSub: "The most important AI programs and assistants, chosen by Kankon. Links go to the official websites.", aiOpen: "Open website", aiDl: "Download", aiNote: "These programs are made by their own companies. Kankon only links to their official pages.", aiHome: "The most important AI programs, in one place.",
    by: "by Kankon · kankon.net",
    eyebrow: "Windows and Mac apps by Kankon", title: "One launcher for all Kankon apps",
    download: "Download Kankon Launcher", dlFor: "Download for", winSub: "Windows 10/11 · zip", macSub: "Apple Silicon / Intel · zip", runsOn: "Runs on", browse: "Browse the apps", free: "Free · Windows 10 and 11 · macOS (Apple Silicon / Intel)",
    version: "Version", latest: "Latest version",
    features: "Main features", how: "How to use", req: "Requirements", screens: "Screenshots",
    sectionsTitle: "Everything in one place", sectionsSub: "The launcher groups the apps into four sections, just like its side menu.",
    installTitle: "How to start", installSub: "It takes about a minute.",
    appsCount: n => n === 1 ? "1 app" : n + " apps",
    allApps: "All apps", allAppsSub: "Every Kankon app and game. Each one installs, opens and updates from inside Kankon Launcher.",
    catSub: { apps: "General apps for everyday use.", games: "Games installed and kept up to date by Kankon Launcher.", tools: "Tools that keep your PC in good shape.", networking: "Apps for your network and internet connection." },
    appsEmpty: "General apps are coming soon. Meanwhile, here are all the apps available today.",
    details: "Full details", getIt: "Get it from Kankon Launcher", site: "Official website",
    getItNote: "Install Kankon Launcher, then open this section and click Install.",
    recent: "What's new", allUpdates: "All updates",
    updTitle: "Updates", updSub: "Every new version of the launcher and the apps, with what changed. Newest first.",
    all: "All", latestBadge: "Latest", home: "Home",
    heroTitle: ["One launcher for ", "all Kankon apps"],
    guides: "Step-by-step guides", guidesSub: "Short, clear guides for the things you will do most.", stepsN: n => n + " steps",
    overview: "Overview", whyTitle: "Why Kankon Launcher", whySub: "Everything you need to keep your apps installed, safe and up to date.",
    sStat: [[String(window.KANKON.apps.length), "apps and games"], ["2", "languages: English and Arabic"], ["SHA-256", "every download verified"], ["Auto", "updates for apps and launcher"]],
    bandTitle: "Ready to start?", bandSub: "Download Kankon Launcher and install any app in one click.",
    mockUpdate: "Update", mockOpen: "Open", mockInstall: "Install", close: "Close"
  },
  ar: {
    langBtn: "English", navLauncher: "المشغّل", navUpdates: "التحديثات", navAI: "الذكاء الاصطناعي", siteVer: "إصدار الموقع",
    picksTitle: "أفضل الألعاب", picksSub: "أبرز الألعاب في ثلاثة أنواع، اختارتها Kankon، وتنقلك الروابط إلى مواقعها الرسمية.", freeTag: "مجانية", paid: "مدفوعة", aiOpen2: "الموقع الرسمي", picksNote: "هذه الألعاب ملك لشركاتها، ويقتصر دور Kankon على توفير روابط صفحاتها الرسمية.", kankonGames: "في Kankon Launcher",
    aiTitle: "برامج الذكاء الاصطناعي", aiSub: "أبرز برامج الذكاء الاصطناعي والمساعدات الذكية، اختارتها Kankon، وتنقلك روابطها إلى المواقع الرسمية.", aiOpen: "فتح الموقع", aiDl: "تنزيل", aiNote: "هذه البرامج ملك لشركاتها، ويقتصر دور Kankon على توفير روابط صفحاتها الرسمية.", aiHome: "أهم برامج الذكاء الاصطناعي في مكان واحد.",
    by: "من Kankon · kankon.net",
    eyebrow: "برامج Kankon لنظام Windows ولأجهزة Mac", title: "مشغّل واحد لجميع برامج Kankon",
    download: "تنزيل Kankon Launcher", dlFor: "تنزيل لنظام", dlForMac: "تنزيل لأجهزة", winSub: "Windows 10/11 · zip", macSub: "Apple Silicon / Intel · zip", runsOn: "يعمل على", browse: "تصفّح البرامج", free: "مجاني · Windows 10 وWindows 11 · macOS (Apple Silicon / Intel)",
    version: "الإصدار", latest: "أحدث إصدار",
    features: "أبرز المزايا", how: "طريقة الاستخدام", req: "المتطلبات", screens: "لقطات الشاشة",
    sectionsTitle: "كل شيء في مكان واحد", sectionsSub: "يصنّف المشغّل البرامج في أربعة أقسام، كما في قائمته الجانبية.",
    installTitle: "كيف تبدأ", installSub: "لا يستغرق الأمر أكثر من دقيقة.",
    appsCount: n => n === 0 ? "لا توجد برامج بعد" : n === 1 ? "برنامج واحد" : n === 2 ? "برنامجان" : n <= 10 ? n + " برامج" : n + " برنامجًا",
    allApps: "جميع البرامج", allAppsSub: "جميع برامج Kankon وألعابها، ويُثبَّت كل منها ويُفتح ويُحدَّث من داخل Kankon Launcher.",
    catSub: { apps: "برامج عامة للاستخدام اليومي.", games: "ألعاب يثبّتها Kankon Launcher ويُبقيها محدَّثة.", tools: "أدوات تحافظ على جهازك في أفضل حال.", networking: "برامج لإدارة الشبكة والاتصال بالإنترنت." },
    appsEmpty: "ستتوفّر البرامج العامة قريبًا، وإلى حين ذلك إليك جميع البرامج المتاحة حاليًا.",
    details: "التفاصيل الكاملة", getIt: "احصل عليه عبر Kankon Launcher", site: "الموقع الرسمي",
    getItNote: "ثبّت Kankon Launcher، ثم افتح هذا القسم وانقر Install.",
    recent: "ما الجديد", allUpdates: "جميع التحديثات",
    updTitle: "التحديثات", updSub: "كل إصدار جديد من المشغّل والبرامج، مع ما تغيّر فيه، مرتّبة من الأحدث إلى الأقدم.",
    all: "الكل", latestBadge: "الأحدث", home: "الرئيسية",
    heroTitle: ["مشغّل واحد ", "لجميع برامج Kankon"],
    guides: "شروحات خطوة بخطوة", guidesSub: "شروحات موجزة وواضحة لأكثر ما ستحتاج إليه.", stepsN: n => n === 2 ? "خطوتان" : n <= 10 ? n + " خطوات" : n + " خطوة",
    overview: "نظرة عامة", whyTitle: "لماذا Kankon Launcher؟", whySub: "كل ما تحتاج إليه لتبقى برامجك مثبّتة وآمنة ومحدَّثة.",
    sStat: [[String(window.KANKON.apps.length), "برامج وألعاب"], ["2", "لغتان: العربية والإنجليزية"], ["SHA-256", "التحقّق من سلامة كل ملف"], ["تلقائي", "تحديث البرامج والمشغّل"]],
    bandTitle: "هل أنت مستعدّ للبدء؟", bandSub: "نزّل Kankon Launcher وثبّت أي برنامج بنقرة واحدة.",
    mockUpdate: "Update", mockOpen: "Open", mockInstall: "Install", close: "إغلاق"
  }
};
let lang = "en"; /* English by default on every visit */
const versions = {};
let macUrl = K.launcher.macDownload, macVer = "";
let updFilter = "all", lbList = [], lbIdx = 0;

const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const t = () => UI[lang];
const catName = id => K.categories.find(c => c.id === id)[lang];
const appsIn = id => K.apps.filter(a => a.cat === id);
const prod = id => id === "launcher" ? { id: "launcher", name: K.launcher.name, icon: K.launcher.icon } : id === "website" ? { id: "website", name: "kankon.net", icon: "favicon-32.png" } : K.apps.find(a => a.id === id);
const verOf = id => versions[id] ? `<span class="ver">${t().version} <span class="ltr">${esc(versions[id])}</span></span>` : "";
const arrow = () => lang === "ar" ? "←" : "→";
const ul = (items, cls) => `<ul class="${cls || ""}">${items.map(i => `<li>${esc(i)}</li>`).join("")}</ul>`;
const shotSrc = s => s.src || s[lang] || s.en;
const svg = p => `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const OSI = {
  win: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M3 5.1l7.4-1v7.2H3zM11.3 3.9L21 2.5v8.8h-9.7zM3 12.6h7.4v7.3L3 18.9zM11.3 12.6H21v8.9l-9.7-1.4z"/></svg>',
  mac: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9-1.2-1.8-3.1-2-3.7-2-1.6-.2-3.1.9-3.9.9-.8 0-2-.9-3.4-.9-1.7 0-3.3 1-4.2 2.6-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6 1.3-.1 1.8-.8 3.3-.8s2 .8 3.4.8c1.4 0 2.3-1.3 3.1-2.5 1-1.4 1.4-2.8 1.4-2.9 0 0-2.7-1-2.7-4.1zM13.9 5c.7-.9 1.2-2 1.1-3.2-1 0-2.3.7-3 1.6-.7.8-1.3 2-1.1 3.1 1.1.1 2.3-.6 3-1.5z"/></svg>'
};
const isMac = /Mac/i.test(navigator.platform || navigator.userAgent) && !/iPhone|iPad/i.test(navigator.userAgent);
function dlBtns(oses) {
  const T = t();
  const b = (os, href, name, sub, pri, extra) => `<a class="btn os ${pri ? "primary" : "ghost"}" ${extra || ""}href="${href}">${OSI[os]}<span class="ol"><small>${os === "mac" && T.dlForMac ? T.dlForMac : T.dlFor}</small><b>${name}</b><i><bdi dir="ltr">${sub}</bdi></i></span></a>`;
  const w = b("win", K.launcher.download, "Windows", T.winSub, !isMac, 'data-os="win" '), m = b("mac", macUrl, "Mac", T.macSub, isMac, 'data-mac data-os="mac" ');
  if (oses && !oses.includes("mac")) return b("win", K.launcher.download, "Windows", T.winSub, true, 'data-os="win" ');
  return isMac ? m + w : w + m;
}
const osTags = a => (a.os || ["win"]).map(o => `<span class="tag ostag">${OSI[o]}${o === "mac" ? "Mac" : "Windows"}</span>`).join("");
const IC = {
  dl: '<path d="M12 3v12m0 0l-5-5m5 5l5-5M4 21h16"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  click: '<path d="M9 9l11 4-5 2-2 5z"/><path d="M4 4l2 2M4 10h2M10 4v2"/>',
  refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  self: '<path d="M12 2v6m0 8v6M4.9 4.9l4.2 4.2m5.8 5.8l4.2 4.2M2 12h6m8 0h6"/>',
  doc: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/>',
  lang: '<path d="M4 5h8M8 3v2m-3 0c1 4 4 7 7 8M11 5c-1 4-4 7-7 8M13 21l4-10 4 10m-7-3h6"/>',
  chev: '<path d="M6 9l6 6 6-6"/>'
};

function nav() {
  const r = location.hash || "#/";
  const links = [["#/", t().navLauncher], ...K.categories.map(c => ["#/" + c.id, c[lang]]), ["#/ai", t().navAI], ["#/updates", t().navUpdates]];
  $("#nav").innerHTML = links.map(([h, l]) => {
    const on = h === "#/" ? (r === "#/" || r === "#") : r.startsWith(h) || (h !== "#/updates" && h !== "#/ai" && r.startsWith("#/app/") && prod(r.split("/")[2])?.cat === h.slice(2));
    return `<a href="${h}" class="${on ? "on" : ""}">${esc(l)}</a>`;
  }).join("");
}

function card(a) {
  const th = (a.shots || []).slice(0, 3).map(s => `<img src="${shotSrc(s)}" alt="" loading="lazy">`).join("");
  return `<a class="card rv" href="#/app/${a.id}"><div class="top"><img src="${a.icon}" alt=""><div><h3>${esc(a.name)}</h3>
    <div class="tags"><span class="tag">${esc(catName(a.cat))}</span>${osTags(a)}${verOf(a.id)}</div></div></div>
    <p>${esc(a.summary[lang])}</p>${th ? `<div class="thumbs">${th}</div>` : ""}<span class="go">${t().details} ${arrow()}</span></a>`;
}

function updItem(u, i) {
  const p = prod(u.product);
  return `<article class="upd rv${i === 0 ? " new" : ""}"><div class="h"><img src="${p.icon}" alt=""><b>${esc(p.name)}</b>
    <span class="ver">${t().version} <span class="ltr">${esc(u.version)}</span></span>
    ${i === 0 ? `<span class="tag">${t().latestBadge}</span>` : ""}<span class="d ltr">${esc(u.date)}</span></div>${ul(u[lang])}</article>`;
}

function guidesHtml(gs) {
  if (!gs || !gs.length) return "";
  return `<div class="guides">${gs.map((g, i) => `<details class="guide rv"${i === 0 ? " open" : ""}><summary><span class="n">${i + 1}</span>${esc(g.t[lang])}
    <span class="c">${t().stepsN(g[lang].length)}</span><span class="chev">${svg(IC.chev)}</span></summary>
    <ol>${g[lang].map(s => `<li>${esc(s)}</li>`).join("")}</ol></details>`).join("")}</div>`;
}

function galleryHtml(shots) {
  if (!shots || !shots.length) return "";
  return `<div class="gal">${shots.map((s, i) => `<figure class="rv" data-i="${i}"><img src="${shotSrc(s)}" alt="${esc(s.cap[lang])}" loading="lazy"><figcaption>${esc(s.cap[lang])}</figcaption></figure>`).join("")}</div>`;
}

function mock() {
  const T = t(), rows = [["AutoIpConfig", T.mockUpdate, "up"], ["NetworkMonitor", T.mockOpen, ""], ["DriverManager", T.mockOpen, ""], ["Dana", T.mockInstall, ""]];
  return `<div class="mock"><div class="tb"><img src="${K.launcher.icon}" alt="">Kankon Launcher<span class="dots"><i></i><i></i><i></i></span></div>
    <div class="body"><div class="side">${K.categories.map((c, i) => `<b class="${i === 0 ? "on" : ""}">${esc(c.en)}</b>`).join("")}</div>
    <div class="list">${rows.map(([id, b, cls]) => { const a = prod(id); return `<div class="row"><img src="${a.icon}" alt=""><div><strong>${esc(a.name)}</strong>
      <small>${esc(K.categories.find(c => c.id === a.cat).en)}${versions[id] ? " · v" + esc(versions[id]) : ""}</small></div><em class="${cls}">${b}</em></div>`; }).join("")}</div></div></div>`;
}

function pageHome() {
  const L = K.launcher, T = t();
  const fIcons = [IC.grid, IC.click, IC.refresh, IC.shield, IC.self, IC.doc, IC.lang];
  return `<div class="wrap hero"><div class="rv">
      <span class="eyebrow">${T.eyebrow}</span>
      <h1>${T.heroTitle[0]}<span class="grad">${T.heroTitle[1]}</span></h1>
      <p class="lead">${esc(L.summary[lang])}</p>
      <div class="cta">${dlBtns()}
      <a class="btn ghost" href="#/apps">${T.browse}</a></div>
      <div class="meta"><span>${T.free}</span>${versions.launcher ? `<span>${T.latest} <span class="ltr">${esc(versions.launcher)}</span></span>` : ""}</div>
    </div><div class="rv" style="position:relative">${mock()}<div class="glow"></div></div></div>
  <div class="wrap"><div class="stats">${T.sStat.map(([b, s]) => `<div class="stat rv"><b class="grad">${b}</b><span>${s}</span></div>`).join("")}</div></div>
  <section><div class="wrap"><div class="kicker">Kankon Launcher</div><h2>${T.sectionsTitle}</h2><p class="sub">${T.sectionsSub}</p><div class="cats">
    ${K.categories.map(c => { const as = appsIn(c.id); return `<a class="cat rv" href="#/${c.id}"><span class="arr">${arrow()}</span><div class="icons">${as.map(a => `<img src="${a.icon}" alt="">`).join("")}</div>
      <b>${esc(c[lang])}</b><span>${T.appsCount(as.length)}</span></a>`; }).join("")}
    <a class="cat rv aicat" href="#/ai"><span class="arr">${arrow()}</span><div class="icons">${K.ai.slice(0, 4).map(x => `<span class="mono s" style="--c:${x.color}">${esc(x.name[0])}</span>`).join("")}</div>
      <b>${T.navAI}</b><span>${T.aiHome}</span></a>
  </div></div></section>
  <section><div class="wrap"><div class="kicker">${T.features}</div><h2>${T.whyTitle}</h2><p class="sub">${T.whySub}</p>
    <div class="bento">${L.features[lang].map((f, i) => `<div class="feat rv${i === 0 ? " wide" : ""}"><div class="ic">${svg(fIcons[i % fIcons.length])}</div><p>${esc(f)}</p></div>`).join("")}</div>
  </div></section>
  ${L.shots && L.shots.length ? `<section id="shots"><div class="wrap"><h2>${T.screens}</h2><p class="sub"></p>${galleryHtml(L.shots)}</div></section>` : ""}
  <section><div class="wrap"><div class="kicker">${T.how}</div><h2>${T.guides}</h2><p class="sub">${T.guidesSub}</p>
    <div class="two">${guidesHtml(L.guides)}<div class="panel rv"><h3>${T.req}</h3>${ul(L.req[lang], "check")}</div></div></div></section>
  <section><div class="wrap"><div class="kicker">${T.navUpdates}</div><h2>${T.recent}</h2><p class="sub">${T.updSub}</p>
    <div class="tl">${K.updates.slice(0, 3).map(updItem).join("")}</div>
    <p style="margin-top:22px"><a class="btn ghost" href="#/updates">${T.allUpdates} ${arrow()}</a></p>
    ${band()}</div></section>`;
}

function band() {
  const T = t();
  return `<div class="band rv"><div><h2>${T.bandTitle}</h2><p>${T.bandSub}</p></div>
    <span class="cta">${dlBtns()}</span></div>`;
}

function pageCat(id) {
  const T = t(); let as = appsIn(id), note = "";
  if (id === "apps" && !as.length) { note = `<div class="note rv">${T.appsEmpty}</div>`; as = K.apps; }
  const picks = id === "games" && K.games ? `<section><div class="wrap"><h2>${T.picksTitle}</h2><p class="sub">${T.picksSub}</p>
    ${K.gameGroups.map(g => `<div class="kicker" style="margin-top:28px">${esc(g[lang])}</div><div class="grid">${K.games.filter(x => x.group === g.id).map(gameCard).join("")}</div>`).join("")}
    <p class="note rv" style="margin-top:22px">${T.picksNote}</p></div></section>` : "";
  return `<section><div class="wrap"><span class="eyebrow">Kankon Launcher</span><h1>${esc(catName(id))}</h1>
    <p class="sub">${T.catSub[id]}</p>${note}${id === "games" ? `<div class="kicker">${T.kankonGames}</div>` : ""}<div class="grid">${as.map(card).join("")}</div></div></section>${picks}
    <div class="wrap">${band()}</div>`;
}

function pageApp(id) {
  const a = K.apps.find(x => x.id === id); if (!a) return pageHome();
  const T = t(), ups = K.updates.filter(u => u.product === id), has = a.shots && a.shots.length;
  const links = [["ov", T.overview], ...(a.guides ? [["guides", T.guides]] : []), ...(has ? [["shots", T.screens]] : []), ...(ups.length ? [["upd", T.recent]] : [])];
  return `<div class="wrap"><div class="crumbs"><a href="#/">${T.home}</a> / <a href="#/${a.cat}">${esc(catName(a.cat))}</a> / ${esc(a.name)}</div>
    <div class="apphero rv"><div class="appicon"><img src="${a.icon}" alt=""></div><div><h1>${esc(a.name)}</h1>
      <div class="tags"><span class="tag">${esc(catName(a.cat))}</span>${osTags(a)}${verOf(a.id)}</div><p class="lead">${esc(a.summary[lang])}</p></div></div>
    <div class="cta">${dlBtns(a.os || ["win"])}
      ${a.site ? `<a class="btn ghost" href="${a.site}" target="_blank" rel="noopener">${T.site}</a>` : ""}</div>
    <div class="meta"><span>${T.getItNote.replace(/this section|هذا القسم/, m => m + " (" + catName(a.cat) + ")")}</span></div>
    <div class="subnav">${links.map(([h, l]) => `<a href="javascript:void(0)" data-go="${h}">${l}</a>`).join("")}</div></div>
  <section id="ov"><div class="wrap"><div class="two">
    <div class="panel rv"><h3>${T.features}</h3>${ul(a.features[lang], "check")}</div>
    <div class="stack"><div class="panel rv"><h3>${T.how}</h3>${ul(a.how[lang], "check")}</div>
    <div class="panel rv"><h3>${T.req}</h3>${ul(a.req[lang], "check")}</div></div></div></div></section>
  ${a.guides ? `<section id="guides"><div class="wrap"><div class="kicker">${esc(a.name)}</div><h2>${T.guides}</h2><p class="sub">${T.guidesSub}</p>${guidesHtml(a.guides)}</div></section>` : ""}
  ${has ? `<section id="shots"><div class="wrap"><h2>${T.screens}</h2><p class="sub"></p>${galleryHtml(a.shots)}</div></section>` : ""}
  ${ups.length ? `<section id="upd"><div class="wrap"><h2>${T.recent}</h2><p class="sub"></p><div class="tl">${ups.map(updItem).join("")}</div>
    <p style="margin-top:22px"><a class="btn ghost" href="#/updates">${T.allUpdates} ${arrow()}</a></p></div></section>` : ""}`;
}

function aiCard(x) {
  const T = t(), mono = x.name.split(" ").map(w => w[0]).join("").slice(0, 2);
  return `<article class="card ai rv"><div class="top"><span class="mono" style="--c:${x.color}">${esc(mono)}</span><div><h3>${esc(x.name)}</h3>
    <div class="tags"><span class="tag">${esc(x.by)}</span></div></div></div><p>${esc(x[lang])}</p>
    <div class="aibtns">${x.dl ? `<a class="btn primary sm" href="${x.dl}" target="_blank" rel="noopener">${svg(IC.dl)}<span>${T.aiDl}</span></a>` : ""}
    <a class="btn ghost sm" href="${x.url}" target="_blank" rel="noopener">${T.aiOpen} ↗</a></div></article>`;
}

function gameCard(x) {
  const T = t(), mono = x.mono || x.name[0];
  return `<article class="card ai rv"><div class="top"><span class="mono" style="--c:${x.color}">${esc(mono)}</span><div><h3>${esc(x.name)}</h3>
    <div class="tags"><span class="tag">${esc(x.by)}</span><span class="ver">${x.free ? T.freeTag : T.paid}</span></div></div></div><p>${esc(x[lang])}</p>
    <div class="aibtns"><a class="btn ghost sm" href="${x.url}" target="_blank" rel="noopener">${T.aiOpen2} ↗</a></div></article>`;
}

function pageAI() {
  const T = t();
  return `<section><div class="wrap"><span class="eyebrow">${T.navAI}</span><h1>${T.aiTitle}</h1><p class="sub">${T.aiSub}</p>
    <div class="grid">${K.ai.map(aiCard).join("")}</div><p class="note rv" style="margin-top:22px">${T.aiNote}</p></div></section>`;
}

function pageUpdates() {
  const T = t();
  const ids = ["website", "launcher", ...K.apps.map(a => a.id)].filter(id => K.updates.some(u => u.product === id));
  const ups = K.updates.filter(u => updFilter === "all" || u.product === updFilter);
  return `<section><div class="wrap"><span class="eyebrow">${T.navUpdates}</span><h1>${T.updTitle}</h1><p class="sub">${T.updSub}</p>
    <div class="filters"><button class="chip all${updFilter === "all" ? " on" : ""}" data-f="all">${T.all}</button>
    ${ids.map(id => { const p = prod(id); return `<button class="chip${id === updFilter ? " on" : ""}" data-f="${id}"><img src="${p.icon}" alt="">${esc(p.name)}</button>`; }).join("")}</div>
    <div class="tl">${ups.map(updItem).join("")}</div></div></section>`;
}

function currentShots() {
  const r = (location.hash || "#/").replace(/^#\/?/, "").split("/");
  return r[0] === "app" ? (K.apps.find(a => a.id === r[1]) || {}).shots || [] : K.launcher.shots || [];
}
function showLb(i) {
  lbList = currentShots(); if (!lbList.length) return; lbIdx = (i + lbList.length) % lbList.length;
  const s = lbList[lbIdx], lb = $("#lb"); lb.querySelector("img").src = shotSrc(s); lb.querySelector("p").textContent = s.cap[lang]; lb.hidden = false;
}

let io;
function reveal() {
  io && io.disconnect();
  io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .08 });
  document.querySelectorAll(".rv").forEach((el, i) => { el.style.transitionDelay = Math.min(i % 6, 5) * 60 + "ms"; io.observe(el); });
}

function render(scroll) {
  const T = t(), r = (location.hash || "#/").replace(/^#\/?/, "").split("/");
  document.documentElement.lang = lang; document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  $("#lang").textContent = T.langBtn; $("#by").textContent = T.by;
  $("#sv").textContent = `${T.siteVer} ${SITE_VERSION}`; $("#yr").textContent = new Date().getFullYear();
  nav(); $("#nav").classList.remove("open");
  let html;
  if (!r[0]) html = pageHome();
  else if (r[0] === "app") html = pageApp(r[1]);
  else if (r[0] === "updates") html = pageUpdates();
  else if (r[0] === "ai") html = pageAI();
  else if (K.categories.some(c => c.id === r[0])) html = pageCat(r[0]);
  else html = pageHome();
  $("#view").innerHTML = html;
  document.querySelectorAll(".chip").forEach(b => b.onclick = () => { updFilter = b.dataset.f; render(false); });
  document.querySelectorAll(".gal figure").forEach(f => f.onclick = () => showLb(+f.dataset.i));
  document.querySelectorAll("[data-go]").forEach(a => a.onclick = () => document.getElementById(a.dataset.go).scrollIntoView({ behavior: "smooth" }));
  document.title = (r[0] === "app" && prod(r[1]) ? prod(r[1]).name + " · " : r[0] === "updates" ? T.updTitle + " · " : "") + "Kankon Launcher";
  reveal();
  if (scroll) window.scrollTo(0, 0);
}

$("#lb").onclick = e => { if (e.target.closest(".prev")) showLb(lbIdx - 1); else if (e.target.closest(".next")) showLb(lbIdx + 1); else if (e.target.tagName !== "IMG") $("#lb").hidden = true; };
document.addEventListener("keydown", e => {
  if ($("#lb").hidden) return;
  if (e.key === "Escape") $("#lb").hidden = true;
  if (e.key === "ArrowRight") showLb(lbIdx + (lang === "ar" ? -1 : 1));
  if (e.key === "ArrowLeft") showLb(lbIdx + (lang === "ar" ? 1 : -1));
});
$("#lang").onclick = () => { lang = lang === "en" ? "ar" : "en"; render(false); };
$("#menuBtn").onclick = () => $("#nav").classList.toggle("open");
window.addEventListener("hashchange", () => render(true));
render(false);

/* Download counter (dl.php on the Synology; stores counts only). Never delays or blocks the download. */
document.addEventListener("click", e => {
  const a = e.target.closest && e.target.closest("a[data-os]"); if (!a) return;
  const os = a.dataset.os, v = os === "mac" ? macVer : (versions.launcher || "");
  try { navigator.sendBeacon("dl.php?p=launcher&os=" + os + "&v=" + encodeURIComponent(v)); } catch (_) {}
});

/* Mac download: app/mac/version.json always names the latest build. */
fetch(K.launcher.macVersionUrl, { cache: "no-store" }).then(r => r.json()).then(j => {
  if (j.version) macVer = j.version;
  if (j.url) { macUrl = "https://github.com/kankonq8/my-app-releases/raw/main/" + j.url; document.querySelectorAll('a[data-mac]').forEach(a => a.href = macUrl); }
}).catch(() => {});

/* Live version numbers from the public releases repo (the site still works if this fails). */
let pending;
[["launcher", K.launcher.versionUrl], ...K.apps.filter(a => a.versionUrl).map(a => [a.id, a.versionUrl])].forEach(([id, url]) =>
  fetch(url, { cache: "no-store" }).then(r => r.json()).then(j => {
    if (j.version) { versions[id] = j.version; clearTimeout(pending); pending = setTimeout(() => { const y = scrollY; render(false); document.querySelectorAll(".rv").forEach(e => e.classList.add("in")); scrollTo(0, y); }, 150); }
  }).catch(() => {}));
