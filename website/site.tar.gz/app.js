/* kankon.net: renders all pages from data.js. Site version below: raise it (and VERSION) on every site update. */
const SITE_VERSION = "1.89.0";
const K = window.KANKON;

const UI = {
  en: {
    langBtn: "العربية", navLauncher: "Launcher", navUpdates: "Updates", navAI: "AI", siteVer: "Site version", helpBtn: "Full help guide", helpTitle: "Help", helpSearch: "Search the guide…", helpContents: "Contents", helpFaq: "Questions and answers", helpTrouble: "Troubleshooting", helpLoading: "Loading the guide…", helpNone: "The detailed guide for this app is coming soon.", helpNoMatch: "Nothing matches your search.", helpFor: "Guide for version", helpBack: "Back to the app page", helpProblem: "Problem", helpFix: "Solution", visitors: "Site visitors", onlineNow: "Online now", privacy: "Privacy", rssBtn: "Follow by RSS", rssHint: "Add this link to any news reader app to get every new update automatically.",
    pvTitle: "Privacy", pvSub: "What the Kankon apps and kankon.net send, store and never collect.",
    pvItems: ["No accounts, no cookies, no ads and no tracking or analytics services.",
      "Visitor counter: your browser keeps a random ID (not linked to you) so a visit is counted once per session. The site stores only the total number of visits and which random IDs were active in the last three minutes, for the Online now number. No IP addresses are stored.",
      "Downloads: when you press a download button, the site counts the download by app, system (Windows or Mac) and version only. No IP address or personal data is stored.",
      "Downloads and version numbers come from GitHub, which handles those requests under its own privacy policy.",
      "Links to other websites (app stores, games and AI services) open those sites, which have their own privacy policies.",
      "Each Kankon app explains in its own help page what it saves and what it sends."],
    picksTitle: "Best games to play", picksSub: "Top games chosen by Kankon in three styles. Links go to the official game websites.", freeTag: "Free", paid: "Paid", aiOpen2: "Official website", picksNote: "These games are made by their own companies. Kankon only links to their official pages.", kankonGames: "In Kankon Launcher",
    aiTitle: "AI programs", aiSub: "The most important AI programs and assistants, chosen by Kankon. Links go to the official websites.", aiOpen: "Open website", aiDl: "Download", aiNote: "These programs are made by their own companies. Kankon only links to their official pages.", aiHome: "The most important AI programs, in one place.",
    by: "by Kankon · kankon.net",
    eyebrow: "Windows and Mac apps by Kankon", title: "One launcher for all Kankon apps",
    download: "Download Kankon Launcher", dlFor: "Download for", winSub: "Windows 10/11 · zip", macSub: "Apple Silicon / Intel · zip", macFirst: "<b>First open on a Mac:</b> if macOS says it could not verify Kankon Launcher, click Done, then open System Settings › Privacy &amp; Security, scroll down and click <b>Open Anyway</b> next to Kankon Launcher (one time only). Full steps in the guides below.", runsOn: "Runs on", browse: "Browse the apps", free: "Free · Windows 10 and 11 · macOS (Apple Silicon / Intel)",
    version: "Version", latest: "Latest version",
    features: "Main features", how: "How to use", req: "Requirements", screens: "Screenshots",
    sectionsTitle: "Everything in one place", sectionsSub: "The launcher groups the apps into four sections, just like its side menu.",
    installTitle: "How to start", installSub: "It takes about a minute.",
    appsCount: n => n === 1 ? "1 app" : n + " apps",
    allApps: "All apps", allAppsSub: "Every Kankon app and game. Each one installs, opens and updates from inside Kankon Launcher.",
    catSub: { apps: "General apps for everyday use.", games: "Games installed and kept up to date by Kankon Launcher.", tools: "Tools that keep your PC in good shape.", networking: "Apps for your network and internet connection." },
    appsEmpty: "General apps are coming soon. Meanwhile, here are all the apps available today.",
    details: "Full details", getIt: "Get it from Kankon Launcher", site: "Official website", extMore: 'All game details, news and guides are on the official website: <bdi dir=\'ltr\'>playdana.net</bdi>.', extBtn: "Open playdana.net", privacyBtn: "Privacy policy", storeNote: "Install it from your device's app store, or use the web version in any browser. It is not part of Kankon Launcher.",
    getItNote: "Install Kankon Launcher, then open this section and click Install.",
    recent: "What's new", allUpdates: "All updates",
    updTitle: "Updates", updSub: "Every new version of the launcher and the apps, with what changed. Newest first.",
    all: "All", latestBadge: "Latest", home: "Home", tmTitle: "Terms of Use", tmSub: "The rules for using Kankon Launcher, the Kankon apps and kankon.net.", updatedOn: "Last updated", ntTitle: "Third-party notices", ntSub: "The open-source parts and the online services that the Kankon apps use, with their licenses and terms.", ntLibs: "Software libraries and fonts", ntData: "Data and online services", colName: "Name", colLic: "License", colUsed: "Used in", colFor: "Used for", colTerms: "Terms", pvApps: "What each app sends over the internet", pvSiteH: "The website kankon.net", contactH: "Contact", contactSoon: "A contact email will be added here soon.", tmLink: "Terms", ntLink: "Third-party notices", tmMark: "Windows is a trademark of Microsoft Corporation. Mac and macOS are trademarks of Apple Inc. Kankon is not affiliated with or endorsed by them.", navAll: "All apps", findApp: "Find an app…", noApp: "No app matches your search.", backTo: "Back to", prevApp: "Previous app", nextApp: "Next app", shortLink: "Short link", copy: "Copy", copied: "Copied", youAreHere: "You are here", inCat: "In this section", openMenu: "Browse all apps",
    heroTitle: ["One launcher for ", "all Kankon apps"],
    guides: "Step-by-step guides", guidesSub: "Short, clear guides for the things you will do most.", stepsN: n => n + " steps",
    overview: "Overview", whyTitle: "Why Kankon Launcher", whySub: "Everything you need to keep your apps installed, safe and up to date.",
    sStat: [[String(window.KANKON.apps.length), "apps and games"], ["2", "languages: English and Arabic"], ["SHA-256", "every download verified"], ["Auto", "updates for apps and launcher"]],
    bandTitle: "Ready to start?", bandSub: "Download Kankon Launcher and install any app in one click.",
    mockUpdate: "Update", mockOpen: "Open", mockInstall: "Install", close: "Close"
  },
  ar: {
    langBtn: "English", navLauncher: "المشغّل", navUpdates: "التحديثات", navAI: "الذكاء الاصطناعي", siteVer: "إصدار الموقع", helpBtn: "الدليل الكامل", helpTitle: "المساعدة", helpSearch: "ابحث في الدليل…", helpContents: "المحتويات", helpFaq: "الأسئلة الشائعة", helpTrouble: "حلّ المشكلات", helpLoading: "جارٍ تحميل الدليل…", helpNone: "سيُتاح الدليل المفصّل لهذا البرنامج قريبًا.", helpNoMatch: "لا توجد نتائج مطابقة لبحثك.", helpFor: "الدليل للإصدار", helpBack: "العودة إلى صفحة البرنامج", helpProblem: "المشكلة", helpFix: "الحل", visitors: "زوّار الموقع", onlineNow: "المتواجدون الآن", privacy: "الخصوصية", rssBtn: "تابِع عبر RSS", rssHint: "أضف هذا الرابط إلى أي قارئ للخلاصات لتصلك التحديثات الجديدة تلقائيًا.",
    pvTitle: "الخصوصية", pvSub: "ما ترسله برامج Kankon وموقع kankon.net وما تحفظه، وما لا تجمعه أبدًا.",
    pvItems: ["لا حسابات، ولا ملفات تعريف الارتباط (Cookies)، ولا إعلانات، ولا خدمات تتبّع أو تحليلات.",
      "عدّاد الزوار: يحتفظ متصفحك بمعرّف عشوائي لا يرتبط بشخصك، حتى تُحسب الزيارة مرة واحدة في كل جلسة. ولا يحفظ الموقع سوى العدد الإجمالي للزيارات، والمعرّفات العشوائية النشطة خلال آخر ثلاث دقائق لحساب عدد المتواجدين الآن. ولا تُحفظ عناوين IP.",
      "التنزيلات: عند الضغط على زرّ التنزيل، يحسب الموقع التنزيل حسب البرنامج والنظام (Windows أو Mac) والإصدار فقط، ولا يحفظ عنوان IP ولا أي بيانات شخصية.",
      "تأتي ملفات التنزيل وأرقام الإصدارات من GitHub، الذي يتعامل مع هذه الطلبات وفق سياسة الخصوصية الخاصة به.",
      "الروابط إلى المواقع الأخرى (متاجر التطبيقات والألعاب وخدمات الذكاء الاصطناعي) تفتح تلك المواقع، ولكلٍّ منها سياسة خصوصية خاصة به.",
      "يوضّح كل برنامج من برامج Kankon في صفحة المساعدة الخاصة به ما يحفظه وما يرسله."],
    picksTitle: "أفضل الألعاب", picksSub: "أبرز الألعاب في ثلاثة أنواع، اختارتها Kankon، وتنقلك الروابط إلى مواقعها الرسمية.", freeTag: "مجانية", paid: "مدفوعة", aiOpen2: "الموقع الرسمي", picksNote: "هذه الألعاب ملك لشركاتها، ويقتصر دور Kankon على توفير روابط صفحاتها الرسمية.", kankonGames: "في Kankon Launcher",
    aiTitle: "برامج الذكاء الاصطناعي", aiSub: "أبرز برامج الذكاء الاصطناعي والمساعدات الذكية، اختارتها Kankon، وتنقلك روابطها إلى المواقع الرسمية.", aiOpen: "فتح الموقع", aiDl: "تنزيل", aiNote: "هذه البرامج ملك لشركاتها، ويقتصر دور Kankon على توفير روابط صفحاتها الرسمية.", aiHome: "أهم برامج الذكاء الاصطناعي في مكان واحد.",
    by: "من Kankon · kankon.net",
    eyebrow: "برامج Kankon لنظام Windows ولأجهزة Mac", title: "مشغّل واحد لجميع برامج Kankon",
    download: "تنزيل Kankon Launcher", dlFor: "تنزيل لنظام", dlForMac: "تنزيل لأجهزة", winSub: "Windows 10/11 · zip", macSub: "Apple Silicon / Intel · zip", macFirst: "<b>عند فتحه أول مرة على جهاز Mac:</b> إذا ظهرت رسالة بأنّ Apple لم تتمكّن من التحقّق من Kankon Launcher، فانقر Done، ثم افتح <bdi dir='ltr'>System Settings › Privacy &amp; Security</bdi>، ومرّر إلى الأسفل، وانقر <b>Open Anyway</b> بجانب Kankon Launcher (مرة واحدة فقط). والخطوات كاملة في الشروحات أدناه.", runsOn: "يعمل على", browse: "تصفّح البرامج", free: "مجاني · Windows 10 وWindows 11 · macOS (Apple Silicon / Intel)",
    version: "الإصدار", latest: "أحدث إصدار",
    features: "أبرز المزايا", how: "طريقة الاستخدام", req: "المتطلبات", screens: "لقطات الشاشة",
    sectionsTitle: "كل شيء في مكان واحد", sectionsSub: "يصنّف المشغّل البرامج في أربعة أقسام، كما في قائمته الجانبية.",
    installTitle: "كيف تبدأ", installSub: "لا يستغرق الأمر أكثر من دقيقة.",
    appsCount: n => n === 0 ? "لا توجد برامج بعد" : n === 1 ? "برنامج واحد" : n === 2 ? "برنامجان" : n <= 10 ? n + " برامج" : n + " برنامجًا",
    allApps: "جميع البرامج", allAppsSub: "جميع برامج Kankon وألعابها، ويُثبَّت كل منها ويُفتح ويُحدَّث من داخل Kankon Launcher.",
    catSub: { apps: "برامج عامة للاستخدام اليومي.", games: "ألعاب يثبّتها Kankon Launcher ويُبقيها محدَّثة.", tools: "أدوات تحافظ على جهازك في أفضل حال.", networking: "برامج لإدارة الشبكة والاتصال بالإنترنت." },
    appsEmpty: "ستتوفّر البرامج العامة قريبًا، وإلى حين ذلك إليك جميع البرامج المتاحة حاليًا.",
    details: "التفاصيل الكاملة", getIt: "احصل عليه عبر Kankon Launcher", site: "الموقع الرسمي", extMore: 'تجد جميع تفاصيل اللعبة وأخبارها وأدلّتها على موقعها الرسمي: <bdi dir=\'ltr\'>playdana.net</bdi>.', extBtn: "افتح playdana.net", privacyBtn: "سياسة الخصوصية", storeNote: "ثبّته من متجر التطبيقات في جهازك، أو استخدم نسخة الويب في أي متصفح. وهو غير متاح عبر Kankon Launcher.",
    getItNote: "ثبّت Kankon Launcher، ثم افتح هذا القسم وانقر Install.",
    recent: "ما الجديد", allUpdates: "جميع التحديثات",
    updTitle: "التحديثات", updSub: "كل إصدار جديد من المشغّل والبرامج، مع ما تغيّر فيه، مرتّبة من الأحدث إلى الأقدم.",
    all: "الكل", latestBadge: "الأحدث", home: "الرئيسية", tmTitle: "شروط الاستخدام", tmSub: "قواعد استخدام Kankon Launcher وبرامج Kankon وموقع kankon.net.", updatedOn: "آخر تحديث", ntTitle: "إشعارات الأطراف الثالثة", ntSub: "المكوّنات مفتوحة المصدر والخدمات الإلكترونية التي تستخدمها برامج Kankon، مع تراخيصها وشروطها.", ntLibs: "المكتبات البرمجية والخطوط", ntData: "البيانات والخدمات الإلكترونية", colName: "الاسم", colLic: "الترخيص", colUsed: "يُستخدم في", colFor: "الغرض", colTerms: "الشروط", pvApps: "ما يرسله كل برنامج عبر الإنترنت", pvSiteH: "موقع kankon.net", contactH: "التواصل", contactSoon: "سيُضاف بريد إلكتروني للتواصل هنا قريبًا.", tmLink: "شروط الاستخدام", ntLink: "إشعارات الأطراف الثالثة", tmMark: "Windows علامة تجارية لشركة Microsoft Corporation، وMac وmacOS علامتان تجاريتان لشركة Apple Inc.، ولا يرتبط Kankon بهما ولا يحظى باعتمادهما.", navAll: "جميع البرامج", findApp: "ابحث عن برنامج…", noApp: "لا يوجد برنامج يطابق بحثك.", backTo: "العودة إلى", prevApp: "البرنامج السابق", nextApp: "البرنامج التالي", shortLink: "رابط مختصر", copy: "نسخ", copied: "تم النسخ", youAreHere: "أنت هنا", inCat: "في هذا القسم", openMenu: "تصفّح جميع البرامج",
    heroTitle: ["مشغّل واحد ", "لجميع برامج Kankon"],
    guides: "شروحات خطوة بخطوة", guidesSub: "شروحات موجزة وواضحة لأكثر ما ستحتاج إليه.", stepsN: n => n === 2 ? "خطوتان" : n <= 10 ? n + " خطوات" : n + " خطوة",
    overview: "نظرة عامة", whyTitle: "لماذا Kankon Launcher؟", whySub: "كل ما تحتاج إليه لتبقى برامجك مثبّتة وآمنة ومحدَّثة.",
    sStat: [[String(window.KANKON.apps.length), "برامج وألعاب"], ["2", "لغتان: العربية والإنجليزية"], ["SHA-256", "التحقّق من سلامة كل ملف"], ["تلقائي", "تحديث البرامج والمشغّل"]],
    bandTitle: "هل أنت مستعدّ للبدء؟", bandSub: "نزّل Kankon Launcher وثبّت أي برنامج بنقرة واحدة.",
    mockUpdate: "Update", mockOpen: "Open", mockInstall: "Install", close: "إغلاق"
  }
};
let lang = new URLSearchParams(location.search).get("lang") === "ar" ? "ar" : "en"; /* English by default; ?lang=ar opens in Arabic */
const versions = {};
let macUrl = K.launcher.macDownload, macVer = "";
let updFilter = "all", lbList = [], lbIdx = 0, lbOverride = null;

const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const t = () => UI[lang];
const catName = id => K.categories.find(c => c.id === id)[lang];
const appsIn = id => K.apps.filter(a => a.cat === id);
const prod = id => id === "launcher" ? { id: "launcher", name: K.launcher.name, icon: K.launcher.icon } : id === "website" ? { id: "website", name: "kankon.net", icon: "favicon-32.png" } : K.apps.find(a => a.id === id);
const findApp = id => id && K.apps.find(a => a.id.toLowerCase() === String(id).toLowerCase());
const shortOf = a => "kankon.net/" + a.id.toLowerCase();
const catOrder = () => ["apps", "networking", "tools", "games"].filter(c => K.categories.some(x => x.id === c));
const backArrow = () => lang === "ar" ? "→" : "←";
const appRow = (a, cur) => `<a class="arow${cur ? " cur" : ""}" href="#/app/${a.id}" data-n="${esc((a.name + " " + a.summary.en + " " + a.summary.ar + " " + catName(a.cat)).toLowerCase())}"${cur ? ' aria-current="page"' : ""}><img src="${a.icon}" alt=""><span>${esc(a.name)}</span></a>`;
function crumbs(items, back) {
  const T = t();
  return `<div class="crumbs" role="navigation" aria-label="${T.youAreHere}">${back ? `<a class="backbtn" href="${back[0]}"><span aria-hidden="true">${backArrow()}</span> ${esc(back[1])}</a>` : ""}<ol>${items.map((x, i) => i === items.length - 1 ? `<li aria-current="page">${esc(x[1])}</li>` : `<li><a href="${x[0]}">${esc(x[1])}</a></li>`).join("")}</ol></div>`;
}
function megaHtml() {
  const T = t();
  return `<div class="mega" role="menu"><div class="mtop"><input id="mq" type="search" placeholder="${T.findApp}" aria-label="${T.findApp}" autocomplete="off"><kbd class="ltr">/</kbd></div>
    <div class="mcols">${catOrder().map(c => `<div class="mcol"><a class="mcat" href="#/${c}">${esc(catName(c))} <span>${appsIn(c).length}</span></a>${appsIn(c).map(a => appRow(a)).join("")}</div>`).join("")}</div>
    <p class="mnone" hidden>${T.noApp}</p></div>`;
}
function sideHtml(cur) {
  const T = t();
  return `<details class="aside"${innerWidth > 1100 ? " open" : ""}><summary>${svg(IC.grid)}<span>${T.navAll}</span><b>${K.apps.length}</b></summary>
    <input class="sq" type="search" placeholder="${T.findApp}" aria-label="${T.findApp}" autocomplete="off">
    ${catOrder().map(c => `<div class="scat"><a href="#/${c}">${esc(catName(c))}</a>${appsIn(c).map(a => appRow(a, a.id === cur)).join("")}</div>`).join("")}
    <p class="mnone" hidden>${T.noApp}</p></details>`;
}
function prevNext(a) {
  const T = t(), L = K.apps, i = L.indexOf(a), p = L[(i - 1 + L.length) % L.length], n = L[(i + 1) % L.length];
  return `<div class="pn"><a class="pnp" href="#/app/${p.id}"><small><span aria-hidden="true">${backArrow()}</span> ${T.prevApp}</small><span><img src="${p.icon}" alt="">${esc(p.name)}</span></a>
    <a class="pnn" href="#/app/${n.id}"><small>${T.nextApp} <span aria-hidden="true">${arrow()}</span></small><span><img src="${n.icon}" alt="">${esc(n.name)}</span></a></div>`;
}
function filterRows(input, scope) {
  const w = input.value.trim().toLowerCase(); let any = false;
  scope.querySelectorAll(".arow").forEach(r => { const hit = !w || r.dataset.n.includes(w); r.hidden = !hit; any = any || hit; });
  scope.querySelectorAll(".mcol,.scat").forEach(g => g.hidden = !!w && !g.querySelector(".arow:not([hidden])"));
  scope.querySelector(".mnone").hidden = any;
}
const verOf = id => versions[id] ? `<span class="ver">${t().version} <span class="ltr">${esc(versions[id])}</span></span>` : "";
const arrow = () => lang === "ar" ? "←" : "→";
const ul = (items, cls) => `<ul class="${cls || ""}">${items.map(i => `<li>${esc(i)}</li>`).join("")}</ul>`;
const shotSrc = s => s.src || s[lang] || s.en;
const svg = p => `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const OSI = { /* neutral device icons: no Microsoft or Apple logos (trademark guidelines) */
  win: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="3.5" width="19" height="13" rx="2"/><path d="M8 20.5h8M12 16.5v4"/></svg>',
  mac: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4.5" width="16" height="11" rx="1.5"/><path d="M2 19.5h20l-1.5-4h-17z"/></svg>'
};
const STI = {
  play: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M4 2.8v18.4c0 .6.7 1 1.2.7l15.6-9.2c.5-.3.5-1.1 0-1.4L5.2 2.1C4.7 1.8 4 2.2 4 2.8z"/></svg>',
  huawei: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="4"/><path d="M9 8a3 3 0 006 0"/></svg>',
  web: '<svg class="osl" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/></svg>'
};
const storeBtns = a => a.stores.map((x, i) => `<a class="btn os ${i === 0 ? "primary" : "ghost"}" href="${x.url}" target="_blank" rel="noopener">${x.icon === "apple" ? OSI.mac : STI[x.icon]}<span class="ol"><small>${esc(x.small[lang])}</small><b>${esc(x.name[lang])}</b></span></a>`).join("");
const isMac = /Mac/i.test(navigator.platform || navigator.userAgent) && !/iPhone|iPad/i.test(navigator.userAgent);
function dlBtns(oses) {
  const T = t();
  const b = (os, href, name, sub, pri, extra) => `<a class="btn os ${pri ? "primary" : "ghost"}" ${extra || ""}href="${href}">${OSI[os]}<span class="ol"><small>${os === "mac" && T.dlForMac ? T.dlForMac : T.dlFor}</small><b>${name}</b><i><bdi dir="ltr">${sub}</bdi></i></span></a>`;
  const w = b("win", K.launcher.download, "Windows", T.winSub, !isMac, 'data-os="win" '), m = b("mac", macUrl, "Mac", T.macSub, isMac, 'data-mac data-os="mac" ');
  if (oses && !oses.includes("mac")) return b("win", K.launcher.download, "Windows", T.winSub, true, 'data-os="win" ');
  return isMac ? m + w : w + m;
}
const osTags = a => a.platforms ? a.platforms.map(p => `<span class="tag ostag">${esc(p)}</span>`).join("") : (a.os || ["win"]).map(o => `<span class="tag ostag">${OSI[o]}${o === "mac" ? "Mac" : "Windows"}</span>`).join("");
const IC = {
  dl: '<path d="M12 3v12m0 0l-5-5m5 5l5-5M4 21h16"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  click: '<path d="M9 9l11 4-5 2-2 5z"/><path d="M4 4l2 2M4 10h2M10 4v2"/>',
  refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  self: '<path d="M12 2v6m0 8v6M4.9 4.9l4.2 4.2m5.8 5.8l4.2 4.2M2 12h6m8 0h6"/>',
  doc: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/>',
  lang: '<path d="M4 5h8M8 3v2m-3 0c1 4 4 7 7 8M11 5c-1 4-4 7-7 8M13 21l4-10 4 10m-7-3h6"/>',
  chev: '<path d="M6 9l6 6 6-6"/>'
};

function nav() {
  const T = t(), r = location.hash || "#/", seg = r.replace(/^#\/?/, "").split("/");
  const inApps = K.categories.some(c => c.id === seg[0]) || ((seg[0] === "app" || seg[0] === "help") && seg[1] !== "launcher" && seg[1] !== "website") || !!findApp(seg[0]);
  const a = (h, l, on) => `<a href="${h}" class="${on ? "on" : ""}">${esc(l)}</a>`;
  $("#nav").innerHTML = a("#/", T.navLauncher, r === "#/" || r === "#" || seg[1] === "launcher")
    + `<div class="dd"><button class="ddb${inApps ? " on" : ""}" type="button" aria-expanded="false" aria-haspopup="true">${T.navAll}${svg(IC.chev)}</button>${megaHtml()}</div>`
    + a("#/ai", T.navAI, seg[0] === "ai") + a("#/updates", T.navUpdates, seg[0] === "updates");
  const dd = $("#nav .dd"), b = dd.querySelector(".ddb"), q = dd.querySelector("#mq");
  const set = o => { dd.classList.toggle("open", o); b.setAttribute("aria-expanded", o); if (o && innerWidth > 980) setTimeout(() => q.focus(), 30); };
  b.onclick = e => { e.stopPropagation(); set(!dd.classList.contains("open")); };
  dd.onclick = e => e.stopPropagation();
  q.oninput = () => filterRows(q, dd);
  q.onkeydown = e => { if (e.key === "Enter") { const f = dd.querySelector(".arow:not([hidden])"); if (f) location.hash = f.getAttribute("href"); } if (e.key === "Escape") set(false); };
  nav.open = set;
}
document.addEventListener("click", () => nav.open && nav.open(false));
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && nav.open) nav.open(false);
  if ((e.key === "/" || (e.key.toLowerCase() === "k" && (e.ctrlKey || e.metaKey))) && !/INPUT|TEXTAREA/.test(document.activeElement.tagName) && $("#lb").hidden) { e.preventDefault(); if (innerWidth <= 980) $("#nav").classList.add("open"); nav.open(true); setTimeout(() => $("#mq").focus(), 40); }
});

function card(a) {
  const th = (a.shots || []).slice(0, 3).map(s => `<img src="${shotSrc(s)}" alt="" loading="lazy">`).join("");
  return `<a class="card rv" href="#/app/${a.id}"><div class="top"><img src="${a.icon}" alt=""><div><h3>${esc(a.name)}</h3>
    <div class="tags"><span class="tag">${esc(catName(a.cat))}</span>${osTags(a)}${verOf(a.id)}</div></div></div>
    <p>${esc(a.summary[lang])}</p>${th ? `<div class="thumbs">${th}</div>` : ""}<span class="go">${t().details} ${arrow()}</span></a>`;
}

function updItem(u, i) {
  const p = prod(u.product);
  return `<article class="upd rv${i === 0 ? " new" : ""}"><div class="h"><img src="${p.icon}" alt=""><b>${esc(p.name)}</b>
    <span class="ver">${t().version} <span class="ltr">${esc(u.version)}</span></span>
    ${i === 0 ? `<span class="tag">${t().latestBadge}</span>` : ""}<span class="d ltr">${esc(u.date)}</span></div>${ul(u[lang])}</article>`;
}

function guidesHtml(gs) {
  if (!gs || !gs.length) return "";
  return `<div class="guides">${gs.map((g, i) => `<details class="guide rv"${i === 0 ? " open" : ""}><summary><span class="n">${i + 1}</span>${esc(g.t[lang])}
    <span class="c">${t().stepsN(g[lang].length)}</span><span class="chev">${svg(IC.chev)}</span></summary>
    <ol>${g[lang].map(s => `<li>${esc(s)}</li>`).join("")}</ol></details>`).join("")}</div>`;
}

function galleryHtml(shots) {
  if (!shots || !shots.length) return "";
  return `<div class="gal">${shots.map((s, i) => `<figure class="rv" data-i="${i}"><img src="${shotSrc(s)}" alt="${esc(s.cap[lang])}" loading="lazy"><figcaption>${esc(s.cap[lang])}</figcaption></figure>`).join("")}</div>`;
}

function mock() {
  const T = t(), rows = [["AutoIpConfig", T.mockUpdate, "up"], ["NetworkMonitor", T.mockOpen, ""], ["DriverManager", T.mockOpen, ""], ["Dana", T.mockInstall, ""]];
  return `<div class="mock"><div class="tb"><img src="${K.launcher.icon}" alt="">Kankon Launcher<span class="dots"><i></i><i></i><i></i></span></div>
    <div class="body"><div class="side">${K.categories.map((c, i) => `<b class="${i === 0 ? "on" : ""}">${esc(c.en)}</b>`).join("")}</div>
    <div class="list">${rows.map(([id, b, cls]) => { const a = prod(id); return `<div class="row"><img src="${a.icon}" alt=""><div><strong>${esc(a.name)}</strong>
      <small>${esc(K.categories.find(c => c.id === a.cat).en)}${versions[id] ? " · v" + esc(versions[id]) : ""}</small></div><em class="${cls}">${b}</em></div>`; }).join("")}</div></div></div>`;
}

function pageHome() {
  const L = K.launcher, T = t();
  const fIcons = [IC.grid, IC.click, IC.refresh, IC.shield, IC.self, IC.doc, IC.lang];
  return `<div class="wrap hero"><div class="rv">
      <span class="eyebrow">${T.eyebrow}</span>
      <h1>${T.heroTitle[0]}<span class="grad">${T.heroTitle[1]}</span></h1>
      <p class="lead">${esc(L.summary[lang])}</p>
      <div class="cta">${dlBtns()}
      <a class="btn ghost" href="#/apps">${T.browse}</a>${K.help && K.help.launcher ? `<a class="btn ghost" href="#/help/launcher">📘 ${T.helpBtn}</a>` : ""}</div>
      <p class="macnote">${T.macFirst}</p>
      <div class="meta"><span>${T.free}</span>${versions.launcher ? `<span>${T.latest} <span class="ltr">${esc(versions.launcher)}</span></span>` : ""}</div>
    </div><div class="rv" style="position:relative">${mock()}<div class="glow"></div></div></div>
  <div class="wrap"><div class="stats">${T.sStat.map(([b, s]) => `<div class="stat rv"><b class="grad">${b}</b><span>${s}</span></div>`).join("")}</div></div>
  <section><div class="wrap"><div class="kicker">Kankon Launcher</div><h2>${T.sectionsTitle}</h2><p class="sub">${T.sectionsSub}</p><div class="cats">
    ${K.categories.map(c => { const as = appsIn(c.id); return `<a class="cat rv" href="#/${c.id}"><span class="arr">${arrow()}</span><div class="icons">${as.map(a => `<img src="${a.icon}" alt="">`).join("")}</div>
      <b>${esc(c[lang])}</b><span>${T.appsCount(as.length)}</span></a>`; }).join("")}
    <a class="cat rv aicat" href="#/ai"><span class="arr">${arrow()}</span><div class="icons">${K.ai.slice(0, 4).map(x => `<span class="mono s" style="--c:${x.color}">${esc(x.name[0])}</span>`).join("")}</div>
      <b>${T.navAI}</b><span>${T.aiHome}</span></a>
  </div></div></section>
  <section><div class="wrap"><div class="kicker">${T.features}</div><h2>${T.whyTitle}</h2><p class="sub">${T.whySub}</p>
    <div class="bento">${L.features[lang].map((f, i) => `<div class="feat rv${i === 0 ? " wide" : ""}"><div class="ic">${svg(fIcons[i % fIcons.length])}</div><p>${esc(f)}</p></div>`).join("")}</div>
  </div></section>
  ${L.shots && L.shots.length ? `<section id="shots"><div class="wrap"><h2>${T.screens}</h2><p class="sub"></p>${galleryHtml(L.shots)}</div></section>` : ""}
  <section><div class="wrap"><div class="kicker">${T.how}</div><h2>${T.guides}</h2><p class="sub">${T.guidesSub}</p>
    <div class="two">${guidesHtml(L.guides)}<div class="panel rv"><h3>${T.req}</h3>${ul(L.req[lang], "check")}</div></div></div></section>
  <section><div class="wrap"><div class="kicker">${T.navUpdates}</div><h2>${T.recent}</h2><p class="sub">${T.updSub}</p>
    <div class="tl">${K.updates.slice(0, 3).map(updItem).join("")}</div>
    <p style="margin-top:22px"><a class="btn ghost" href="#/updates">${T.allUpdates} ${arrow()}</a></p>
    ${band()}</div></section>`;
}

function band() {
  const T = t();
  return `<div class="band rv"><div><h2>${T.bandTitle}</h2><p>${T.bandSub}</p></div>
    <span class="cta">${dlBtns()}</span></div>`;
}

function pageCat(id) {
  const T = t(); let as = appsIn(id), note = "";
  if (id === "apps" && !as.length) { note = `<div class="note rv">${T.appsEmpty}</div>`; as = K.apps; }
  const picks = id === "games" && K.games ? `<section><div class="wrap"><h2>${T.picksTitle}</h2><p class="sub">${T.picksSub}</p>
    ${K.gameGroups.map(g => `<div class="kicker" style="margin-top:28px">${esc(g[lang])}</div><div class="grid">${K.games.filter(x => x.group === g.id).map(gameCard).join("")}</div>`).join("")}
    <p class="note rv" style="margin-top:22px">${T.picksNote}</p></div></section>` : "";
  return `<section><div class="wrap"><span class="eyebrow">Kankon Launcher</span><h1>${esc(catName(id))}</h1>
    <p class="sub">${T.catSub[id]}</p>${note}${id === "games" ? `<div class="kicker">${T.kankonGames}</div>` : ""}<div class="grid">${as.map(card).join("")}</div></div></section>${picks}
    <div class="wrap">${band()}</div>`;
}

function pageApp(id) {
  const a = findApp(id); if (!a) return pageHome();
  return `<div class="wrap applay">${sideHtml(a.id)}<div class="amain">${appMain(a)}${prevNext(a)}</div></div>`;
}
function appMain(a) {
  const id = a.id;
  const T = t(), ups = K.updates.filter(u => u.product === id), has = a.shots && a.shots.length;
  const links = [["ov", T.overview], ...(a.guides ? [["guides", T.guides]] : []), ...(has ? [["shots", T.screens]] : []), ...(ups.length ? [["upd", T.recent]] : [])];
  return `<div class="wrap">${crumbs([["#/", T.home], ["#/" + a.cat, catName(a.cat)], ["", a.name]], ["#/" + a.cat, T.backTo + " " + catName(a.cat)])}
    <div class="apphero rv"><div class="appicon"><img src="${a.icon}" alt=""></div><div><h1>${esc(a.name)}</h1>
      <div class="tags"><span class="tag">${esc(catName(a.cat))}</span>${osTags(a)}${verOf(a.id)}</div><p class="lead">${esc(a.summary[lang])}</p>
      <button class="slink" type="button" data-copy="https://${shortOf(a)}" title="${T.shortLink}">🔗 <span class="ltr">${shortOf(a)}</span> <em>${T.copy}</em></button></div></div>
    ${a.ext ? `<div class="cta"><a class="btn primary" href="${a.site}" target="_blank" rel="noopener">${T.extBtn} ↗</a>${dlBtns(a.os || ["win"])}</div>
    <div class="meta"><span>${T.extMore}</span></div><div class="meta"><span>${T.getItNote.replace(/this section|هذا القسم/, m => m + " (" + catName(a.cat) + ")")}</span></div></div>
    ${ups.length ? `<section id="upd"><div class="wrap"><h2>${T.recent}</h2><p class="sub"></p><div class="tl">${ups.map(updItem).join("")}</div></div></section>` : ""}` : `
    <div class="cta">${a.stores ? storeBtns(a) : dlBtns(a.os || ["win"])}
      ${a.privacy ? `<a class="btn ghost" href="${a.privacy}" target="_blank" rel="noopener">${T.privacyBtn}</a>` : ""}
      ${a.site ? `<a class="btn ghost" href="${a.site}" target="_blank" rel="noopener">${T.site}</a>` : ""}
      ${K.help && K.help[a.id] ? `<a class="btn ghost" href="#/help/${a.id}">📘 ${T.helpBtn}</a>` : ""}</div>
    ${a.warn ? `<div class="appwarn" role="note"><span aria-hidden="true">⚠️</span><p>${esc(a.warn[lang])}</p></div>` : ""}
    <div class="meta"><span>${a.stores ? T.storeNote : T.getItNote.replace(/this section|هذا القسم/, m => m + " (" + catName(a.cat) + ")")}</span></div>
    <div class="subnav">${links.map(([h, l]) => `<a href="javascript:void(0)" data-go="${h}">${l}</a>`).join("")}</div></div>
  <section id="ov"><div class="wrap"><div class="two">
    <div class="panel rv"><h3>${T.features}</h3>${ul(a.features[lang], "check")}</div>
    <div class="stack"><div class="panel rv"><h3>${T.how}</h3>${ul(a.how[lang], "check")}</div>
    <div class="panel rv"><h3>${T.req}</h3>${ul(a.req[lang], "check")}</div></div></div></div></section>
  ${a.guides ? `<section id="guides"><div class="wrap"><div class="kicker">${esc(a.name)}</div><h2>${T.guides}</h2><p class="sub">${T.guidesSub}</p>${guidesHtml(a.guides)}</div></section>` : ""}
  ${has ? `<section id="shots"><div class="wrap"><h2>${T.screens}</h2><p class="sub"></p>${galleryHtml(a.shots)}</div></section>` : ""}
  ${ups.length ? `<section id="upd"><div class="wrap"><h2>${T.recent}</h2><p class="sub"></p><div class="tl">${ups.map(updItem).join("")}</div>
    <p style="margin-top:22px"><a class="btn ghost" href="#/updates">${T.allUpdates} ${arrow()}</a></p></div></section>` : ""}`}`;
}

function aiCard(x) {
  const T = t(), mono = x.name.split(" ").map(w => w[0]).join("").slice(0, 2);
  return `<article class="card ai rv"><div class="top"><span class="mono" style="--c:${x.color}">${esc(mono)}</span><div><h3>${esc(x.name)}</h3>
    <div class="tags"><span class="tag">${esc(x.by)}</span></div></div></div><p>${esc(x[lang])}</p>
    <div class="aibtns">${x.dl ? `<a class="btn primary sm" href="${x.dl}" target="_blank" rel="noopener">${svg(IC.dl)}<span>${T.aiDl}</span></a>` : ""}
    <a class="btn ghost sm" href="${x.url}" target="_blank" rel="noopener">${T.aiOpen} ↗</a></div></article>`;
}

function gameCard(x) {
  const T = t(), mono = x.mono || x.name[0];
  return `<article class="card ai rv"><div class="top"><span class="mono" style="--c:${x.color}">${esc(mono)}</span><div><h3>${esc(x.name)}</h3>
    <div class="tags"><span class="tag">${esc(x.by)}</span><span class="ver">${x.free ? T.freeTag : T.paid}</span></div></div></div><p>${esc(x[lang])}</p>
    <div class="aibtns"><a class="btn ghost sm" href="${x.url}" target="_blank" rel="noopener">${T.aiOpen2} ↗</a></div></article>`;
}

function pageAI() {
  const T = t();
  return `<section><div class="wrap"><span class="eyebrow">${T.navAI}</span><h1>${T.aiTitle}</h1><p class="sub">${T.aiSub}</p>
    <div class="grid">${K.ai.map(aiCard).join("")}</div><p class="note rv" style="margin-top:22px">${T.aiNote}</p></div></section>`;
}

const LG = () => K.legal || { terms: [], privacyIntro: [], privacyApps: [], libs: [], sources: [] };
const legalHead = (eb, title, sub) => `<section><div class="wrap legal"><span class="eyebrow">${eb}</span><h1>${title}</h1><p class="sub">${sub}</p>
    <p class="lupd">${t().updatedOn}: <span class="ltr">${esc(LG().updated || "")}</span></p>`;
const contactBox = () => { const T = t(), c = LG().contact; return `<div class="panel rv lsec"><h3>${T.contactH}</h3><p>${c ? `<a class="hlink" href="mailto:${esc(c)}"><bdi dir="ltr">${esc(c)}</bdi></a>` : T.contactSoon}</p></div>`; };
const legalNav = cur => { const T = t(); return `<div class="lnav">${[["#/terms", T.tmTitle, "terms"], ["#/privacy", T.pvTitle, "privacy"], ["#/notices", T.ntTitle, "notices"]].map(([h, l, k]) => `<a class="${k === cur ? "on" : ""}" href="${h}">${esc(l)}</a>`).join("")}</div>`; };
function pageTerms() {
  const T = t();
  return legalHead("kankon.net", T.tmTitle, T.tmSub) + legalNav("terms") + LG().terms.map((x, i) => `<div class="panel rv lsec"><h3><span>${i + 1}</span>${esc(x.h[lang])}</h3>${x.p.map(q => `<p>${esc(q[lang])}</p>`).join("")}</div>`).join("") + contactBox() + `</div></section>`;
}
function pagePrivacy() {
  const T = t(), L = LG();
  return legalHead("kankon.net", T.pvTitle, T.pvSub) + legalNav("privacy") + L.privacyIntro.map(q => `<p class="lead lintro">${esc(q[lang])}</p>`).join("")
    + `<div class="panel rv lsec"><h3>${T.pvApps}</h3><div class="papps">${L.privacyApps.map(x => { const a = prod(x.id); if (!a) return ""; return `<div class="papp"><img src="${a.icon}" alt=""><div><b>${esc(a.name)}</b><p>${esc(x[lang])}</p></div></div>`; }).join("")}</div></div>
    <div class="panel rv lsec"><h3>${T.pvSiteH}</h3>${ul(T.pvItems, "check")}</div>` + contactBox() + `</div></section>`;
}
function pageNotices() {
  const T = t(), L = LG(), lk = u => `<a class="hlink" href="${esc(u)}" target="_blank" rel="noopener"><bdi dir="ltr">${esc(u.replace(/^https:\/\//, "").replace(/\/$/, ""))}</bdi></a>`;
  return legalHead("kankon.net", T.ntTitle, T.ntSub) + legalNav("notices")
    + `<div class="panel rv lsec"><h3>${T.ntLibs}</h3><div class="htable"><table><thead><tr><th>${T.colName}</th><th>${T.colLic}</th><th>${T.colUsed}</th></tr></thead><tbody>${L.libs.map(x => `<tr><td data-l="${T.colName}"><b><bdi dir="ltr">${esc(x.name)}</bdi></b><br>${lk(x.url)}</td><td data-l="${T.colLic}">${esc(x.lic)}</td><td data-l="${T.colUsed}"><bdi>${esc(x.apps)}</bdi></td></tr>`).join("")}</tbody></table></div></div>
    <div class="panel rv lsec"><h3>${T.ntData}</h3><div class="htable"><table><thead><tr><th>${T.colName}</th><th>${T.colFor}</th><th>${T.colUsed}</th><th>${T.colTerms}</th></tr></thead><tbody>${L.sources.map(x => `<tr><td data-l="${T.colName}"><b><bdi dir="ltr">${esc(x.name)}</bdi></b></td><td data-l="${T.colFor}">${esc(x.use[lang])}</td><td data-l="${T.colUsed}"><bdi>${esc(x.apps)}</bdi></td><td data-l="${T.colTerms}">${lk(x.url)}</td></tr>`).join("")}</tbody></table></div></div>
    <p class="note">${T.tmMark}</p></div></section>`;
}

function pageUpdates() {
  const T = t();
  const ids = ["website", "launcher", ...K.apps.map(a => a.id)].filter(id => K.updates.some(u => u.product === id));
  const ups = K.updates.filter(u => updFilter === "all" || u.product === updFilter);
  return `<section><div class="wrap"><span class="eyebrow">${T.navUpdates}</span><h1>${T.updTitle}</h1><p class="sub">${T.updSub}</p>
    <p class="meta"><a class="btn ghost sm" href="${lang === "ar" ? "feed-ar.xml" : "feed.xml"}" target="_blank" rel="noopener">${T.rssBtn}</a> <span>${T.rssHint}</span></p>
    <div class="filters"><button class="chip all${updFilter === "all" ? " on" : ""}" data-f="all">${T.all}</button>
    ${ids.map(id => { const p = prod(id); return `<button class="chip${id === updFilter ? " on" : ""}" data-f="${id}"><img src="${p.icon}" alt="">${esc(p.name)}</button>`; }).join("")}</div>
    <div class="tl">${ups.map(updItem).join("")}</div></div></section>`;
}

function currentShots() {
  const r = (location.hash || "#/").replace(/^#\/?/, "").split("/");
  return r[0] === "app" ? (K.apps.find(a => a.id === r[1]) || {}).shots || [] : K.launcher.shots || [];
}
function showLb(i) {
  lbList = lbOverride || currentShots(); if (!lbList.length) return; lbIdx = (i + lbList.length) % lbList.length;
  const s = lbList[lbIdx], lb = $("#lb"); lb.querySelector("img").src = shotSrc(s); lb.querySelector("p").textContent = s.cap[lang]; lb.hidden = false;
}

let io;
function reveal() {
  io && io.disconnect();
  io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .08 });
  document.querySelectorAll(".rv").forEach((el, i) => { el.style.transitionDelay = Math.min(i % 6, 5) * 60 + "ms"; io.observe(el); });
}

/* Visitor counter: counter.php (no IPs, random browser id). Hidden if PHP is off. */
let visits = null;
function showVisits() {
  const el = document.getElementById("vc"); if (!el) return;
  if (!visits) { el.hidden = true; return; }
  const T = t(), f = n => n.toLocaleString(lang === "ar" ? "ar-KW" : "en-US");
  el.innerHTML = `${T.visitors}: <b>${f(visits.total)}</b> · ${T.onlineNow}: <b>${f(visits.online)}</b>`; el.hidden = false;
}
function pingVisits(first) {
  let id = ""; try { id = localStorage.getItem("kvid") || ""; if (!/^[a-z0-9]{8,32}$/.test(id)) { id = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); localStorage.setItem("kvid", id); } } catch (_) { id = Math.random().toString(36).slice(2, 14); }
  let n = 0; if (first) { try { if (!sessionStorage.getItem("kvs")) { n = 1; sessionStorage.setItem("kvs", "1"); } } catch (_) { n = 1; } }
  fetch("counter.php?id=" + id + "&n=" + n, { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(j => { if (j && typeof j.total === "number") { visits = j; showVisits(); } }).catch(() => {});
}
pingVisits(true); setInterval(() => { if (!document.hidden) pingVisits(false); }, 60000);


/* Detailed help pages: help/<id>.json (written by each app's thread, format in site-help/FORMAT.md). */
const helpCache = {};
const lk = v => esc(v).replace(/https?:\/\/[a-z0-9][^\s<"&]*[^\s<".,;:!?)»،&]/gi, u => `<a class="hlink" href="${u}" target="_blank" rel="noopener"><bdi dir="ltr">${u}</bdi></a>`);
function helpBlock(b, id) {
  const v = b[lang] != null ? b[lang] : b.en;
  if (b.type === "steps") return `<ol class="hsteps">${v.map(x => `<li>${lk(x)}</li>`).join("")}</ol>`;
  if (b.type === "list") return `<ul class="hlist">${v.map(x => `<li>${lk(x)}</li>`).join("")}</ul>`;
  if (b.type === "table") return `<div class="htable"><table><thead><tr>${v[0].map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${v.slice(1).map(r => `<tr>${r.map(c => `<td>${lk(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  if (b.type === "tip" || b.type === "warn") return `<div class="hbox ${b.type}">${b.type === "tip" ? "💡" : "⚠️"} <span>${lk(v)}</span></div>`;
  if (b.type === "img") { const fig = (src, c, os) => { const cap = c ? (c[lang] || c.en) : ""; return `<figure class="himg"><img loading="lazy" src="img/help/${id}/${esc(src)}" alt="${esc(cap)}">${cap || os ? `<figcaption>${os ? `<b class="oslbl">${os}</b> ` : ""}${esc(cap)}</figcaption>` : ""}</figure>`; };
    return fig((lang === "ar" && b.src_ar) || b.src, b.cap, b.src_mac ? "Windows" : "") + (b.src_mac ? fig((lang === "ar" && b.src_mac_ar) || b.src_mac, b.cap_mac || b.cap, "Mac") : ""); }
  return `<p>${lk(v)}</p>`;
}
function helpBody(h, id) {
  const T = t(), L = o => (o && (o[lang] || o.en)) || "";
  const secs = (h.sections || []).map(s => ({ id: "s-" + s.id, title: L(s.title), html: s.blocks.map(b => helpBlock(b, id)).join("") }));
  if (h.troubleshooting && h.troubleshooting.length) secs.push({ id: "s-trouble", title: T.helpTrouble, html: h.troubleshooting.map(x => `<div class="hqa"><h4>${esc(L(x.problem))}</h4><p>${lk(L(x.fix))}</p></div>`).join("") });
  if (h.faq && h.faq.length) secs.push({ id: "s-faq", title: T.helpFaq, html: h.faq.map(x => `<details class="hqa"><summary>${esc(L(x.q))}</summary><p>${lk(L(x.a))}</p></details>`).join("") });
  return `<div class="hgrid"><aside class="htoc"><input id="hq" type="search" placeholder="${T.helpSearch}"><b>${T.helpContents}</b>
    <nav>${secs.map((s, i) => `<a href="javascript:void(0)" data-h="${s.id}"><span>${i + 1}</span>${esc(s.title)}</a>`).join("")}</nav></aside>
    <div class="hmain">${secs.map((s, i) => `<section class="hsec" id="${s.id}"><h2><span>${i + 1}</span>${esc(s.title)}</h2>${s.html}</section>`).join("")}
    <p class="note" id="hnone" hidden>${T.helpNoMatch}</p></div></div>`;
}
function pageHelp(id) {
  const a = findApp(id) || prod(id), T = t(); if (a) id = a.id; if (!a) return pageHome(); if (a.ext) return pageApp(id);
  const back = id === "launcher" ? "#/" : "#/app/" + id;
  const ver = K.help && K.help[id] ? K.help[id].version : "";
  return `<div class="wrap helpw">${crumbs([["#/", T.home], ...(a.cat ? [["#/" + a.cat, catName(a.cat)]] : []), [back, a.name], ["", T.helpTitle]], [back, T.helpBack])}
    <div class="apphero"><div class="appicon"><img src="${a.icon}" alt=""></div><div><h1>${esc(a.name)} · ${T.helpTitle}</h1>
    <div class="tags">${ver ? `<span class="ver">${T.helpFor} <span class="ltr">${esc(ver)}</span></span>` : ""}<a class="tag" href="${back}">${T.helpBack}</a></div></div></div>
    <div id="hbody"><p class="note">${K.help && K.help[id] ? T.helpLoading : T.helpNone}</p></div></div>`;
}
function helpWire(id) {
  if (!K.help || !K.help[id]) return;
  const fill = h => {
    const el = document.getElementById("hbody"); if (!el) return;
    el.innerHTML = helpBody(h, id);
    document.querySelectorAll("[data-h]").forEach(a => a.onclick = () => { document.getElementById(a.dataset.h).scrollIntoView({ behavior: "smooth", block: "start" }); history.replaceState(null, "", "#/help/" + id + "/" + a.dataset.h.slice(2)); });
    const want = (location.hash.split("/")[3] || "").toLowerCase(), tgt = want && document.getElementById("s-" + want);
    if (tgt) { tgt.classList.add("hit"); const go = () => tgt.scrollIntoView({ block: "start" });
      const above = [...document.querySelectorAll(".hmain img")].filter(i => tgt.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_PRECEDING);
      above.forEach(i => i.loading = "eager"); setTimeout(go, 60);
      Promise.race([Promise.all(above.map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; }))), new Promise(r => setTimeout(r, 4000))]).then(go); }
    const q = document.getElementById("hq");
    q.oninput = () => { const w = q.value.trim().toLowerCase(); let any = false;
      document.querySelectorAll(".hsec").forEach(s => { const hit = !w || s.textContent.toLowerCase().includes(w); s.hidden = !hit; any = any || hit;
        const l = document.querySelector(`[data-h="${s.id}"]`); if (l) l.hidden = !hit;
        if (w && hit) s.querySelectorAll("details").forEach(d => d.open = d.textContent.toLowerCase().includes(w)); });
      document.getElementById("hnone").hidden = any; };
    const hl = [...document.querySelectorAll(".himg img")];
    hl.forEach((i, n) => i.onclick = () => { lbOverride = hl.map(x => ({ src: x.getAttribute("src"), cap: { en: x.alt, ar: x.alt } })); showLb(n); });
  };
  if (helpCache[id]) return fill(helpCache[id]);
  fetch("help/" + id + ".json?v=" + SITE_VERSION).then(r => r.json()).then(h => { helpCache[id] = h; fill(h); })
    .catch(() => { const el = document.getElementById("hbody"); if (el) el.innerHTML = `<p class="note">${t().helpNone}</p>`; });
}

function render(scroll) {
  const T = t(), r = (location.hash || "#/").replace(/^#\/?/, "").split("/");
  document.documentElement.lang = lang; document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  $("#lang").textContent = T.langBtn; $("#by").textContent = T.by;
  $("#sv").textContent = `${T.siteVer} ${SITE_VERSION}`; $("#pv").textContent = T.privacy; $("#tm").textContent = T.tmLink; $("#nt").textContent = T.ntLink; $("#mk").textContent = T.tmMark; $("#rss").href = lang === "ar" ? "feed-ar.xml" : "feed.xml"; showVisits(); $("#yr").textContent = new Date().getFullYear();
  nav(); $("#nav").classList.remove("open");
  let html;
  lbOverride = null;
  const alias = !["app", "help", "updates", "ai", "privacy", "terms", "notices", "third-party-notices"].includes(r[0]) && !K.categories.some(c => c.id === r[0]) && findApp(r[0]);
  if (alias) { history.replaceState(null, "", (r[1] === "help" ? "#/help/" : "#/app/") + alias.id); return render(scroll); }
  if (r[0] === "app" && findApp(r[1]) && findApp(r[1]).id !== r[1]) { history.replaceState(null, "", "#/app/" + findApp(r[1]).id); return render(scroll); }
  if (!r[0]) html = pageHome();
  else if (r[0] === "app") html = pageApp(r[1]);
  else if (r[0] === "help") html = pageHelp(r[1]); else if (r[0] === "privacy") html = pagePrivacy(); else if (r[0] === "terms") html = pageTerms(); else if (r[0] === "notices" || r[0] === "third-party-notices") html = pageNotices();
  else if (r[0] === "updates") html = pageUpdates();
  else if (r[0] === "ai") html = pageAI();
  else if (K.categories.some(c => c.id === r[0])) html = pageCat(r[0]);
  else html = pageHome();
  $("#view").innerHTML = html;
  if (r[0] === "help") { const hp = findApp(r[1]) || prod(r[1]); if (hp && !hp.ext) helpWire(hp.id); }
  document.querySelectorAll(".chip").forEach(b => b.onclick = () => { updFilter = b.dataset.f; render(false); });
  document.querySelectorAll(".gal figure").forEach(f => f.onclick = () => showLb(+f.dataset.i));
  document.querySelectorAll(".aside .sq").forEach(q => q.oninput = () => filterRows(q, q.closest(".aside")));
  document.querySelectorAll("[data-copy]").forEach(b => b.onclick = () => { const done = () => { b.classList.add("ok"); b.querySelector("em").textContent = T.copied; setTimeout(() => { b.classList.remove("ok"); b.querySelector("em").textContent = T.copy; }, 1800); };
    if (navigator.clipboard) navigator.clipboard.writeText(b.dataset.copy).then(done, done); else done(); });
  document.querySelectorAll("[data-go]").forEach(a => a.onclick = () => document.getElementById(a.dataset.go).scrollIntoView({ behavior: "smooth" }));
  document.title = (r[0] === "app" && findApp(r[1]) ? findApp(r[1]).name + " · " : r[0] === "updates" ? T.updTitle + " · " : "") + "Kankon Launcher";
  reveal();
  if (scroll && !(r[0] === "help" && r[2])) window.scrollTo(0, 0);
}

$("#lb").onclick = e => { if (e.target.closest(".prev")) showLb(lbIdx - 1); else if (e.target.closest(".next")) showLb(lbIdx + 1); else if (e.target.tagName !== "IMG") $("#lb").hidden = true; };
document.addEventListener("keydown", e => {
  if ($("#lb").hidden) return;
  if (e.key === "Escape") $("#lb").hidden = true;
  if (e.key === "ArrowRight") showLb(lbIdx + (lang === "ar" ? -1 : 1));
  if (e.key === "ArrowLeft") showLb(lbIdx + (lang === "ar" ? 1 : -1));
});
$("#lang").onclick = () => { lang = lang === "en" ? "ar" : "en"; render(false); };
$("#menuBtn").onclick = () => $("#nav").classList.toggle("open");
window.addEventListener("hashchange", () => render(true));
render(false);

/* Download counter (dl.php on the Synology; stores counts only). Never delays or blocks the download. */
document.addEventListener("click", e => {
  const a = e.target.closest && e.target.closest("a[data-os]"); if (!a) return;
  const os = a.dataset.os, v = os === "mac" ? macVer : (versions.launcher || "");
  try { navigator.sendBeacon("dl.php?p=launcher&os=" + os + "&v=" + encodeURIComponent(v)); } catch (_) {}
});

/* Mac download: app/mac/version.json always names the latest build. */
fetch(K.launcher.macVersionUrl, { cache: "no-store" }).then(r => r.json()).then(j => {
  if (j.version) macVer = j.version;
  if (j.url) { macUrl = "https://github.com/kankonq8/my-app-releases/raw/main/" + j.url; document.querySelectorAll('a[data-mac]').forEach(a => a.href = macUrl); }
}).catch(() => {});

/* Live version numbers from the public releases repo (the site still works if this fails). */
let pending;
[["launcher", K.launcher.versionUrl], ...K.apps.filter(a => a.versionUrl).map(a => [a.id, a.versionUrl])].forEach(([id, url]) =>
  fetch(url, { cache: "no-store" }).then(r => r.json()).then(j => {
    if (j.version) { versions[id] = j.version; clearTimeout(pending); pending = setTimeout(() => { const y = scrollY; render(false); document.querySelectorAll(".rv").forEach(e => e.classList.add("in")); scrollTo(0, y); }, 150); }
  }).catch(() => {}));
