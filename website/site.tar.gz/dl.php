<?php
/* Kankon download counter (kankon.net). Counts only, never redirects, stores no IPs.
   Called by the site's download buttons (sendBeacon) and, optionally, by Kankon Launcher:
   dl.php?p=<product>&os=<win|mac>&v=<version>   ->  204 No Content */
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');
$clean = function ($k, $max) { $x = isset($_GET[$k]) ? (string)$_GET[$k] : ''; return preg_match('/^[A-Za-z0-9._-]{1,' . $max . '}$/', $x) ? $x : ''; };
$p = $clean('p', 32); $os = $clean('os', 8); $v = $clean('v', 20);
if ($p === '' || !in_array($os, array('win', 'mac'), true)) { http_response_code(400); exit; }
if ($v === '') $v = '?';
$file = __DIR__ . '/stats-data.php';
$fh = @fopen($file, 'c+');
if (!$fh) { http_response_code(500); exit; }
if (flock($fh, LOCK_EX)) {
  $raw = stream_get_contents($fh);
  $nl = strpos($raw, "\n");
  $d = $nl === false ? null : json_decode(substr($raw, $nl + 1), true);
  if (!is_array($d)) $d = array('c' => array(), 'day' => array());
  $key = "$p|$os|$v";
  if (count($d['c']) < 2000 || isset($d['c'][$key])) $d['c'][$key] = (isset($d['c'][$key]) ? $d['c'][$key] : 0) + 1;
  $day = gmdate('Y-m-d');
  $d['day'][$day] = (isset($d['day'][$day]) ? $d['day'][$day] : 0) + 1;
  if (count($d['day']) > 400) { ksort($d['day']); $d['day'] = array_slice($d['day'], -400, null, true); }
  ftruncate($fh, 0); rewind($fh);
  fwrite($fh, "<?php http_response_code(404); exit; ?>\n" . json_encode($d));
  fflush($fh); flock($fh, LOCK_UN);
}
fclose($fh);
http_response_code(204);
