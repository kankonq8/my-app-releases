/* kankon.net site content (English + Modern Standard Arabic).
   App/launcher text: English from description.json, Arabic from translator/website/descriptions-ar-msa.json.
   On every app or launcher release: add an entry at the top of "updates", update the app text, and raise the site version (VERSION + SITE_VERSION in index.html). */
window.KANKON = {
 "launcher": {
  "name": "Kankon Launcher",
  "icon": "img/launcher.png",
  "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/app/version.json",
  "download": "https://github.com/kankonq8/my-app-releases/raw/main/AppsLauncher-Setup.zip",
  "macVersionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/app/mac/version.json",
  "macDownload": "https://github.com/kankonq8/my-app-releases/raw/main/app/mac/2.21.0/Kankon-Launcher-2.21.0-mac.zip",
  "summary": {
   "en": "Kankon Launcher is one place to install, open and update all Kankon apps and games on Windows. Install it once, and every app stays on its latest version.",
   "ar": "Kankon Launcher هو المشغّل الموحّد لجميع البرامج: من خلاله تُثبَّت البرامج وتُفتح وتُحدَّث، دون الحاجة إلى البحث عن كل برنامج على حدة."
  },
  "features": {
   "en": [
    "A modern Home page: welcome banner, stat cards, quick access to your apps, section cards and a tip of the day.",
    "Apps are grouped in a side menu: Apps, Games, Tools and Networking, with a kankon.net button.",
    "Install any app with one click, then open it from the launcher. Apps that need administrator rights are started with them.",
    "Checks for new versions automatically and shows an Update button next to the app.",
    "Every download is verified (SHA-256) before it is installed, so only the original, unchanged file runs on your PC.",
    "Updates itself: when a new launcher version is released, it downloads it and restarts on its own.",
    "Every app has a Details page with a full description in English and Arabic.",
    "Uninstall any app from its Details page with one click.",
    "Internet plan card in the sidebar: used and plan size in GB, GB left and days until renewal, read from Network Monitor. Choose its look in Settings: battery, ring, bar or hidden.",
    "English by default, with an Arabic button that switches the whole window to right-to-left."
   ],
   "ar": [
    "صفحة رئيسية حديثة تضمّ: لافتة ترحيب، وبطاقات إحصائية، ووصولًا سريعًا إلى برامجك، وبطاقات للأقسام، ونصيحة اليوم.",
    "تُعرض البرامج في القائمة الجانبية مصنّفةً في أقسام: Apps (البرامج) وGames (الألعاب) وTools (الأدوات) وNetworking (الشبكات)، إلى جانب زر kankon.net.",
    "تثبيت أي برنامج بنقرة واحدة، ثم فتحه من المشغّل مباشرةً. ولا تعمل البرامج إلا من خلال المشغّل، وبصلاحيات المسؤول عند الحاجة إليها.",
    "يتحقّق تلقائيًا من توفّر إصدارات جديدة ويُظهر زر Update، ويتحقّق من سلامة كل ملف قبل تثبيته.",
    "يُتحقَّق من كل ملف يُنزَّل (SHA-256) قبل تثبيته، فلا يعمل على حاسوبك إلا الملف الأصلي دون أي تعديل.",
    "يحدّث نفسه تلقائيًا؛ فإذا صدر إصدار جديد من المشغّل نزّله وأعاد التشغيل.",
    "لكل برنامج وصف مفصّل باللغتين العربية والإنجليزية.",
    "إزالة أي برنامج بنقرة واحدة من صفحة تفاصيله.",
    "بطاقة باقة الإنترنت في الشريط الجانبي: المستهلك وحجم الباقة بالغيغابايت، والمتبقّي، والأيام الباقية حتى التجديد، تُقرأ من Network Monitor. واختر شكلها من الإعدادات: بطارية أو حلقة أو شريط، أو أخفِها.",
    "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
   ]
  },
  "how": {
   "en": [
    "Download Kankon Launcher and run the setup file. It installs for your Windows user and adds Start menu and desktop shortcuts.",
    "Open Kankon Launcher and pick a section from the side menu.",
    "Press Install next to an app, then Open.",
    "When Update appears next to an app, press it to get the new version."
   ],
   "ar": [
    "اختر القسم المطلوب من القائمة الجانبية.",
    "انقر Install بجانب البرنامج، ثم Open.",
    "عند ظهور زر Update انقره للحصول على الإصدار الجديد."
   ]
  },
  "req": {
   "en": [
    "Windows 10 or 11.",
    "Or a Mac with Apple Silicon (M1 or newer) or Intel.",
    "An internet connection for installs and updates.",
    "No administrator rights needed to install the launcher."
   ],
   "ar": [
    "نظام Windows 10 أو Windows 11.",
    "أو جهاز Mac بمعالج Apple Silicon (M1 أو أحدث) أو Intel.",
    "اتصال بالإنترنت لتثبيت البرامج وتحديثها.",
    "لا يحتاج تثبيت المشغّل إلى صلاحيات المسؤول."
   ]
  },
  "guides": [
   {
    "t": {
     "en": "Install Kankon Launcher",
     "ar": "تثبيت Kankon Launcher"
    },
    "en": [
     "Click Download for Windows at the top of this page. A zip file is downloaded.",
     "Open the downloaded file AppsLauncher-Setup.zip and extract it (right-click, Extract All).",
     "Run Kankon-Launcher-Setup.exe from the extracted folder.",
     "If Windows SmartScreen appears, click More info, then Run anyway.",
     "Wait a few seconds. Kankon Launcher opens by itself and adds shortcuts to the Start menu and the desktop."
    ],
    "ar": [
     "انقر «تنزيل لنظام Windows» في أعلى هذه الصفحة، فيُنزَّل ملف مضغوط (zip).",
     "انقر بزر الفأرة الأيمن على الملف المضغوط الذي نُزِّل (AppsLauncher-Setup.zip)، ثم اختر Extract All لاستخراج محتواه.",
     "شغّل الملف Kankon-Launcher-Setup.exe من المجلد المستخرَج.",
     "إذا ظهرت نافذة Windows SmartScreen، فانقر More info ثم Run anyway.",
     "انتظر بضع ثوانٍ؛ إذ يفتح Kankon Launcher تلقائيًا، ويضيف اختصارًا في قائمة «ابدأ» وعلى سطح المكتب."
    ]
   },
   {
    "t": {
     "en": "Install Kankon Launcher on a Mac",
     "ar": "تثبيت Kankon Launcher على جهاز Mac"
    },
    "en": [
     "Click Download for Mac at the top of this page. It works on every Mac, with Apple Silicon (M1 or newer) or Intel.",
     "Open the downloaded zip file; macOS extracts Kankon Launcher automatically.",
     "Drag Kankon Launcher into the Applications folder.",
     "The first time only, macOS may say Apple could not verify Kankon Launcher is free of malware (it is not notarized by Apple). Click Done, open System Settings › Privacy & Security, scroll down, click Open Anyway next to Kankon Launcher and confirm. After that it opens normally.",
     "Alternative, in Terminal: xattr -dr com.apple.quarantine \"/Applications/Kankon Launcher.app\". The same steps work for any other Kankon Mac app if it ever shows this message (apps installed by the launcher normally do not)."
    ],
    "ar": [
     "انقر «تنزيل لأجهزة Mac» في أعلى هذه الصفحة. وتعمل هذه النسخة على جميع أجهزة Mac، بمعالجات Apple Silicon (M1 أو أحدث) أو Intel.",
     "افتح الملف المضغوط الذي نُزِّل، فيستخرج نظام macOS برنامج Kankon Launcher تلقائيًا.",
     "اسحب Kankon Launcher إلى مجلد التطبيقات (Applications).",
     "في المرة الأولى فقط، قد يعرض نظام macOS رسالة بأنّ Apple لم تتمكّن من التحقّق من خلوّ Kankon Launcher من البرامج الضارة (لأنه غير موثَّق لدى Apple). انقر Done، ثم افتح System Settings، ثم Privacy & Security، ومرّر إلى الأسفل، وانقر Open Anyway بجانب Kankon Launcher، ثم أكّد. وبعد ذلك يُفتح بالطريقة المعتادة.",
     "طريقة بديلة من Terminal: xattr -dr com.apple.quarantine \"/Applications/Kankon Launcher.app\". وتصلح الخطوات نفسها لأي برنامج آخر من Kankon على Mac إذا ظهرت له هذه الرسالة (والبرامج التي يثبّتها المشغّل لا تظهر لها عادةً)."
    ]
   },
   {
    "t": {
     "en": "Install and open an app",
     "ar": "تثبيت برنامج وتشغيله"
    },
    "en": [
     "Pick a section from the side menu: Apps, Games, Tools or Networking.",
     "Click Install next to the app you want. The file is downloaded and verified before it is installed.",
     "When the button changes to Open, click it to start the app.",
     "If Windows asks for administrator rights, click Yes. Some apps need them to change system settings."
    ],
    "ar": [
     "اختر القسم المطلوب من القائمة الجانبية: Apps أو Games أو Tools أو Networking.",
     "انقر Install بجانب البرنامج المطلوب؛ فيُنزَّل الملف ويُتحقَّق من سلامته قبل تثبيته.",
     "عندما يتحوّل الزر إلى Open، انقره لتشغيل البرنامج.",
     "إذا طلب Windows صلاحيات المسؤول، فانقر Yes؛ إذ تحتاج بعض البرامج إليها لتعديل إعدادات النظام."
    ]
   },
   {
    "t": {
     "en": "Update the apps and the launcher",
     "ar": "تحديث البرامج والمشغّل"
    },
    "en": [
     "Open Kankon Launcher. It checks for new versions every time it starts.",
     "When Update appears next to an app, click it. The app closes, updates and is ready again in seconds.",
     "When a new version of the launcher itself is out, it downloads it and restarts on its own. You do not need to do anything."
    ],
    "ar": [
     "افتح Kankon Launcher؛ إذ يتحقّق من توفّر إصدارات جديدة في كل مرة يبدأ فيها.",
     "عند ظهور زر Update بجانب أي برنامج، انقره؛ فيُغلَق البرنامج ويُحدَّث، ويصبح جاهزًا خلال ثوانٍ.",
     "عند صدور إصدار جديد من المشغّل نفسه، ينزّله ويعيد التشغيل تلقائيًا، دون أي إجراء منك."
    ]
   },
   {
    "t": {
     "en": "Switch the language",
     "ar": "تغيير اللغة"
    },
    "en": [
     "Click العربية in the top corner to show the launcher in Arabic, from right to left.",
     "Click English to go back. The launcher always starts in English."
    ],
    "ar": [
     "انقر زر «العربية» في الزاوية العلوية لعرض المشغّل باللغة العربية ومن اليمين إلى اليسار.",
     "انقر English للعودة إلى الإنجليزية. ويبدأ المشغّل دائمًا باللغة الإنجليزية."
    ]
   }
  ],
  "shots": [
   {
    "ar": "img/shots/launcher/ar-01-networking.jpg",
    "cap": {
     "en": "Every app in one place, grouped by category: Apps, Games, Tools and Networking.",
     "ar": "جميع البرامج في مكان واحد، مصنّفة في أقسام، وبواجهة عربية من اليمين إلى اليسار."
    },
    "en": "img/shots/launcher/en-01-networking.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-02-games.jpg",
    "cap": {
     "en": "Games sit in their own section, ready to install and open with one click.",
     "ar": "قسم الألعاب: كل لعبة جاهزة للتثبيت والتشغيل بنقرة واحدة."
    },
    "en": "img/shots/launcher/en-02-games.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-03-tools.jpg",
    "cap": {
     "en": "Handy tools, such as Driver Manager, installed and kept current by the launcher.",
     "ar": "قسم الأدوات: أدوات مثل Driver Manager يثبّتها المشغّل ويُبقيها محدّثة."
    },
    "en": "img/shots/launcher/en-03-tools.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-04-details.jpg",
    "cap": {
     "en": "A full description of every app, with its main features and how to use it.",
     "ar": "وصف كامل لكل برنامج بالعربية، مع أبرز المزايا وطريقة الاستخدام."
    },
    "en": "img/shots/launcher/en-04-details.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-05-update-available.jpg",
    "cap": {
     "en": "Updates are spotted automatically, and one click installs them.",
     "ar": "يكتشف المشغّل التحديثات تلقائيًا، وتُثبَّت بنقرة واحدة."
    },
    "en": "img/shots/launcher/en-05-update-available.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-06-installer.jpg",
    "cap": {
     "en": "A small installer with no administrator rights needed.",
     "ar": "ملف تثبيت صغير لا يحتاج إلى صلاحيات المسؤول."
    },
    "en": "img/shots/launcher/en-06-installer.jpg"
   }
  ]
 },
 "categories": [
  {
   "id": "apps",
   "en": "Apps",
   "ar": "البرامج"
  },
  {
   "id": "games",
   "en": "Games",
   "ar": "الألعاب"
  },
  {
   "id": "tools",
   "en": "Tools",
   "ar": "الأدوات"
  },
  {
   "id": "networking",
   "en": "Networking",
   "ar": "الشبكات"
  }
 ],
 "apps": [
  {
   "id": "iReportAI",
   "name": "iReport AI",
   "cat": "apps",
   "icon": "img/ireport-ai.png",
   "platforms": [
    "iPhone / iPad",
    "Mac",
    "Android",
    "Huawei",
    "Web"
   ],
   "site": "https://ireportai.com/",
   "privacy": "https://ireportai.com/privacy-policy.html",
   "stores": [
    {
     "icon": "apple",
     "url": "https://apps.apple.com/us/app/ireport-ai/id6770074024",
     "small": {
      "en": "iPhone, iPad and Mac",
      "ar": "لأجهزة iPhone وiPad وMac"
     },
     "name": {
      "en": "App Store",
      "ar": "App Store"
     }
    },
    {
     "icon": "play",
     "url": "https://play.google.com/store/apps/details?id=com.sitsz.reports",
     "small": {
      "en": "Get it on",
      "ar": "احصل عليه من"
     },
     "name": {
      "en": "Google Play",
      "ar": "Google Play"
     }
    },
    {
     "icon": "huawei",
     "url": "https://appgallery.huawei.com/app/C118667349",
     "small": {
      "en": "Explore it on",
      "ar": "اكتشفه في"
     },
     "name": {
      "en": "AppGallery",
      "ar": "AppGallery"
     }
    },
    {
     "icon": "web",
     "url": "https://ireportai.com/index.html",
     "small": {
      "en": "No install",
      "ar": "دون تثبيت"
     },
     "name": {
      "en": "Web version",
      "ar": "نسخة الويب"
     }
    }
   ],
   "summary": {
    "en": "iReport AI is a field reporting app for inspection visits: pick the report type, enter the site, attach photos, and the app helps write, print and send the report, with AI photo analysis and text polishing, monthly visit sheets and a leave calendar. Arabic first, with English.",
    "ar": "iReport AI نظامٌ للتقارير الميدانية الخاصة بزيارات التفتيش: تختار نوع التقرير، وتُدخل الموقع، وترفق الصور، فيساعدك البرنامج على كتابة التقرير وطباعته وإرساله، مع تحليل الصور وتحسين الصياغة بالذكاء الاصطناعي، وكشوف الزيارات الشهرية، وتقويم للإجازات. وواجهته عربية أولًا، مع دعم الإنجليزية."
   },
   "features": {
    "en": [
     "Reports for many specialties: engineering, air conditioning, photocopiers, firefighting, agriculture, cleaning, hotel services, gas stations, cooperative facilities, technical reports and general reports. Date and time fill in automatically, and the governorate and region fill in from sites you visited before.",
     "AI tools: photo analysis, polishing your wording, a summary with a suggested recommendation, and an instant assistant. Data is sent to the AI only when you press the button.",
     "Faster input: voice dictation, a site sketch tool, reading the serial and model from a nameplate photo, and coloured highlighting of important words that is printed in the report.",
     "Photos: optional stamp with date, day, time, site and temperature, continuous capture, an album for each site, and an editor with pen, circle, arrow, magnifier, blur and rotate.",
     "Records: autosave, a report log with search and month filter, sharing, printing, a trash with restore, version history, sending a report to a colleague, and a quality check before sending.",
     "Printing and PDF: share as PDF, bulk printing, compressed or high-quality PDF, and one combined PDF.",
     "Automatic reports for routes across several dates and time windows, without duplicates.",
     "Monthly visit sheet with a signature page and archive, and the site allowance sheet.",
     "Dashboard: reports today, this week, this month and this year, progress towards the monthly target, and a breakdown by governorate. iPhone home-screen and lock-screen widgets.",
     "Calendar and leave: leave types and balance, leave statements as PDF, flexible or shift work settings, reminders, and calculators for permissions and working hours.",
     "Security and backup: app lock with a PIN or biometrics, a full backup including photos, and an optional online account with encrypted sync (needs an invitation code)."
    ],
    "ar": [
     "تقارير لتخصّصات متعدّدة: الهندسة، والتكييف، وآلات التصوير، والإطفاء، والزراعة، والنظافة، والخدمات الفندقية، ومحطات الوقود، ومرافق الجمعيات التعاونية، والتقارير الفنية، والتقارير العامة. ويُملأ التاريخ والوقت تلقائيًا، وتُملأ المحافظة والمنطقة من المواقع التي زرتها سابقًا.",
     "أدوات الذكاء الاصطناعي: تحليل الصور، وتحسين الصياغة، وتلخيص مع توصية مقترحة، ومساعد فوري. ولا تُرسَل البيانات إلى الذكاء الاصطناعي إلا عند الضغط على الزرّ.",
     "إدخال أسرع: الإملاء الصوتي، وأداة لرسم مخطّط الموقع، وقراءة الرقم التسلسلي والطراز من صورة لوحة البيانات، وتلوين الكلمات المهمّة بحيث يظهر التلوين في التقرير المطبوع.",
     "الصور: ختم اختياري يتضمّن التاريخ واليوم والوقت والموقع ودرجة الحرارة، والتصوير المتتابع، وألبوم لكل موقع، ومحرّر للصور فيه القلم والدائرة والسهم والمكبّر والتمويه والتدوير.",
     "السجلّات: حفظ تلقائي، وسجلّ للتقارير مع البحث والتصفية حسب الشهر، والمشاركة، والطباعة، وسلّة محذوفات مع الاستعادة، وسجلّ للإصدارات، وتحويل التقرير إلى زميل، وفحص الجودة قبل الإرسال.",
     "الطباعة وملفات PDF: المشاركة بصيغة PDF، والطباعة الجماعية، وملف PDF مضغوط أو عالي الجودة، ودمج التقارير في ملف PDF واحد.",
     "تقارير تلقائية لخطوط السير على عدّة تواريخ وفترات زمنية، دون تكرار.",
     "كشف الزيارات الشهري مع صفحة التوقيع والأرشيف، وكشف بدل الموقع.",
     "لوحة متابعة: عدد التقارير اليوم وهذا الأسبوع وهذا الشهر وهذه السنة، ونسبة الإنجاز من الهدف الشهري، وتوزيع التقارير حسب المحافظات، مع أدوات (Widgets) للشاشة الرئيسية وشاشة القفل في iPhone.",
     "التقويم والإجازات: أنواع الإجازات ورصيدها، وكشوف الإجازات بصيغة PDF، وإعدادات العمل المرن أو بنظام النوبات، والتذكيرات، وحاسبات للاستئذان وساعات العمل.",
     "الأمان والنسخ الاحتياطي: قفل البرنامج برمز PIN أو بالبصمة، ونسخة احتياطية كاملة تشمل الصور، وحساب إلكتروني اختياري للمزامنة المشفّرة (يتطلّب رمز دعوة)."
    ]
   },
   "how": {
    "en": [
     "Install it from the App Store (iPhone, iPad or Mac), Google Play or Huawei AppGallery, or open the web version in your browser with no install.",
     "Enter your details once: full name and specialty.",
     "Choose the report type, type the site, attach photos and press analyse, or write the text and use the summary tool.",
     "Press save. The report appears in the log, ready to print or share as PDF."
    ],
    "ar": [
     "ثبّته من App Store (لأجهزة iPhone أو iPad أو Mac)، أو من Google Play، أو من Huawei AppGallery، أو افتح نسخة الويب في المتصفح دون تثبيت.",
     "أدخل بياناتك مرة واحدة: الاسم الكامل والتخصّص.",
     "اختر نوع التقرير، واكتب اسم الموقع، وأرفق الصور ثم اضغط زرّ التحليل، أو اكتب النص واستخدم أداة التلخيص.",
     "اضغط «حفظ»، فيظهر التقرير في السجلّ جاهزًا للطباعة أو للمشاركة بصيغة PDF."
    ]
   },
   "req": {
    "en": [
     "iPhone, iPad or Mac (App Store), Android (Google Play), a Huawei phone (AppGallery), or any modern browser for the web version.",
     "Reports, photos and settings stay on your device. An internet connection is needed for the AI tools and the optional online account.",
     "The AI tools use Anthropic's Claude, and data is sent only when you press the button. Details are in the privacy policy."
    ],
    "ar": [
     "جهاز iPhone أو iPad أو Mac (من App Store)، أو جهاز Android (من Google Play)، أو هاتف Huawei (من AppGallery)، أو أي متصفح حديث لنسخة الويب.",
     "تبقى التقارير والصور والإعدادات على جهازك، ويلزم الاتصال بالإنترنت لأدوات الذكاء الاصطناعي وللحساب الإلكتروني الاختياري.",
     "تعتمد أدوات الذكاء الاصطناعي على Claude من Anthropic، ولا تُرسَل البيانات إلا عند الضغط على الزرّ. والتفاصيل في سياسة الخصوصية."
    ]
   }
  },
  {
   "id": "KankonMarkets",
   "name": "Kankon Markets",
   "os": [
    "win",
    "mac"
   ],
   "cat": "apps",
   "icon": "img/kankon-markets.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/KankonMarkets/version.json",
   "summary": {
    "en": "Kankon Markets shows live prices, charts and a rise/fall analysis for gold, silver, Bitcoin, Kuwait crude, US crude and more, in one window. It is a prices and analysis app only: it does not buy or sell anything, needs no trading account and is not financial advice.",
    "ar": "يعرض Kankon Markets الأسعار المباشرة والرسوم البيانية وتحليل الصعود والهبوط للذهب والفضة والبيتكوين ونفط الكويت وخام غرب تكساس وغيرها، في نافذة واحدة. وهو برنامج للأسعار والتحليل فقط: لا يبيع ولا يشتري شيئًا، ولا يحتاج إلى حساب تداول، ولا يُعدّ نصيحة مالية."
   },
   "features": {
    "en": [
     "Watchlist of 20 markets, each with its live price, today's change and a small chart. Metals: Gold, Silver, Platinum, Copper. Energy: Kuwait Crude (KEC), US Crude (WTI), Brent Crude, Natural Gas. Crypto: Bitcoin, Ethereum, Solana, XRP. Currencies: US Dollar to Kuwaiti Dinar, Euro, British Pound, Japanese Yen, Saudi Riyal. Indices: S&P 500, Nasdaq, Dow Jones.",
     "Big chart for every market: 1 day, 1 week, 1 month, 3 months, 6 months, 1 year and 5 years, as candles or a line, with the 20 and 50-day averages, support and resistance lines, and a crosshair that shows open, high, low and close for any point.",
     "Chart tools: Bollinger Bands, volume, RSI and MACD panes, your own level and trend lines (saved for each market), and Compare, which puts two markets on one chart as percent change.",
     "Market hours in Kuwait time: whether crypto, metals and oil, currencies and the US, Japanese and UK stock markets are open now, and when they open or close.",
     "Daily brief: with one press, or automatically each morning, the AI Assistant writes a short summary of all your markets, your portfolio and the main headlines.",
     "Kuwait and Gulf stocks: National Bank of Kuwait, Kuwait Finance House and Zain in the watchlist, and Boubyan, Gulf Bank, Mabanee, Saudi Aramco, Al Rajhi, SABIC, Emaar and QNB to add. Boursa Kuwait prices are shown in Kuwaiti dinar, with Boursa Kuwait and Saudi Exchange opening hours.",
     "Mini window: a small always-on-top window with your markets, their prices and small charts.",
     "Export: save the chart as a picture (PNG), and the prices or your portfolio as a spreadsheet file (CSV).",
     "Light theme in addition to the dark theme.",
     "Rise / Fall Analyzer: a gauge from strong fall to strong rise, the trend, RSI, the price against the 50 and 200-day averages, support, resistance and MACD, and a written analysis in English or Arabic that explains what the numbers mean. Everything is calculated from the price history; it does not predict the future and is not financial advice.",
     "Gold in Kuwait: the price of a gram of gold in Kuwaiti dinar for 24K, 22K, 21K and 18K, calculated from the world gold price and the dollar rate (shops add making charges).",
     "News tab: headlines in English or Arabic for the selected market, and a summary of the price move over the last 15 minutes, 30 minutes, 1 hour or 4 hours, refreshed automatically.",
     "AI Assistant tab: ask Claude about any market in plain words. It sees the prices, the analyzer, the recent moves and the headlines in the app. It uses your own Anthropic API key, saved only on your computer; each question costs a few cents from your Anthropic credit. Chats are saved on your computer with a History list. Not financial advice.",
     "Add more markets: Palladium, Heating Oil, BNB, Dogecoin, UAE Dirham, Egyptian Pound, Nikkei 225, FTSE 100, or any Yahoo Finance symbol (for example AAPL or Saudi Aramco 2222.SR). Remove any market with the × button.",
     "Prices refresh every minute. The last prices are saved, so the app still opens without internet.",
     "Alerts: a computer notification when a price goes above or below a number, or moves more than a set % today, with a bell next to the price.",
     "Portfolio: what you own, valued live in Kuwaiti dinar, with today's change and profit or loss. Saved only on your computer.",
     "Calculator: currency converter, gold and silver price by weight, karat and making charge, and the value of any amount of any market.",
     "Help page (Help button or F1): a quick start, a full guide to every part of the app and a step-by-step Anthropic API key guide. A− and A+ make everything in the window bigger or smaller (80% to 180%).",
     "English by default, with an Arabic button (right to left)."
    ],
    "ar": [
     "قائمة متابعة تضمّ 20 سوقًا، لكلٍّ منها سعره المباشر وتغيّره اليوم ورسم بياني صغير. المعادن: الذهب والفضة والبلاتين والنحاس. الطاقة: نفط الكويت (KEC) وخام غرب تكساس الوسيط (WTI) وخام برنت والغاز الطبيعي. العملات الرقمية: بيتكوين وإيثيريوم وسولانا وXRP. العملات: الدولار مقابل الدينار الكويتي، واليورو، والجنيه الإسترليني، والين الياباني، والريال السعودي. المؤشرات: S&P 500 وناسداك وداو جونز.",
     "رسم بياني كبير لكل سوق لفترات: يوم، وأسبوع، وشهر، و3 أشهر، و6 أشهر، وسنة، و5 سنوات، بالشموع أو بالخط، مع متوسطَي 20 و50 يومًا، وخطوط الدعم والمقاومة، وعند تمرير الفأرة على أي نقطة تظهر أسعار الافتتاح والأعلى والأدنى والإغلاق.",
     "أدوات الرسم البياني: نطاقات بولينجر، ولوحات حجم التداول وRSI وMACD، وخطوط المستوى والاتجاه التي ترسمها بنفسك (وتُحفظ لكل سوق)، وخاصية المقارنة التي تعرض سوقين على رسم واحد بنسبة التغيّر.",
     "أوقات الأسواق بتوقيت الكويت: هل أسواق العملات الرقمية والمعادن والنفط والعملات وأسواق الأسهم الأمريكية واليابانية والبريطانية مفتوحة الآن، ومتى تفتح أو تُغلق.",
     "الملخّص اليومي: بنقرة واحدة، أو تلقائيًا كل صباح، يكتب المساعد الذكي ملخّصًا موجزًا لجميع أسواقك ومحفظتك وأهمّ العناوين.",
     "أسهم الكويت والخليج: بنك الكويت الوطني وبيت التمويل الكويتي وزين في قائمة المتابعة، ويمكن إضافة بوبيان وبنك الخليج والمباني وأرامكو السعودية والراجحي وسابك وإعمار وبنك قطر الوطني. وتُعرض أسعار بورصة الكويت بالدينار الكويتي، مع أوقات تداول بورصة الكويت والسوق المالية السعودية.",
     "النافذة الصغيرة: نافذة صغيرة تبقى فوق النوافذ الأخرى، تعرض أسواقك وأسعارها ورسومها البيانية الصغيرة.",
     "التصدير: حفظ الرسم البياني صورةً (PNG)، وحفظ الأسعار أو محفظتك في ملف جدول بيانات (CSV).",
     "الوضع الفاتح إلى جانب الوضع الداكن.",
     "محلّل الصعود والهبوط: مقياس من هبوط قوي إلى صعود قوي، والاتجاه، ومؤشّر RSI، والسعر مقارنةً بمتوسطَي 50 يومًا و200 يوم، والدعم والمقاومة وMACD، مع تحليل مكتوب بالعربية أو الإنجليزية يشرح دلالة الأرقام. وكل ذلك محسوب من تاريخ الأسعار، فلا يتنبّأ بالمستقبل، ولا يُعدّ نصيحة مالية.",
     "الذهب في الكويت: سعر غرام الذهب بالدينار الكويتي لعيار 24 و22 و21 و18، محسوبًا من سعر الذهب العالمي وسعر الدولار (وتضيف المحلات أجرة الصنعة).",
     "تبويب News (الأخبار): عناوين الأخبار بالعربية أو الإنجليزية للسوق المختار، وملخّص لحركة السعر خلال آخر 15 دقيقة أو 30 دقيقة أو ساعة أو 4 ساعات، ويُحدَّث تلقائيًا.",
     "تبويب AI Assistant (المساعد الذكي): اسأل Claude عن أي سوق بلغة عادية، فهو يطّلع على الأسعار والمحلّل والحركات الأخيرة وعناوين الأخبار في البرنامج. ويستخدم مفتاح Anthropic API الخاص بك، المحفوظ على حاسوبك فقط، ويكلّف كل سؤال بضعة سنتات من رصيدك لدى Anthropic. وتُحفظ المحادثات على حاسوبك مع قائمة History للرجوع إليها. ولا يُعدّ نصيحة مالية.",
     "إضافة أسواق أخرى: البلاديوم، وزيت التدفئة، وBNB، ودوجكوين، والدرهم الإماراتي، والجنيه المصري، ونيكاي 225، وفوتسي 100، أو أي رمز من Yahoo Finance (مثل AAPL أو أرامكو السعودية 2222.SR). ويمكن حذف أي سوق بزرّ ×.",
     "تُحدَّث الأسعار كل دقيقة، وتُحفظ آخر الأسعار، فيُفتح البرنامج حتى دون اتصال بالإنترنت.",
     "التنبيهات: إشعار على الحاسوب عندما يرتفع السعر فوق رقم معيّن أو ينخفض تحته، أو يتحرّك اليوم بأكثر من نسبة تحدّدها، مع جرس بجانب السعر.",
     "المحفظة: ما تملكه مُقيَّمًا مباشرةً بالدينار الكويتي، مع تغيّر اليوم والربح أو الخسارة، وتُحفظ على حاسوبك فقط.",
     "الحاسبة: محوّل للعملات، وسعر الذهب والفضة بحسب الوزن والعيار وأجرة الصنعة، وقيمة أي كمية من أي سوق.",
     "صفحة المساعدة (زرّ Help أو مفتاح F1): دليل سريع للبدء، ودليل كامل لكل أجزاء البرنامج، وشرح خطوة بخطوة لمفتاح Anthropic API. ويكبّر زرّا A− وA+ محتوى النافذة كله أو يصغّرانه (من 80% إلى 180%).",
     "الواجهة بالإنجليزية افتراضيًا، مع زرّ للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Apps and click Install next to Kankon Markets, then Open.",
     "Click a market in the watchlist on the left. Use the buttons at the top to filter by Metals, Energy, Crypto, Currencies or Indices.",
     "Choose the period (1D to 5Y) and Candles or Line above the chart. Move the mouse over the chart to see the prices of any day.",
     "Read the Rise / Fall Analyzer on the right. When Gold is selected, the gold price per gram in Kuwaiti dinar is shown below it.",
     "Click + Add market to add more markets, or type any Yahoo Finance symbol.",
     "Click Help at the top (or press F1) for the full guide."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Apps (البرامج)، ثم انقر Install بجانب Kankon Markets، ثم Open.",
     "انقر سوقًا من قائمة المتابعة على الجانب، واستخدم الأزرار في الأعلى لعرض Metals أو Energy أو Crypto أو Currencies أو Indices.",
     "اختر الفترة (من 1D إلى 5Y) وCandles أو Line فوق الرسم البياني، وحرّك الفأرة على الرسم لعرض أسعار أي يوم.",
     "اقرأ Rise / Fall Analyzer (محلّل الصعود والهبوط) على الجانب. وعند اختيار Gold يظهر تحته سعر غرام الذهب بالدينار الكويتي.",
     "انقر + Add market لإضافة أسواق أخرى، أو اكتب أي رمز من Yahoo Finance.",
     "انقر Help في الأعلى (أو اضغط F1) لعرض الدليل الكامل."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit), or a Mac (Apple Silicon or Intel), through Kankon Launcher for Mac. No administrator rights needed.",
     "Internet for live prices. Opens from Kankon Launcher (Apps), which installs and updates it.",
     "Prices and analysis only, not financial advice. The app does not buy or sell and needs no trading account."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit)، أو جهاز Mac (بمعالج Apple Silicon أو Intel) من خلال نسخة Kankon Launcher لأجهزة Mac. ولا يحتاج إلى صلاحيات المسؤول.",
     "يحتاج إلى اتصال بالإنترنت للأسعار المباشرة، ويُفتح من خلال Kankon Launcher، من قسم Apps (البرامج)، وهو الذي يثبّته ويحدّثه.",
     "للأسعار والتحليل فقط، ولا يُعدّ نصيحة مالية. ولا يبيع البرنامج ولا يشتري، ولا يحتاج إلى حساب تداول."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Where the prices come from",
      "ar": "مصادر الأسعار"
     },
     "en": [
      "Yahoo Finance: gold, silver, platinum, copper and oil are futures prices (COMEX and NYMEX); crypto, currencies and indices are market prices. They may be delayed by up to 15 minutes.",
      "Kuwait Crude: there is no free live price for Kuwait Export Crude. The app shows the official end-of-day price for each trading day from OilPrice.com and saves every day on your computer, so its chart grows day by day.",
      "The analyzer for Kuwait crude starts after 30 days of history."
     ],
     "ar": [
      "Yahoo Finance: أسعار الذهب والفضة والبلاتين والنحاس والنفط هي أسعار عقود آجلة (COMEX وNYMEX)، وأسعار العملات الرقمية والعملات والمؤشرات هي أسعار السوق، وقد تتأخّر حتى 15 دقيقة.",
      "نفط الكويت: لا يتوفّر سعر مباشر مجاني لخام التصدير الكويتي، لذا يعرض البرنامج سعر الإغلاق الرسمي لكل يوم تداول من OilPrice.com، ويحفظ كل يوم على حاسوبك، فيتّسع الرسم البياني يومًا بعد يوم.",
      "يبدأ تحليل نفط الكويت بعد جمع أسعار 30 يومًا."
     ]
    },
    {
     "t": {
      "en": "Set up the AI Assistant",
      "ar": "إعداد المساعد الذكي"
     },
     "en": [
      "Create an account at console.anthropic.com and add a small credit (pay as you go).",
      "Create an API key on the API Keys page and copy it.",
      "In Kankon Markets, open the AI Assistant tab, paste the key and click Save. The key is saved only on this computer and sent only to Anthropic."
     ],
     "ar": [
      "أنشئ حسابًا في console.anthropic.com وأضف رصيدًا صغيرًا (الدفع حسب الاستخدام).",
      "أنشئ مفتاح API من صفحة API Keys وانسخه.",
      "في Kankon Markets افتح تبويب AI Assistant، والصق المفتاح، ثم انقر Save. ويُحفظ المفتاح على هذا الحاسوب فقط، ولا يُرسل إلا إلى Anthropic."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/kankonmarkets/win-en-01-gold.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-01-gold.jpg",
     "cap": {
      "en": "Gold: live price, a one-month candle chart with averages, support and resistance, and the Rise / Fall Analyzer with a written analysis.",
      "ar": "الذهب: السعر المباشر، ورسم بالشموع لشهر مع المتوسطات والدعم والمقاومة، ومحلّل الصعود والهبوط مع تحليل مكتوب."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-02-bitcoin.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-02-bitcoin.jpg",
     "cap": {
      "en": "Bitcoin with its chart and analysis.",
      "ar": "البيتكوين مع رسمه البياني وتحليله."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-03-kuwait-crude.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-03-kuwait-crude.jpg",
     "cap": {
      "en": "Kuwait crude (KEC): the official end-of-day price, saved day by day.",
      "ar": "نفط الكويت (KEC): سعر الإغلاق الرسمي اليومي، محفوظًا يومًا بعد يوم."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-04-us-crude.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-04-us-crude.jpg",
     "cap": {
      "en": "US crude (WTI) with the 20 and 50-day averages.",
      "ar": "خام غرب تكساس (WTI) مع متوسطَي 20 و50 يومًا."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-05-news.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-05-news.jpg",
     "cap": {
      "en": "News: what happened in the last hour and the latest headlines for the selected market.",
      "ar": "الأخبار: ما حدث خلال الساعة الأخيرة وأحدث العناوين للسوق المختار."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-06-assistant.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-06-assistant.jpg",
     "cap": {
      "en": "AI Assistant: ask Claude about any market, with your own Anthropic API key.",
      "ar": "المساعد الذكي: اسأل Claude عن أي سوق باستخدام مفتاح Anthropic API الخاص بك."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-08-help.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-08-help.jpg",
     "cap": {
      "en": "Help: a quick start and a full guide to the app, including the API key steps.",
      "ar": "المساعدة: دليل سريع للبدء ودليل كامل للبرنامج، يتضمّن خطوات إنشاء مفتاح API."
     }
    },
    {
     "src": "img/shots/kankonmarkets/win-en-10-alerts.jpg",
     "cap": {
      "en": "Alerts: get a notification when a price reaches your number.",
      "ar": "التنبيهات: إشعار عندما يصل السعر إلى الرقم الذي تحدّده."
     }
    },
    {
     "src": "img/shots/kankonmarkets/win-en-11-portfolio.jpg",
     "cap": {
      "en": "Portfolio: what you own, valued live in Kuwaiti dinar (sample data).",
      "ar": "المحفظة: ما تملكه مُقيَّمًا مباشرةً بالدينار الكويتي (بيانات تجريبية)."
     }
    },
    {
     "src": "img/shots/kankonmarkets/win-ar-12-calculator.jpg",
     "cap": {
      "en": "Calculator (Arabic): currency converter and gold price by weight and karat.",
      "ar": "الحاسبة: محوّل العملات وسعر الذهب بحسب الوزن والعيار."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-13-indicators.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-13-indicators.jpg",
     "cap": {
      "en": "Chart tools: Bollinger Bands, volume, RSI and MACD under the price chart.",
      "ar": "أدوات الرسم: نطاقات بولينجر وحجم التداول وRSI وMACD أسفل رسم السعر."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-14-compare.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-14-compare.jpg",
     "cap": {
      "en": "Compare: two markets on one chart as percent change.",
      "ar": "المقارنة: سوقان على رسم واحد بنسبة التغيّر."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-15-hours.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-15-hours.jpg",
     "cap": {
      "en": "Market hours in Kuwait time, next to the gold price in Kuwaiti dinar.",
      "ar": "أوقات الأسواق بتوقيت الكويت، بجانب سعر الذهب بالدينار الكويتي."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-16-gulf.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-16-gulf.jpg",
     "cap": {
      "en": "Gulf stocks: National Bank of Kuwait in Kuwaiti dinar, with Boursa Kuwait hours.",
      "ar": "أسهم الخليج: بنك الكويت الوطني بالدينار الكويتي، مع أوقات تداول بورصة الكويت."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-17-light.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-17-light.jpg",
     "cap": {
      "en": "The light theme.",
      "ar": "الوضع الفاتح."
     }
    },
    {
     "en": "img/shots/kankonmarkets/win-en-18-mini.jpg",
     "ar": "img/shots/kankonmarkets/win-ar-18-mini.jpg",
     "cap": {
      "en": "The mini window, always on top.",
      "ar": "النافذة الصغيرة، فوق النوافذ الأخرى دائمًا."
     }
    },
    {
     "src": "img/shots/kankonmarkets/mac-en-01-gold.jpg",
     "cap": {
      "en": "Kankon Markets on a Mac.",
      "ar": "Kankon Markets على جهاز Mac."
     }
    }
   ],
   "warn": {
    "en": "Prices, charts, analysis, news and AI answers are for information only and are not investment advice. Prices can be delayed or wrong.",
    "ar": "الأسعار والرسوم البيانية والتحليلات والأخبار وإجابات الذكاء الاصطناعي للاطلاع فقط، وليست نصيحة استثمارية. وقد تتأخر الأسعار أو تكون غير دقيقة."
   }
  },
  {
   "id": "SizeFinder",
   "name": "Size Finder",
   "os": [
    "win",
    "mac"
   ],
   "cat": "apps",
   "icon": "img/size-finder.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/SizeFinder/version.json",
   "summary": {
    "en": "Size Finder tells you your clothing and shoe size in seconds. Choose the person, men, women, boys or girls, and the kind of clothes, set your height, weight and body shape, and it shows the size that fits best (XS to 5XL), its measurements, the same size in EU, US, UK and Asian sizes, and short tips on how it will fit.",
    "ar": "Size Finder يحدّد لك مقاس ملابسك وحذائك في ثوانٍ. اختر الشخص، ثم الفئة (رجال أو نساء أو أولاد أو بنات) ونوع الملابس، وأدخل طولك ووزنك وشكل جسمك، فيعرض لك المقاس الأنسب (من XS إلى 5XL) وقياساته، والمقاس المقابل له في الأنظمة الأوروبية والأمريكية والبريطانية والآسيوية، مع نصائح قصيرة عن ملاءمته لك."
   },
   "features": {
    "en": [
     "Men, women, boys and girls, each with its own size chart. Kids sizes go from 2 to 15 years (EU 92 to 170 by height), with kids shoes (EU 20 to 36) and kids thobe and abaya.",
     "Kinds of clothes: Trousers, Shirt / T-shirt (Top / Blouse for women), Thobe (Abaya for women), Jacket and Shoes.",
     "Height and weight: drag the slider or press − and + to change by one step (adults 140 to 210 cm and 40 to 160 kg, kids 80 to 185 cm and 10 to 90 kg).",
     "Units: cm/kg or ft/lb with one tap. In ft/lb, height shows in feet and inches (for example 5' 6\"), weight in pounds and measurements in inches.",
     "Body shape: Slim, Medium or Broad moves the result down or up when you are between two sizes.",
     "I know my measurements (optional): enter your waist and chest. Trousers then follow the waist, and shirts, jackets and thobes follow the chest, for a more exact size.",
     "Your size in big letters, with In stock or Out of stock. If it is out of stock, it tells you the nearest size in stock.",
     "Fit tips: trouser length (for example \"Runs longer by about 6 cm\"), sleeve length for shirts and jackets, and a waist tip when the size may feel snug or relaxed.",
     "Measurements of the recommended size: trousers (waist, hip, length), shirts and jackets (chest, length, sleeve), thobe or abaya (length, chest, sleeve).",
     "Thobe and abaya: the size number (length in inches, for example 56) that reaches your ankle, and the cut to take for the width.",
     "Shoes: measure your foot from the heel to the longest toe to get your EU, US and UK size. Between two sizes, it takes the bigger one.",
     "The same size in EU, US, UK and Asia (Asian sizes usually run one size small).",
     "Saved people: add yourself, your family and anyone else, rename or delete them. Each person keeps their own height, weight, shape, foot and measurements.",
     "Copy result: one button copies a short summary (person, size, measurements and tips) to paste in WhatsApp or send to a shop.",
     "Your own size chart: all sizes, measurements, conversions, shoes and stock status are in one file, size-chart.json. Press Edit size chart, change the numbers, save, then press Reload.",
     "English by default, with an Arabic button (right to left)."
    ],
    "ar": [
     "للرجال والنساء والأولاد والبنات، ولكلٍّ منهم جدول مقاسات خاص. ومقاسات الأطفال من سنتين إلى 15 سنة (من EU 92 إلى 170 بحسب الطول)، مع أحذية الأطفال (من EU 20 إلى 36) والثوب والعباءة للأطفال.",
     "أنواع الملابس: البنطال، والقميص / التيشيرت (البلوزة / التوب للنساء)، والثوب (العباءة للنساء)، والجاكيت، والأحذية.",
     "الطول والوزن: اسحب المؤشّر أو انقر − و+ للتغيير خطوةً واحدة (للكبار من 140 إلى 210 سم ومن 40 إلى 160 كغ، وللأطفال من 80 إلى 185 سم ومن 10 إلى 90 كغ).",
     "الوحدات: سم/كغ أو قدم/رطل بنقرة واحدة. وفي وحدة قدم/رطل يظهر الطول بالقدم والإنش (مثل 5' 6\")، والوزن بالرطل، والقياسات بالإنش.",
     "شكل الجسم: نحيف أو متوسط أو عريض، فيُصغّر المقاس أو يُكبّره إذا كنت بين مقاسين.",
     "خيار I know my measurements (اختياري): أدخل محيط الخصر والصدر، فيُحدَّد مقاس البنطال بحسب الخصر، ومقاس القميص والجاكيت والثوب بحسب الصدر، ليكون المقاس أدقّ.",
     "يظهر مقاسك بحرف كبير مع حالة التوفّر: «متوفر» أو «غير متوفر»، وإن لم يكن متوفرًا يقترح أقرب مقاس متوفر.",
     "نصائح الملاءمة: طول البنطال (مثل «أطول بنحو 6 سم»)، وطول الأكمام للقميص والجاكيت، وتنبيه إذا كان المقاس ضيّقًا أو واسعًا قليلًا عند الخصر.",
     "قياسات المقاس المقترح: البنطال (الخصر، والورك، والطول)، والقميص والجاكيت (الصدر، والطول، والكمّ)، والثوب أو العباءة (الطول، والصدر، والكمّ).",
     "الثوب والعباءة: رقم المقاس (الطول بالإنش، مثل 56) الذي يصل إلى الكاحل، والقَصّة المناسبة للعرض.",
     "الأحذية: قِس قدمك من الكعب إلى أطول إصبع، فيظهر مقاسك الأوروبي والأمريكي والبريطاني. وإذا كنت بين مقاسين، يُختار الأكبر.",
     "المقاس نفسه في أنظمة EU وUS وUK وآسيا (وغالبًا ما تكون المقاسات الآسيوية أصغر بمقاس واحد).",
     "الأشخاص المحفوظون: أضف نفسك وأفراد أسرتك وغيرهم، وغيّر أسماءهم أو احذفهم. ويحتفظ كل شخص بطوله ووزنه وشكل جسمه وطول قدمه وقياساته.",
     "نسخ النتيجة: زرّ واحد ينسخ ملخّصًا قصيرًا (الشخص، والمقاس، والقياسات، والنصائح) للصقه في واتساب أو إرساله إلى متجر.",
     "جدول مقاساتك الخاص: جميع المقاسات والقياسات والتحويلات والأحذية وحالة التوفّر في ملف واحد هو size-chart.json. انقر Edit size chart، وغيّر الأرقام، واحفظ، ثم انقر Reload.",
     "الواجهة بالإنجليزية افتراضيًا، مع زرّ للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Apps and click Install next to Size Finder, then Open.",
     "Choose the person at the top, or press + Add person (press Rename to give the name).",
     "Choose Men, Women, Boys or Girls and the kind of clothes.",
     "Choose cm/kg or ft/lb, then set height and weight (or foot length for shoes).",
     "Choose the body shape, or tick I know my measurements and enter waist and chest.",
     "Read the size in the card below, with the tips, the measurements and the other size systems, and press Copy result to send it to anyone."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Apps (البرامج)، ثم انقر Install بجانب Size Finder، ثم Open.",
     "اختر الشخص في الأعلى، أو انقر + Add person (وانقر Rename لكتابة اسمه).",
     "اختر Men (رجال) أو Women (نساء) أو Boys (أولاد) أو Girls (بنات)، ثم نوع الملابس.",
     "اختر سم/كغ أو قدم/رطل، ثم حدّد الطول والوزن (أو طول القدم للأحذية).",
     "اختر شكل الجسم، أو فعّل I know my measurements وأدخل الخصر والصدر.",
     "اقرأ المقاس في البطاقة السفلية مع النصائح والقياسات والأنظمة الأخرى، ثم انقر Copy result لإرسال النتيجة إلى من تشاء."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit), or a Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No admin rights and no internet needed; nothing is sent anywhere.",
     "Opens from Kankon Launcher (Apps), which installs and updates it."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit)، أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon أو Intel) من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول ولا إلى اتصال بالإنترنت، ولا يرسل أي بيانات إلى أي جهة.",
     "يُفتح من خلال Kankon Launcher، من قسم Apps (البرامج)، وهو الذي يثبّته ويحدّثه."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "How the size is chosen",
      "ar": "كيف يُختار المقاس"
     },
     "en": [
      "Each size has a top weight and a top height. Weight counts for 70% and height for 30%, then the body shape moves it: Slim a bit smaller, Broad a bit bigger.",
      "If you are more than 3 kg above a size's weight range, it goes one size up so the clothes close at the waist (not for Slim).",
      "With I know my measurements on, it picks the first size made for your waist (trousers) or your chest (other clothes).",
      "The ideal trouser length and sleeve are a share of your height; the tips show how much longer or shorter the size runs."
     ],
     "ar": [
      "لكل مقاس حدٌّ أعلى للوزن وحدٌّ أعلى للطول. ويُحسب الوزن بنسبة 70% والطول بنسبة 30%، ثم يُعدَّل بحسب شكل الجسم: النحيف أصغر قليلًا، والعريض أكبر قليلًا.",
      "إذا زاد وزنك على حدّ المقاس بأكثر من 3 كغ، يُرفع المقاس مقاسًا واحدًا حتى تُغلق الملابس عند الخصر (عدا النحيف).",
      "عند تفعيل I know my measurements، يُختار أول مقاس يناسب خصرك (للبنطال) أو صدرك (لبقية الملابس).",
      "يُحسب الطول المثالي للبنطال والكمّ نسبةً من طولك، وتبيّن النصائح مقدار زيادة المقاس أو نقصه."
     ]
    },
    {
     "t": {
      "en": "Use your own shop's size chart",
      "ar": "استخدام جدول مقاسات متجرك"
     },
     "en": [
      "Press Edit size chart at the bottom of the window: size-chart.json opens.",
      "Change the sizes, measurements, conversions or stock status. The file explains each setting at the top.",
      "Save the file, then press Reload: the new numbers are used at once."
     ],
     "ar": [
      "انقر Edit size chart أسفل النافذة، فيُفتح الملف size-chart.json.",
      "غيّر المقاسات أو القياسات أو التحويلات أو حالة التوفّر، ويشرح الملف كل إعداد في أوله.",
      "احفظ الملف، ثم انقر Reload، فتُعتمد الأرقام الجديدة فورًا."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/sizefinder/win-en-01-main.jpg",
     "ar": "img/shots/sizefinder/win-ar-01-main.jpg",
     "cap": {
      "en": "Trousers for men: height, weight and body shape give size L, with its measurements, a length tip and the size in other systems.",
      "ar": "البنطال للرجال: الطول والوزن وشكل الجسم تعطي المقاس L، مع قياساته، ونصيحة عن الطول، والمقاس في الأنظمة الأخرى."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-02-thobe.jpg",
     "ar": "img/shots/sizefinder/win-ar-02-thobe.jpg",
     "cap": {
      "en": "Thobe: the size number that reaches the ankle and the cut to take for the width.",
      "ar": "الثوب: رقم المقاس الذي يصل إلى الكاحل، والقَصّة المناسبة للعرض."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-03-women-top.jpg",
     "ar": "img/shots/sizefinder/win-ar-03-women-top.jpg",
     "cap": {
      "en": "Women: the size for a top or blouse, with chest, length and sleeve.",
      "ar": "النساء: مقاس التوب أو البلوزة، مع الصدر والطول والكمّ."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-04-shoes.jpg",
     "ar": "img/shots/sizefinder/win-ar-04-shoes.jpg",
     "cap": {
      "en": "Shoes: foot length gives the EU, US and UK size.",
      "ar": "الأحذية: طول القدم يعطي المقاس الأوروبي والأمريكي والبريطاني."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-05-exact-jacket.jpg",
     "ar": "img/shots/sizefinder/win-ar-05-exact-jacket.jpg",
     "cap": {
      "en": "I know my measurements: the jacket size follows the chest measurement.",
      "ar": "خيار I know my measurements: مقاس الجاكيت يتبع محيط الصدر."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-06-imperial-broad.jpg",
     "ar": "img/shots/sizefinder/win-ar-06-imperial-broad.jpg",
     "cap": {
      "en": "ft/lb units with a Broad body shape.",
      "ar": "وحدة قدم/رطل مع شكل جسم عريض."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-07-girls.jpg",
     "ar": "img/shots/sizefinder/win-ar-07-girls.jpg",
     "cap": {
      "en": "Girls: trousers for a 7-year-old, with measurements and the size in other systems.",
      "ar": "البنات: مقاس البنطال لطفلة في السابعة، مع القياسات والمقاس في الأنظمة الأخرى."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-08-boys-shoes.jpg",
     "ar": "img/shots/sizefinder/win-ar-08-boys-shoes.jpg",
     "cap": {
      "en": "Boys: kids shoe size from foot length (EU, US and UK).",
      "ar": "الأولاد: مقاس حذاء الطفل من طول القدم (EU وUS وUK)."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-09-help.jpg",
     "ar": "img/shots/sizefinder/win-ar-09-help.jpg",
     "cap": {
      "en": "The built-in Help guide (Help button or F1).",
      "ar": "دليل المساعدة المدمج (زرّ Help أو مفتاح F1)."
     }
    },
    {
     "en": "img/shots/sizefinder/win-en-10-help-shoes.jpg",
     "ar": "img/shots/sizefinder/win-ar-10-help-shoes.jpg",
     "cap": {
      "en": "Help: contents and details.",
      "ar": "المساعدة: الفهرس والتفاصيل."
     }
    }
   ],
   "warn": {
    "en": "Sizes are estimates and differ from brand to brand. Check each shop's own size chart. Size Finder is not affiliated with any brand or store.",
    "ar": "المقاسات تقديرية وتختلف من علامة تجارية إلى أخرى، فراجع جدول المقاسات الخاص بكل متجر. ولا يرتبط Size Finder بأي علامة تجارية أو متجر."
   }
  },
  {
   "id": "GulfWeather",
   "name": "Gulf Weather",
   "os": [
    "win",
    "mac"
   ],
   "cat": "apps",
   "icon": "img/gulf-weather.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/GulfWeather/version.json",
   "summary": {
    "en": "Gulf Weather shows the weather for Kuwait, the Gulf, the Arab world and the whole globe on an animated map and in a live 3D scene, with a 10-day forecast, air pressure, tropical cyclones and alerts for heat, dust and storms.",
    "ar": "يعرض برنامج Gulf Weather حالة الطقس في الكويت ودول الخليج والعالم العربي والعالم كله على خريطة متحركة وفي مشهد حيّ ثلاثي الأبعاد، مع توقّعات لعشرة أيام، والضغط الجوي، والأعاصير المدارية، وتنبيهات للحرّ الشديد والغبار والعواصف."
   },
   "features": {
    "en": [
     "Animated weather map (opens first): temperature colours, moving wind lines, clouds and rain by intensity, dust, and the temperature of every city. Zoom, drag and switch each layer on or off.",
     "Real map underneath: street, satellite or dark style (Esri), with deep zoom down to the streets.",
     "51 places in 21 Arab countries, from Morocco to Oman, with a Kuwait panel covering all 6 governorates plus Abdali, Al Salmi, Al Wafra and Nuwaiseeb, each with its temperature.",
     "The whole world: click the globe button on the map (or zoom out) to see temperature, wind, clouds and rain over every continent, with major world cities. Click anywhere on the map, or search any city by name, to open its full 10-day forecast. Places you open are saved.",
     "Satellite clouds over the whole world (GOES and Himawari via NASA, plus EUMETSAT Meteosat) and a worldwide rain radar.",
     "Air pressure: isobars with values, a blue H for highs and a red L for lows, moving with the time bar.",
     "Tropical cyclones: live cyclones anywhere in the world with position, wind, category, past and forecast track and cone (GDACS).",
     "Season banner: the current season, its dates and the days left; click it to see every season with its dates and how many days until it starts.",
     "Where's the rain: the water-drop button finds the nearest rain to the selected city, with its distance, direction and whether it is approaching.",
     "El Niño card: the current El Niño or La Niña status, the ONI index and a two-year chart, plus a sea surface temperature anomaly layer (difference from average) on the map with a colour legend.",
     "3D scene that moves with time: sun, moon and stars, clouds, rain, thunder and lightning, dust and fog, palm trees swaying with the wind, and day and night from the real sunrise and sunset.",
     "10-day forecast with a timeline: drag it or click Play to watch the weather change hour by hour.",
     "Details: temperature, feels like, humidity, wind and gusts, UV index, visibility, dust, sunrise and sunset.",
     "Alerts: extreme heat, dust storms, thunderstorms, heavy rain and flooding risk, strong wind, fog, high UV and cold nights.",
     "Insights panel: prayer times for the chosen place, today compared with yesterday, air quality (AQI, PM10, PM2.5, dust) with simple advice, sea and waves, and a camping (kashta) outlook for Al Salmi, Al Wafra, Al Abdali and Al Jahra.",
     "Rain radar on the map (the last two hours, animated), favourite places, My location with the nearest city’s weather, and a spoken weather summary in Arabic or English.",
     "Climate over the years: compare any period (the autumn rains season, summer, winter or your own months) with the same period in every year since 1950: average temperature, total rain, rainy days, days of 45° or more and stormy days, with trend lines and a table for each decade.",
     "Past and present: this year so far against the 1991–2020 average, the last 10 years or any other year, with year-by-year charts, a month-by-month profile, a temperature map of every year and month, records and a decade table.",
     "Camping outlook (kashta) for 8 desert areas (including Subiya, Mutlaa, Kabd and Shaqaya): the coldest night temperature with what to wear, the best calm hours to pitch the tent and light the fire, and a verdict for the weekend.",
     "Free live data from Open-Meteo. The last forecast is saved, so the app still opens without internet.",
     "English by default, with an Arabic button (right to left)."
    ],
    "ar": [
     "خريطة طقس متحركة (تظهر عند فتح البرنامج): ألوان لدرجات الحرارة، وخطوط متحركة لاتجاه الرياح، والسحب والأمطار بحسب شدّتها، والغبار، ودرجة حرارة كل مدينة. ويمكنك تكبير الخريطة وسحبها، وإظهار كل طبقة أو إخفاؤها.",
     "خريطة حقيقية في الخلفية بثلاثة أنماط: الشوارع، أو صور الأقمار الصناعية، أو النمط الداكن (من Esri)، مع إمكانية التكبير حتى مستوى الشوارع.",
     "51 موقعًا في 21 دولة عربية، من المغرب إلى عُمان، مع لوحة خاصة بالكويت تشمل المحافظات الست، إضافةً إلى العبدلي والسالمي والوفرة والنويصيب، وتُعرض درجة حرارة كلٍّ منها.",
     "العالم كله: انقر زرّ الكرة الأرضية على الخريطة (أو صغّر العرض) لمشاهدة الحرارة والرياح والسحب والأمطار فوق جميع القارات مع كبرى مدن العالم. وانقر أي نقطة على الخريطة، أو ابحث عن أي مدينة باسمها، لفتح توقّعاتها الكاملة لعشرة أيام، وتُحفظ الأماكن التي تفتحها.",
     "صور السحب بالأقمار الصناعية للعالم كله (GOES وHimawari عبر NASA، وMeteosat من EUMETSAT)، ورادار أمطار عالمي.",
     "الضغط الجوي: خطوط الضغط المتساوي مع قيمها، وحرف H أزرق للمرتفعات وحرف L أحمر للمنخفضات، وتتحرّك مع الشريط الزمني.",
     "الأعاصير المدارية: الأعاصير النشطة في أي مكان في العالم مع موقعها وسرعة رياحها وفئتها ومسارها السابق والمتوقّع ومخروط التوقّع (GDACS).",
     "شريط المواسم: الموسم الحالي وتواريخه والأيام المتبقّية منه؛ وبالنقر عليه تظهر جميع المواسم بتواريخها وعدد الأيام المتبقّية على بدء كلٍّ منها.",
     "أين المطر: يحدّد زرّ قطرة الماء أقرب مطر إلى المدينة المختارة، مع بُعده واتجاهه وما إذا كان يقترب منها.",
     "بطاقة El Niño (النينيو): الحالة الحالية لظاهرة النينيو أو النينيا، ومؤشّر ONI، ورسم بياني لسنتين، إضافةً إلى طبقة لفرق درجة حرارة سطح البحر عن المعدل على الخريطة مع مفتاح للألوان.",
     "مشهد ثلاثي الأبعاد يتغيّر مع الوقت: الشمس والقمر والنجوم، والسحب، والمطر، والرعد والبرق، والغبار والضباب، وأشجار النخيل تتمايل مع الرياح، مع تعاقب الليل والنهار وفق مواعيد الشروق والغروب الفعلية.",
     "توقّعات لعشرة أيام مع شريط زمني: اسحبه أو انقر Play لمشاهدة تغيّر الطقس ساعةً بساعة.",
     "التفاصيل: درجة الحرارة، والحرارة المحسوسة، والرطوبة، والرياح وهبّاتها، ومؤشر الأشعة فوق البنفسجية، ومدى الرؤية، والغبار، وموعدا الشروق والغروب.",
     "التنبيهات: الحرّ الشديد، والعواصف الترابية، والعواصف الرعدية، والأمطار الغزيرة وخطر السيول، والرياح القوية، والضباب، وارتفاع مؤشر الأشعة فوق البنفسجية، والليالي الباردة.",
     "لوحة المعلومات (Insights): مواقيت الصلاة للمكان المختار، ومقارنة طقس اليوم بطقس الأمس، وجودة الهواء (AQI وPM10 وPM2.5 والغبار) مع نصائح مبسّطة، وحالة البحر والأمواج، وتوقّعات مناسبة للرحلات البرية (الكشتة) في السالمي والوفرة والعبدلي والجهراء.",
     "رادار الأمطار على الخريطة (آخر ساعتين بصورة متحركة)، والأماكن المفضّلة، وخاصية My location مع طقس أقرب مدينة، وملخّص صوتي للطقس بالعربية أو الإنجليزية.",
     "المناخ عبر السنين (Climate over the years): مقارنة أي فترة (موسم أمطار الخريف «السرايات»، أو الصيف، أو الشتاء، أو أشهر تختارها) بالفترة نفسها في كل عام منذ 1950: متوسط درجة الحرارة، ومجموع الأمطار، وعدد الأيام الممطرة، والأيام التي تبلغ فيها الحرارة 45° فأكثر، والأيام العاصفة، مع خطوط للاتجاه العام وجدول لكل عقد.",
     "الماضي والحاضر (Past and present): مقارنة العام الحالي حتى اليوم بمعدّل الفترة 1991–2020، أو بالسنوات العشر الأخيرة، أو بأي عام آخر، مع رسوم بيانية عامًا بعام، ومنحنى شهري (شهرًا بشهر)، وخريطة لونية لدرجات الحرارة في كل عام وشهر، والأرقام القياسية، وجدول لكل عقد.",
     "توقّعات الرحلات البرية (الكشتة) في 8 مناطق صحراوية (منها الصبية والمطلاع وكبد والشقايا): أدنى درجة حرارة ليلًا مع ما يناسبها من ملابس، وأنسب الساعات الهادئة لنصب الخيمة وإشعال النار، وتقييم لعطلة نهاية الأسبوع.",
     "بيانات مباشرة مجانية من Open-Meteo. وتُحفظ آخر التوقّعات، فيعمل البرنامج حتى دون اتصال بالإنترنت.",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Apps and click Install next to Gulf Weather, then Open.",
     "On the map, click a city to choose it. Click Play on the timeline to watch the next 10 days.",
     "Click 3D view for the animated scene, and Map to come back.",
     "Click the city name at the top to pick any other city, or type any city in the world in the search box. Click the globe button on the map to see the whole world."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Apps (البرامج)، ثم انقر Install بجانب Gulf Weather، ثم Open.",
     "انقر أي مدينة على الخريطة لاختيارها، ثم انقر Play على الشريط الزمني لمشاهدة الأيام العشرة القادمة.",
     "انقر 3D view لعرض المشهد ثلاثي الأبعاد، وMap للعودة إلى الخريطة.",
     "انقر اسم المدينة في الأعلى لاختيار مدينة أخرى، أو اكتب اسم أي مدينة في العالم في مربّع البحث. وانقر زرّ الكرة الأرضية على الخريطة لعرض العالم كله."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit), or a Mac (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No administrator rights needed.",
     "An internet connection for live forecasts (free, from Open-Meteo) and the map.",
     "Opens from Kankon Launcher only (Apps)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit)، أو جهاز Mac (بمعالج Apple Silicon أو Intel) من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول.",
     "اتصال بالإنترنت للحصول على التوقّعات المباشرة (مجانًا من Open-Meteo) ولعرض الخريطة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Apps (البرامج)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Watch the next 10 days",
      "ar": "مشاهدة طقس الأيام العشرة القادمة"
     },
     "en": [
      "Open Gulf Weather and click your city on the map.",
      "Click Play on the timeline at the bottom; the map and the numbers change hour by hour.",
      "Click any day card to jump to that day, or Now to come back to the current hour."
     ],
     "ar": [
      "افتح Gulf Weather وانقر مدينتك على الخريطة.",
      "انقر Play على الشريط الزمني في الأسفل، فتتغيّر الخريطة والأرقام ساعةً بساعة.",
      "انقر بطاقة أي يوم للانتقال إليه، أو Now للعودة إلى الساعة الحالية."
     ]
    },
    {
     "t": {
      "en": "See dust and rain on the map",
      "ar": "متابعة الغبار والأمطار على الخريطة"
     },
     "en": [
      "Use the layer buttons at the top: Temperature, Wind, Clouds & rain and Dust.",
      "Click a button to show or hide that layer; the legend on the right explains the colours.",
      "Scroll to zoom and drag to move the map."
     ],
     "ar": [
      "استخدم أزرار الطبقات في الأعلى: Temperature (الحرارة)، وWind (الرياح)، وClouds & rain (السحب والأمطار)، وDust (الغبار).",
      "انقر أي زر لإظهار طبقته أو إخفائها، ويشرح مفتاح الخريطة معنى الألوان.",
      "مرّر عجلة الفأرة للتكبير، واسحب الخريطة لتحريكها."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/gulfweather/win-en-01-main.jpg",
     "ar": "img/shots/gulfweather/win-ar-01-main.jpg",
     "cap": {
      "en": "The animated weather map over a real map of the Arab world, with every city’s temperature and the 10-day forecast.",
      "ar": "خريطة الطقس المتحركة فوق خريطة حقيقية للعالم العربي، مع درجة حرارة كل مدينة وتوقّعات الأيام العشرة."
     }
    },
    {
     "en": "img/shots/gulfweather/win-en-02-3d.jpg",
     "ar": "img/shots/gulfweather/win-ar-02-3d.jpg",
     "cap": {
      "en": "The 3D scene during a real dust storm in Kuwait City.",
      "ar": "المشهد ثلاثي الأبعاد في أثناء عاصفة ترابية حقيقية في مدينة الكويت."
     }
    },
    {
     "src": "img/shots/gulfweather/mac-en-01-main.jpg",
     "cap": {
      "en": "Gulf Weather on a Mac, with details and a dust storm alert for Kuwait City.",
      "ar": "Gulf Weather على جهاز Mac، مع التفاصيل وتنبيه بعاصفة ترابية في مدينة الكويت."
     }
    }
   ]
  },
  {
   "id": "Noor",
   "name": "Noor",
   "os": [
    "win",
    "mac"
   ],
   "cat": "apps",
   "icon": "img/noor.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/Noor/version.json",
   "summary": {
    "en": "Noor is an Islamic companion for your computer: accurate prayer times with a prayer-time alert, a hadith reminder every few minutes, the complete Holy Quran, adhkar, Qibla, tasbih and the Hijri date, all working offline.",
    "ar": "Noor رفيق إسلامي لحاسوبك: مواقيت صلاة دقيقة مع تنبيه عند دخول وقت الصلاة، وتذكير بحديث نبوي كل بضع دقائق، والقرآن الكريم كاملًا، والأذكار، واتجاه القبلة، والمسبحة، والتاريخ الهجري، ويعمل كل ذلك دون اتصال بالإنترنت."
   },
   "features": {
    "en": [
     "Prayer times: Fajr, Sunrise, Dhuhr, Asr, Maghrib and Isha for your city, calculated on your computer, with a big countdown to the next prayer. 80 cities built in (all Gulf and Arab capitals, Kuwait governorates, Saudi cities and major cities worldwide), or detect your location, or type the coordinates.",
     "Calculation methods: Kuwait (Ministry of Awqaf), Umm al-Qura (Makkah), Qatar, UAE, Muslim World League, Egypt, Karachi, North America (ISNA), Turkey and Singapore; Asr Standard or Hanafi, a high-latitude rule, and a minute adjustment for every prayer.",
     "Prayer alerts: a short tone and an on-screen card at each prayer time (or silent), for the prayers you choose, with volume control and a reminder 5 to 30 minutes before the prayer. Adhan recordings were removed in 1.1.0 until a recording with a clear licence is available.",
     "Hadith reminders: a short hadith appears in the corner of the screen every 10 minutes by default. Change it to 1, 5, 15, 20, 30 or 45 minutes or 1 to 3 hours, or turn it off; with an optional soft tone, display time and quiet hours at night.",
     "Authentic hadith only: 1,575 hadiths from Sahih al-Bukhari and Sahih Muslim, in Arabic, each with its number, grade, book, full chain of narrators and a link to sunnah.com, where you can also read it in English. Every text was matched against a second copy of the book.",
     "The Holy Quran: all 114 surahs and 6,236 ayat in the Uthmani script of the King Fahd Complex (Madinah Mushaf, Hafs), with the Amiri Quran font. Surah list, search by surah name or any word, bookmarks, continue from the last ayah you read, text size and an optional English translation (Marmaduke Pickthall, 1930, public domain).",
     "Quran recitation: 15 reciters (including Ali Jaber, Maher Al-Muaiqly, Mishary Alafasy, Abdul Rahman Al-Sudais and Saud Al-Shuraim), ayah by ayah with the current ayah highlighted. Pause and resume, listen from any ayah, repeat each ayah, and continue to the next surah automatically. Download a surah (the ⬇ button) or the whole Quran for any reciter to listen offline, and delete saved recitations per reciter or all at once in Settings. Recitation pauses for the prayer alert.",
     "Adhkar: morning and evening, after prayer, before sleep and at any time, from the Quran and the two Sahihs, with the source of each and a counter.",
     "Qibla: the direction of the Kaaba from your city in degrees, with a compass and the distance to Makkah.",
     "Tasbih: SubhanAllah, Alhamdulillah, Allahu Akbar and La ilaha illallah, with a target (33, 99, 100 or 1,000) and a running total. Click or press Space.",
     "Worship guides: wudu, ghusl, tayammum, how to pray, prostration of forgetfulness, travel prayer, Friday, Witr, Istikhara, funeral and Eid prayers, fasting, zakat, Umrah and Hajj, step by step, with every hadith checked against two copies of al-Bukhari and Muslim.",
     "Hijri date (Umm al-Qura) with a day adjustment, and a Friday reminder to read Surat Al-Kahf.",
     "Runs quietly in the background (system tray on Windows, menu bar on Mac) and can start with the computer, so you never miss a reminder.",
     "English by default, with an Arabic button (right to left)."
    ],
    "ar": [
     "مواقيت الصلاة: الفجر والشروق والظهر والعصر والمغرب والعشاء لمدينتك، تُحسب على جهازك مباشرةً، مع عدّاد تنازلي كبير للصلاة القادمة. ويضمّ البرنامج 80 مدينة (جميع العواصم الخليجية والعربية، ومحافظات الكويت، والمدن السعودية، وكبرى مدن العالم)، ويمكنك أيضًا تحديد موقعك تلقائيًا أو إدخال الإحداثيات.",
     "طرق الحساب: الكويت (وزارة الأوقاف)، وأم القرى (مكة المكرمة)، وقطر، والإمارات، ورابطة العالم الإسلامي، ومصر، وكراتشي، وأمريكا الشمالية (ISNA)، وتركيا، وسنغافورة؛ مع اختيار مذهب العصر (الجمهور أو الحنفي)، وقاعدة خطوط العرض العليا، وتعديل وقت كل صلاة بالدقائق.",
     "تنبيه الصلاة: نغمة قصيرة وبطاقة على الشاشة عند دخول وقت كل صلاة (أو دون صوت)، للصلوات التي تختارها، مع التحكّم في مستوى الصوت، وتذكير قبل الصلاة بمدة تتراوح بين 5 و30 دقيقة. وأُزيلت تسجيلات الأذان في الإصدار 1.1.0 إلى أن يتوفّر تسجيل برخصة واضحة.",
     "التذكير بالأحاديث: يظهر حديث قصير في زاوية الشاشة كل 10 دقائق افتراضيًا، ويمكنك تغيير المدة إلى 1 أو 5 أو 15 أو 20 أو 30 أو 45 دقيقة، أو من ساعة إلى ثلاث ساعات، أو إيقافه، مع نغمة هادئة اختيارية، وتحديد مدة ظهوره، وساعات هدوء في الليل.",
     "الأحاديث الصحيحة فقط: 1,575 حديثًا من صحيح البخاري وصحيح مسلم باللغة العربية، ولكل حديث رقمه ودرجته وكتابه وسنده كاملًا، ورابط إلى موقع sunnah.com للتحقّق منه وقراءة ترجمته. وقد قوبل كل نصّ بنسخة ثانية من الكتاب قبل إدراجه.",
     "القرآن الكريم: 114 سورة و6,236 آية بالرسم العثماني كما في مصحف المدينة النبوية الصادر عن مجمّع الملك فهد لطباعة المصحف الشريف (برواية حفص عن عاصم)، بخط Amiri Quran. مع فهرس للسور، والبحث باسم السورة أو بأي كلمة، والعلامات المرجعية، ومتابعة القراءة من آخر آية، وتغيير حجم الخط، وترجمة إنجليزية اختيارية (Marmaduke Pickthall، 1930، ملك عام).",
     "تلاوة القرآن الكريم بأصوات 15 قارئًا (منهم علي جابر، وماهر المعيقلي، ومشاري العفاسي، وعبد الرحمن السديس، وسعود الشريم)، آيةً آية مع تمييز الآية التي تُتلى. ويمكنك الإيقاف المؤقت والاستئناف، والاستماع من أي آية، وتكرار كل آية، والانتقال إلى السورة التالية تلقائيًا. ويمكنك تحميل تلاوة سورة (بزرّ ⬇) أو تلاوة القرآن الكريم كاملًا بصوت أي قارئ للاستماع دون اتصال بالإنترنت، وحذف التلاوات المحفوظة لكل قارئ أو جميعها دفعةً واحدة من Settings. وتتوقّف التلاوة عند تنبيه الصلاة.",
     "الأذكار: أذكار الصباح والمساء، وأذكار ما بعد الصلاة، وأذكار النوم، والأذكار العامة، من القرآن الكريم والصحيحين، مع مصدر كل ذكر وعدّاد له.",
     "القبلة: اتجاه الكعبة المشرّفة من مدينتك بالدرجات، مع بوصلة، والمسافة إلى مكة المكرمة.",
     "المسبحة: سبحان الله، والحمد لله، والله أكبر، ولا إله إلا الله، مع هدف محدّد (33 أو 99 أو 100 أو 1,000) ومجموع إجمالي. انقر أو اضغط مفتاح المسافة.",
     "دليل العبادات: الوضوء والغسل والتيمم وصفة الصلاة وسجود السهو وصلاة المسافر والجمعة والوتر والاستخارة وصلاة الجنازة والعيد والصيام والزكاة والعمرة والحج، خطوة بخطوة، وكل حديث فيه مُراجَع على نسختين من صحيحَي البخاري ومسلم.",
     "التاريخ الهجري (تقويم أم القرى) مع إمكانية تعديله بالأيام، وتذكير يوم الجمعة بقراءة سورة الكهف.",
     "يعمل بهدوء في الخلفية (في شريط النظام على Windows، وفي شريط القوائم على Mac)، ويمكن تشغيله مع بدء تشغيل الجهاز، فلا يفوتك أي تذكير.",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Apps and click Install next to Noor, then Open.",
     "Go to Settings and pick your city (or click Detect my location). The calculation method is chosen for your country; you can change it.",
     "Choose which prayers get an alert, and how often you want a hadith.",
     "Close the window: Noor keeps running and reminds you. Open it again from the launcher or from the tray or menu bar icon.",
     "Use Quran to read (it remembers where you stopped), and Hadith, Adhkar, Qibla and Tasbih from the menu on the left."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Apps (البرامج)، ثم انقر Install بجانب Noor، ثم Open.",
     "انتقل إلى Settings واختر مدينتك (أو انقر Detect my location)، فتُختار طريقة الحساب المناسبة لبلدك، ويمكنك تغييرها.",
     "اختر الصلوات التي تريد التنبيه لها، وعدد مرات التذكير بالأحاديث.",
     "أغلق النافذة، فيستمرّ Noor في العمل والتذكير. ويمكنك فتحه مجددًا من المشغّل أو من أيقونته في شريط النظام أو شريط القوائم.",
     "استخدم Quran للقراءة (ويحفظ موضع توقّفك)، وHadith وAdhkar وQibla وTasbih من القائمة الجانبية."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit), or a Mac with macOS 11 or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No internet needed, except for Detect my location.",
     "Opens from Kankon Launcher (Apps). Settings are saved in your user folder.",
     "Sources: Quran text from the King Fahd Glorious Quran Printing Complex (Madinah Mushaf, Hafs), unedited and checked letter by letter against a second copy; English translation by Marmaduke Pickthall (1930, public domain, from tanzil.net); hadith only from Sahih al-Bukhari and Sahih Muslim (sunnah.com)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit)، أو جهاز Mac بنظام macOS 11 أو أحدث (بمعالج Apple Silicon أو Intel) من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى اتصال بالإنترنت، إلا عند استخدام Detect my location.",
     "يُفتح من خلال Kankon Launcher، من قسم Apps (البرامج)، وتُحفظ الإعدادات في مجلد المستخدم.",
     "المصادر: نصّ القرآن الكريم من مجمّع الملك فهد لطباعة المصحف الشريف (مصحف المدينة النبوية، برواية حفص عن عاصم) دون أي تعديل، وقد قوبلت آياته حرفًا حرفًا بنسخة ثانية؛ والترجمة الإنجليزية هي ترجمة Marmaduke Pickthall (1930، ملك عام، من tanzil.net)؛ والأحاديث من صحيح البخاري وصحيح مسلم فقط (sunnah.com)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Set up prayer times and alerts",
      "ar": "ضبط مواقيت الصلاة والتنبيهات"
     },
     "en": [
      "Open Noor and click Settings.",
      "Pick your city from the list, or click Detect my location.",
      "Check the calculation method (for Kuwait: Ministry of Awqaf), then choose the prayers you want an alert for.",
      "Go back to Today: the next prayer and its countdown appear at the top."
     ],
     "ar": [
      "افتح Noor وانقر Settings.",
      "اختر مدينتك من القائمة، أو انقر Detect my location.",
      "تحقّق من طريقة الحساب (للكويت: وزارة الأوقاف)، ثم اختر الصلوات التي تريد التنبيه لها.",
      "عُد إلى Today، فتظهر الصلاة القادمة وعدّادها التنازلي في الأعلى."
     ]
    },
    {
     "t": {
      "en": "Change how often hadith appear",
      "ar": "تغيير مدة التذكير بالأحاديث"
     },
     "en": [
      "Open Settings and scroll to Hadith reminders.",
      "Choose the interval (10 minutes by default), or turn reminders off.",
      "Optionally set quiet hours so no hadith appears at night."
     ],
     "ar": [
      "افتح Settings وانتقل إلى قسم Hadith reminders.",
      "اختر المدة بين كل تذكير وآخر (10 دقائق افتراضيًا)، أو أوقف التذكير.",
      "يمكنك أيضًا تحديد ساعات هدوء حتى لا تظهر الأحاديث في الليل."
     ]
    },
    {
     "t": {
      "en": "Read the Quran and continue later",
      "ar": "قراءة القرآن الكريم ومتابعتها لاحقًا"
     },
     "en": [
      "Click Quran and choose a surah, or search by its name or any word.",
      "Read and scroll; Noor remembers the last ayah you reached.",
      "Next time, click Continue reading on the Today page."
     ],
     "ar": [
      "انقر Quran واختر سورة، أو ابحث باسمها أو بأي كلمة.",
      "اقرأ وتابع التمرير، ويحفظ Noor آخر آية وصلت إليها.",
      "في المرة التالية، انقر Continue reading في صفحة Today."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/noor/win-en-01-today.jpg",
     "ar": "img/shots/noor/win-ar-01-today.jpg",
     "cap": {
      "en": "Today: the Hijri date, the next prayer with a countdown, all prayer times and a hadith.",
      "ar": "صفحة Today: التاريخ الهجري، والصلاة القادمة مع عدّاد تنازلي، وجميع مواقيت الصلاة، وحديث نبوي."
     }
    },
    {
     "en": "img/shots/noor/win-en-02-quran.jpg",
     "ar": "img/shots/noor/win-ar-02-quran.jpg",
     "cap": {
      "en": "The Holy Quran in the Uthmani script of the Madinah Mushaf, with recitation and the current ayah highlighted.",
      "ar": "القرآن الكريم بالرسم العثماني لمصحف المدينة النبوية، مع التلاوة وتمييز الآية التي تُتلى."
     }
    },
    {
     "en": "img/shots/noor/win-en-03-hadith.jpg",
     "ar": "img/shots/noor/win-ar-03-hadith.jpg",
     "cap": {
      "en": "Hadith from Sahih al-Bukhari and Sahih Muslim, with the source and chain of narrators.",
      "ar": "أحاديث من صحيح البخاري وصحيح مسلم، مع المصدر والسند."
     }
    },
    {
     "en": "img/shots/noor/win-en-04-adhkar.jpg",
     "ar": "img/shots/noor/win-ar-04-adhkar.jpg",
     "cap": {
      "en": "Adhkar for the morning, evening, after prayer and before sleep, with a counter.",
      "ar": "أذكار الصباح والمساء، وأذكار ما بعد الصلاة، وأذكار النوم، مع عدّاد."
     }
    },
    {
     "en": "img/shots/noor/win-en-05-qibla.jpg",
     "ar": "img/shots/noor/win-ar-05-qibla.jpg",
     "cap": {
      "en": "The Qibla direction from your city, with the distance to Makkah.",
      "ar": "اتجاه القبلة من مدينتك، مع المسافة إلى مكة المكرمة."
     }
    },
    {
     "en": "img/shots/noor/win-en-06-tasbih.jpg",
     "ar": "img/shots/noor/win-ar-06-tasbih.jpg",
     "cap": {
      "en": "The tasbih counter with a target and a running total.",
      "ar": "المسبحة مع هدف محدّد ومجموع إجمالي."
     }
    },
    {
     "en": "img/shots/noor/win-en-07-settings.jpg",
     "ar": "img/shots/noor/win-ar-07-settings.jpg",
     "cap": {
      "en": "Settings: city, calculation method, prayer alerts and hadith reminders.",
      "ar": "الإعدادات: المدينة، وطريقة الحساب، وتنبيهات الصلاة، والتذكير بالأحاديث."
     }
    },
    {
     "en": "img/shots/noor/win-en-09-guides.jpg",
     "ar": "img/shots/noor/win-ar-09-guides.jpg",
     "cap": {
      "en": "Worship guides: 15 step-by-step guides, from wudu to Hajj, with their sources from the Quran and authentic hadith.",
      "ar": "دليل العبادات: 15 دليلًا خطوة بخطوة، من الوضوء إلى الحج، مع مصادرها من القرآن الكريم والأحاديث الصحيحة."
     }
    },
    {
     "en": "img/shots/noor/win-en-08-help.jpg",
     "ar": "img/shots/noor/win-ar-08-help.jpg",
     "cap": {
      "en": "The built-in Help guide (Help page or F1).",
      "ar": "دليل المساعدة المدمج (صفحة Help أو مفتاح F1)."
     }
    }
   ]
  },
  {
   "id": "AutoIpConfig",
   "name": "Auto Create IP Config",
   "os": [
    "win",
    "mac"
   ],
   "cat": "networking",
   "icon": "img/auto-ip-config.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/AutoIpConfig/version.json",
   "summary": {
    "en": "Auto Create IP Config sets a static IP address on any network adapter in one click, or switches it back to automatic (DHCP).",
    "ar": "يضبط برنامج Auto Create IP Config عنوان IP ثابتًا لأي بطاقة شبكة بنقرة واحدة، أو يعيدها إلى الإعداد التلقائي (DHCP)."
   },
   "features": {
    "en": [
     "Shows every enabled network adapter with its current IP, gateway and mode (Static or DHCP).",
     "Enter the IP address, Subnet Mask, gateway and DNS, then press Apply.",
     "Checks before applying: warns if another device already uses the IP, and if the gateway is not in the same network.",
     "Network scan: lists free and used IP addresses with device names, and picks the closest free address for you.",
     "Saved profiles (Office, Home, ...) fill all fields with one click. On Wi-Fi, the network name is suggested as the profile name. Profiles can be exported and imported between PCs.",
     "Quick DNS buttons: Google, Cloudflare, Quad9 and OpenDNS.",
     "Safety first: the previous settings are saved before any change. If the gateway does not reply after a change, the app reverts automatically unless you press Keep, and Restore previous is always available.",
     "A connection test after every change (gateway and internet), and a button to copy the settings."
    ],
    "ar": [
     "يعرض جميع بطاقات الشبكة المفعّلة مع عنوان IP الحالي والبوابة (Gateway) ونوع الإعداد (ثابت أو DHCP).",
     "تُدخل عنوان IP وقناع الشبكة (Subnet Mask) والبوابة وخوادم DNS، ثم تنقر Apply.",
     "يتحقّق قبل التطبيق: ينبّهك إذا كان جهاز آخر يستخدم العنوان نفسه، أو إذا كانت البوابة خارج نطاق الشبكة.",
     "فحص الشبكة: يعرض العناوين المتاحة والمستخدمة مع أسماء الأجهزة، ويقترح أقرب عنوان متاح.",
     "الإعدادات المحفوظة (العمل، المنزل...): تملأ جميع الحقول بنقرة واحدة. وعند الاتصال عبر Wi-Fi يُقترح اسم الشبكة اسمًا للإعداد. ويمكن تصديرها واستيرادها لنقلها إلى جهاز آخر.",
     "أزرار DNS سريعة: Google وCloudflare وQuad9 وOpenDNS.",
     "الأمان: يحفظ الإعدادات السابقة أولًا، وإذا لم تستجب البوابة بعد التغيير يعود إليها تلقائيًا ما لم تختر Keep. ويمكنك الرجوع إليها في أي وقت عبر Restore previous.",
     "اختبار الاتصال بعد كل تغيير (البوابة والإنترنت)، وزر لنسخ الإعدادات."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and press Open on Auto Create IP Config.",
     "Pick the network adapter.",
     "Type the IP you want, or press Scan network and choose a free one.",
     "Press Apply. To go back to automatic settings, press Switch to DHCP."
    ],
    "ar": [
     "اختر بطاقة الشبكة.",
     "اكتب عنوان IP المطلوب (أو انقر Scan network واختر عنوانًا متاحًا).",
     "انقر Apply. وللعودة إلى الإعداد التلقائي انقر Switch to DHCP."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11.",
     "Or a Mac (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "Administrator rights (Windows requires them to change IP settings). The launcher requests them when it opens the app.",
     "Opens from Kankon Launcher only.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11.",
     "أو جهاز Mac (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "صلاحيات المسؤول (يشترطها Windows لتغيير إعدادات IP)، ويطلبها المشغّل عند فتح البرنامج.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/autoipconfig/ar-01-main.jpg",
     "cap": {
      "en": "Pick an adapter and set a static IP, subnet mask, gateway and DNS, with a live check that the address is free.",
      "ar": "اختر بطاقة الشبكة وحدّد عنوان IP ثابتًا وقناع الشبكة والبوابة وخوادم DNS، مع فحص مباشر لتوفّر العنوان."
     },
     "en": "img/shots/autoipconfig/en-01-main.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-02-scan.jpg",
     "cap": {
      "en": "Scan the network to see which addresses are free or used, with device names, and pick the closest free one.",
      "ar": "افحص الشبكة لمعرفة العناوين المتاحة والمستخدمة مع أسماء الأجهزة، ثم اختر أقرب عنوان متاح بنقرة واحدة."
     },
     "en": "img/shots/autoipconfig/en-02-scan.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-03-profiles.jpg",
     "cap": {
      "en": "Save your settings as named profiles (Office, Home, Lab) and switch between them in one click. Export and import are supported.",
      "ar": "احفظ إعداداتك بأسماء (العمل، المنزل، المختبر) وبدّل بينها بنقرة واحدة، مع إمكانية التصدير والاستيراد."
     },
     "en": "img/shots/autoipconfig/en-03-profiles.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-04-keep-revert.jpg",
     "cap": {
      "en": "After applying, the app tests the connection and automatically reverts if the gateway does not reply.",
      "ar": "بعد التطبيق يختبر البرنامج الاتصال، ويعيد الإعدادات السابقة تلقائيًا إذا لم تستجب البوابة."
     },
     "en": "img/shots/autoipconfig/en-04-keep-revert.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-05-quick-dns.jpg",
     "cap": {
      "en": "One-click DNS presets (Google, Cloudflare, Quad9, OpenDNS) and a connection test after applying.",
      "ar": "إعدادات DNS جاهزة بنقرة واحدة (Google وCloudflare وQuad9 وOpenDNS) مع اختبار الاتصال بعد التطبيق."
     },
     "en": "img/shots/autoipconfig/en-05-quick-dns.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-06-dhcp.jpg",
     "cap": {
      "en": "Switch back to automatic addressing (DHCP) at any time.",
      "ar": "ارجع إلى الإعداد التلقائي (DHCP) في أي وقت."
     },
     "en": "img/shots/autoipconfig/en-06-dhcp.jpg"
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Set a static IP address",
      "ar": "تعيين عنوان IP ثابت"
     },
     "en": [
      "Open Auto Create IP Config from Kankon Launcher (Networking).",
      "Pick the network adapter from the list at the top.",
      "Type the IP address, Subnet Mask, gateway and DNS.",
      "Click Apply. The app checks the address first and warns you if another device already uses it.",
      "After the change, the app tests the gateway and the internet. If everything works, click Keep."
     ],
     "ar": [
      "افتح Auto Create IP Config من Kankon Launcher (قسم Networking «الشبكات»).",
      "اختر بطاقة الشبكة من القائمة في الأعلى.",
      "أدخل عنوان IP وقناع الشبكة (Subnet Mask) والبوابة وخوادم DNS.",
      "انقر Apply؛ فيتحقّق البرنامج من العنوان أولًا، وينبّهك إذا كان جهاز آخر يستخدمه.",
      "بعد التغيير، يختبر البرنامج الاتصال بالبوابة والإنترنت، فإذا كان كل شيء سليمًا، انقر Keep."
     ]
    },
    {
     "t": {
      "en": "Find a free IP address",
      "ar": "العثور على عنوان IP متاح"
     },
     "en": [
      "Click Scan network.",
      "Wait a few seconds while the app checks every address in your network.",
      "The list shows used addresses with device names, and free ones.",
      "Click the suggested closest free address, or any free one, and it is filled in for you. Then click Apply."
     ],
     "ar": [
      "انقر Scan network.",
      "انتظر بضع ثوانٍ بينما يفحص البرنامج جميع عناوين الشبكة.",
      "تعرض القائمة العناوين المستخدمة مع أسماء الأجهزة، والعناوين المتاحة.",
      "انقر أقرب عنوان متاح يقترحه البرنامج، أو أي عنوان متاح آخر، فيُملأ تلقائيًا، ثم انقر Apply."
     ]
    },
    {
     "t": {
      "en": "Save and reuse a profile",
      "ar": "حفظ إعداد واستخدامه لاحقًا"
     },
     "en": [
      "Fill in the IP settings you use in a place (for example Office).",
      "Save them as a profile. On Wi-Fi, the network name is suggested as the profile name.",
      "Next time, pick the profile and click Apply: all fields are filled with one click.",
      "Use Export and Import to move your profiles to another PC."
     ],
     "ar": [
      "أدخل إعدادات IP التي تستخدمها في مكان معيّن (العمل مثلًا).",
      "احفظها إعدادًا محفوظًا، وعند الاتصال عبر Wi-Fi يُقترح اسم الشبكة اسمًا له.",
      "في المرة التالية، اختر الإعداد وانقر Apply، فتُملأ جميع الحقول بنقرة واحدة.",
      "استخدم Export وImport لنقل إعداداتك إلى جهاز آخر."
     ]
    },
    {
     "t": {
      "en": "Go back to automatic settings",
      "ar": "العودة إلى الإعداد التلقائي"
     },
     "en": [
      "Pick the network adapter.",
      "Click Switch to DHCP. The adapter gets its address from the router again.",
      "If something goes wrong after any change, click Restore previous to return to the settings you had before."
     ],
     "ar": [
      "اختر بطاقة الشبكة.",
      "انقر Switch to DHCP؛ فتحصل البطاقة على عنوانها من جهاز التوجيه مجددًا.",
      "إذا حدث خلل بعد أي تغيير، فانقر Restore previous للعودة إلى الإعدادات السابقة."
     ]
    }
   ],
   "warn": {
    "en": "Use this app only on networks and devices you own, or manage with the owner's permission. Unauthorized access to networks or devices can be a crime under Kuwait Law No. 63 of 2015 on Combating Information Technology Crimes. You alone are responsible for how you use it.",
    "ar": "لا تستخدم هذا البرنامج إلا على الشبكات والأجهزة التي تملكها أو تديرها بإذن من مالكها، فقد يُعدّ الدخول إلى الشبكات أو الأجهزة دون إذن جريمةً بموجب القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات. وأنت وحدك المسؤول عن طريقة استخدامه."
   }
  },
  {
   "id": "NetworkMonitor",
   "name": "Network Monitor",
   "os": [
    "win",
    "mac"
   ],
   "cat": "networking",
   "icon": "img/network-monitor.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/NetworkMonitor/version.json",
   "summary": {
    "en": "Network Monitor shows every device on your network, how much each one uses, and your whole home internet usage, live, in its own window.",
    "ar": "يعرض برنامج Network Monitor جميع الأجهزة المتصلة بشبكتك، واستهلاك كل جهاز، واستهلاك إنترنت المنزل بالكامل، بصورة مباشرة وفي نافذة مستقلة."
   },
   "features": {
    "en": [
     "Devices: scans the network every minute and lists every device with its name, IP, MAC, maker, online status, response time and how often it is online. Rename devices and mark important ones.",
     "Router: whole-home internet download and upload, now, today and this month (Huawei home routers, read without a password).",
     "Switch: how much each device on a managed switch uses, today and over the last 30 days (SNMP, read only). Setup can find the switch on the network for you.",
     "Speed limits: set a maximum download and upload speed for the devices plugged into your managed switch, port by port (NETGEAR S350: GS308T, GS324T, GS324TP), and see which devices are on each port. The limits are saved on the switch, so they keep working when the app is closed.",
     "Auto Detect: finds your router and managed switches by itself, and shows their model and whether speed limits are supported.",
     "Daily limit: set a daily usage limit for any device and get an alert when it is passed.",
     "Internet outages: checks the internet every 15 seconds, logs every outage and how long it lasted, and tells you when the connection is back.",
     "Weekly summary: every Friday, a short summary on WhatsApp with the top devices, home internet usage and outages.",
     "This PC: download and upload speed, the programs using the internet and how many MB each one used, and the services (ports) on this PC.",
     "Free IPs: the addresses in each network that no device uses, ready for a new device.",
     "Reports: daily, weekly (Sunday to Saturday), monthly and yearly, with home internet usage, every device, outages, a chart, and the top devices and programs. Save any report as an A4 PDF with one click. Readings are kept for about 13 months.",
     "Internet plan: enter your monthly plan size in GB and renew day. A plan card at the top of the main window shows used and plan size, what is left and the days to renewal, in the look you pick (Blue bar, Ring or Battery). It turns amber at 80% and red when the plan runs out, and you get an alert at both.",
     "WhatsApp alerts: every alert, the weekly summary and the Internet plan alerts reach your WhatsApp through the free CallMeBot service (personal use). Set it up once in Setup > WhatsApp with your WhatsApp number and CallMeBot key.",
     "Alerts when a new device joins or an important device goes offline, plus a monthly report, all on WhatsApp.",
     "Open it from other devices on the network in a browser, protected by a password.",
     "Export the device list to Excel (CSV).",
     "Start with Windows: keeps running in the background so alerts and history never stop."
    ],
    "ar": [
     "الأجهزة: يفحص الشبكة كل دقيقة ويعرض كل جهاز باسمه وعنوان IP وعنوان MAC والشركة المصنّعة، وحالة اتصاله، وزمن استجابته، ونسبة وجوده على الشبكة. ويمكنك تسمية الأجهزة وتمييز المهم منها.",
     "جهاز التوجيه (Router): معدّل التنزيل والرفع لإنترنت المنزل كله الآن، واستهلاك اليوم والشهر الحالي (لأجهزة Huawei المنزلية، دون كلمة مرور).",
     "المحوّل (Switch): استهلاك كل جهاز متصل بمحوّل مُدار، لليوم ولآخر 30 يومًا (عبر SNMP للقراءة فقط).",
     "حدود السرعة: حدّد سرعة تنزيل قصوى وسرعة رفع قصوى للأجهزة الموصولة بالمحوّل المُدار (Managed Switch) منفذًا منفذًا (NETGEAR S350: GS308T وGS324T وGS324TP)، واعرف الأجهزة الموصولة بكل منفذ. وتُحفظ الحدود في المحوّل نفسه، فتبقى سارية حتى بعد إغلاق البرنامج.",
     "الاكتشاف التلقائي (Auto Detect): يعثر على جهاز التوجيه والمحوّلات المُدارة تلقائيًا، ويعرض طرازها وما إذا كانت تدعم حدود السرعة.",
     "الحدّ اليومي: حدّد حدًّا يوميًا للاستهلاك لأي جهاز، واحصل على تنبيه عند تجاوزه.",
     "انقطاعات الإنترنت: يتحقّق من الاتصال بالإنترنت كل 15 ثانية، ويسجّل كل انقطاع ومدّته، ويُعلمك عند عودة الاتصال.",
     "الملخّص الأسبوعي: كل يوم جمعة يصلك على WhatsApp ملخّص قصير يتضمّن أكثر الأجهزة استهلاكًا، واستهلاك إنترنت المنزل، والانقطاعات.",
     "This PC: سرعة التنزيل والرفع، والبرامج التي تستخدم الإنترنت وحجم ما استهلكه كل منها بالميغابايت، والخدمات (المنافذ) العاملة على الجهاز.",
     "العناوين المتاحة: عناوين IP غير المستخدمة في كل شبكة، الجاهزة لجهاز جديد.",
     "التقارير: يومية وأسبوعية (من الأحد إلى السبت) وشهرية وسنوية، تتضمّن استهلاك إنترنت المنزل، وكل الأجهزة، والانقطاعات، ورسمًا بيانيًا، وأكثر الأجهزة والبرامج استهلاكًا. ويمكن حفظ أي تقرير بصيغة PDF بمقاس A4 بنقرة واحدة. وتُحفظ القراءات نحو 13 شهرًا.",
     "باقة الإنترنت: أدخل حجم باقتك الشهرية بالغيغابايت (GB) ويوم تجديدها. وتعرض بطاقة الباقة في أعلى النافذة الرئيسية المستهلك وحجم الباقة والمتبقّي والأيام الباقية حتى التجديد، بالشكل الذي تختاره (شريط أزرق أو حلقة أو بطارية). ويتحوّل لونها إلى البرتقالي عند 80% وإلى الأحمر عند نفاد الباقة، ويصلك تنبيه في الحالتين.",
     "تنبيهات WhatsApp: تصلك كل التنبيهات والملخّص الأسبوعي وتنبيهات باقة الإنترنت على WhatsApp عبر خدمة CallMeBot المجانية (للاستخدام الشخصي). ويكفي إعدادها مرة واحدة في Setup > WhatsApp برقم WhatsApp ومفتاح CallMeBot.",
     "التنبيهات: عند انضمام جهاز جديد إلى الشبكة، وعند انقطاع جهاز مهم، إضافةً إلى تقرير شهري، وكلها تصل على WhatsApp.",
     "يمكن فتحه من أي جهاز آخر على الشبكة عبر المتصفح، مع حمايته بكلمة مرور.",
     "تصدير قائمة الأجهزة إلى Excel (بصيغة CSV).",
     "التشغيل مع Windows: يواصل العمل في الخلفية حتى لا تتوقّف التنبيهات والسجل."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and press Open on Network Monitor.",
     "Wait a few seconds for the first scan, then click any device to see its details.",
     "Press Setup and fill in Router (type and address) and Switch (the switch's own address and SNMP community, or press Find the switch). The steps to turn on SNMP are shown there.",
     "Optional: in Setup, turn on WhatsApp alerts, a password for other devices, and Start with Windows."
    ],
    "ar": [
     "افتح Kankon Launcher، ثم انتقل إلى قسم Networking (الشبكات) وانقر Open بجانب Network Monitor.",
     "انتظر بضع ثوانٍ حتى يكتمل الفحص الأول، ثم انقر أي جهاز لعرض تفاصيله.",
     "انقر Setup وأدخل بيانات Router (النوع والعنوان) وSwitch (العنوان واسم SNMP Community). وتجد هناك خطوات تفعيل SNMP.",
     "اختياري: من Setup فعّل تنبيهات WhatsApp، وكلمة المرور للأجهزة الأخرى، والتشغيل مع Windows."
    ]
   },
   "req": {
    "en": [
     "Windows 10, Windows 11 or Windows Server.",
     "Or a Mac (Apple Silicon or Intel) with macOS 12 or newer.",
     "On Windows: administrator rights (to measure each program and to start with Windows).",
     "Opens from Kankon Launcher only (Networking).",
     "English by default, with an Arabic button.",
     "Router and switch settings are saved on each PC only and are never shared."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 أو Windows Server.",
     "أو جهاز Mac (بمعالج Apple Silicon أو Intel) بنظام macOS 12 أو أحدث.",
     "على Windows: صلاحيات المسؤول (لقياس استهلاك كل برنامج وللتشغيل مع Windows).",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية.",
     "تُحفظ إعدادات جهاز التوجيه والمحوّل على الجهاز نفسه فقط، ولا تُشارك مع أي جهة."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/networkmonitor/ar-01-dashboard.jpg",
     "cap": {
      "en": "Every device on your network, with the whole home internet, outages and top devices at a glance.",
      "ar": "جميع الأجهزة المتصلة بشبكتك، مع استهلاك إنترنت المنزل والانقطاعات وأكثر الأجهزة استهلاكًا في نظرة واحدة."
     },
     "en": "img/shots/networkmonitor/en-01-dashboard.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-02-device-details.jpg",
     "cap": {
      "en": "Device details: rename it, mark it important, and set a daily usage limit.",
      "ar": "تفاصيل الجهاز: إعادة تسميته، وتمييزه بوصفه جهازًا مهمًا، وتحديد حدٍّ يومي للاستهلاك."
     },
     "en": "img/shots/networkmonitor/en-02-device-details.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-03-alerts.jpg",
     "cap": {
      "en": "Alerts for new devices, devices going offline, internet outages, daily limits and the weekly summary.",
      "ar": "تنبيهات عند انضمام جهاز جديد، أو انقطاع جهاز، أو انقطاع الإنترنت، أو تجاوز الحد اليومي، إضافةً إلى الملخص الأسبوعي."
     },
     "en": "img/shots/networkmonitor/en-03-alerts.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-04-monthly-report.jpg",
     "cap": {
      "en": "Monthly report: which devices and programs used the most data.",
      "ar": "التقرير الشهري: الأجهزة والبرامج الأكثر استهلاكًا للبيانات."
     },
     "en": "img/shots/networkmonitor/en-04-monthly-report.jpg"
    },
    {
     "en": "img/shots/networkmonitor/en-09-report-pdf.jpg",
     "ar": "img/shots/networkmonitor/ar-09-report-pdf.jpg",
     "cap": {
      "en": "Save as PDF: an A4 report saved to Downloads and opened for you.",
      "ar": "الحفظ بصيغة PDF: تقرير بمقاس A4 يُحفظ في مجلد التنزيلات ويُفتح لك مباشرة."
     }
    },
    {
     "ar": "img/shots/networkmonitor/ar-05-setup-switch.jpg",
     "cap": {
      "en": "Setup: find your managed switch on the network and connect it with SNMP (read only).",
      "ar": "الإعدادات: البحث عن المحوّل المُدار في الشبكة وربطه عبر بروتوكول SNMP للقراءة فقط."
     },
     "en": "img/shots/networkmonitor/en-05-setup-switch.jpg"
    },
    {
     "en": "img/shots/networkmonitor/en-06-setup-whatsapp.jpg",
     "ar": "img/shots/networkmonitor/ar-06-setup-whatsapp.jpg",
     "cap": {
      "en": "Setup > WhatsApp: get every alert, the weekly summary and plan alerts on WhatsApp.",
      "ar": "الإعدادات > WhatsApp: تصلك كل التنبيهات والملخّص الأسبوعي وتنبيهات الباقة على WhatsApp."
     }
    },
    {
     "en": "img/shots/networkmonitor/en-07-plan-card.jpg",
     "ar": "img/shots/networkmonitor/ar-07-plan-card.jpg",
     "cap": {
      "en": "The Internet plan card: used and left this month, and the days to renewal.",
      "ar": "بطاقة باقة الإنترنت: المستهلك والمتبقّي هذا الشهر، والأيام الباقية حتى التجديد."
     }
    },
    {
     "ar": "img/shots/networkmonitor/ar-07-free-ips.jpg",
     "cap": {
      "en": "Free IPs: addresses no device uses, ready for a new device.",
      "ar": "العناوين المتاحة: عناوين IP غير المستخدمة والجاهزة لجهاز جديد."
     },
     "en": "img/shots/networkmonitor/en-07-free-ips.jpg"
    },
    {
     "en": "img/shots/networkmonitor/en-08-speed-limits.jpg",
     "ar": "img/shots/networkmonitor/ar-08-speed-limits.jpg",
     "cap": {
      "en": "Speed limits: a download and upload cap for each switch port, with the router and switch found by Auto Detect.",
      "ar": "حدود السرعة: حدّ للتنزيل وحدّ للرفع لكل منفذ في المحوّل، مع جهاز التوجيه والمحوّل اللذين عثر عليهما البحث التلقائي."
     }
    }
   ],
   "guides": [
    {
     "t": {
      "en": "First start",
      "ar": "التشغيل الأول"
     },
     "en": [
      "Open Network Monitor from Kankon Launcher (Networking).",
      "Wait a few seconds for the first scan of your network.",
      "Every device appears in the list with its name, maker and status. Click a device to see its details, rename it or mark it as important."
     ],
     "ar": [
      "افتح Network Monitor من Kankon Launcher (قسم Networking «الشبكات»).",
      "انتظر بضع ثوانٍ حتى يكتمل الفحص الأول للشبكة.",
      "يظهر كل جهاز في القائمة باسمه والشركة المصنّعة وحالته. انقر أي جهاز لعرض تفاصيله، أو إعادة تسميته، أو تمييزه جهازًا مهمًا."
     ]
    },
    {
     "t": {
      "en": "Connect your router",
      "ar": "ربط جهاز التوجيه (Router)"
     },
     "en": [
      "Click Setup, then Router.",
      "Choose the router type and type its address.",
      "Click Save. The Router card now shows your whole home internet usage: now, today and this month."
     ],
     "ar": [
      "انقر Setup ثم Router.",
      "اختر نوع جهاز التوجيه وأدخل عنوانه.",
      "انقر Save؛ فتعرض بطاقة Router استهلاك الإنترنت المنزلي بالكامل: الآن، واليوم، وهذا الشهر."
     ]
    },
    {
     "t": {
      "en": "Measure each device through the switch",
      "ar": "قياس استهلاك كل جهاز عبر المحوّل (Switch)"
     },
     "en": [
      "Turn on SNMP (read only) in your managed switch. The steps are shown in Setup > Switch.",
      "In Setup > Switch, click Find the switch, or type the switch's own address.",
      "Type the SNMP community and click Save.",
      "After a few minutes, each device shows how much it used today and over the last 30 days."
     ],
     "ar": [
      "فعّل SNMP (للقراءة فقط) في المحوّل المُدار، وستجد الخطوات في Setup ثم Switch.",
      "من Setup ثم Switch، انقر Find the switch، أو أدخل عنوان المحوّل نفسه.",
      "أدخل اسم SNMP Community وانقر Save.",
      "بعد بضع دقائق، يعرض كل جهاز استهلاكه اليومي واستهلاكه خلال آخر 30 يومًا."
     ]
    },
    {
     "t": {
      "en": "Get alerts on WhatsApp",
      "ar": "استقبال التنبيهات على WhatsApp"
     },
     "en": [
      "WhatsApp alerts use the free CallMeBot service (personal use). On your phone, save the CallMeBot number shown in the Help guide in your contacts.",
      "Send it the WhatsApp message: I allow callmebot to send me messages. It replies with your API key.",
      "In Network Monitor, open Setup > WhatsApp, type your number with the country code and the API key, then click Save and send a test.",
      "Optional: tick the weekly summary and click Send one now to try it. Every alert, the weekly summary and the plan alerts then arrive on your WhatsApp."
     ],
     "ar": [
      "تعتمد تنبيهات WhatsApp على خدمة CallMeBot المجانية (للاستخدام الشخصي). احفظ في جهات الاتصال على هاتفك رقمَ CallMeBot المذكور في دليل المساعدة.",
      "أرسل إليه عبر WhatsApp الرسالة «I allow callmebot to send me messages»، فيردّ عليك بمفتاح API.",
      "في Network Monitor افتح Setup ثم WhatsApp، واكتب رقمك مع رمز الدولة ومفتاح API، ثم احفظ الإعدادات وأرسل رسالة تجربة.",
      "اختياريًا: فعّل الملخّص الأسبوعي وانقر Send one now لتجربته. وبعدها تصلك كل التنبيهات والملخّص الأسبوعي وتنبيهات الباقة على WhatsApp."
     ]
    },
    {
     "t": {
      "en": "Set a daily limit for a device",
      "ar": "تحديد حد يومي لجهاز"
     },
     "en": [
      "Click the device in the list.",
      "In its details, set the daily limit in MB or GB.",
      "When the device passes the limit, you get an alert in the app and on your phone."
     ],
     "ar": [
      "انقر الجهاز في القائمة.",
      "حدّد الحد اليومي بالميغابايت أو الغيغابايت من صفحة تفاصيله.",
      "عند تجاوز الجهاز هذا الحد، يصلك تنبيه في البرنامج وعلى هاتفك."
     ]
    }
   ],
   "warn": {
    "en": "Use this app only on networks and devices you own, or manage with the owner's permission. Unauthorized access to networks or devices can be a crime under Kuwait Law No. 63 of 2015 on Combating Information Technology Crimes. You alone are responsible for how you use it.",
    "ar": "لا تستخدم هذا البرنامج إلا على الشبكات والأجهزة التي تملكها أو تديرها بإذن من مالكها، فقد يُعدّ الدخول إلى الشبكات أو الأجهزة دون إذن جريمةً بموجب القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات. وأنت وحدك المسؤول عن طريقة استخدامه."
   }
  },
  {
   "id": "NetworkTools",
   "name": "Network Tools",
   "os": [
    "win",
    "mac"
   ],
   "cat": "networking",
   "icon": "img/network-tools.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/NetworkTools/version.json",
   "summary": {
    "en": "Network Tools brings the network checks you need every day into one app: internet speed test, ping, traceroute, DNS, port check and a subnet calculator.",
    "ar": "يجمع برنامج Network Tools في تطبيق واحد فحوصات الشبكة التي تحتاج إليها يوميًا: اختبار سرعة الإنترنت، وPing، وتتبّع المسار، وDNS، وفحص المنافذ، وحاسبة الشبكات الفرعية."
   },
   "features": {
    "en": [
     "Overview: this computer's name and system, every connected network adapter (IP address, subnet mask, router, DNS servers, MAC address, link speed, DHCP or static), your public IP, internet provider and location, and live ping to your router and the internet. Copy everything with one click.",
     "Speed Test: download and upload speed, ping and jitter, measured against the nearest Cloudflare server, with a live speedometer and chart. Every result is saved in a history on this computer.",
     "Ping: ping any device or website, continuously or a fixed number of times. Shows sent, received, lost %, minimum, average and maximum time and jitter, with a live chart that marks lost packets in red and slow replies in amber.",
     "Traceroute: every router (hop) between you and the destination, with three timings per hop and the host names, to see where a connection slows down.",
     "DNS lookup: ask any DNS server (this computer's, Cloudflare, Google, Quad9, OpenDNS, AdGuard or your own) for A, AAAA, CNAME, MX, NS, TXT, PTR or SOA records. Type an IP address to get its name.",
     "DNS benchmark: tests all the DNS servers with 10 popular sites and shows the fastest one for your connection.",
     "Port Check: checks which TCP ports are open on any device, with ready lists for web, remote access, file sharing, Synology NAS, mail and common ports.",
     "Subnet Calculator: type 192.168.1.10/24 (or an IP address and a mask) to get the network, broadcast, first and last host, number of hosts, mask and wildcard.",
     "Fix & Speed: see which apps use your internet right now (download and upload per app, CPU and memory) and stop the ones you do not need; a network health check (adapter, Wi-Fi, IP, router, internet, DNS) with one-click fixes (turn Wi-Fi back on, quick repair, full network reset); pause Windows background downloads; and speed tips for your connection.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظرة عامة (Overview): اسم الجهاز ونظام تشغيله، وكل بطاقة شبكة متصلة (عنوان IP، وقناع الشبكة الفرعية، وجهاز التوجيه، وخوادم DNS، وعنوان MAC، وسرعة الاتصال، ونوع الإعداد: تلقائي DHCP أو ثابت)، إلى جانب عنوان IP العام، ومزوّد خدمة الإنترنت، والموقع، وقياس Ping مباشر لجهاز التوجيه وللإنترنت. ويمكن نسخ هذه المعلومات كلّها بنقرة واحدة.",
     "اختبار السرعة (Speed Test): يقيس سرعة التنزيل والرفع، وزمن الاستجابة (Ping)، وتذبذبه (Jitter)، عبر أقرب خادم من خوادم Cloudflare، مع عدّاد سرعة ورسم بياني مباشرين. وتُحفظ كل نتيجة في سجلّ على هذا الجهاز.",
     "Ping: لاختبار الاتصال بأي جهاز أو موقع، باستمرار أو لعدد محدّد من المرات. ويعرض عدد الحزم المرسلة والمستلمة، ونسبة المفقود منها، وأقلّ زمن ومتوسّطه وأعلاه، والتذبذب، مع رسم بياني مباشر يُظهر الحزم المفقودة باللون الأحمر والردود البطيئة باللون البرتقالي.",
     "تتبّع المسار (Traceroute): يعرض كل جهاز توجيه (قفزة) بينك وبين الوجهة، مع ثلاثة قياسات زمنية لكل قفزة وأسماء الأجهزة، لمعرفة الموضع الذي يحدث فيه البطء.",
     "استعلام DNS: يستعلم من أي خادم DNS (خادم الجهاز، أو Cloudflare، أو Google، أو Quad9، أو OpenDNS، أو AdGuard، أو خادم تحدّده بنفسك) عن السجلات A وAAAA وCNAME وMX وNS وTXT وPTR وSOA. وعند إدخال عنوان IP يُظهر الاسم المرتبط به.",
     "مقارنة سرعة خوادم DNS: يختبر جميع الخوادم على 10 مواقع شائعة، ويُبيّن أسرعها لاتصالك.",
     "فحص المنافذ (Port Check): يتحقّق من منافذ TCP المفتوحة على أي جهاز، مع قوائم جاهزة لخدمات الويب، والتحكّم عن بُعد، ومشاركة الملفات، وأجهزة Synology NAS، والبريد، والمنافذ الشائعة.",
     "حاسبة الشبكات الفرعية (Subnet Calculator): أدخل 192.168.1.10/24 (أو عنوان IP وقناعًا) لتحصل على عنوان الشبكة، وعنوان البثّ (Broadcast)، وأول عنوان وآخره، وعدد الأجهزة الممكنة، والقناع، والقناع المعكوس (Wildcard).",
     "الإصلاح والسرعة (Fix & Speed): اعرف البرامج التي تستخدم الإنترنت الآن (التنزيل والرفع لكل برنامج، والمعالج والذاكرة) وأوقف ما لا تحتاج إليه؛ وفحص لسلامة الشبكة (كرت الشبكة، وWi-Fi، وعنوان IP، وجهاز التوجيه، والإنترنت، وDNS) مع إصلاحات بنقرة واحدة (إعادة تشغيل Wi-Fi، والإصلاح السريع، وإعادة ضبط الشبكة بالكامل)؛ وإيقاف تنزيلات Windows في الخلفية مؤقتًا؛ ونصائح لتسريع اتصالك.",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and click Install next to Network Tools, then Open.",
     "Pick a tool from the menu on the left.",
     "Speed Test: click Start test and wait about 25 seconds.",
     "Ping and Traceroute: type an address or click a quick button (Router, Google DNS, Cloudflare), then click Start.",
     "Port Check: type the device address, pick a preset or type the ports (for example 80, 443 or 1-1024), then click Start."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Networking (الشبكات)، ثم انقر Install بجانب Network Tools، ثم Open.",
     "اختر الأداة المطلوبة من القائمة الجانبية.",
     "اختبار السرعة: انقر Start test وانتظر نحو 25 ثانية.",
     "Ping وتتبّع المسار: أدخل العنوان أو انقر أحد الأزرار السريعة (Router، أو Google DNS، أو Cloudflare)، ثم انقر Start.",
     "فحص المنافذ: أدخل عنوان الجهاز، واختر قائمة جاهزة أو اكتب المنافذ (مثل 80 و443، أو النطاق 1-1024)، ثم انقر Start."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "Or a Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No administrator rights needed.",
     "An internet connection for the speed test, the public IP and the DNS benchmark.",
     "Opens from Kankon Launcher only (Networking)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول.",
     "اتصال بالإنترنت لاختبار السرعة، ومعرفة عنوان IP العام، ومقارنة خوادم DNS.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Test your internet speed",
      "ar": "اختبار سرعة الإنترنت"
     },
     "en": [
      "Open Network Tools and click Speed Test.",
      "Click Start test and wait about 25 seconds without heavy downloads on the network.",
      "Read the download, upload, ping and jitter results. Earlier results are listed in the history below."
     ],
     "ar": [
      "افتح Network Tools وانقر Speed Test.",
      "انقر Start test وانتظر نحو 25 ثانية، مع تجنّب التنزيلات الكبيرة على الشبكة في أثناء الاختبار.",
      "اطّلع على نتائج سرعة التنزيل والرفع وزمن الاستجابة والتذبذب، وتجد النتائج السابقة في السجلّ أسفل الصفحة."
     ]
    },
    {
     "t": {
      "en": "Find where a connection slows down",
      "ar": "تحديد موضع البطء في الاتصال"
     },
     "en": [
      "Click Ping, type the address (or click Router or Google DNS) and click Start. Red marks on the chart are lost packets.",
      "If replies are slow or lost, click Traceroute, type the same address and click Start.",
      "The first hop with high times shows where the delay starts: your router, your provider or beyond."
     ],
     "ar": [
      "انقر Ping، وأدخل العنوان (أو انقر Router أو Google DNS)، ثم انقر Start. وتدلّ العلامات الحمراء في الرسم البياني على الحزم المفقودة.",
      "إذا كانت الردود بطيئة أو مفقودة، فانقر Traceroute، وأدخل العنوان نفسه، ثم انقر Start.",
      "أول قفزة يرتفع عندها الزمن تُبيّن موضع بدء التأخير: جهاز التوجيه، أو مزوّد الخدمة، أو ما بعدهما."
     ]
    },
    {
     "t": {
      "en": "Choose the fastest DNS",
      "ar": "اختيار أسرع خادم DNS"
     },
     "en": [
      "Click DNS, then open the benchmark.",
      "Click Start. Every DNS server is tested with 10 popular sites.",
      "The fastest server for your connection is shown at the top; you can set it on your router or network adapter."
     ],
     "ar": [
      "انقر DNS، ثم افتح أداة المقارنة.",
      "انقر Start، فيُختبر كل خادم DNS على 10 مواقع شائعة.",
      "يظهر أسرع خادم لاتصالك في أعلى القائمة، ويمكنك اعتماده في إعدادات جهاز التوجيه أو بطاقة الشبكة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/networktools/en-01-overview.jpg",
     "ar": "img/shots/networktools/ar-01-overview.jpg",
     "cap": {
      "en": "Overview: this computer, every network adapter, your public IP and provider at a glance.",
      "ar": "نظرة عامة: معلومات الجهاز، وكل بطاقة شبكة، وعنوان IP العام ومزوّد الخدمة في نظرة واحدة."
     }
    },
    {
     "en": "img/shots/networktools/en-02-speed-test.jpg",
     "ar": "img/shots/networktools/ar-02-speed-test.jpg",
     "cap": {
      "en": "Speed Test: download, upload, ping and jitter, with a history of every test.",
      "ar": "اختبار السرعة: التنزيل والرفع وزمن الاستجابة والتذبذب، مع سجلّ لكل اختبار."
     }
    },
    {
     "en": "img/shots/networktools/en-03-ping.jpg",
     "ar": "img/shots/networktools/ar-03-ping.jpg",
     "cap": {
      "en": "Ping with a live chart: lost packets in red, slow replies in amber.",
      "ar": "Ping مع رسم بياني مباشر: الحزم المفقودة باللون الأحمر، والردود البطيئة باللون البرتقالي."
     }
    },
    {
     "en": "img/shots/networktools/en-04-traceroute.jpg",
     "ar": "img/shots/networktools/ar-04-traceroute.jpg",
     "cap": {
      "en": "Traceroute: every hop to the destination, with three timings each.",
      "ar": "تتبّع المسار: كل قفزة حتى الوجهة، مع ثلاثة قياسات زمنية لكلٍّ منها."
     }
    },
    {
     "en": "img/shots/networktools/en-05-dns.jpg",
     "ar": "img/shots/networktools/ar-05-dns.jpg",
     "cap": {
      "en": "DNS lookup on any server, and a benchmark to find the fastest one.",
      "ar": "استعلام DNS من أي خادم، ومقارنة لمعرفة أسرع الخوادم."
     }
    },
    {
     "en": "img/shots/networktools/en-06-port-check.jpg",
     "ar": "img/shots/networktools/ar-06-port-check.jpg",
     "cap": {
      "en": "Port Check with ready presets, including Synology NAS.",
      "ar": "فحص المنافذ بقوائم جاهزة، منها قائمة لأجهزة Synology NAS."
     }
    },
    {
     "en": "img/shots/networktools/en-07-subnet.jpg",
     "ar": "img/shots/networktools/ar-07-subnet.jpg",
     "cap": {
      "en": "Subnet Calculator: network, broadcast, host range and mask from one entry.",
      "ar": "حاسبة الشبكات الفرعية: عنوان الشبكة والبثّ ونطاق العناوين والقناع من إدخال واحد."
     }
    },
    {
     "en": "img/shots/networktools/en-08-fix-and-speed.jpg",
     "ar": "img/shots/networktools/ar-08-fix-and-speed.jpg",
     "cap": {
      "en": "Fix & Speed: the apps using your internet right now, with a Stop button, and tips to make the internet faster.",
      "ar": "الإصلاح والسرعة: البرامج التي تستخدم الإنترنت الآن مع زرّ للإيقاف، ونصائح لتسريع الإنترنت."
     }
    },
    {
     "en": "img/shots/networktools/en-08-help-quick-start.jpg",
     "ar": "img/shots/networktools/ar-08-help-quick-start.jpg",
     "cap": {
      "en": "The built-in Help guide (Help button or F1): quick start.",
      "ar": "دليل المساعدة المدمج (زرّ Help أو مفتاح F1): البدء السريع."
     }
    },
    {
     "en": "img/shots/networktools/en-09-help-speed-test.jpg",
     "ar": "img/shots/networktools/ar-09-help-speed-test.jpg",
     "cap": {
      "en": "Help: how the speed test works and how to read its results.",
      "ar": "المساعدة: طريقة عمل اختبار السرعة وكيفية قراءة نتائجه."
     }
    }
   ],
   "warn": {
    "en": "Use this app only on networks and devices you own, or manage with the owner's permission. Unauthorized access to networks or devices can be a crime under Kuwait Law No. 63 of 2015 on Combating Information Technology Crimes. You alone are responsible for how you use it.",
    "ar": "لا تستخدم هذا البرنامج إلا على الشبكات والأجهزة التي تملكها أو تديرها بإذن من مالكها، فقد يُعدّ الدخول إلى الشبكات أو الأجهزة دون إذن جريمةً بموجب القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات. وأنت وحدك المسؤول عن طريقة استخدامه."
   }
  },
  {
   "id": "DriverManager",
   "name": "Driver Manager",
   "cat": "tools",
   "icon": "img/driver-manager.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/DriverManager/version.json",
   "summary": {
    "en": "Driver Manager keeps the drivers of your PC safe and up to date. Its main job is to back up all drivers and put them back after a clean Windows install, without internet.",
    "ar": "يحافظ برنامج Driver Manager على برامج تشغيل الأجهزة (التعريفات) في حاسوبك ويُبقيها محدّثة. ووظيفته الأساسية حفظ نسخة احتياطية من جميع التعريفات واستعادتها بعد إعادة تثبيت Windows، دون الحاجة إلى الإنترنت."
   },
   "features": {
    "en": [
     "Backup & Restore (main screen): save all third-party drivers of this PC in one click, as a folder or one ZIP file. Restore them later from the list, from any folder, or straight from a ZIP file.",
     "Backups are kept outside Windows: on a second drive if there is one, otherwise in Documents with a reminder to copy them to a USB drive. You can change the folder at any time.",
     "Each backup remembers which PC it came from, and the app asks before restoring a backup from a different PC.",
     "Driver Updates: finds new drivers from Windows Update (the official Microsoft source) and installs the ones you choose, after creating a system restore point.",
     "Hide drivers you do not want, so they no longer appear in update searches.",
     "Backs up the current drivers automatically before installing updates, and keeps only the last 3 backups of this PC (both can be turned off).",
     "This PC: shows the PC specifications, devices that need a driver, available updates and the last backup.",
     "Installed Drivers: search the list and export it as a CSV report.",
     "Automatic check every 4 weeks, with a notice when new drivers are found.",
     "Log: every action is shown in the app and saved to a log file."
    ],
    "ar": [
     "النسخ الاحتياطي والاستعادة (الشاشة الرئيسية): حفظ جميع تعريفات الجهاز بنقرة واحدة، في مجلد أو في ملف ZIP واحد، ثم استعادتها لاحقًا من القائمة أو من أي مجلد أو من ملف ZIP مباشرةً.",
     "تُحفظ النسخ خارج قرص Windows: على قرص ثانٍ إن وُجد، وإلا ففي مجلد المستندات مع تنبيه بنسخها إلى ذاكرة USB. ويمكن تغيير المجلد في أي وقت.",
     "تحتفظ كل نسخة باسم الجهاز الذي أُخذت منه، ويطلب البرنامج التأكيد قبل استعادة نسخة من جهاز آخر.",
     "تحديث التعريفات: يبحث عن تعريفات جديدة في Windows Update (المصدر الرسمي من Microsoft) ويثبّت ما تختاره منها، بعد إنشاء نقطة استعادة للنظام.",
     "إخفاء التعريفات غير المرغوب فيها حتى لا تظهر في نتائج البحث عن التحديثات.",
     "نسخة احتياطية تلقائية من التعريفات الحالية قبل تثبيت التحديثات، مع الاحتفاظ بآخر ثلاث نسخ فقط لهذا الجهاز (ويمكن إيقاف الخيارين).",
     "صفحة This PC: تعرض مواصفات الجهاز، والأجهزة التي تحتاج إلى تعريف، والتحديثات المتاحة، وتاريخ آخر نسخة احتياطية.",
     "التعريفات المثبّتة: البحث في القائمة وتصديرها تقريرًا بصيغة CSV.",
     "فحص تلقائي كل أربعة أسابيع، مع تنبيه عند توفّر تعريفات جديدة.",
     "السجل: تُعرض كل عملية في البرنامج وتُحفظ في ملف."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Tools and press Open on Driver Manager.",
     "Before formatting the PC, open Backup & Restore and press Back up now (a USB drive or a second drive is best).",
     "After installing Windows, open the app, pick the backup and press Restore selected.",
     "Restart the PC if the app asks."
    ],
    "ar": [
     "قبل إعادة تثبيت Windows، افتح Backup & Restore وانقر Back up now (ويُفضَّل الحفظ على ذاكرة USB أو قرص ثانٍ).",
     "بعد تثبيت Windows، افتح البرنامج واختر النسخة ثم انقر Restore selected.",
     "أعد تشغيل الجهاز إذا طلب البرنامج ذلك."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11.",
     "Administrator rights (needed to back up and install drivers).",
     "Opens from Kankon Launcher only (Tools).",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11.",
     "صلاحيات المسؤول (لازمة لحفظ التعريفات وتثبيتها).",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/drivermanager/ar-01-backup.jpg",
     "cap": {
      "en": "Backup & Restore: save every driver on the PC and restore them offline after a clean install.",
      "ar": "النسخ الاحتياطي والاستعادة: احفظ جميع تعريفات الجهاز واستعدها دون اتصال بالإنترنت بعد إعادة تثبيت Windows."
     },
     "en": "img/shots/drivermanager/en-01-backup.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-02-backing.jpg",
     "cap": {
      "en": "One click backs up all drivers and compresses them into a single ZIP file.",
      "ar": "بنقرة واحدة تُحفَظ جميع التعريفات وتُضغَط في ملف ZIP واحد."
     },
     "en": "img/shots/drivermanager/en-02-backing.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-03-otherpc.jpg",
     "cap": {
      "en": "Each backup records the PC it came from, so you are warned before restoring drivers from a different PC.",
      "ar": "تحمل كل نسخة اسم الجهاز الذي أُخذت منه، فيُنبّهك البرنامج قبل استعادة تعريفات جهاز آخر."
     },
     "en": "img/shots/drivermanager/en-03-otherpc.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-04-home.jpg",
     "cap": {
      "en": "This PC: device health, available updates, last backup and the PC specifications at a glance.",
      "ar": "هذا الجهاز: حالة الأجهزة والتحديثات المتاحة وآخر نسخة احتياطية ومواصفات الجهاز في لمحة واحدة."
     },
     "en": "img/shots/drivermanager/en-04-home.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-05-updates.jpg",
     "cap": {
      "en": "Driver updates from Windows Update, with an automatic backup and a restore point before installing.",
      "ar": "تحديث التعريفات من Windows Update، مع نسخة احتياطية تلقائية ونقطة استعادة قبل التثبيت."
     },
     "en": "img/shots/drivermanager/en-05-updates.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-06-installed.jpg",
     "cap": {
      "en": "Installed drivers with search and CSV export.",
      "ar": "قائمة التعريفات المثبتة مع البحث والتصدير إلى ملف CSV."
     },
     "en": "img/shots/drivermanager/en-06-installed.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-07-log.jpg",
     "cap": {
      "en": "A clear log of every action, also saved to a file.",
      "ar": "سجل واضح لكل عملية، يُحفَظ أيضًا في ملف."
     },
     "en": "img/shots/drivermanager/en-07-log.jpg"
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Back up your drivers before formatting",
      "ar": "نسخ التعريفات احتياطيًا قبل إعادة تثبيت Windows"
     },
     "en": [
      "Open Driver Manager from Kankon Launcher (Tools).",
      "Backup & Restore is the main screen. Check the backup folder: a USB drive or a second drive is best.",
      "Click Back up now. All third-party drivers are saved in a folder, or in one ZIP file if you choose.",
      "Wait until the app says the backup is done, then keep the USB drive safe."
     ],
     "ar": [
      "افتح Driver Manager من Kankon Launcher (قسم Tools «الأدوات»).",
      "شاشة Backup & Restore هي الشاشة الرئيسية؛ تحقّق من مجلد النسخ الاحتياطي، ويُفضَّل أن يكون على ذاكرة USB أو قرص ثانٍ.",
      "انقر Back up now؛ فتُحفظ جميع تعريفات الشركات المصنّعة في مجلد، أو في ملف ZIP واحد إن اخترت ذلك.",
      "انتظر حتى يُعلمك البرنامج باكتمال النسخ، ثم احتفظ بذاكرة USB في مكان آمن."
     ]
    },
    {
     "t": {
      "en": "Restore your drivers after installing Windows",
      "ar": "استعادة التعريفات بعد تثبيت Windows"
     },
     "en": [
      "Install Kankon Launcher, then Driver Manager (Tools). No internet is needed for the restore itself.",
      "Open Backup & Restore and pick your backup from the list, or click to choose a folder or a ZIP file.",
      "Click Restore selected. If the backup is from a different PC, the app asks you first.",
      "Restart the PC when the app asks."
     ],
     "ar": [
      "ثبّت Kankon Launcher، ثم Driver Manager من قسم Tools (الأدوات)؛ ولا تحتاج عملية الاستعادة نفسها إلى الإنترنت.",
      "افتح Backup & Restore واختر نسختك من القائمة، أو اختر مجلدًا أو ملف ZIP.",
      "انقر Restore selected، وإذا كانت النسخة من جهاز آخر، فسيطلب البرنامج تأكيدك أولًا.",
      "أعد تشغيل الجهاز عندما يطلب البرنامج ذلك."
     ]
    },
    {
     "t": {
      "en": "Update your drivers safely",
      "ar": "تحديث التعريفات بأمان"
     },
     "en": [
      "Open Driver Updates and click Check for updates. The app searches Windows Update, the official Microsoft source.",
      "Tick the drivers you want.",
      "Click Install. The app creates a restore point and backs up your current drivers first.",
      "If you do not want a driver offered again, select it and click Hide."
     ],
     "ar": [
      "افتح Driver Updates وانقر Check for updates؛ فيبحث البرنامج في Windows Update، المصدر الرسمي من Microsoft.",
      "حدّد التعريفات التي تريدها.",
      "انقر Install؛ فينشئ البرنامج نقطة استعادة، وينسخ تعريفاتك الحالية احتياطيًا أولًا.",
      "إذا لم تكن تريد ظهور تعريف معيّن مجددًا، فحدّده وانقر Hide."
     ]
    }
   ],
   "warn": {
    "en": "Warning: Installing or removing drivers can make devices stop working. Create a backup and a restore point first, and use this only on your own computer. Drivers belong to their manufacturers; do not share backed-up drivers publicly. You are solely responsible for changes you make.",
    "ar": "تحذير: قد يؤدي تثبيت التعاريف أو حذفها إلى توقّف بعض الأجهزة عن العمل. فأنشئ نسخة احتياطية ونقطة استعادة أولًا، ولا تستخدم البرنامج إلا على جهازك. والتعاريف ملك لشركاتها المصنّعة، فلا تنشر التعاريف المحفوظة علنًا. وأنت وحدك المسؤول عن التغييرات التي تجريها."
   }
  },
  {
   "id": "SystemInfo",
   "name": "System Info",
   "os": [
    "win",
    "mac"
   ],
   "cat": "tools",
   "icon": "img/system-info.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/SystemInfo/version.json",
   "summary": {
    "en": "System Info shows everything about your computer on one clear page, so you can answer \"what's in my computer?\" in seconds, and copy your specs to send to anyone.",
    "ar": "يعرض برنامج System Info جميع مواصفات جهازك في صفحة واحدة واضحة، لتعرف مكوّنات حاسوبك في ثوانٍ، وتنسخ مواصفاته لترسلها إلى من يسألك عنها."
   },
   "features": {
    "en": [
     "Graphics card: model and video memory (VRAM) in GB, shown big at the top: the same number games show in their settings. Built-in graphics are marked \"Shared with RAM\"; on Apple Silicon it shows the unified memory and GPU cores.",
     "Processor (CPU): full name, cores and threads (performance and efficiency cores on Apple Silicon), maximum speed and architecture.",
     "Memory (RAM): total size, type (DDR4, DDR5, LPDDR5 and others), speed, used slots and each installed module.",
     "Storage: every disk with its brand and model, size, type (SSD or HDD), form factor (M.2 NVMe, 2.5-inch SATA, or built-in on Macs), connection (for example PCIe 4.0 x4 or SATA 6 Gb/s) and the most it can carry, health, spin speed for hard disks, and which drives (C:, D:) are on it, plus the free space on each drive.",
     "Drive space cards: one card per drive with the space used out of the total (for example \"1.1 TB / 4 TB\"), how much is left, the % used, and a battery-style bar that turns amber at 75% and red at 90% (\"Almost full\").",
     "Test speed: a button for each disk measures its real read and write speed in MB/s (using a 1 GB temporary file that is deleted afterwards) and shows what is normal for that kind of disk, for example 1,500 to 3,500 MB/s for a PCIe 3.0 NVMe disk.",
     "Screen: resolution, refresh rate (Hz), size in inches and scaling for every screen.",
     "Operating system: Windows or macOS name, version and build, and how long the computer has been running.",
     "Battery (laptops): charge, health %, charge cycles and condition.",
     "Computer: maker and model (for example \"MacBook Air (M2, 2022)\"), motherboard, BIOS and serial number, plus the Wi-Fi and Ethernet adapters.",
     "Copy my specs: one button copies a short, tidy summary, including the disk details and measured speed, to paste in WhatsApp or anywhere. The serial number and MAC addresses are left out.",
     "Save as file: saves the same summary as a text file on the Desktop.",
     "Short plain-language notes explain each part, for example how much RAM is good for games.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "بطاقة الرسوميات: طرازها وذاكرة الفيديو (VRAM) بالغيغابايت، معروضةً بخطّ كبير في أعلى الصفحة، وهي القيمة نفسها التي تُظهرها الألعاب في إعداداتها. وتُوسَم الرسوميات المدمجة بعبارة Shared with RAM (مشتركة مع الذاكرة)، ويُعرض في أجهزة Apple Silicon حجم الذاكرة الموحّدة وعدد أنوية معالج الرسوميات.",
     "المعالج (CPU): اسمه الكامل، وعدد الأنوية والمسارات (أنوية الأداء والكفاءة في أجهزة Apple Silicon)، وأقصى سرعة له، ومعماريته.",
     "الذاكرة (RAM): حجمها الإجمالي، ونوعها (DDR4 أو DDR5 أو LPDDR5 وغيرها)، وسرعتها، والفتحات المستخدمة، وكل شريحة مركّبة.",
     "التخزين: كل قرص بعلامته التجارية وطرازه وسعته ونوعه (SSD أو HDD)، وشكله (M.2 NVMe، أو SATA بقياس 2.5 بوصة، أو مدمج في أجهزة Mac)، وطريقة توصيله (مثل PCIe 4.0 x4 أو SATA 6 Gb/s) وأقصى سرعة يدعمها، وحالته الصحية، وسرعة دوران الأقراص الصلبة (HDD)، والأقسام (C: وD:) الموجودة عليه، مع المساحة الفارغة في كل قسم.",
     "بطاقات المساحة: بطاقة لكل قسم تعرض المساحة المستخدمة من السعة الكلية (مثل «1.1 TB / 4 TB»)، والمساحة المتبقية، ونسبة الاستخدام، وشريطًا على شكل بطارية يصبح برتقاليًا عند 75% وأحمر عند 90% («شبه ممتلئ»).",
     "اختبار السرعة (Test speed): زرّ لكل قرص يقيس سرعته الفعلية في القراءة والكتابة بالميغابايت في الثانية (MB/s)، باستخدام ملف مؤقت حجمه 1 GB يُحذف بعد الاختبار، ويُبيّن السرعة المعتادة لهذا النوع من الأقراص، مثل 1,500 إلى 3,500 MB/s لأقراص PCIe 3.0 NVMe.",
     "الشاشة: الدقّة، ومعدّل التحديث (Hz)، والحجم بالبوصة، ونسبة التكبير لكل شاشة.",
     "نظام التشغيل: اسم Windows أو macOS وإصداره ورقم بنائه، والمدة التي مضت على تشغيل الجهاز.",
     "البطارية (للحواسيب المحمولة): نسبة الشحن، ونسبة صحّة البطارية، وعدد دورات الشحن، وحالتها.",
     "الجهاز: الشركة المصنّعة والطراز (مثل «MacBook Air (M2, 2022)»)، واللوحة الأم، وBIOS، والرقم التسلسلي، إضافةً إلى بطاقات Wi-Fi وEthernet.",
     "نسخ المواصفات (Copy my specs): زر واحد ينسخ ملخّصًا قصيرًا ومرتّبًا يمكنك لصقه في WhatsApp أو في أي مكان، ويتضمّن تفاصيل الأقراص وسرعتها المقيسة، دون الرقم التسلسلي وعناوين MAC.",
     "الحفظ في ملف (Save as file): يحفظ الملخّص نفسه في ملف نصي على سطح المكتب.",
     "ملاحظات قصيرة بلغة مبسّطة تشرح كل مكوّن، مثل مقدار الذاكرة المناسب للألعاب.",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Tools and click Install next to System Info, then Open.",
     "Wait a few seconds while it reads the computer.",
     "Read the four big numbers at the top: processor, graphics memory, RAM and storage. Scroll down for the details.",
     "Click Copy my specs and paste it to the person who asked, or click Save as file.",
     "Click Refresh after changing hardware or connecting a screen."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Tools (الأدوات)، ثم انقر Install بجانب System Info، ثم Open.",
     "انتظر بضع ثوانٍ ريثما يقرأ البرنامج مواصفات الجهاز.",
     "اطّلع على القيم الأربع الكبيرة في الأعلى: المعالج، وذاكرة الرسوميات، والذاكرة (RAM)، والتخزين، ثم مرّر الصفحة للاطّلاع على التفاصيل.",
     "انقر Copy my specs والصق الملخّص لمن سألك عن مواصفات جهازك، أو انقر Save as file.",
     "انقر Refresh بعد تغيير أي قطعة في الجهاز أو توصيل شاشة."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "Or a Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No administrator rights and no internet connection needed; nothing is sent anywhere.",
     "Opens from Kankon Launcher only (Tools)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول ولا إلى اتصال بالإنترنت، ولا يُرسل أي بيانات إلى أي جهة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Send your specs to a friend",
      "ar": "إرسال مواصفات جهازك إلى صديق"
     },
     "en": [
      "Open System Info from Kankon Launcher (Tools).",
      "Click Copy my specs at the top.",
      "Open WhatsApp (or any chat), paste the message and send it. The serial number and MAC addresses are not included."
     ],
     "ar": [
      "افتح System Info من Kankon Launcher (قسم Tools «الأدوات»).",
      "انقر Copy my specs في أعلى النافذة.",
      "افتح WhatsApp (أو أي تطبيق محادثة)، والصق الرسالة ثم أرسلها. ولا يتضمّن الملخّص الرقم التسلسلي ولا عناوين MAC."
     ]
    },
    {
     "t": {
      "en": "Check if a game will run",
      "ar": "معرفة ما إذا كانت لعبة ما ستعمل على جهازك"
     },
     "en": [
      "Open the game's page and find its minimum and recommended requirements.",
      "In System Info, compare the four big numbers at the top: processor, graphics memory (VRAM), RAM and free storage.",
      "If your graphics memory and RAM are at or above the recommended values, the game should run well."
     ],
     "ar": [
      "افتح صفحة اللعبة واطّلع على متطلباتها الدنيا والموصى بها.",
      "قارن في System Info القيم الأربع الكبيرة في الأعلى: المعالج، وذاكرة الرسوميات (VRAM)، والذاكرة (RAM)، والمساحة الفارغة.",
      "إذا كانت ذاكرة الرسوميات والذاكرة (RAM) مساويتين للقيم الموصى بها أو أعلى منها، فمن المتوقّع أن تعمل اللعبة بصورة جيدة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/systeminfo/win-en-help-00.jpg",
     "ar": "img/shots/systeminfo/win-ar-help-00.jpg",
     "cap": {
      "en": "The built-in Help guide: contents on the left, one topic at a time on the right.",
      "ar": "دليل المساعدة المدمج: الفهرس في اللوحة الجانبية، وكل موضوع على حدة بجانبه."
     }
    },
    {
     "en": "img/shots/systeminfo/win-en-help-09.jpg",
     "ar": "img/shots/systeminfo/win-ar-help-09.jpg",
     "cap": {
      "en": "Help: how to test a disk's real speed, with normal speeds for each kind of disk.",
      "ar": "المساعدة: طريقة قياس السرعة الفعلية للقرص، مع السرعات المعتادة لكل نوع من الأقراص."
     }
    },
    {
     "en": "img/shots/systeminfo/win-en-01-drives.jpg",
     "ar": "img/shots/systeminfo/win-ar-01-drives.jpg",
     "cap": {
      "en": "The main tiles and the new drive space cards: used out of total, space left and a fill bar that turns amber at 75% and red at 90%.",
      "ar": "البطاقات الرئيسية وبطاقات مساحة الأقسام الجديدة: المستخدَم من الإجمالي، والمساحة المتبقّية، وشريط امتلاء يتحوّل إلى البرتقالي عند 75% وإلى الأحمر عند 90%."
     }
    },
    {
     "en": "img/shots/systeminfo/mac-en-01-main.jpg",
     "ar": "img/shots/systeminfo/mac-ar-01-main.jpg",
     "cap": {
      "en": "Everything about a MacBook Pro (M1 Max) on one page: processor, graphics memory, RAM and storage at the top.",
      "ar": "جميع مواصفات جهاز MacBook Pro (M1 Max) في صفحة واحدة: المعالج، وذاكرة الرسوميات، والذاكرة (RAM)، والتخزين في الأعلى."
     }
    }
   ]
  },
  {
   "id": "ForceUninstaller",
   "name": "Force Uninstaller",
   "os": [
    "win",
    "mac"
   ],
   "cat": "tools",
   "icon": "img/force-uninstaller.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/ForceUninstaller/version.json",
   "summary": {
    "en": "Force Uninstaller removes any program from your computer, including the stubborn ones that refuse to uninstall, show an error, keep running in the background or come back after you remove them. Pick a program, stop it completely, then remove it together with everything it leaves behind. Works on Windows 10/11 and on Mac (Apple Silicon and Intel).",
    "ar": "يحذف Force Uninstaller أي برنامج من جهازك، بما فيها البرامج العنيدة التي ترفض الإزالة، أو تُظهر رسالة خطأ، أو تبقى تعمل في الخلفية، أو تعود بعد حذفها. اختر برنامجًا، وأوقفه تمامًا، ثم احذفه مع كل ما يتركه خلفه. يعمل على Windows 10 و11 وعلى Mac (معالجات Apple Silicon وIntel)."
   },
   "features": {
    "en": [
     "Every installed program in one list: classic Windows programs, Microsoft Store apps, and Mac apps from /Applications and ~/Applications, with publisher, version, install date and size. Search, filter (All / Desktop apps / Store apps) and sort by name, size or newest.",
     "Running tag: see at a glance which programs are open right now, even in the background.",
     "Stop now: closes a program, all of its background processes and its services at once (Windows services are also disabled so they do not start again). On Mac it also stops its launch agents.",
     "Uninstall: runs the program's own uninstaller (or Windows Installer for MSI programs), waits for it, then searches for what it left behind and lets you clean it. On Mac it quits the app and moves it and its files to the Trash.",
     "Force remove: for programs that refuse to uninstall or whose uninstaller is broken or missing. It stops everything and deletes the program and all its leftovers directly.",
     "Leftover finder: install folder, folders with the program's name in Program Files, ProgramData and AppData, Start menu and desktop shortcuts, services, scheduled tasks, startup (Run) entries, registry keys, Windows Installer records and its entry in Installed apps. On Mac: the .app, Application Support, Caches, Preferences, Logs, Containers, Saved Application State, launch agents and daemons, privileged helpers and installer receipts.",
     "You approve everything: a clear list grouped by kind, with the reason and size of each item. Untick anything you want to keep.",
     "Stubborn files: locked folders are taken over by the Administrators group, and files that Windows keeps in use are deleted at the next restart (with a Restart now button).",
     "Remove a folder: choose any folder by hand to force-remove a broken program that is no longer in the list.",
     "Safety: parts of Windows and macOS, Apple apps and shared runtimes (Visual C++, .NET, Edge, WebView2) are protected; shared folders such as Program Files, AppData or ~/Library are never deleted; folders used by other programs are not ticked; a Windows restore point is created first; every registry key is backed up to a .reg file; Mac files go to the Trash.",
     "A full log of every removal, and a complete in-app guide (Help button or F1).",
     "English by default, with an Arabic switch (right to left)."
    ],
    "ar": [
     "كل البرامج المثبّتة في قائمة واحدة: برامج Windows التقليدية، وتطبيقات Microsoft Store، وتطبيقات Mac في ‎/Applications و‎~/Applications، مع الناشر والإصدار وتاريخ التثبيت والحجم. مع البحث والتصفية (الكل / برامج سطح المكتب / تطبيقات المتجر) والترتيب حسب الاسم أو الحجم أو الأحدث.",
     "وسم «يعمل»: ترى مباشرةً البرامج المفتوحة الآن، حتى في الخلفية.",
     "إيقاف الآن: يغلق البرنامج وجميع عملياته الخلفية وخدماته دفعة واحدة (وتُعطَّل خدمات Windows حتى لا تعمل من جديد). وفي Mac يوقف أيضًا مساعدات الخلفية.",
     "إزالة: يشغّل أداة الإزالة الخاصة بالبرنامج (أو Windows Installer لبرامج MSI)، وينتظرها، ثم يبحث عمّا تركته خلفها ويتيح لك تنظيفه. وفي Mac يُغلق التطبيق وينقله مع ملفاته إلى سلة المهملات.",
     "حذف بالقوة: للبرامج التي ترفض الإزالة أو التي تكون أداة إزالتها معطوبة أو مفقودة؛ يوقف كل شيء ويحذف البرنامج وجميع بقاياه مباشرة.",
     "البحث عن البقايا: مجلد التثبيت، والمجلدات التي تحمل اسم البرنامج في Program Files وProgramData وAppData، واختصارات قائمة «ابدأ» وسطح المكتب، والخدمات، والمهام المجدولة، وعناصر بدء التشغيل (Run)، ومفاتيح السجل، وسجلات Windows Installer، ومدخله في قائمة التطبيقات المثبّتة. وفي Mac: ملف ‎.app، وApplication Support وCaches وPreferences وLogs وContainers وSaved Application State، ومساعدات الخلفية، والأدوات المساعدة ذات الصلاحيات، وسجلات المثبّت.",
     "أنت توافق على كل شيء: قائمة واضحة مقسّمة حسب النوع، مع سبب كل عنصر وحجمه. أزِل العلامة عن أي عنصر تريد الاحتفاظ به.",
     "الملفات العنيدة: تُنقل ملكية المجلدات المقفلة إلى مجموعة المسؤولين، والملفات التي يُبقيها Windows قيد الاستخدام تُحذف عند إعادة التشغيل التالية (مع زر «إعادة التشغيل الآن»).",
     "حذف مجلد: اختر أي مجلد يدويًا لحذف برنامج معطوب لم يعد ظاهرًا في القائمة.",
     "الأمان: أجزاء Windows وmacOS وتطبيقات Apple والمكتبات المشتركة (Visual C++ و‎.NET وEdge وWebView2) محمية؛ ولا تُحذف المجلدات المشتركة مثل Program Files أو AppData أو ‎~/Library أبدًا؛ ولا تُحدَّد المجلدات التي تستخدمها برامج أخرى؛ وتُنشأ نقطة استعادة في Windows أولًا؛ ويُحفظ كل مفتاح سجل في ملف ‎.reg احتياطي؛ وتُنقل ملفات Mac إلى سلة المهملات.",
     "سجل كامل لكل عملية حذف، ودليل مساعدة شامل داخل التطبيق (زر المساعدة أو F1).",
     "الواجهة بالإنجليزية افتراضيًا، مع زر للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Open Force Uninstaller from Kankon Launcher (Tools). In Windows, answer Yes to the administrator prompt.",
     "Choose a program in the list.",
     "Press Stop now to close it, Uninstall to remove it the normal way, or Force remove if it refuses.",
     "Read the list of items, untick anything you want to keep, then press Delete.",
     "Read the result. If some files are in use, restart the computer to finish."
    ],
    "ar": [
     "افتح Force Uninstaller من Kankon Launcher (قسم Tools). وفي Windows أجب بـ«نعم» على طلب صلاحيات المسؤول.",
     "اختر برنامجًا من القائمة.",
     "اضغط «إيقاف الآن» لإغلاقه، أو «إزالة» لحذفه بالطريقة العادية، أو «حذف بالقوة» إذا رفض.",
     "اقرأ قائمة العناصر، وأزِل العلامة عمّا تريد الاحتفاظ به، ثم اضغط «حذف العناصر المحددة».",
     "اقرأ النتيجة. وإذا كانت بعض الملفات قيد الاستخدام، فأعِد تشغيل الجهاز لإكمال الحذف."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit), administrator rights.",
     "Or macOS 11 Big Sur or newer (Apple Silicon M1 to M5 or Intel). Your Mac password is asked only for protected items.",
     "No internet needed. Nothing is sent anywhere."
    ],
    "ar": [
     "Windows 10 أو 11 (64-bit)، مع صلاحيات المسؤول.",
     "أو macOS 11 Big Sur أو أحدث (Apple Silicon من M1 إلى M5 أو Intel). وتُطلب كلمة مرور Mac للعناصر المحمية فقط.",
     "لا يحتاج إلى الإنترنت، ولا يرسل أي بيانات إلى أي جهة."
    ]
   },
   "shots": [
    {
     "en": "img/shots/forceuninstaller/win-en-01-main.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-01-main.jpg",
     "cap": {
      "en": "Every installed program in one list, with what is running now. Pick one and choose Stop now, Uninstall or Force remove.",
      "ar": "كل البرامج المثبّتة في قائمة واحدة مع ما يعمل منها الآن. اختر برنامجًا ثم «إيقاف الآن» أو «إزالة» أو «حذف بالقوة»."
     }
    },
    {
     "en": "img/shots/forceuninstaller/win-en-02-confirm.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-02-confirm.jpg",
     "cap": {
      "en": "You approve everything: every process, service, task, registry key and folder, grouped by kind. Untick what you want to keep.",
      "ar": "أنت من يوافق على كل شيء: كل عملية وخدمة ومهمة مجدولة ومفتاح في السجل (Registry) ومجلد، مصنّفة حسب النوع. أزل العلامة عمّا تريد الاحتفاظ به."
     }
    },
    {
     "en": "img/shots/forceuninstaller/win-en-03-done.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-03-done.jpg",
     "cap": {
      "en": "The result: what was stopped and deleted, with a full log.",
      "ar": "النتيجة: ما أُوقف وما حُذف، مع سجل كامل."
     }
    },
    {
     "en": "img/shots/forceuninstaller/win-en-04-wait.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-04-wait.jpg",
     "cap": {
      "en": "Uninstall opens the program's own uninstaller and waits while you follow its steps. If it fails or does nothing, switch to Force remove.",
      "ar": "عند الضغط على «إزالة» تُفتح أداة الإزالة الخاصة بالبرنامج، وينتظر Force Uninstaller حتى تُكمل خطواتها. وإذا فشلت أو لم تفعل شيئًا فانتقل إلى «حذف بالقوة»."
     }
    },
    {
     "en": "img/shots/forceuninstaller/win-en-help-00.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-help-00.jpg",
     "cap": {
      "en": "The built-in Help guide (Help button or F1).",
      "ar": "دليل المساعدة المدمج (زرّ Help أو المفتاح F1)."
     }
    },
    {
     "en": "img/shots/forceuninstaller/win-en-help-05.jpg",
     "ar": "img/shots/forceuninstaller/win-ar-help-05.jpg",
     "cap": {
      "en": "Help: how to force-remove a stubborn program, step by step.",
      "ar": "المساعدة: كيف تحذف برنامجًا عنيدًا بالقوة، خطوة بخطوة."
     }
    }
   ],
   "warn": {
    "en": "Warning: Force removal deletes files and settings and cannot be undone. Removing system, security or someone else's software may damage the computer or break rules where you work. Use it only on your own computer. You are solely responsible for what you remove.",
    "ar": "تحذير: الإزالة القسرية تحذف الملفات والإعدادات، ولا يمكن التراجع عنها. وإزالة برامج النظام أو برامج الحماية أو البرامج التي تخص غيرك قد تضرّ بالجهاز أو تخالف أنظمة جهة عملك. فلا تستخدمها إلا على جهازك. وأنت وحدك المسؤول عمّا تزيله."
   }
  },
  {
   "id": "FileRecovery",
   "name": "File Recovery",
   "os": [
    "win",
    "mac"
   ],
   "cat": "tools",
   "icon": "img/file-recovery.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/FileRecovery/version.json",
   "summary": {
    "en": "File Recovery gets back files you deleted by mistake: photos, videos, music, documents, archives and more. It looks in the Recycle Bin (Trash on a Mac), finds recently deleted files with their names on NTFS drives, and searches the free space of any drive for files by their content, which also works on memory cards and USB sticks that were formatted. Works on Windows 10 and 11 and on Mac (Apple Silicon and Intel).",
    "ar": "يستعيد File Recovery الملفات التي حذفتها خطأً: الصور ومقاطع الفيديو والموسيقى والمستندات والملفات المضغوطة وغيرها. فهو يبحث في سلة المحذوفات (سلة المهملات في Mac)، ويعثر على الملفات المحذوفة حديثًا بأسمائها في أقراص NTFS، ويبحث في المساحة الفارغة من أي قرص عن الملفات من خلال محتواها، وهذا يصلح أيضًا لبطاقات الذاكرة وذواكر USB التي هُيّئت. يعمل على Windows 10 و11 وعلى Mac (معالجات Apple Silicon وIntel)."
   },
   "features": {
    "en": [
     "Recycle Bin / Trash: lists everything you deleted but did not empty, with its original folder and deletion time.",
     "Quick scan (NTFS): finds recently deleted files with their real names, folders and dates in seconds.",
     "Deep scan: searches the free space of the drive for more than 50 file types by their content: JPG, PNG, HEIC, GIF, RAW (CR2, CR3, NEF, ARW, DNG), MP4, MOV, AVI, MKV, WMV, MP3, WAV, M4A, PDF, Word, Excel, PowerPoint, ZIP, RAR, 7Z and more. Works on NTFS, FAT32 and exFAT, and after a quick format.",
     "Whole disk scan: for a drive that was formatted, shows as RAW or asks to be formatted.",
     "Smart photos (new in 1.1): reads the date, place and camera stored in each found photo and groups photos into events and trips (for example \"Salmiya, 13 Nov 2026\"), months or places; marks look-alike copies, blurry shots and screenshots; \"Best photos\" shows only the good ones; recover into folders by event, month or place. Works offline: place names for 144,000 towns are built in, nothing is uploaded.",
     "Preview of pictures, details of every file, and a condition mark (likely good, unknown, partly overwritten).",
     "Filters by type, size and place, search, and sorting by name, size or date.",
     "Safe: the scanned drive is only read; recovered files must go to a different drive; a report (CSV) lists every recovered file.",
     "Honest about limits: clear notes for SSDs (TRIM), system drives and Mac internal drives.",
     "English by default, with an Arabic switch (right to left)."
    ],
    "ar": [
     "سلة المحذوفات وسلة المهملات: تعرض كل ما حذفته ولم تُفرغه، مع مجلده الأصلي ووقت حذفه.",
     "الفحص السريع (NTFS): يعثر خلال ثوانٍ على الملفات المحذوفة حديثًا بأسمائها الحقيقية ومجلداتها وتواريخها.",
     "الفحص العميق: يبحث في المساحة الفارغة من القرص عن أكثر من 50 نوعًا من الملفات من خلال محتواها: JPG وPNG وHEIC وGIF والصيغ الخام (CR2 وCR3 وNEF وARW وDNG) وMP4 وMOV وAVI وMKV وWMV وMP3 وWAV وM4A وPDF وWord وExcel وPowerPoint وZIP وRAR و7Z وغيرها. ويعمل على أنظمة NTFS وFAT32 وexFAT، وبعد التهيئة السريعة.",
     "فحص القرص كاملًا: للقرص الذي هُيّئ، أو يظهر بتنسيق RAW، أو يطلب التهيئة.",
     "الصور الذكية (جديد في الإصدار 1.1): يقرأ التاريخ والمكان والكاميرا المحفوظة في كل صورة يعثر عليها، ويجمع الصور في مناسبات ورحلات (مثل «السالمية، 13 نوفمبر 2026») أو حسب الشهر أو المكان، ويُعلّم النسخ المتشابهة والصور المهتزّة ولقطات الشاشة، ويعرض خيار «أفضل الصور» الجيدة منها فقط، ويستعيدها في مجلدات حسب المناسبة أو الشهر أو المكان. يعمل دون إنترنت: أسماء 144 ألف مدينة وبلدة مضمّنة فيه، ولا يُرفع أي شيء.",
     "معاينة الصور، وتفاصيل كل ملف، وعلامة لحالته (سليم على الأرجح، أو غير معروف، أو كُتب فوق جزء منه).",
     "تصفية حسب النوع والحجم والمكان، وبحث، وترتيب بالاسم أو الحجم أو التاريخ.",
     "آمن: القرص الذي يُفحص يُقرأ فقط، ويجب حفظ الملفات المستعادة على قرص آخر، ويسجّل تقرير (CSV) كل ملف مستعاد.",
     "صريح في حدوده: ملاحظات واضحة لأقراص SSD (ميزة TRIM) وأقراص النظام والقرص الداخلي في Mac.",
     "الواجهة بالإنجليزية افتراضيًا، مع زر للتبديل إلى العربية (من اليمين إلى اليسار)."
    ]
   },
   "how": {
    "en": [
     "Stop using the drive the files were on.",
     "Choose where the files were: Recycle Bin, a drive, a memory card or a whole disk.",
     "Choose Quick scan and/or Deep scan and press Start scan.",
     "Filter, search and preview the found files, and tick the ones you want.",
     "Press Recover selected and choose a folder on a different drive."
    ],
    "ar": [
     "توقّف عن استخدام القرص الذي كانت عليه الملفات.",
     "اختر مكان الملفات: سلة المحذوفات، أو قرصًا، أو بطاقة ذاكرة، أو قرصًا كاملًا.",
     "اختر الفحص السريع أو العميق أو كليهما، واضغط «Start scan (بدء الفحص)».",
     "صفِّ الملفات التي عُثر عليها وابحث فيها وعاينها، وحدّد ما تريده منها.",
     "اضغط «Recover selected (استعادة المحدد)» واختر مجلدًا على قرص آخر."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit); runs as administrator to read drives directly.",
     "Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel); asks for the Mac password to scan a drive, and Full Disk Access for the Trash. The internal drive of a Mac cannot be scanned (encrypted).",
     "A second drive (USB stick or external drive) to save the recovered files.",
     "Opens from Kankon Launcher only (Tools).",
     "Place names: GeoNames (geonames.org, CC BY 4.0) and Unicode CLDR."
    ],
    "ar": [
     "Windows 10 أو 11 (64-bit)، ويعمل بصلاحيات المسؤول ليقرأ الأقراص مباشرة.",
     "Mac بنظام macOS 11 Big Sur أو أحدث (Apple Silicon أو Intel)، ويطلب كلمة مرور Mac لفحص قرص، والوصول الكامل إلى القرص لعرض سلة المهملات. ولا يمكن فحص القرص الداخلي في Mac (فهو مشفّر).",
     "قرص ثانٍ (ذاكرة USB أو قرص خارجي) لحفظ الملفات المستعادة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات).",
     "أسماء الأماكن: GeoNames (geonames.org، بترخيص CC BY 4.0) وUnicode CLDR."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Get back deleted photos from a memory card",
      "ar": "استعادة صور محذوفة من بطاقة ذاكرة"
     },
     "en": [
      "Stop using the card and connect it to the computer.",
      "Open File Recovery from Kankon Launcher (Tools) and choose the card under Drives.",
      "Tick Deep scan and press Start scan.",
      "Pick Images on the left, preview the photos and tick the ones you want.",
      "Press Recover selected and choose a folder on a different drive."
     ],
     "ar": [
      "توقّف عن استخدام البطاقة ووصّلها بالحاسوب.",
      "افتح File Recovery من Kankon Launcher (قسم Tools) واختر البطاقة من قائمة الأقراص.",
      "حدّد «Deep scan» (فحص عميق) واضغط «Start scan» (بدء الفحص).",
      "اختر «Images» (الصور) من الجانب، وعاين الصور، وحدّد ما تريده منها.",
      "اضغط «Recover selected» (استعادة المحدد) واختر مجلدًا على قرص آخر."
     ]
    },
    {
     "t": {
      "en": "Restore a file from the Recycle Bin or Trash",
      "ar": "استرجاع ملف من سلة المحذوفات أو سلة المهملات"
     },
     "en": [
      "Choose Recycle Bin (Trash on a Mac) under Where were the files?",
      "Find the file by name, type or date.",
      "Tick it and press Recover selected, then choose a folder."
     ],
     "ar": [
      "اختر «Recycle Bin» (سلة المحذوفات)، أو «Trash» (سلة المهملات) في Mac، من قسم مكان الملفات.",
      "ابحث عن الملف بالاسم أو النوع أو التاريخ.",
      "حدّده واضغط «Recover selected» (استعادة المحدد)، ثم اختر مجلدًا."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/filerecovery/win-en-01-home.jpg",
     "ar": "img/shots/filerecovery/win-ar-01-home.jpg",
     "cap": {
      "en": "Choose where the files were: Recycle Bin, a drive, a memory card or a whole disk, then the kind of scan.",
      "ar": "اختر مكان الملفات: سلة المحذوفات أو قرصًا أو بطاقة ذاكرة أو قرصًا كاملًا، ثم نوع الفحص."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-02-ssd.jpg",
     "ar": "img/shots/filerecovery/win-ar-02-ssd.jpg",
     "cap": {
      "en": "Clear notes for SSDs (TRIM) and the system drive before you scan.",
      "ar": "ملاحظات واضحة لأقراص SSD (ميزة TRIM) ولقرص النظام قبل الفحص."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-03-scanning.jpg",
     "ar": "img/shots/filerecovery/win-ar-03-scanning.jpg",
     "cap": {
      "en": "Deep scan searches the free space for files by their content.",
      "ar": "يبحث الفحص العميق في المساحة الفارغة عن الملفات من خلال محتواها."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-04-results.jpg",
     "ar": "img/shots/filerecovery/win-ar-04-results.jpg",
     "cap": {
      "en": "Found files with preview, details and a condition mark.",
      "ar": "الملفات التي عُثر عليها مع المعاينة والتفاصيل وعلامة الحالة."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-05-filters.jpg",
     "ar": "img/shots/filerecovery/win-ar-05-filters.jpg",
     "cap": {
      "en": "Filter by type, size and place, search and sort.",
      "ar": "التصفية حسب النوع والحجم والمكان، والبحث والترتيب."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-11-best.jpg",
     "ar": "img/shots/filerecovery/win-ar-11-best.jpg",
     "cap": {
      "en": "Smart photos: photos grouped by event or trip, with a Best photos filter.",
      "ar": "الصور الذكية: الصور مجمّعة حسب المناسبة أو الرحلة، مع خيار «أفضل الصور»."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-12-place.jpg",
     "ar": "img/shots/filerecovery/win-ar-12-place.jpg",
     "cap": {
      "en": "Group photos by place, with the date taken, place and camera of each photo.",
      "ar": "تجميع الصور حسب المكان، مع تاريخ الالتقاط والمكان والكاميرا لكل صورة."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-13-dup.jpg",
     "ar": "img/shots/filerecovery/win-ar-13-dup.jpg",
     "cap": {
      "en": "Look-alike copies and blurry shots are marked, so you keep only the best.",
      "ar": "تُعلَّم النسخ المتشابهة والصور المهتزّة لتحتفظ بأفضلها فقط."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-06-preview.jpg",
     "ar": "img/shots/filerecovery/win-ar-06-preview.jpg",
     "cap": {
      "en": "Tick the files you want to recover.",
      "ar": "حدّد الملفات التي تريد استعادتها."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-07-same.jpg",
     "ar": "img/shots/filerecovery/win-ar-07-same.jpg",
     "cap": {
      "en": "Recovered files must go to a different drive, so nothing is overwritten.",
      "ar": "يجب حفظ الملفات المستعادة على قرص آخر حتى لا يُكتب فوق شيء."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-08-recovering.jpg",
     "ar": "img/shots/filerecovery/win-ar-08-recovering.jpg",
     "cap": {
      "en": "Recovering: the scanned drive is only read.",
      "ar": "الاستعادة: القرص الذي يُفحص يُقرأ فقط."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-09-done.jpg",
     "ar": "img/shots/filerecovery/win-ar-09-done.jpg",
     "cap": {
      "en": "Done: files sorted into folders by type, with a CSV report.",
      "ar": "اكتملت الاستعادة: الملفات مرتّبة في مجلدات حسب النوع مع تقرير CSV."
     }
    },
    {
     "en": "img/shots/filerecovery/win-en-10-bin.jpg",
     "ar": "img/shots/filerecovery/win-ar-10-bin.jpg",
     "cap": {
      "en": "Recycle Bin: everything you deleted but did not empty.",
      "ar": "سلة المحذوفات: كل ما حذفته ولم تُفرغه."
     }
    },
    {
     "en": "img/shots/filerecovery/mac-en-01-home.jpg",
     "ar": "img/shots/filerecovery/mac-ar-01-home.jpg",
     "cap": {
      "en": "File Recovery on Mac: Trash, drives, memory cards and whole disks.",
      "ar": "File Recovery على Mac: سلة المهملات والأقراص وبطاقات الذاكرة والأقراص الكاملة."
     }
    }
   ],
   "warn": {
    "en": "Warning: use it only on drives you own or have permission to examine. No tool can promise every file: overwritten files and files erased by an SSD cannot come back.",
    "ar": "تحذير: لا تستخدمه إلا على أقراص تملكها أو أُذِن لك بفحصها. ولا توجد أداة تضمن استعادة كل ملف، فالملفات التي كُتب فوقها أو محاها قرص SSD لا يمكن أن تعود."
   }
  },
  {
   "id": "KankonPhotoAI",
   "name": "Kankon Photo AI",
   "os": [
    "win",
    "mac"
   ],
   "cat": "tools",
   "icon": "img/kankon-photo-ai.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/KankonPhotoAI/version.json",
   "summary": {
    "en": "Kankon Photo AI is a photo program with strong AI features. It sorts the photos already on your computer into smart albums, finds duplicates, look-alikes and blurry shots, finds photos by a description, edits photos with sliders or plain words, makes AI edits such as background removal, and puts your photos into tidy album folders. Works on Windows 10/11 and on Mac (Apple Silicon).",
    "ar": "Kankon Photo AI برنامج صور بميزات ذكاء اصطناعي قوية. يرتّب الصور الموجودة على حاسوبك في ألبومات ذكية، ويعثر على الصور المكررة والمتشابهة والمشوشة، ويبحث عن الصور بالوصف، ويعدّل الصور بأشرطة التحكم أو بالكلام العادي، ويجري تعديلات ذكية مثل إزالة الخلفية، ويضع صورك في مجلدات ألبومات مرتبة. يعمل على Windows 10 و11 وعلى Mac (Apple Silicon)."
   },
   "features": {
    "en": [
     "Your library: reads the folders you choose (your Pictures folder first) with the date, place (from GPS, offline) and camera of every photo. Sort by date, name, size or AI score; select one or many photos.",
     "Smart albums: Events & trips (photos taken close together in time and place), Months, Years, Places, AI categories (Beach, City, Nature, Sunset, Food, Documents...), Cameras, Favourites, Best shots and your own albums.",
     "Clean up: exact copies, look-alikes (bursts, smaller or cropped copies), blurry photos and screenshots. The best photo of every group is kept and the others go to the Recycle Bin / Trash.",
     "Find similar: photos of the same scene by picture structure, colours and AI tags.",
     "AI search: type \"sunset by the sea in Kuwait last year\" or \"receipts from March\" in English or Arabic; the AI understands dates, places and meaning.",
     "AI tags & captions: a caption in English and Arabic, keywords, a category, a quality score, a people count and any readable text for every photo. Faces are never recognised.",
     "Photo editor: auto enhance, crop, rotate, 8 looks, 12 sliders, before/after, full history with undo, upscale 2×/4×, save a copy with the date and GPS kept, and batch edits.",
     "Edit with words: \"brighter and warmer\", \"moody black and white\"; the AI sets the sliders for you.",
     "Generative AI editing (OpenAI or Gemini): remove or replace the background, remove an object, new sky, restore an old photo, expand the view and art styles.",
     "Organize into folders: copy or move your photos into album folders by event, month, year, place, category or camera, with a full preview first and Undo afterwards."
    ],
    "ar": [
     "مكتبتك: يقرأ المجلدات التي تختارها (مجلد «الصور» أولًا) مع تاريخ كل صورة ومكانها (من GPS بلا إنترنت) والكاميرا. رتّب حسب التاريخ أو الاسم أو الحجم أو تقييم الذكاء الاصطناعي، واختر صورة واحدة أو عدة صور.",
     "الألبومات الذكية: المناسبات والرحلات (صور ملتقطة متقاربة في الوقت والمكان)، والأشهر، والسنوات، والأماكن، وفئات الذكاء الاصطناعي (شاطئ، مدينة، طبيعة، غروب، طعام، مستندات...)، والكاميرات، والمفضلة، وأفضل اللقطات، وألبوماتك الخاصة.",
     "التنظيف: النسخ المطابقة، والصور المتشابهة (التصوير المتتابع والنسخ الأصغر أو المقصوصة)، والصور المشوشة، ولقطات الشاشة. وتبقى أفضل صورة في كل مجموعة وتذهب البقية إلى سلة المحذوفات.",
     "البحث عن صور مشابهة: صور المشهد نفسه حسب بنية الصورة وألوانها ووسوم الذكاء الاصطناعي.",
     "البحث الذكي: اكتب «غروب على البحر في الكويت السنة الماضية» أو «إيصالات شهر مارس» بالعربية أو الإنجليزية، ويفهم الذكاء الاصطناعي التواريخ والأماكن والمعنى.",
     "الوسوم والأوصاف الذكية: وصف بالعربية والإنجليزية وكلمات مفتاحية وفئة وتقييم للجودة وعدد الأشخاص وأي نص مقروء لكل صورة. ولا يتعرّف البرنامج على الوجوه أبدًا.",
     "محرر الصور: تحسين تلقائي، وقص، وتدوير، و8 أنماط، و12 شريط ضبط، ومقارنة قبل وبعد، وسجل كامل مع التراجع، وتكبير بمرتين أو 4 مرات، وحفظ نسخة مع الإبقاء على التاريخ وGPS، وتعديل دفعة واحدة.",
     "التعديل بالكلام: «أكثر إشراقًا ودفئًا»، «أبيض وأسود بجو درامي»؛ ويضبط الذكاء الاصطناعي الأشرطة لك.",
     "التعديل التوليدي بالذكاء الاصطناعي (OpenAI أو Gemini): إزالة الخلفية أو استبدالها، وإزالة شيء، وسماء جديدة، وترميم صورة قديمة، وتوسيع المشهد، وأنماط فنية.",
     "الترتيب في مجلدات: انسخ صورك أو انقلها إلى مجلدات ألبومات حسب المناسبة أو الشهر أو السنة أو المكان أو الفئة أو الكاميرا، مع معاينة كاملة قبل التنفيذ وزر تراجع بعده."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Photo AI from Kankon Launcher (Tools). Your Pictures folder is read; add more with + Add folder.",
     "Browse All photos and Smart albums; double-click a photo to edit it.",
     "Optional: open AI settings, choose a provider, paste your key and press Save and test, then run AI tags & captions.",
     "Use Duplicates & look-alikes and Blurry photos to free space, and Organize into folders to tidy your folders."
    ],
    "ar": [
     "افتح Kankon Photo AI من Kankon Launcher (قسم Tools). يُقرأ مجلد «الصور»، وأضف غيره عبر «+ إضافة مجلد».",
     "تصفّح «كل الصور» و«الألبومات الذكية»، وانقر الصورة نقرتين لتعديلها.",
     "اختياري: افتح «إعدادات الذكاء الاصطناعي»، واختر مزوّدًا، والصق مفتاحك واضغط «حفظ واختبار»، ثم شغّل «وسوم وأوصاف ذكية».",
     "استخدم «المكرر والمتشابه» و«الصور المشوشة» لتوفير المساحة، و«الترتيب في مجلدات» لترتيب مجلداتك."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "Or a Mac with macOS 11 Big Sur or newer (Apple Silicon), through Kankon Launcher for Mac.",
     "The library, albums, cleanup and the basic editor work offline. The AI features need your own API key from OpenAI, Google Gemini or Anthropic Claude; you pay the provider directly.",
     "Opens from Kankon Launcher only (Tools)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "تعمل المكتبة والألبومات والتنظيف والمحرر الأساسي دون إنترنت. أما ميزات الذكاء الاصطناعي فتحتاج مفتاح API خاصًّا بك من OpenAI أو Google Gemini أو Anthropic Claude، وتدفع للمزوّد مباشرة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Sort your photos into smart albums",
      "ar": "ترتيب صورك في ألبومات ذكية"
     },
     "en": [
      "Open Kankon Photo AI from Kankon Launcher (Tools); your Pictures folder is read, add more with + Add folder.",
      "Open Smart albums to see Events & trips, Months, Places and more.",
      "To get AI categories and search, open AI settings, choose a provider, paste your key, press Save and test, then run AI tags & captions.",
      "Use Organize into folders to copy or move your photos into tidy album folders."
     ],
     "ar": [
      "افتح Kankon Photo AI من Kankon Launcher (قسم Tools)، فيُقرأ مجلد «الصور»، وأضف غيره عبر «+ إضافة مجلد».",
      "افتح «الألبومات الذكية» لترى المناسبات والرحلات والأشهر والأماكن وغيرها.",
      "للحصول على فئات الذكاء الاصطناعي والبحث، افتح «إعدادات الذكاء الاصطناعي»، واختر مزوّدًا، والصق مفتاحك، واضغط «حفظ واختبار»، ثم شغّل «وسوم وأوصاف ذكية».",
      "استخدم «الترتيب في مجلدات» لنسخ صورك أو نقلها إلى مجلدات ألبومات مرتبة."
     ]
    },
    {
     "t": {
      "en": "Clean up and edit photos",
      "ar": "تنظيف الصور وتعديلها"
     },
     "en": [
      "Open Duplicates & look-alikes and Blurry photos; the best photo of each group is kept and the rest go to the Recycle Bin.",
      "Double-click a photo to open the editor: auto enhance, crop, looks and 12 sliders.",
      "Type what you want in Edit with words, or use generative editing (needs an OpenAI or Gemini key) to remove the background or an object."
     ],
     "ar": [
      "افتح «المكرر والمتشابه» و«الصور المشوشة»، فتبقى أفضل صورة في كل مجموعة وتذهب البقية إلى سلة المحذوفات.",
      "انقر نقرًا مزدوجًا على الصورة لفتح المحرر: تحسين تلقائي، وقص، وأنماط، و12 شريط ضبط.",
      "اكتب ما تريد في «التعديل بالكلام»، أو استخدم «التعديل التوليدي» (يحتاج مفتاح OpenAI أو Gemini) لإزالة الخلفية أو شيء من الصورة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/kankonphotoai/win-en-01-library.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-01-library.jpg",
     "cap": {
      "en": "Your whole photo library, read from the folders you choose, with date, place and camera.",
      "ar": "مكتبة صورك كاملة، مقروءة من المجلدات التي تختارها، مع التاريخ والمكان والكاميرا."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-03-albums.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-03-albums.jpg",
     "cap": {
      "en": "Smart albums: events and trips, months, years, places and more.",
      "ar": "الألبومات الذكية: المناسبات والرحلات والأشهر والسنوات والأماكن وغيرها."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-05-categories.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-05-categories.jpg",
     "cap": {
      "en": "AI categories such as Beach, City, Nature, Sunset, Food and Documents.",
      "ar": "فئات الذكاء الاصطناعي مثل الشاطئ والمدينة والطبيعة والغروب والطعام والمستندات."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-07-search.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-07-search.jpg",
     "cap": {
      "en": "AI search: type a description in English or Arabic and it understands dates, places and meaning.",
      "ar": "البحث الذكي: اكتب وصفًا بالعربية أو الإنجليزية، ويفهم التواريخ والأماكن والمعنى."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-09-duplicates.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-09-duplicates.jpg",
     "cap": {
      "en": "Duplicates and look-alikes: keep the best and send the rest to the Recycle Bin.",
      "ar": "المكرر والمتشابه: أبقِ الأفضل وأرسل البقية إلى سلة المحذوفات."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-12-aitags.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-12-aitags.jpg",
     "cap": {
      "en": "AI tags and captions in English and Arabic, with keywords and a quality score. Faces are never recognised.",
      "ar": "وسوم وأوصاف ذكية بالعربية والإنجليزية، مع كلمات مفتاحية وتقييم للجودة. ولا يتعرّف البرنامج على الوجوه أبدًا."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-13-settings.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-13-settings.jpg",
     "cap": {
      "en": "AI settings: choose OpenAI, Gemini or Claude and paste your own key; it stays on this computer.",
      "ar": "إعدادات الذكاء الاصطناعي: اختر OpenAI أو Gemini أو Claude والصق مفتاحك الخاص، ويبقى على هذا الحاسوب."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-14-editor.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-14-editor.jpg",
     "cap": {
      "en": "Photo editor: auto enhance, crop, looks, 12 sliders and full history.",
      "ar": "محرر الصور: تحسين تلقائي، وقص، وأنماط، و12 شريط ضبط، وسجل كامل."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-15-words.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-15-words.jpg",
     "cap": {
      "en": "Edit with words: type \"brighter and warmer\" and the AI sets the sliders.",
      "ar": "التعديل بالكلام: اكتب «أكثر إشراقًا ودفئًا» ويضبط الذكاء الاصطناعي الأشرطة."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-17-generate.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-17-generate.jpg",
     "cap": {
      "en": "Generative editing: remove or replace the background, remove an object or add a new sky.",
      "ar": "التعديل التوليدي: إزالة الخلفية أو استبدالها، وإزالة شيء، أو إضافة سماء جديدة."
     }
    },
    {
     "en": "img/shots/kankonphotoai/win-en-11-organize.jpg",
     "ar": "img/shots/kankonphotoai/win-ar-11-organize.jpg",
     "cap": {
      "en": "Organize into folders by event, month, place, category or camera, with a preview and Undo.",
      "ar": "الترتيب في مجلدات حسب المناسبة أو الشهر أو المكان أو الفئة أو الكاميرا، مع معاينة وتراجع."
     }
    },
    {
     "en": "img/shots/kankonphotoai/mac-en-01-library.jpg",
     "ar": "img/shots/kankonphotoai/mac-ar-01-library.jpg",
     "cap": {
      "en": "Kankon Photo AI on Mac.",
      "ar": "Kankon Photo AI على Mac."
     }
    }
   ],
   "warn": {
    "en": "Legal notice: use AI editing responsibly. Do not edit photos of other people to mislead, insult or harm them, and do not share edited photos as real evidence. Misuse can be a crime under Kuwait Law No. 63 of 2015 on combating information technology crimes and similar laws elsewhere.",
    "ar": "تنبيه قانوني: استخدم التعديل بالذكاء الاصطناعي بمسؤولية. لا تعدّل صور الآخرين لتضليلهم أو الإساءة إليهم أو الإضرار بهم، ولا تنشر صورًا معدّلة على أنها دليل حقيقي. فإساءة الاستخدام قد تكون جريمة وفق القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات ووفق قوانين مماثلة في دول أخرى."
   }
  },
  {
   "id": "GameRater",
   "name": "Game Rater",
   "os": [
    "win",
    "mac"
   ],
   "cat": "games",
   "icon": "img/game-rater.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/GameRater/version.json",
   "summary": {
    "en": "Game Rater estimates how well every game installed on your computer will run on your graphics card. It finds your graphics cards and processor, searches only the drives and folders you choose for your games, and shows the estimated frame rate (FPS) of each game at 1080p, 1440p and 4K. Works on Windows 10/11 and on Mac (Apple Silicon and Intel).",
    "ar": "يقدّر Game Rater مدى جودة تشغيل كل لعبة مثبّتة على حاسوبك ببطاقة الرسومات لديك. فهو يتعرّف على بطاقات الرسومات والمعالج، ويبحث عن ألعابك في الأقراص والمجلدات التي تختارها فقط، ويعرض معدل الإطارات التقديري (FPS) لكل لعبة بدقة 1080p و1440p و4K. يعمل على Windows 10 و11 وعلى Mac (Apple Silicon وIntel)."
   },
   "features": {
    "en": [
     "Graphics card detection: every card in the computer with its video memory. Two cards (for example built-in graphics plus an NVIDIA card)? You choose which one to rate.",
     "Rate another card: pick any of more than 160 NVIDIA, AMD, Intel and Apple graphics chips to see how your games would run on it before you buy.",
     "You choose where to search: tick drives (games are often on D: or an external SSD, not on the Windows drive) or add folders.",
     "Finds Steam, Epic Games, GOG and Xbox games, plus game folders from EA, Ubisoft, Riot, Battle.net or your own copies. On Mac: native games in Applications and in Steam.",
     "Estimated FPS for every game at 1080p, 1440p and 4K with the preset (Low to Ultra), upscaling (DLSS / FSR / XeSS) and ray tracing you choose, colour-coded with a rating: Excellent, Smooth, Playable, Struggles or Too heavy.",
     "Your screen: set its refresh rate (60, 120, 144, 165 or 240 Hz; read automatically) and every game shows whether it fills your screen or how much of it it reaches.",
     "Setup rating: rank 1 to 15, net performance compared with a PlayStation 5 (= 100), scores for rasterization, ray tracing and processor, a bottleneck check, estimated gaming power use and a suggested power supply.",
     "A card icon tinted in the maker's colour, with the maker's name (NVIDIA, AMD, Intel or Apple) in plain text, next to the rating.",
     "Honest estimates: every number is marked as an estimate from the Kankon performance model (card and processor scores written by Kankon from public specifications, plus a demand profile for more than 90 games). Nothing is sent over the internet."
    ],
    "ar": [
     "التعرّف على بطاقات الرسومات: كل بطاقة في الحاسوب مع ذاكرة الرسومات. لديك بطاقتان (مثل رسومات مدمجة وبطاقة NVIDIA)؟ أنت تختار أيهما يُقيَّم.",
     "تقييم بطاقة أخرى: اختر أيًّا من أكثر من 160 شريحة رسومات من NVIDIA وAMD وIntel وApple لترى كيف ستعمل ألعابك عليها قبل الشراء.",
     "أنت تختار مكان البحث: حدّد الأقراص (فالألعاب كثيرًا ما تكون على القرص D: أو على قرص SSD خارجي لا على قرص Windows) أو أضف مجلدات.",
     "يعثر على ألعاب Steam وEpic Games وGOG وXbox، وعلى مجلدات ألعاب EA وUbisoft وRiot وBattle.net أو نسخك الخاصة. وفي Mac: الألعاب الأصلية في مجلد Applications وفي Steam.",
     "معدل إطارات تقديري لكل لعبة بدقة 1080p و1440p و4K وفق مستوى الرسومات (من Low إلى Ultra) ورفع الدقة (DLSS / FSR / XeSS) وتتبّع الأشعة الذي تختاره، بألوان وكلمة تقييم: ممتاز، سلس، قابل للعب، متعثر، ثقيل جدًا.",
     "شاشتك: حدّد معدل تحديثها (60 أو 120 أو 144 أو 165 أو 240 Hz، ويقرؤه البرنامج تلقائيًا)، فتُظهر كل لعبة هل تبلغ أقصى معدل لشاشتك أو النسبة التي تبلغها منه.",
     "تقييم الجهاز: مرتبة من 1 إلى 15، وصافي الأداء مقارنةً بجهاز PlayStation 5 (= 100)، ودرجات للرسم التقليدي وتتبّع الأشعة والمعالج، وفحص الاختناق، والاستهلاك التقديري للطاقة في أثناء اللعب، وحجم مزود الطاقة المقترح.",
     "أيقونة بطاقة بلون الشركة المصنّعة مع اسمها نصًّا عاديًا (NVIDIA أو AMD أو Intel أو Apple) بجانب التقييم.",
     "تقديرات صريحة: كل رقم موسوم بأنه تقدير من نموذج الأداء الخاص بـKankon (درجات للبطاقات والمعالجات أعدّها Kankon اعتمادًا على المواصفات المنشورة، وملف لمتطلبات أكثر من 90 لعبة). ولا يُرسل أي شيء عبر الإنترنت."
    ]
   },
   "how": {
    "en": [
     "Open Game Rater from Kankon Launcher (Games).",
     "If you have two graphics cards, press the one you play on.",
     "Tick the drives where your games are, or press Add folder..., then press Scan for games.",
     "Choose resolution, preset, upscaling and ray tracing. Every game updates at once.",
     "Sort by Most demanding, Highest FPS or Name. Press ? Help (F1) for the full guide."
    ],
    "ar": [
     "افتح Game Rater من Kankon Launcher (قسم Games).",
     "إذا كانت لديك بطاقتا رسومات، فاضغط البطاقة التي تلعب عليها.",
     "حدّد الأقراص التي فيها ألعابك، أو اضغط «Add folder...» (إضافة مجلد)، ثم اضغط «Scan for games» (البحث عن الألعاب).",
     "اختر الدقة ومستوى الرسومات ورفع الدقة وتتبّع الأشعة، فتتحدّث كل الألعاب فورًا.",
     "رتّب حسب الأكثر تطلبًا أو الأعلى في FPS أو الاسم. واضغط «? Help» (F1) للدليل الكامل."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "Or a Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No administrator rights and no internet needed; nothing is sent anywhere.",
     "Opens from Kankon Launcher only (Games)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول ولا إلى اتصال بالإنترنت، ولا يُرسل أي بيانات إلى أي جهة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Games (الألعاب)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Rate your games",
      "ar": "تقييم ألعابك"
     },
     "en": [
      "Open Game Rater from Kankon Launcher (Games).",
      "If you have two graphics cards, press the one you play on.",
      "Tick the drives where your games are, or press Add folder..., then press Scan for games.",
      "Choose resolution, preset, upscaling and ray tracing; every game updates at once."
     ],
     "ar": [
      "افتح Game Rater من Kankon Launcher (قسم Games).",
      "إذا كانت لديك بطاقتا رسومات، فاضغط البطاقة التي تلعب عليها.",
      "حدّد الأقراص التي فيها ألعابك، أو اضغط «Add folder...»، ثم اضغط «Scan for games».",
      "اختر الدقة ومستوى الرسومات ورفع الدقة وتتبّع الأشعة، فتتحدّث كل الألعاب فورًا."
     ]
    },
    {
     "t": {
      "en": "Check a card before you buy",
      "ar": "تجربة بطاقة قبل شرائها"
     },
     "en": [
      "Open the Rate another card list under Graphics card.",
      "Pick any of more than 160 NVIDIA, AMD, Intel or Apple chips.",
      "Read the new rating and the estimated FPS of your games with that card."
     ],
     "ar": [
      "افتح قائمة «Rate another card» أسفل قسم بطاقة الرسومات.",
      "اختر أيًّا من أكثر من 160 شريحة رسومات من NVIDIA وAMD وIntel وApple.",
      "اقرأ التقييم الجديد ومعدل الإطارات التقديري لألعابك مع تلك البطاقة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/gamerater/win-en-01-main.jpg",
     "ar": "img/shots/gamerater/win-ar-01-main.jpg",
     "cap": {
      "en": "Your setup rating, the graphics cards found, and the estimated FPS of every installed game.",
      "ar": "تقييم جهازك، وبطاقات الرسومات المكتشفة، ومعدل الإطارات التقديري لكل لعبة مثبّتة."
     }
    },
    {
     "en": "img/shots/gamerater/win-en-02-second.jpg",
     "ar": "img/shots/gamerater/win-ar-02-second.jpg",
     "cap": {
      "en": "Two graphics cards: press the other one to rate it instead.",
      "ar": "بطاقتا رسومات: اضغط البطاقة الأخرى لتقييمها بدلًا من الأولى."
     }
    },
    {
     "en": "img/shots/gamerater/win-en-03-locations.jpg",
     "ar": "img/shots/gamerater/win-ar-03-locations.jpg",
     "cap": {
      "en": "Choose the drives and folders to search for games.",
      "ar": "اختر الأقراص والمجلدات التي يُبحث فيها عن الألعاب."
     }
    },
    {
     "en": "img/shots/gamerater/win-en-04-settings.jpg",
     "ar": "img/shots/gamerater/win-ar-04-settings.jpg",
     "cap": {
      "en": "Resolution, preset, upscaling and ray tracing update every game at once.",
      "ar": "الدقة ومستوى الرسومات ورفع الدقة وتتبّع الأشعة تحدّث كل الألعاب فورًا."
     }
    },
    {
     "en": "img/shots/gamerater/win-en-05-other.jpg",
     "ar": "img/shots/gamerater/win-ar-05-other.jpg",
     "cap": {
      "en": "Rate another card to see how your games would run before you buy.",
      "ar": "قيّم بطاقة أخرى لترى أداء ألعابك عليها قبل الشراء."
     }
    },
    {
     "en": "img/shots/gamerater/win-en-06-scanning.jpg",
     "ar": "img/shots/gamerater/win-ar-06-scanning.jpg",
     "cap": {
      "en": "Scanning the chosen places for games.",
      "ar": "البحث عن الألعاب في الأماكن المختارة."
     }
    },
    {
     "en": "img/shots/gamerater/mac-en-01-main.jpg",
     "ar": "img/shots/gamerater/mac-ar-01-main.jpg",
     "cap": {
      "en": "Game Rater on Mac.",
      "ar": "Game Rater على Mac."
     }
    }
   ],
   "warn": {
    "en": "Note: every FPS number and rating is an estimate from Kankon's own performance model, built from public specifications. No third-party benchmark data is used, and real results depend on drivers, game updates and settings. The rating card shows a generic card icon tinted in the maker's colour with the maker's name, not any company logo. Game Rater is not affiliated with or endorsed by NVIDIA, AMD, Intel, Apple, Sony or any game publisher; these names and game names are trademarks of their owners.",
    "ar": "ملاحظة: كل أرقام FPS والتقييمات تقديرات من نموذج الأداء الخاص بـKankon المبني على المواصفات المنشورة، ولا تُستخدم أي بيانات اختبار من جهات خارجية، وتختلف النتائج الفعلية بحسب التعريفات وتحديثات الألعاب والإعدادات. وتعرض بطاقة التقييم أيقونة بطاقة عامة بلون الشركة المصنّعة مع اسمها، لا شعار أي شركة. وبرنامج Game Rater غير تابع لشركات NVIDIA وAMD وIntel وApple وSony ولا لأي ناشر ألعاب، ولا يحظى باعتمادها، وهذه الأسماء وأسماء الألعاب علامات تجارية لأصحابها."
   }
  },
  {
   "id": "Dana",
   "name": "Dana",
   "cat": "games",
   "icon": "img/dana.png",
   "site": "https://playdana.net",
   "summary": {
    "en": "Dana is an online action role-playing game (MMORPG) set in old Kuwait and the Gulf. Kankon Launcher installs the Dana Launcher, the game's own program that signs you in, downloads the game and keeps it up to date.",
    "ar": "الدانة لعبة أكشن وتقمّص أدوار جماعية عبر الإنترنت (MMORPG)، تدور أحداثها في الكويت والخليج قديمًا. ويثبّت Kankon Launcher برنامج Dana Launcher، وهو المشغّل الخاص باللعبة الذي يتولّى تسجيل الدخول وتنزيل اللعبة وتحديثها."
   },
   "features": {
    "en": [
     "Explore old Kuwait and the Gulf with other players online, on Dana's official server.",
     "Dana Launcher shows the latest game news and the server status.",
     "Sign in with your Dana account (or Google), or create a new account.",
     "Downloads and installs the game for you, and resumes the download if it stops.",
     "Updates the game and itself automatically, so you always play the newest version.",
     "Characters page: see your characters before you start the game.",
     "Starts the game already signed in.",
     "Can check and repair the game files if something is damaged."
    ],
    "ar": [
     "استكشاف الكويت والخليج قديمًا مع لاعبين آخرين عبر الإنترنت، على الخادم الرسمي للعبة.",
     "يعرض Dana Launcher آخر أخبار اللعبة وحالة الخادم.",
     "تسجيل الدخول بحساب الدانة (أو بحساب Google)، أو إنشاء حساب جديد.",
     "تنزيل اللعبة وتثبيتها تلقائيًا، مع استئناف التنزيل إذا توقّف.",
     "تحديث اللعبة والمشغّل تلقائيًا، لتلعب دائمًا بأحدث إصدار.",
     "صفحة الشخصيات: لعرض شخصياتك قبل بدء اللعب.",
     "تشغيل اللعبة مع تسجيل الدخول مسبقًا.",
     "فحص ملفات اللعبة وإصلاحها عند تلف أي منها."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Games and press Install next to Dana.",
     "Press Open to start the Dana Launcher.",
     "Sign in (or create an account) and let it download the game the first time.",
     "Press Play. Next time just press Open: updates arrive on their own."
    ],
    "ar": [
     "افتح Kankon Launcher، ثم انتقل إلى قسم Games (الألعاب) وانقر Install بجانب Dana.",
     "انقر Open لتشغيل Dana Launcher.",
     "سجّل الدخول (أو أنشئ حسابًا)، واترك المشغّل ينزّل اللعبة في المرة الأولى.",
     "انقر Play. وفي المرات التالية يكفي النقر على Open، إذ تصل التحديثات تلقائيًا."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "An internet connection and a Dana account.",
     "No administrator rights needed (installs to your Windows user folder).",
     "Arabic and English (switch the language in the Dana Launcher)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "اتصال بالإنترنت وحساب في الدانة.",
     "لا يحتاج إلى صلاحيات المسؤول (يُثبَّت في مجلد المستخدم).",
     "يدعم العربية والإنجليزية (يُغيَّر من داخل Dana Launcher).",
     "الموقع الرسمي: playdana.net"
    ]
   },
   "shots": [
    {
     "src": "img/shots/dana-hero.jpg",
     "cap": {
      "en": "Old Kuwait",
      "ar": "الكويت قديمًا"
     }
    },
    {
     "src": "img/shots/dana-town.jpg",
     "cap": {
      "en": "The town",
      "ar": "الحيّ القديم (الفريج)"
     }
    },
    {
     "src": "img/shots/dana-map.jpg",
     "cap": {
      "en": "The map",
      "ar": "الخريطة"
     }
    },
    {
     "src": "img/shots/dana-underwater.jpg",
     "cap": {
      "en": "Pearl diving",
      "ar": "الغوص على اللؤلؤ"
     }
    },
    {
     "src": "img/shots/dana-caravan.jpg",
     "cap": {
      "en": "Caravans",
      "ar": "القوافل"
     }
    },
    {
     "src": "img/shots/dana-bridge.jpg",
     "cap": {
      "en": "Across the Gulf",
      "ar": "عبر الخليج"
     }
    },
    {
     "src": "img/shots/dana-house.jpg",
     "cap": {
      "en": "Old Kuwaiti houses",
      "ar": "البيوت الكويتية القديمة"
     }
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Install Dana",
      "ar": "تثبيت الدانة"
     },
     "en": [
      "Open Kankon Launcher and go to Games.",
      "Click Install next to Dana. The Dana Launcher is downloaded, verified and installed.",
      "Click Open to start the Dana Launcher."
     ],
     "ar": [
      "افتح Kankon Launcher وانتقل إلى قسم Games (الألعاب).",
      "انقر Install بجانب Dana؛ فيُنزَّل Dana Launcher ويُتحقَّق منه ثم يُثبَّت.",
      "انقر Open لتشغيل Dana Launcher."
     ]
    },
    {
     "t": {
      "en": "Create an account and start playing",
      "ar": "إنشاء حساب وبدء اللعب"
     },
     "en": [
      "In the Dana Launcher, sign in with your Dana account or Google, or create a new account.",
      "The first time, let it download the game. If the download stops, it continues from where it stopped.",
      "Open the Characters page to see your characters.",
      "Click Play. The game starts already signed in."
     ],
     "ar": [
      "في Dana Launcher، سجّل الدخول بحساب الدانة أو بحساب Google، أو أنشئ حسابًا جديدًا.",
      "في المرة الأولى، اتركه ينزّل اللعبة، وإذا انقطع التنزيل فإنه يُستأنف من حيث توقّف.",
      "افتح صفحة الشخصيات لاستعراض شخصياتك.",
      "انقر Play؛ فتبدأ اللعبة وأنت مسجّل الدخول."
     ]
    },
    {
     "t": {
      "en": "Fix a game that does not start",
      "ar": "إصلاح اللعبة إذا لم تعمل"
     },
     "en": [
      "Open the Dana Launcher.",
      "Use the option to check and repair the game files.",
      "Wait until it finishes, then click Play again."
     ],
     "ar": [
      "افتح Dana Launcher.",
      "استخدم خيار فحص ملفات اللعبة وإصلاحها.",
      "انتظر حتى ينتهي، ثم انقر Play مجددًا."
     ]
    }
   ],
   "ext": true
  }
 ],
 "updates": [
  {
   "product": "KankonPhotoAI",
   "version": "1.0.0",
   "date": "2026-11-23",
   "en": [
    "New app in Tools: Kankon Photo AI sorts the photos already on your computer into smart albums (events and trips, months, places, AI categories and more).",
    "Cleans up duplicates, look-alikes, blurry photos and screenshots, keeping the best of each group.",
    "AI search in English or Arabic, AI tags and captions, and a photo editor with edit-with-words and generative edits (background removal, object removal, new sky).",
    "Organize your photos into tidy album folders by event, month, place, category or camera.",
    "The AI features use your own OpenAI, Gemini or Claude key; the app is free, your key stays on this computer, and faces are never recognised.",
    "Legal note: use AI editing responsibly (Kuwait Law No. 63 of 2015).",
    "Full Help guide with pictures, in English and Arabic.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "برنامج جديد في قسم الأدوات: يرتّب Kankon Photo AI الصور الموجودة على حاسوبك في ألبومات ذكية (المناسبات والرحلات والأشهر والأماكن وفئات الذكاء الاصطناعي وغيرها).",
    "ينظّف الصور المكررة والمتشابهة والمشوشة ولقطات الشاشة، ويبقي أفضل صورة في كل مجموعة.",
    "بحث ذكي بالعربية أو الإنجليزية، ووسوم وأوصاف ذكية، ومحرر صور فيه التعديل بالكلام والتعديل التوليدي (إزالة الخلفية، وإزالة شيء، وسماء جديدة).",
    "رتّب صورك في مجلدات ألبومات حسب المناسبة أو الشهر أو المكان أو الفئة أو الكاميرا.",
    "تستخدم ميزات الذكاء الاصطناعي مفتاحك الخاص من OpenAI أو Gemini أو Claude، والبرنامج مجاني، ويبقى مفتاحك على هذا الحاسوب، ولا يتعرّف على الوجوه أبدًا.",
    "تنبيه قانوني: استخدم التعديل بالذكاء الاصطناعي بمسؤولية (القانون الكويتي رقم 63 لسنة 2015).",
    "دليل مساعدة كامل بالصور بالعربية والإنجليزية.",
    "متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "FileRecovery",
   "version": "1.1.1",
   "date": "2026-11-22",
   "en": [
    "Improved Arabic wording in Smart photos (tags and side panel), and fresh pictures in the Help guide.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية في «الصور الذكية» (الوسوم واللوحة الجانبية)، وأُضيفت صور جديدة إلى دليل المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "FileRecovery",
   "version": "1.1.0",
   "date": "2026-11-22",
   "en": [
    "New Smart photos: every found photo is read for its date taken, place (GPS) and camera.",
    "Photos are grouped by event or trip (for example \"Salmiya, 13 Nov 2026\"), month or place, with place names in English and Arabic that work offline.",
    "Look-alike copies, blurry shots and screenshots are marked, and a Best photos filter shows only the good ones.",
    "Recover photos into folders by event, month or place.",
    "Help: a new Smart photos section and fresh pictures.",
    "Place names: GeoNames (geonames.org, CC BY 4.0) and Unicode CLDR.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُضيفت ميزة «الصور الذكية»: يقرأ البرنامج تاريخ الالتقاط والمكان (GPS) والكاميرا من كل صورة يعثر عليها.",
    "تُجمَّع الصور حسب المناسبة أو الرحلة (مثل «السالمية، 13 نوفمبر 2026») أو الشهر أو المكان، بأسماء أماكن بالعربية والإنجليزية تعمل دون اتصال بالإنترنت.",
    "تُعلَّم النسخ المتشابهة والصور المهتزّة ولقطات الشاشة، ويعرض خيار «أفضل الصور» الجيدة منها فقط.",
    "أصبح بالإمكان استعادة الصور في مجلدات حسب المناسبة أو الشهر أو المكان.",
    "أُضيف إلى المساعدة قسم عن الصور الذكية، مع صور جديدة.",
    "أسماء الأماكن: GeoNames (geonames.org، بترخيص CC BY 4.0) وUnicode CLDR.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "GameRater",
   "version": "1.0.2",
   "date": "2026-11-22",
   "en": [
    "New Your screen (Hz) setting: 60, 120, 144, 165 or 240 Hz, read automatically.",
    "Every game now shows whether it fills your screen (for example \"Fills your 240 Hz screen\") or how much of it it reaches (\"75% of your 240 Hz screen\").",
    "Dana, Kankon's own game, is now recognised.",
    "Improved Arabic wording, and fresh pictures in the Help guide.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُضيف إعداد «معدل تحديث شاشتك (Hz)»: ‏60 أو 120 أو 144 أو 165 أو 240 Hz، ويقرؤه البرنامج تلقائيًا.",
    "أصبحت كل لعبة تُظهر هل تبلغ أقصى معدل لشاشتك (مثل «يبلغ أقصى معدل لشاشتك (240 Hz)») أو النسبة التي تبلغها منه (مثل «‏75% من معدل شاشتك (240 Hz)»).",
    "أصبح البرنامج يتعرّف على لعبة Dana، لعبة Kankon الخاصة.",
    "روجعت الصياغة العربية، وأُضيفت صور جديدة إلى دليل المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "FileRecovery",
   "version": "1.0.1",
   "date": "2026-11-22",
   "en": [
    "Improved Arabic wording: the message after recovery now reads correctly for any number of files, with a clearer footer note and Help button.",
    "Help guide and description corrections, and fresh pictures.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية: أصبحت رسالة انتهاء الاستعادة صحيحة لأي عدد من الملفات، وأصبحت الملاحظة في أسفل النافذة وزر المساعدة أوضح.",
    "صُحّحت مواضع في دليل المساعدة والوصف، وأُضيفت صور جديدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "FileRecovery",
   "version": "1.0.0",
   "date": "2026-11-22",
   "en": [
    "New app in Tools: File Recovery gets back deleted photos, videos, documents, music and archives.",
    "Recycle Bin and Trash, a quick NTFS scan with original names and folders, and a deep scan of free space for more than 50 file types on NTFS, FAT32 and exFAT, memory cards, USB drives and whole disks.",
    "Preview, filters and search; recovered files go to a different drive, with a CSV report.",
    "Honest about limits: no tool can promise every file, SSDs usually erase deleted data (TRIM), and the internal drive of a Mac cannot be scanned.",
    "Clear legal warning: use it only on drives you own or have permission to examine.",
    "Full Help guide with pictures, in English and Arabic.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "برنامج جديد في قسم الأدوات: يستعيد File Recovery الصور ومقاطع الفيديو والمستندات والموسيقى والملفات المضغوطة المحذوفة.",
    "سلة المحذوفات وسلة المهملات، وفحص سريع لأقراص NTFS بالأسماء والمجلدات الأصلية، وفحص عميق للمساحة الفارغة عن أكثر من 50 نوعًا من الملفات في أنظمة NTFS وFAT32 وexFAT وبطاقات الذاكرة وذواكر USB والأقراص الكاملة.",
    "معاينة وتصفية وبحث، وتُحفظ الملفات المستعادة على قرص آخر مع تقرير CSV.",
    "صريح في حدوده: لا توجد أداة تضمن استعادة كل ملف، وأقراص SSD تمحو البيانات المحذوفة غالبًا (ميزة TRIM)، ولا يمكن فحص القرص الداخلي في Mac.",
    "تحذير قانوني واضح: لا تستخدمه إلا على أقراص تملكها أو أُذِن لك بفحصها.",
    "دليل مساعدة كامل بالصور بالعربية والإنجليزية.",
    "متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "GameRater",
   "version": "1.0.1",
   "date": "2026-11-22",
   "en": [
    "The rating card now shows a generic card icon tinted in the maker's colour, with the maker's name in plain text.",
    "A clear note in the app, Help and description: Game Rater is not affiliated with or endorsed by NVIDIA, AMD, Intel, Apple, Sony or any game publisher.",
    "Improved Arabic wording, and fresh pictures in the Help guide.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبحت بطاقة التقييم تعرض أيقونة بطاقة عامة بلون الشركة المصنّعة مع اسمها نصًّا عاديًا.",
    "أُضيفت ملاحظة واضحة في البرنامج والمساعدة والوصف: برنامج Game Rater غير تابع لشركات NVIDIA وAMD وIntel وApple وSony ولا لأي ناشر ألعاب، ولا يحظى باعتمادها.",
    "روجعت الصياغة العربية، وأُضيفت صور جديدة إلى دليل المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "GameRater",
   "version": "1.0.0",
   "date": "2026-11-22",
   "en": [
    "New app in Games: Game Rater estimates the frame rate (FPS) of every game on your computer at 1080p, 1440p and 4K for your graphics card.",
    "Detects your graphics cards and processor, searches only the drives and folders you choose, and finds Steam, Epic Games, GOG and Xbox games.",
    "Rates your whole setup against a PlayStation 5, checks for a bottleneck and suggests a power supply size.",
    "Rate another card from more than 160 chips to see how your games would run before you buy.",
    "Every number is an estimate from Kankon's own model; nothing is sent over the internet.",
    "Full Help guide with pictures, in English and Arabic.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "برنامج جديد في قسم الألعاب: يقدّر Game Rater معدل الإطارات (FPS) لكل لعبة على حاسوبك بدقة 1080p و1440p و4K وفق بطاقة الرسومات لديك.",
    "يتعرّف على بطاقات الرسومات والمعالج، ولا يبحث إلا في الأقراص والمجلدات التي تختارها، ويعثر على ألعاب Steam وEpic Games وGOG وXbox.",
    "يقيّم جهازك كاملًا مقارنةً بجهاز PlayStation 5، ويفحص الاختناق، ويقترح حجم مزود الطاقة.",
    "قيّم بطاقة أخرى من بين أكثر من 160 شريحة لترى أداء ألعابك عليها قبل الشراء.",
    "كل رقم تقدير من نموذج الأداء الخاص بـKankon، ولا يُرسل أي شيء عبر الإنترنت.",
    "دليل مساعدة كامل بالصور بالعربية والإنجليزية.",
    "متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.17.3",
   "date": "2026-11-21",
   "en": [
    "Corrections to the Arabic wording of the Help guide.",
    "Available for Windows and Mac. On Mac, this update also brings the 1.17.2 changes."
   ],
   "ar": [
    "روجعت الصياغة العربية لدليل المساعدة.",
    "التحديث متاح لنظامَي Windows وMac، ويتضمّن في Mac أيضًا تغييرات الإصدار 1.17.2."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.14",
   "date": "2026-11-21",
   "en": [
    "The internet plan card in Kankon Launcher now also works when Network Monitor is closed or still starting: the app saves the plan reading every minute.",
    "Help: a new tip about this in the internet plan section.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبحت بطاقة باقة الإنترنت في Kankon Launcher تعمل أيضًا عندما يكون Network Monitor مغلقًا أو في أثناء بدء تشغيله، إذ يحفظ البرنامج قراءة الباقة كل دقيقة.",
    "أُضيفت إلى المساعدة نصيحة عن ذلك في قسم باقة الإنترنت.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.17.2",
   "date": "2026-11-21",
   "en": [
    "Lighter start: only the Temperature layer is on when the app opens; turn on other layers when you need them.",
    "Temperature colours now continue below 0°.",
    "The world map no longer repeats side by side.",
    "Clouds & rain and Satellite can no longer be on together: turning one on turns the other off.",
    "Help: a new tip about the map layers, an updated settings table and fresh pictures.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبح البدء أخفّ: لا تكون مشغّلة عند فتح البرنامج إلا طبقة «الحرارة»، ويمكنك تشغيل الطبقات الأخرى عند الحاجة.",
    "أصبحت ألوان الحرارة تمتدّ إلى ما دون الصفر.",
    "لم تعد خريطة العالم تتكرّر جنبًا إلى جنب.",
    "لم يعد بالإمكان تشغيل طبقتَي «الغيوم والمطر» و«أقمار صناعية» معًا، فتشغيل إحداهما يطفئ الأخرى.",
    "أُضيفت إلى المساعدة نصيحة جديدة عن طبقات الخريطة، وحُدِّث جدول الإعدادات والصور.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "Noor",
   "version": "1.1.0",
   "date": "2026-11-21",
   "en": [
    "Licence clean-up: the English meaning of the Quran is now Marmaduke Pickthall (1930, public domain) instead of Saheeh International.",
    "Hadith are shown in Arabic with a link to the source on sunnah.com; the English hadith translations were removed because they are under copyright.",
    "The adhan recordings were removed and replaced by Noor's own prayer alert tone, until a recording with a clear licence is available.",
    "Help now has pictures, and a sources and licences table.",
    "The Qibla page layout is fixed.",
    "Includes the Worship guides page from 1.0.8.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت التراخيص، فأصبحت الترجمة الإنجليزية لمعاني القرآن الكريم هي ترجمة Marmaduke Pickthall (1930، ملك عام) بدلًا من Saheeh International.",
    "تُعرض الأحاديث باللغة العربية مع رابط إلى مصدرها على موقع sunnah.com، وأُزيلت الترجمات الإنجليزية للأحاديث لأنها محمية بحقوق النشر.",
    "أُزيلت تسجيلات الأذان واستُبدلت بها نغمة تنبيه خاصة ببرنامج Noor، إلى أن يتوفّر تسجيل برخصة واضحة.",
    "أصبح دليل المساعدة يتضمّن صورًا، وجدولًا بالمصادر والتراخيص.",
    "أُصلح تخطيط صفحة القبلة.",
    "يتضمّن أيضًا صفحة دليل العبادات التي أُضيفت في الإصدار 1.0.8.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.8",
   "date": "2026-11-21",
   "en": [
    "All screenshots in the Help guide were refreshed to show the current version and the legal warning.",
    "Available for Windows and Mac. On Mac, this update also brings the 1.2.4 to 1.2.7 changes: the Fix & Speed safety fixes, the public IP fallback, the Help pictures and the legal warning."
   ],
   "ar": [
    "حُدّثت جميع صور دليل المساعدة لتعرض الإصدار الحالي والتحذير القانوني.",
    "التحديث متاح لنظامَي Windows وMac، ويتضمّن في Mac أيضًا تغييرات الإصدارات من 1.2.4 إلى 1.2.7: إصلاحات الأمان في صفحة الإصلاح والسرعة، والمصدر البديل لعنوان IP العام، وصور المساعدة، والتحذير القانوني."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.16.1",
   "date": "2026-11-21",
   "en": [
    "The hour labels on the timeline are fixed.",
    "New pictures in the Help guide.",
    "Available for Windows and Mac. On Mac, this update also brings the 1.16.0 changes."
   ],
   "ar": [
    "أُصلحت تسميات الساعات في الخط الزمني.",
    "أُضيفت صور جديدة إلى دليل المساعدة.",
    "التحديث متاح لنظامَي Windows وMac، ويتضمّن في Mac أيضًا تغييرات الإصدار 1.16.0."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.16.0",
   "date": "2026-11-21",
   "en": [
    "The rain radar layer is now based on satellite rain data (the Sat. rain button), because the previous radar service allows personal use only.",
    "The footer credits Open-Meteo.com with a link.",
    "Help has a new Where the data comes from section with the terms of each source, plus the third-party licenses, and pictures for every part of the app.",
    "Windows now; the Mac update follows soon."
   ],
   "ar": [
    "أصبحت طبقة مطر الرادار تعتمد على بيانات المطر من الأقمار الصناعية (زرّ «مطر الأقمار»)، لأن خدمة الرادار السابقة لا تسمح إلا بالاستخدام الشخصي.",
    "أصبح أسفل النافذة يذكر Open-Meteo.com مصدرًا لبيانات الطقس، مع رابط إليه.",
    "أُضيف إلى المساعدة قسم «مصادر البيانات» مع شروط كل مصدر، وتراخيص الأطراف الثالثة، وصور لكل جزء من البرنامج.",
    "التحديث متاح لنظام Windows الآن، ويليه تحديث Mac قريبًا."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.5.0",
   "date": "2026-11-20",
   "en": [
    "A clear red warning on Backup & Restore and Driver Updates, in the confirmations and in Help: installing or removing drivers can stop devices working, so back up first and use the app only on your own computer."
   ],
   "ar": [
    "أُضيف تحذير أحمر واضح في صفحتَي النسخ الاحتياطي والاسترجاع وتحديثات التعاريف، وفي رسائل التأكيد وفي المساعدة: قد يؤدي تثبيت التعاريف أو حذفها إلى توقّف بعض الأجهزة عن العمل، فأنشئ نسخة احتياطية أولًا، ولا تستخدم البرنامج إلا على جهازك."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.4.2",
   "date": "2026-11-20",
   "en": [
    "Clearer Arabic wording in the app and in Help.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية في البرنامج وفي المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.4.2",
   "date": "2026-11-20",
   "en": [
    "Clearer Arabic wording in the Copied message and on the Privacy and licenses pages.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية لرسالة النسخ ولقسمَي الخصوصية والتراخيص في المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.4.1",
   "date": "2026-11-20",
   "en": [
    "No store or brand names in the app any more.",
    "A clear note: sizes are estimates, they differ from brand to brand, and Size Finder is not affiliated with any brand or store.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُزيلت أسماء المتاجر والعلامات التجارية من البرنامج.",
    "أُضيفت ملاحظة واضحة: المقاسات تقديرية وتختلف من علامة تجارية إلى أخرى، ولا يرتبط Size Finder بأي علامة تجارية أو متجر.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "launcher",
   "version": "2.21.0",
   "date": "2026-11-20",
   "en": [
    "Help: the guide now has English and Arabic pictures for every section, here and in the app.",
    "New About window with links to the Terms of Use, Privacy Policy and Third-party notices, and the list of open-source parts.",
    "A one-time Terms notice on first run.",
    "The Send report button now follows the app language.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "المساعدة: أصبح الدليل يضم صورًا بالعربية والإنجليزية لكل قسم، هنا وفي البرنامج.",
    "أُضيفت نافذة «حول» فيها روابط إلى شروط الاستخدام وسياسة الخصوصية وإشعارات الأطراف الثالثة، وقائمة بالمكوّنات مفتوحة المصدر.",
    "أُضيف إشعار بشروط الاستخدام يظهر مرة واحدة عند التشغيل الأول.",
    "أصبح زرّ «إرسال تقرير» يظهر بلغة البرنامج.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.4.1",
   "date": "2026-11-20",
   "en": [
    "The Copied message confirms that no serial number, MAC addresses or computer name are included.",
    "Help warns about sharing window screenshots and lists the third-party licenses.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبحت رسالة النسخ تؤكّد أن الملخص المنسوخ لا يتضمّن الرقم التسلسلي ولا عناوين MAC ولا اسم الجهاز.",
    "أصبحت المساعدة تنبّه إلى الحذر عند مشاركة صور نافذة البرنامج، وتعرض تراخيص مكوّنات الأطراف الثالثة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.4.0",
   "date": "2026-11-20",
   "en": [
    "Help now has screenshots for every part of the app, in English and Arabic, with sample data.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبحت المساعدة تضم صورًا لكل جزء من البرنامج، بالعربية والإنجليزية، ببيانات توضيحية.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "website",
   "version": "1.83.0",
   "date": "2026-11-20",
   "en": [
    "New Terms of Use page: the apps are free and provided \"as is\", lawful use of the network tools (Kuwait Law No. 63 of 2015), and Kankon Markets is not investment advice.",
    "Privacy page now lists exactly what each app sends over the internet, and why.",
    "New Third-party notices page: the libraries, fonts and online services the apps use, with their licenses and terms.",
    "Download buttons now use neutral computer icons instead of the Windows and Apple logos, with a trademark notice in the footer.",
    "App pages for the network tools, Kankon Markets and Force Uninstaller now show a clear warning."
   ],
   "ar": [
    "أُضيفت صفحة لشروط الاستخدام: البرامج مجانية وتُقدَّم «كما هي»، والاستخدام المشروع لأدوات الشبكات (القانون الكويتي رقم 63 لسنة 2015)، وKankon Markets لا يقدّم نصيحة استثمارية.",
    "أصبحت صفحة الخصوصية تبيّن بدقة ما يرسله كل برنامج عبر الإنترنت وسبب ذلك.",
    "أُضيفت صفحة لإشعارات الأطراف الثالثة: المكتبات والخطوط والخدمات الإلكترونية التي تستخدمها البرامج، مع تراخيصها وشروطها.",
    "أصبحت أزرار التنزيل تستخدم أيقونات حاسوب محايدة بدلًا من شعارَي Windows وApple، مع إشعار بالعلامات التجارية في أسفل الصفحة.",
    "أصبحت صفحات أدوات الشبكات وKankon Markets وForce Uninstaller تعرض تحذيرًا واضحًا."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.13",
   "date": "2026-11-20",
   "en": [
    "Reviewed Arabic wording of the legal warning, in the app and in Help.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية للتحذير القانوني في البرنامج وفي المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.6",
   "date": "2026-11-20",
   "en": [
    "A clear red warning on the main screen, before every Force remove, and in Help: force removal cannot be undone, and you should use it only on your own computer.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُضيف تحذير أحمر واضح في الشاشة الرئيسية، وقبل كل إزالة قسرية، وفي المساعدة: الإزالة القسرية لا يمكن التراجع عنها، ولا تستخدمها إلا على جهازك.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.5.0",
   "date": "2026-11-20",
   "en": [
    "Help now has a picture for each part of the app.",
    "Saved chart pictures are sharper.",
    "A clear notice appears the first time the app opens, on the AI Assistant, Alerts and Portfolio tabs, and at the start of Help: prices are for information only, are not investment advice, and the data sources are named.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أصبحت المساعدة تضم صورة لكل جزء من البرنامج.",
    "أصبحت صور الرسوم البيانية المحفوظة أوضح.",
    "أُضيف تنبيه واضح يظهر عند تشغيل البرنامج أول مرة، وفي تبويبات المساعد الذكي والتنبيهات والمحفظة، وفي بداية المساعدة: الأسعار للاطلاع فقط وليست نصيحة استثمارية، مع ذكر مصادر البيانات.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.9.0",
   "date": "2026-11-20",
   "en": [
    "A clear legal warning in the app and in Help: use it only on networks you own or manage with permission (Kuwait Law No. 63 of 2015 on combating information technology crimes)."
   ],
   "ar": [
    "أُضيف تحذير قانوني واضح في البرنامج وفي المساعدة: لا تستخدم البرنامج إلا على الشبكات التي تملكها أو تديرها بإذن (القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات)."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.4.0",
   "date": "2026-11-20",
   "en": [
    "A clear legal warning in the app and in Help: use it only on networks you own or manage with permission (Kuwait Law No. 63 of 2015 on combating information technology crimes)."
   ],
   "ar": [
    "أُضيف تحذير قانوني واضح في البرنامج وفي المساعدة: لا تستخدم البرنامج إلا على الشبكات التي تملكها أو تديرها بإذن (القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات)."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.7",
   "date": "2026-11-20",
   "en": [
    "Reviewed Arabic wording of the legal warning.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "روجعت الصياغة العربية للتحذير القانوني.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.6",
   "date": "2026-11-20",
   "en": [
    "A clear legal warning on the Ping, Traceroute, Port Check and Fix & Speed pages and in Help: use the tools only on your own networks or with written permission (Kuwait Law No. 63 of 2015 on combating information technology crimes).",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُضيف تحذير قانوني واضح في صفحات Ping، وتتبع المسار، وفحص المنافذ، والإصلاح والسرعة، وفي المساعدة: لا تستخدم الأدوات إلا على شبكاتك أو بإذن كتابي (القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات).",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.12",
   "date": "2026-11-20",
   "en": [
    "A clear legal warning at the top of Setup, Speed limits and Help: use the app only on networks and devices you own or manage with permission (Kuwait Law No. 63 of 2015 on combating information technology crimes).",
    "Available for Windows and Mac."
   ],
   "ar": [
    "أُضيف تحذير قانوني واضح في أعلى صفحات الإعدادات وحدود السرعة والمساعدة: لا تستخدم البرنامج إلا على الشبكات والأجهزة التي تملكها أو تديرها بإذن (القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات).",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.4.0",
   "date": "2026-11-20",
   "en": [
    "Help (F1): the guide now has pictures for its sections, in English and Arabic.",
    "The full guide with pictures is also on this site (Full help guide button)."
   ],
   "ar": [
    "المساعدة (F1): أصبح الدليل يضم صورًا توضيحية لأقسامه، بالعربية والإنجليزية.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»)."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.11",
   "date": "2026-11-20",
   "en": [
    "Clearer Arabic wording in the WhatsApp setup steps and in two Help picture captions.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "صياغة عربية أوضح في خطوات إعداد WhatsApp وفي تعليقَين على صور المساعدة.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.10",
   "date": "2026-11-20",
   "en": [
    "Setup > WhatsApp shows the CallMeBot steps in the app language (Arabic too), with a CallMeBot website button and a Step-by-step guide button that opens the WhatsApp section of the guide on this site.",
    "Help: new WhatsApp (CallMeBot) section, fresh English and Arabic pictures in 13 sections, and web links you can click.",
    "Windows: outside links now open in your normal browser.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "يعرض قسم WhatsApp في الإعدادات (Setup) خطوات CallMeBot بلغة البرنامج (بما فيها العربية)، مع زرّ لموقع CallMeBot وزرّ «الشرح خطوة بخطوة» يفتح قسم WhatsApp في الدليل على هذا الموقع.",
    "المساعدة: قسم جديد لتنبيهات WhatsApp (CallMeBot)، وصور جديدة بالعربية والإنجليزية في 13 قسمًا، وروابط ويب قابلة للنقر.",
    "في Windows: تُفتح الروابط الخارجية الآن في متصفحك المعتاد.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.5",
   "date": "2026-11-20",
   "en": [
    "Mac: the Help section \"Install and first run\" now shows a Mac picture, and the Mac pictures show Mac apps only.",
    "Available for Windows and Mac."
   ],
   "ar": [
    "في Mac: يعرض قسم «التثبيت والتشغيل أول مرة» في المساعدة الآن صورة من Mac، وتعرض صور Mac تطبيقات Mac فقط.",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.4.0",
   "date": "2026-11-20",
   "en": [
    "Help: the in-app guide now has pictures for its sections, in English and Arabic.",
    "The full guide with pictures is also on this site (Full help guide button).",
    "Available for Windows and Mac."
   ],
   "ar": [
    "المساعدة: أصبح الدليل داخل البرنامج يضم صورًا توضيحية لأقسامه، بالعربية والإنجليزية.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»).",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.8.0",
   "date": "2026-11-20",
   "en": [
    "Help: the in-app guide now has screenshots for its sections, in English and Arabic.",
    "The full guide with pictures is also on this site (Full help guide button)."
   ],
   "ar": [
    "المساعدة: أصبح الدليل داخل البرنامج يضم صورًا توضيحية لأقسامه، بالعربية والإنجليزية.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»)."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.3.0",
   "date": "2026-11-20",
   "en": [
    "Help: the in-app guide now has screenshots for its sections, in English and Arabic.",
    "The full guide with pictures is also on this site (Full help guide button)."
   ],
   "ar": [
    "المساعدة: أصبح الدليل داخل البرنامج يضم صورًا توضيحية لأقسامه، بالعربية والإنجليزية.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»)."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.4",
   "date": "2026-11-20",
   "en": [
    "Help: the in-app guide now has pictures for every section, in English and Arabic.",
    "After Stop now, the result title clearly says the program was stopped.",
    "The full guide with pictures is also on this site (Full help guide button).",
    "Available for Windows and Mac."
   ],
   "ar": [
    "المساعدة: أصبح الدليل داخل البرنامج يضم صورًا لكل قسم، بالعربية والإنجليزية.",
    "بعد «إيقاف الآن» يوضّح عنوان النتيجة أن البرنامج قد أُوقف.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»).",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.5",
   "date": "2026-11-20",
   "en": [
    "Help: the in-app guide now shows screenshots for every part of the app, in English and Arabic.",
    "The full guide with pictures is also on this site (Full help guide button).",
    "Available for Windows and Mac."
   ],
   "ar": [
    "المساعدة: يعرض الدليل داخل البرنامج الآن صورًا لكل جزء من البرنامج، بالعربية والإنجليزية.",
    "الدليل الكامل بالصور متاح أيضًا في هذا الموقع (زر «الدليل الكامل»).",
    "التحديث متاح لنظامَي Windows وMac."
   ]
  },
  {
   "product": "website",
   "version": "1.82.0",
   "date": "2026-11-20",
   "en": [
    "New \"All apps\" menu at the top: every app grouped by section, with a search box (press / to search from anywhere).",
    "Clear path and back button on every app and help page (Home › Networking › Network Monitor).",
    "App pages now have a side list of all apps and Previous / Next app buttons.",
    "Short links for every app, like kankon.net/noor, with a Copy button on the app page.",
    "Help guides: links can be clicked, pictures open large, and each section has its own link. New WhatsApp alerts section in the Network Monitor guide."
   ],
   "ar": [
    "قائمة جديدة باسم «جميع البرامج» في الأعلى: كل البرامج مرتّبة حسب القسم، مع مربع بحث (اضغط / للبحث من أي صفحة).",
    "مسار واضح وزر رجوع في أعلى كل صفحة برنامج ودليل (الرئيسية › الشبكات › Network Monitor).",
    "أصبحت صفحة كل برنامج تعرض قائمة جانبية بجميع البرامج، وزرَّي «البرنامج السابق» و«البرنامج التالي».",
    "روابط مختصرة لكل برنامج، مثل kankon.net/noor، مع زر نسخ في صفحة البرنامج.",
    "أدلة المساعدة: الروابط قابلة للنقر، والصور تُفتح بحجم كبير، ولكل قسم رابط خاص. وأُضيف قسم تنبيهات WhatsApp إلى دليل Network Monitor."
   ]
  },
  {
   "product": "launcher",
   "version": "2.20.4",
   "date": "2026-11-20",
   "en": [
    "Arabic wording of the Internet plan card's size unit options reviewed."
   ],
   "ar": [
    "روجعت الصياغة العربية لخيارات وحدة الحجم في بطاقة باقة الإنترنت."
   ]
  },
  {
   "product": "launcher",
   "version": "2.20.3",
   "date": "2026-11-20",
   "en": [
    "Internet plan card: a new size unit setting: Same as Network Monitor (default), Auto (GB below 1 TB, TB from 1 TB with one decimal), GB, or TB (1 TB = 1000 GB). Needs Network Monitor 1.6.9 or newer for matching text."
   ],
   "ar": [
    "بطاقة باقة الإنترنت: إعداد جديد لوحدة الحجم: «كما في Network Monitor» (الافتراضي)، أو «تلقائي» (بالغيغابايت لما دون 1 TB، وبالتيرابايت من 1 TB برقم عشري واحد)، أو GB، أو TB (‏1 TB = ‏1000 GB). ويلزم Network Monitor 1.6.9 أو أحدث ليتطابق النص في البرنامجين."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.9",
   "date": "2026-11-20",
   "en": [
    "Internet plan: choose how sizes are shown, in GB (9,000 GB) or TB (1.1 TB; amounts under 1 TB stay in GB, for example 987 GB). The choice saves right away, and the Kankon Launcher plan card uses the same format.",
    "Help guide updated."
   ],
   "ar": [
    "باقة الإنترنت: اختر طريقة عرض الأحجام، بالغيغابايت (9,000 GB) أو بالتيرابايت (1.1 TB، وتبقى الكميات الأقل من 1 TB بالغيغابايت، مثل 987 GB). ويُحفظ اختيارك فورًا، وتستخدم بطاقة الباقة في Kankon Launcher التنسيق نفسه.",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "launcher",
   "version": "2.20.0",
   "date": "2026-11-20",
   "en": [
    "New Internet plan card in the sidebar (above the kankon.net button): used and plan size in GB, GB left and days until renewal, read from the running Network Monitor (version 1.6.7 or newer, with a plan set).",
    "Choose its look in Settings: battery (default), ring, bar or hidden."
   ],
   "ar": [
    "بطاقة جديدة لباقة الإنترنت في الشريط الجانبي (فوق زرّ kankon.net): المستهلك وحجم الباقة بالغيغابايت، والمتبقّي، والأيام الباقية حتى التجديد، تُقرأ من Network Monitor في أثناء تشغيله (الإصدار 1.6.7 أو أحدث، مع ضبط الباقة فيه).",
    "اختر شكلها من الإعدادات: بطارية (الافتراضي) أو حلقة أو شريط، أو أخفِها."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.8",
   "date": "2026-11-20",
   "en": [
    "Internet plan: the plan size and renew day now save automatically as you type, with no need to press Enter or Save. Picking a card look saves them too.",
    "Help guide updated."
   ],
   "ar": [
    "باقة الإنترنت: أصبح حجم الباقة ويوم التجديد يُحفظان تلقائيًا في أثناء الكتابة، دون حاجة إلى الضغط على Enter أو «حفظ». ويحفظهما أيضًا اختيار شكل البطاقة.",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.7",
   "date": "2026-11-20",
   "en": [
    "Shares this month's Internet plan (used and plan size in GB, days to renewal) with Kankon Launcher, so the launcher can show the plan card in its sidebar. Only programs on the same computer can read it."
   ],
   "ar": [
    "أصبح البرنامج يشارك بيانات باقة الإنترنت لهذا الشهر (المستهلك وحجم الباقة بالغيغابايت والأيام الباقية حتى التجديد) مع Kankon Launcher، ليعرض المشغّل بطاقة الباقة في شريطه الجانبي. ولا تقرؤها إلا البرامج الموجودة على الجهاز نفسه."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.6",
   "date": "2026-11-20",
   "en": [
    "Speed limits: the upload limit on NETGEAR S350 switches is fixed. The rule is now built the same way the switch's own web page builds it."
   ],
   "ar": [
    "حدود السرعة: أُصلح حدّ الرفع في محوّلات NETGEAR S350، إذ أصبحت القاعدة تُبنى بالطريقة نفسها التي تبنيها بها صفحة الإعدادات الخاصة بالمحوّل."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.5",
   "date": "2026-11-20",
   "en": [
    "Speed limits: a second fix for the upload limit on NETGEAR S350 switches. The app now builds the switch rule the way this firmware expects."
   ],
   "ar": [
    "حدود السرعة: إصلاح ثانٍ لحدّ الرفع في محوّلات NETGEAR S350، إذ أصبح البرنامج يبني قاعدة المحوّل بالطريقة التي يتطلّبها نظامه الثابت (Firmware)."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.4",
   "date": "2026-11-20",
   "en": [
    "Speed limits: the upload limit failed on NETGEAR S350 switches with \"error 14\". The app now uses a rule the switch accepts, and error messages are clearer."
   ],
   "ar": [
    "حدود السرعة: كان حدّ الرفع يفشل في محوّلات NETGEAR S350 مع ظهور «error 14». وأصبح البرنامج الآن يستخدم قاعدة يقبلها المحوّل، مع رسائل خطأ أوضح."
   ]
  },
  {
   "product": "launcher",
   "version": "2.19.0",
   "date": "2026-11-20",
   "en": [
    "While an app downloads, the launcher now shows the download speed and the time left next to the percentage (for example \"Updating... 27% · 3.2 MB/s · 0:12 left\")."
   ],
   "ar": [
    "في أثناء تنزيل أي برنامج، يعرض المشغّل الآن سرعة التنزيل والوقت المتبقّي بجانب النسبة المئوية (مثل «27% · 3.2 MB/s · متبقٍّ 0:12»)."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.8",
   "date": "2026-11-20",
   "en": [
    "New Worship guides page: 15 step-by-step guides with their sources (wudu, ghusl, tayammum, how to pray, prostration of forgetfulness, travel prayer, Friday, Witr, Istikhara, funeral prayer, Eid, fasting, zakat, Umrah and Hajj).",
    "After Isha, \"Tomorrow\" now shows next to Fajr.",
    "The start-with-the-computer entry is now created only by the installed copy."
   ],
   "ar": [
    "صفحة جديدة باسم دليل العبادات: 15 دليلًا خطوة بخطوة مع مصادرها (الوضوء، والغسل، والتيمم، وصفة الصلاة، وسجود السهو، وصلاة المسافر، والجمعة، والوتر، والاستخارة، وصلاة الجنازة، والعيد، والصيام، والزكاة، والعمرة، والحج).",
    "بعد صلاة العشاء تظهر الآن كلمة «غدًا» بجانب الفجر.",
    "أصبح التشغيل التلقائي مع بدء الجهاز يُضاف من النسخة المثبّتة فقط."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.3",
   "date": "2026-11-20",
   "en": [
    "Mac: the Location question now really appears, so Network Monitor shows up in Location Services and can see device MAC addresses."
   ],
   "ar": [
    "في Mac: أصبح طلب إذن الموقع يظهر فعلًا، فيُدرَج Network Monitor في خدمات الموقع (Location Services) ويتمكّن من رؤية عناوين MAC للأجهزة."
   ]
  },
  {
   "product": "launcher",
   "version": "2.18.1",
   "date": "2026-11-20",
   "en": [
    "Kankon Launcher 2.18.0 and 2.18.1 (Windows and Mac): Force Uninstaller is now in Tools.",
    "Dana is now a link to playdana.net instead of a download."
   ],
   "ar": [
    "Kankon Launcher 2.18.0 و2.18.1 (Windows وMac): أصبح Force Uninstaller متاحًا في قسم Tools.",
    "أصبح Dana رابطًا إلى موقع playdana.net بدلًا من تنزيله."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.2",
   "date": "2026-11-20",
   "en": [
    "Mac: newer macOS hides device MAC addresses from apps without Location access. The app now asks for Location once, only to see MAC addresses; it never reads your location.",
    "If Location is off, the app shows how to turn it on."
   ],
   "ar": [
    "في Mac: تُخفي الإصدارات الأحدث من macOS عناوين MAC للأجهزة عن البرامج التي لا تملك إذن الموقع (Location). لذا يطلب البرنامج هذا الإذن مرة واحدة لرؤية عناوين MAC فقط، ولا يقرأ موقعك أبدًا.",
    "إذا كان إذن الموقع متوقفًا، يعرض البرنامج طريقة تفعيله."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.2",
   "date": "2026-11-20",
   "en": [
    "Mac: fixed a crash at start on Apple Silicon (M1 to M5)."
   ],
   "ar": [
    "في Mac: أُصلح توقّف البرنامج عند التشغيل على معالجات Apple Silicon (من M1 إلى M5)."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.1",
   "date": "2026-11-20",
   "en": [
    "Arabic reviewed throughout, with correct counts for every number.",
    "Kankon Launcher's own folders are now protected."
   ],
   "ar": [
    "روجعت الصياغة العربية في البرنامج كله، وأصبحت الأعداد تظهر بصيغة صحيحة في كل الحالات.",
    "أصبحت مجلدات Kankon Launcher نفسها محمية."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.3.1",
   "date": "2026-11-20",
   "en": [
    "Mac: volume names with ':' show correctly, and Computer name shows the name from System Settings instead of the network hostname."
   ],
   "ar": [
    "في Mac: تظهر أسماء وحدات التخزين التي تحتوي على «:» بشكل صحيح، ويعرض اسم الجهاز الاسمَ المحدَّد في إعدادات النظام (System Settings) بدلًا من اسم المضيف على الشبكة."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.4",
   "date": "2026-11-20",
   "en": [
    "Overview: the public IP, provider and location work again. A Cloudflare service started refusing requests, so the app now falls back to Cloudflare trace and ipinfo.io.",
    "Mac: the Overview shows the real computer name and the macOS version.",
    "Help: the privacy table now lists ipinfo.io."
   ],
   "ar": [
    "النظرة العامة: عاد عنوان IP العام ومزوّد الخدمة والموقع إلى الظهور. فقد بدأت إحدى خدمات Cloudflare برفض الطلبات، لذا أصبح البرنامج يلجأ بدلًا منها إلى Cloudflare trace وipinfo.io.",
    "في Mac: تعرض النظرة العامة اسم الجهاز الفعلي وإصدار macOS.",
    "المساعدة: أصبح جدول الخصوصية يذكر ipinfo.io."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.1",
   "date": "2026-11-20",
   "en": [
    "Mac: device MAC addresses show again, and the Mac's own MAC address is read correctly.",
    "Free IPs never lists this computer's own addresses (Wi-Fi and Ethernet) as free.",
    "Mac: the computer name now comes from System Settings, and the English text says \"this Mac\"."
   ],
   "ar": [
    "في Mac: عادت عناوين MAC للأجهزة إلى الظهور، ويُقرأ عنوان MAC الخاص بجهاز Mac نفسه بشكل صحيح.",
    "لا تُدرج قائمة العناوين الشاغرة (Free IPs) أبدًا عناوينَ هذا الجهاز نفسه (Wi-Fi وEthernet) على أنها شاغرة.",
    "في Mac: يُؤخذ اسم الجهاز الآن من إعدادات النظام (System Settings)، ويظهر في النص الإنجليزي «this Mac»."
   ]
  },
  {
   "product": "ForceUninstaller",
   "version": "1.0.0",
   "date": "2026-11-20",
   "en": [
    "New app in Tools, for Windows and Mac: stop any program, uninstall it with its own uninstaller, or force-remove stubborn programs with all their leftovers.",
    "Safe by design: system parts are protected, you approve every item, a restore point is created first and registry keys are backed up to .reg files.",
    "Full Help guide in English and Arabic (Help button or F1)."
   ],
   "ar": [
    "برنامج جديد في قسم Tools لنظامَي Windows وMac: أوقف أي برنامج، أو أزله ببرنامج الإزالة الخاص به، أو احذف البرامج العنيدة بالقوة مع كل بقاياها.",
    "مصمَّم ليكون آمنًا: أجزاء النظام محمية، وأنت من يوافق على كل عنصر، وتُنشأ نقطة استعادة أولًا، وتُحفظ مفاتيح السجل في ملفات ‎.reg احتياطية.",
    "دليل مساعدة كامل بالعربية والإنجليزية (زرّ Help أو المفتاح F1)."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.3",
   "date": "2026-11-20",
   "en": [
    "Fix & Speed is now on Mac too (Windows and Mac): download and upload per app, with full Mac app names.",
    "Safer Fix & Speed: the Stop button is never offered for unnamed or system processes.",
    "More macOS system agents are protected as well."
   ],
   "ar": [
    "أصبحت صفحة الإصلاح والسرعة متاحة في Mac أيضًا (Windows وMac): التنزيل والرفع لكل برنامج، مع الأسماء الكاملة لبرامج Mac.",
    "الإصلاح والسرعة أكثر أمانًا: لا يظهر زرّ الإيقاف أبدًا لعمليات النظام أو العمليات التي لا اسم لها.",
    "أصبح المزيد من العمليات الخلفية لنظام macOS (System Agents) محميًا كذلك."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.1",
   "date": "2026-11-20",
   "en": [
    "Arabic reviewed across the whole app, including the new Fix & Speed page (Windows)."
   ],
   "ar": [
    "روجعت الصياغة العربية في البرنامج كله، بما في ذلك صفحة الإصلاح والسرعة الجديدة (في Windows)."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.2.0",
   "date": "2026-11-20",
   "en": [
    "New Fix & Speed page (Windows): see which apps use the internet right now (download and upload per app, CPU, memory) and stop them with one click.",
    "Network health check (adapter, Wi-Fi, IP, router, internet, DNS) with one-click fixes: turn Wi-Fi back on, quick repair and full network reset.",
    "Pause Windows background downloads, and speed tips for your connection.",
    "Help guide updated with a new Fix & Speed section."
   ],
   "ar": [
    "صفحة جديدة باسم الإصلاح والسرعة (Fix & Speed) في Windows: اعرف البرامج التي تستخدم الإنترنت الآن (التنزيل والرفع لكل برنامج، والمعالج، والذاكرة) وأوقفها بنقرة واحدة.",
    "فحص لسلامة الشبكة (كرت الشبكة، وWi-Fi، وعنوان IP، وجهاز التوجيه، والإنترنت، وDNS) مع إصلاحات بنقرة واحدة: إعادة تشغيل Wi-Fi، والإصلاح السريع، وإعادة ضبط الشبكة بالكامل.",
    "إيقاف تنزيلات Windows في الخلفية مؤقتًا، ونصائح لتسريع اتصالك.",
    "حُدِّث دليل المساعدة بقسم جديد عن الإصلاح والسرعة."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.3.0",
   "date": "2026-11-20",
   "en": [
    "New drive space cards: used / total, space left and a fill bar per drive that turns amber at 75% and red at 90%.",
    "Help guide updated with a new Storage paragraph."
   ],
   "ar": [
    "بطاقات جديدة لمساحة الأقسام: المستخدَم من الإجمالي، والمساحة المتبقّية، وشريط امتلاء لكل قسم يتحوّل إلى البرتقالي عند 75% وإلى الأحمر عند 90%.",
    "حُدِّث دليل المساعدة بفقرة جديدة عن التخزين."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.6.0",
   "date": "2026-11-20",
   "en": [
    "Reports: new Save as PDF button that saves an A4 report to your Downloads folder and opens it.",
    "Speed limits: set an upload limit for each switch port next to the download limit (NETGEAR S350).",
    "Help guide updated."
   ],
   "ar": [
    "التقارير: زرّ جديد للحفظ بصيغة PDF يحفظ تقريرًا بمقاس A4 في مجلد التنزيلات ويفتحه.",
    "حدود السرعة: أصبح بالإمكان تحديد حدّ للرفع لكل منفذ في المحوّل إلى جانب حدّ التنزيل (NETGEAR S350).",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.5",
   "date": "2026-11-20",
   "en": [
    "New Internet plan card at the top of the main window: used and plan size in GB, what is left and the days to renewal.",
    "Pick its look in Setup > Internet plan: Blue bar, Ring (default) or Battery. It turns amber at 80% and red when the plan is used up.",
    "Fix: the plan size now shows in GB exactly as typed (10000 no longer shows as 9.8 TB).",
    "Help guide updated."
   ],
   "ar": [
    "بطاقة جديدة لباقة الإنترنت في أعلى النافذة الرئيسية: المستهلك وحجم الباقة بالغيغابايت (GB)، والمتبقّي، والأيام الباقية حتى التجديد.",
    "اختر شكلها من Setup > Internet plan: شريط أزرق أو حلقة (الافتراضي) أو بطارية. ويتحوّل لونها إلى البرتقالي عند 80% وإلى الأحمر عند نفاد الباقة.",
    "إصلاح: يظهر حجم الباقة الآن بالغيغابايت كما أدخلته تمامًا (لم يعد الرقم 10000 يظهر بصيغة 9.8 TB).",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.4",
   "date": "2026-11-20",
   "en": [
    "Arabic screens reviewed: formal Arabic throughout, consistent terms such as «المحوّل» for the switch, and WhatsApp written in English.",
    "Help guide updated."
   ],
   "ar": [
    "روجعت الشاشات العربية: صياغة فصيحة في كل الشاشات، ومصطلحات موحّدة مثل «المحوّل»، واسم WhatsApp مكتوب بالإنجليزية.",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.3",
   "date": "2026-11-20",
   "en": [
    "Alerts now go to WhatsApp only: phone alerts through the ntfy app are removed.",
    "The Setup tab \"Phone alerts\" is renamed \"WhatsApp\". The weekly summary and the Internet plan alerts arrive on WhatsApp.",
    "Help guide updated."
   ],
   "ar": [
    "أصبحت التنبيهات تصل على WhatsApp فقط، وأُزيلت تنبيهات الهاتف عبر تطبيق ntfy.",
    "تغيّر اسم تبويب «Phone alerts» في Setup إلى «WhatsApp». ويصل الملخّص الأسبوعي وتنبيهات باقة الإنترنت على WhatsApp.",
    "حُدِّث دليل المساعدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.2",
   "date": "2026-11-20",
   "en": [
    "New WhatsApp alerts through the free CallMeBot service (personal use): every alert, the weekly summary and the Internet plan alerts can reach your WhatsApp.",
    "Setup: send the CallMeBot activation message once to get your key, then type your WhatsApp number and the key in Setup > Phone alerts. The Help guide shows the steps.",
    "Email alerts are removed."
   ],
   "ar": [
    "تنبيهات جديدة على WhatsApp عبر خدمة CallMeBot المجانية (للاستخدام الشخصي): تصل كل التنبيهات والملخّص الأسبوعي وتنبيهات باقة الإنترنت إلى WhatsApp.",
    "الإعداد: أرسل رسالة التفعيل إلى CallMeBot مرة واحدة لتحصل على مفتاحك، ثم أدخل رقم WhatsApp والمفتاح في Setup > Phone alerts. ويشرح دليل المساعدة الخطوات.",
    "أُزيلت التنبيهات بالبريد الإلكتروني."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.1",
   "date": "2026-11-20",
   "en": [
    "Email alerts are now sent from your own Gmail using a Gmail app password, saved on that PC only. Other email providers work too: type the server and port.",
    "Clear messages when the app password is wrong or the mail server cannot be reached.",
    "The weekly summary's \"Send one now\" button now works with email only.",
    "Help guide: new email setup steps under Alerts and a new troubleshooting item."
   ],
   "ar": [
    "تُرسَل التنبيهات بالبريد الإلكتروني الآن من حسابك في Gmail باستخدام كلمة مرور التطبيقات (App Password) التي تُحفظ على ذلك الجهاز فقط. ويمكن استخدام مزوّدي بريد آخرين بإدخال عنوان الخادم والمنفذ.",
    "رسائل واضحة عندما تكون كلمة مرور التطبيقات غير صحيحة أو يتعذّر الوصول إلى خادم البريد.",
    "أصبح زرّ «Send one now» للملخّص الأسبوعي يعمل مع البريد الإلكتروني وحده.",
    "دليل المساعدة: خطوات جديدة لإعداد البريد في قسم التنبيهات، وبند جديد في حلّ المشكلات."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.5.0",
   "date": "2026-11-20",
   "en": [
    "New Reports: daily, weekly (Sunday to Saturday), monthly and yearly, with home internet, all devices, outages, a chart, and the top devices and programs.",
    "New Internet plan: plan size and renew day (1 to 28), a used and left bar, and alerts at 80% and 100%.",
    "New email alerts for the plan, daily limits and the weekly and monthly summaries (through ntfy.sh).",
    "Readings are now kept for about 13 months. The Help guide has a new Internet plan section and an updated Reports section."
   ],
   "ar": [
    "تقارير جديدة: يومية وأسبوعية (من الأحد إلى السبت) وشهرية وسنوية، تتضمّن استهلاك إنترنت المنزل وكل الأجهزة والانقطاعات ورسمًا بيانيًا وأكثر الأجهزة والبرامج استهلاكًا.",
    "ميزة باقة الإنترنت الجديدة: حجم الباقة ويوم التجديد (من 1 إلى 28)، وشريط يبيّن المستهلك والمتبقّي، وتنبيهات عند 80% و100%.",
    "تنبيهات جديدة بالبريد الإلكتروني للباقة والحدّ اليومي والملخّصين الأسبوعي والشهري (عبر ntfy.sh).",
    "تُحفظ القراءات الآن نحو 13 شهرًا. وفي دليل المساعدة قسم جديد لباقة الإنترنت، وقسم التقارير محدَّث."
   ]
  },
  {
   "product": "website",
   "version": "1.53.0",
   "date": "2026-11-18",
   "en": [
    "RSS feeds: follow every app update in your feed reader (English and Arabic feeds).",
    "New Privacy page: what the site collects (an anonymous visitor ID and download counts only) and what it never collects."
   ],
   "ar": [
    "خلاصات RSS: تابِع كل تحديث للبرامج في قارئ الخلاصات (خلاصة بالإنجليزية وأخرى بالعربية).",
    "صفحة خصوصية جديدة: ما يجمعه الموقع (معرّف زائر عشوائي وأعداد التنزيلات فقط) وما لا يجمعه أبدًا."
   ]
  },
  {
   "product": "launcher",
   "version": "2.17.1",
   "date": "2026-11-18",
   "en": [
    "Icons of apps that open from a link now refresh automatically."
   ],
   "ar": [
    "أصبحت أيقونات البرامج التي تُفتح عبر رابط تُحدَّث تلقائيًا."
   ]
  },
  {
   "product": "launcher",
   "version": "2.17.0",
   "date": "2026-11-18",
   "en": [
    "iReport AI is now in Apps: it opens the web version, with buttons for the App Store (iPhone, iPad and Mac), Google Play, AppGallery and the privacy policy.",
    "The launcher can now list apps that open from a link instead of being installed."
   ],
   "ar": [
    "أصبح iReport AI متاحًا في قسم Apps (البرامج): يفتح نسخة الويب، مع أزرار لـ App Store (لأجهزة iPhone وiPad وMac) وGoogle Play وAppGallery وسياسة الخصوصية.",
    "أصبح بإمكان المشغّل عرض برامج تُفتح عبر رابط بدلًا من تثبيتها."
   ]
  },
  {
   "product": "website",
   "version": "1.52.0",
   "date": "2026-11-18",
   "en": [
    "New app page: iReport AI, the field reporting app, with App Store (iPhone, iPad and Mac), Google Play, AppGallery and web links."
   ],
   "ar": [
    "صفحة جديدة لبرنامج iReport AI، نظام التقارير الميدانية، مع روابط App Store (لأجهزة iPhone وiPad وMac) وGoogle Play وAppGallery ونسخة الويب."
   ]
  },
  {
   "product": "website",
   "version": "1.51.0",
   "date": "2026-11-18",
   "en": [
    "Games page: ArcheAge Chronicles, AION 2 and Silkroad Online added to the MMORPG picks."
   ],
   "ar": [
    "صفحة الألعاب: أُضيفت ArcheAge Chronicles وAION 2 وSilkroad Online إلى قائمة ألعاب الأدوار الجماعية."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.5",
   "date": "2026-11-18",
   "en": [
    "Much faster start-up on Windows and Mac: the launcher no longer unpacks a large compressed file at every start, and its code is precompiled.",
    "On Mac, app icons are now cached, so the window opens about twice as fast."
   ],
   "ar": [
    "بدء تشغيل أسرع بكثير على Windows وMac: لم يعد المشغّل يفكّ ضغط ملف كبير عند كل تشغيل، وأصبحت شيفرته مُصرَّفة مسبقًا.",
    "على Mac، تُحفظ أيقونات البرامج مؤقتًا، فتُفتح النافذة أسرع بنحو الضعف."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.4",
   "date": "2026-11-18",
   "en": [
    "Faster launcher: the My Device card is saved for a day, and its system check runs a few seconds after start-up in the background."
   ],
   "ar": [
    "مشغّل أسرع: تُحفظ بيانات بطاقة My Device (جهازي) مؤقتًا ليوم كامل، ويجري فحص النظام الخاص بها في الخلفية بعد ثوانٍ من بدء التشغيل."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.3",
   "date": "2026-11-18",
   "en": [
    "Only one Kankon Launcher runs at a time: opening it again brings the open window to the front.",
    "If the launcher has stopped responding, opening it again replaces it with a working one.",
    "Closing the launcher during an update now exits it completely."
   ],
   "ar": [
    "لا تعمل إلا نسخة واحدة من Kankon Launcher في الوقت نفسه: فإذا فتحته مرة أخرى تظهر النافذة المفتوحة في المقدّمة.",
    "إذا توقّف المشغّل عن الاستجابة، فإن فتحه مرة أخرى يُغلق النسخة المعلّقة ويفتح نسخة جديدة.",
    "إغلاق المشغّل أثناء التحديث يُنهيه الآن إنهاءً كاملًا."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.2",
   "date": "2026-11-18",
   "en": [
    "Kankon Markets is back in the Apps list."
   ],
   "ar": [
    "عاد Kankon Markets إلى قائمة Apps (البرامج)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.1",
   "date": "2026-11-18",
   "en": [
    "The Help button for Dana now opens the official game website, playdana.net."
   ],
   "ar": [
    "أصبح زرّ Help الخاص بلعبة Dana يفتح الموقع الرسمي للعبة، playdana.net."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.14.1",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the ❓ button or F1), in English and Arabic: the map and its layers, the 3D view, the El Niño card, finding the nearest rain, settings, troubleshooting and frequently asked questions. The same guide appears on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ ❓ أو مفتاح F1) بالعربية والإنجليزية: الخريطة وطبقاتها، والعرض ثلاثي الأبعاد، وبطاقة النينيو، والبحث عن أقرب مطر، والإعدادات، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في هذا الموقع."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.4.0",
   "date": "2026-11-18",
   "en": [
    "New Gulf stocks group: National Bank of Kuwait, Kuwait Finance House and Zain in the watchlist; Boubyan, Gulf Bank, Mabanee, Saudi Aramco, Al Rajhi, SABIC, Emaar and QNB to add. Boursa Kuwait prices in Kuwaiti dinar.",
    "New mini window that stays on top of other windows.",
    "New export: chart as a picture (PNG), prices and portfolio as CSV files.",
    "New light theme."
   ],
   "ar": [
    "مجموعة جديدة لأسهم الخليج: بنك الكويت الوطني وبيت التمويل الكويتي وزين في قائمة المتابعة، ويمكن إضافة بوبيان وبنك الخليج والمباني وأرامكو السعودية والراجحي وسابك وإعمار وبنك قطر الوطني. وتُعرض أسعار بورصة الكويت بالدينار الكويتي.",
    "نافذة صغيرة جديدة تبقى فوق النوافذ الأخرى.",
    "التصدير الجديد: الرسم البياني صورةً (PNG)، والأسعار والمحفظة في ملفات CSV.",
    "وضع فاتح جديد."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.3.1",
   "date": "2026-11-18",
   "en": [
    "Arabic wording of the Help guide reviewed, and the guide now states that the app always starts in English."
   ],
   "ar": [
    "مراجعة الصياغة العربية لدليل المساعدة، وأصبح الدليل يوضّح أن البرنامج يبدأ دائمًا باللغة الإنجليزية."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.6",
   "date": "2026-11-18",
   "en": [
    "New Help page inside the app (in the sidebar, or F1 from any page), in English and Arabic: prayer times and the adhan, hadith reminders, reading and listening to the Quran, adhkar, Qibla, tasbih, settings, privacy and frequently asked questions. The same guide appears in Kankon Launcher and on this website."
   ],
   "ar": [
    "صفحة مساعدة جديدة داخل البرنامج (في الشريط الجانبي، أو بمفتاح F1 من أي صفحة) بالعربية والإنجليزية: مواقيت الصلاة والأذان، وتذكير الأحاديث، وقراءة القرآن الكريم والاستماع إليه، والأذكار، والقبلة، والتسبيح، والإعدادات، والخصوصية، والأسئلة الشائعة. ويظهر الدليل نفسه في Kankon Launcher وفي هذا الموقع."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.1.1",
   "date": "2026-11-18",
   "en": [
    "Arabic wording of the Help guide reviewed and improved."
   ],
   "ar": [
    "مراجعة الصياغة العربية لدليل المساعدة وتحسينها."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.2.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the Help button or F1), in English and Arabic: every setting explained step by step, troubleshooting and frequently asked questions. The same guide appears on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ Help أو مفتاح F1) بالعربية والإنجليزية: شرح كل إعداد خطوة بخطوة، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في هذا الموقع."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.7.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the Help button or F1), in English and Arabic: every setting explained step by step, troubleshooting and frequently asked questions. The same guide appears on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ Help أو مفتاح F1) بالعربية والإنجليزية: شرح كل إعداد خطوة بخطوة، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في هذا الموقع."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.3.1",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app in English and Arabic; open it with the Help button or F1. The same guide appears on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج بالعربية والإنجليزية، يُفتح بزرّ Help أو مفتاح F1. ويظهر الدليل نفسه في هذا الموقع."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.3.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the Help button or F1), in English and Arabic: backing up drivers and restoring them after reinstalling Windows, updating them, the installed drivers list, troubleshooting and frequently asked questions. The same guide appears in Kankon Launcher and on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ Help أو مفتاح F1) بالعربية والإنجليزية: النسخ الاحتياطي للتعريفات واستعادتها بعد إعادة تثبيت Windows، وتحديثها، وقائمة التعريفات المثبّتة، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في Kankon Launcher وفي هذا الموقع."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.1.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the Help button or F1), in English and Arabic: every tool explained step by step, how to read the results, troubleshooting and frequently asked questions. The same guide appears on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ Help أو مفتاح F1) بالعربية والإنجليزية: شرح كل أداة خطوة بخطوة، وكيفية قراءة النتائج، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في هذا الموقع."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.2.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the ? Help button or F1, Esc closes it), in English and Arabic: every card explained, the disk speed test step by step, sharing your specs, privacy, troubleshooting and frequently asked questions. The same guide opens from the Help button in Kankon Launcher and on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ ? Help أو مفتاح F1، ويُغلق بمفتاح Esc) بالعربية والإنجليزية: شرح كل بطاقة، واختبار سرعة القرص خطوة بخطوة، ومشاركة مواصفات جهازك، والخصوصية، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في Kankon Launcher (زرّ Help) وفي هذا الموقع."
   ]
  },
  {
   "product": "launcher",
   "version": "2.16.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the launcher (the Help button or F1), in English and Arabic.",
    "Every app's Details panel now has a Help button that opens that app's full help guide.",
    "Kankon Markets is now available under Apps (Windows and Mac)."
   ],
   "ar": [
    "دليل مساعدة جديد داخل المشغّل (زرّ Help أو مفتاح F1) بالعربية والإنجليزية.",
    "أصبح في لوحة التفاصيل لكل برنامج زرّ Help يفتح دليل المساعدة الكامل لذلك البرنامج.",
    "أصبح Kankon Markets متاحًا في قسم Apps (البرامج) على Windows وMac."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.4.1",
   "date": "2026-11-18",
   "en": [
    "Arabic wording of the Help guide and the screens reviewed: tab names and the Windows, Mac and Kankon Launcher terms are now consistent."
   ],
   "ar": [
    "مراجعة الصياغة العربية لدليل المساعدة والشاشات: أصبحت أسماء التبويبات ومصطلحات Windows وMac وKankon Launcher موحّدة."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.4.0",
   "date": "2026-11-18",
   "en": [
    "New Help guide inside the app (the Help button or F1), in English and Arabic: setup, every tab, troubleshooting and frequently asked questions. The same guide appears in the Kankon Launcher Details panel and on this website."
   ],
   "ar": [
    "دليل مساعدة جديد داخل البرنامج (زرّ Help أو مفتاح F1) بالعربية والإنجليزية: الإعداد، وشرح كل تبويب، وحلّ المشكلات، والأسئلة الشائعة. ويظهر الدليل نفسه في لوحة التفاصيل في Kankon Launcher وفي هذا الموقع."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.3.0",
   "date": "2026-11-18",
   "en": [
    "New chart tools: Bollinger Bands, volume, RSI and MACD panes, and your own level and trend lines, saved for each market.",
    "New Compare: put two markets on one chart as percent change.",
    "New Market hours: open or closed now, and when each market opens or closes, in Kuwait time.",
    "New Daily brief: the AI Assistant writes a short summary of your markets, portfolio and headlines, with one press or automatically each morning."
   ],
   "ar": [
    "أدوات رسم جديدة: نطاقات بولينجر، ولوحات حجم التداول وRSI وMACD، وخطوط المستوى والاتجاه التي ترسمها بنفسك وتُحفظ لكل سوق.",
    "خاصية المقارنة الجديدة: عرض سوقين على رسم واحد بنسبة التغيّر.",
    "أوقات الأسواق الجديدة: حالة كل سوق الآن (مفتوح أو مغلق)، ومتى يفتح أو يُغلق، بتوقيت الكويت.",
    "الملخّص اليومي الجديد: يكتب المساعد الذكي ملخّصًا موجزًا لأسواقك ومحفظتك والعناوين، بنقرة واحدة أو تلقائيًا كل صباح."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.2.0",
   "date": "2026-11-18",
   "en": [
    "New Alerts tab: a computer notification when a price goes above or below a number, or moves more than a set % today. A bell next to the price shows active alerts.",
    "New Portfolio tab: what you own (for example gold grams by karat, or coins), valued live in Kuwaiti dinar with today's change and profit or loss.",
    "New Calculator tab: a currency converter, the price of gold or silver by weight, karat and making charge, and the value of any amount of any market."
   ],
   "ar": [
    "تبويب جديد للتنبيهات (Alerts): إشعار على الحاسوب عندما يرتفع السعر فوق رقم معيّن أو ينخفض تحته، أو يتحرّك اليوم بأكثر من نسبة تحدّدها. ويُظهر جرس بجانب السعر التنبيهات المفعّلة.",
    "تبويب جديد للمحفظة (Portfolio): ما تملكه (مثل غرامات الذهب بحسب العيار، أو العملات الرقمية) مُقيَّمًا مباشرةً بالدينار الكويتي، مع تغيّر اليوم والربح أو الخسارة.",
    "تبويب جديد للحاسبة (Calculator): محوّل للعملات، وسعر الذهب أو الفضة بحسب الوزن والعيار وأجرة الصنعة، وقيمة أي كمية من أي سوق."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.1.3",
   "date": "2026-11-18",
   "en": [
    "New Help page (the Help button at the top, or F1): a quick-start guide, a full guide to every part of the app, and a step-by-step guide to the Anthropic API key (how to create it, what it costs, privacy and common errors). The AI Assistant setup card links to it."
   ],
   "ar": [
    "صفحة مساعدة جديدة (زرّ Help في الأعلى أو مفتاح F1): دليل سريع للبدء، ودليل كامل لكل أجزاء البرنامج، وشرح خطوة بخطوة لمفتاح Anthropic API (طريقة إنشائه وتكلفته والخصوصية والأخطاء الشائعة). وتتضمّن بطاقة إعداد المساعد الذكي رابطًا إلى هذا الشرح."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.1.2",
   "date": "2026-11-18",
   "en": [
    "A− and A+ buttons at the top make everything in the window bigger or smaller (80% to 180%: text, chart and chat). The size is remembered; double-click the percentage to return to 100%."
   ],
   "ar": [
    "زرّا A− وA+ في الأعلى يكبّران محتوى النافذة كله أو يصغّرانه (من 80% إلى 180%: النصوص والرسم البياني والمحادثة)، ويُحفظ الحجم الذي تختاره، وبالنقر المزدوج على النسبة يعود إلى 100%."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.1.1",
   "date": "2026-11-18",
   "en": [
    "Drag the lines on both sides of the chart to resize the watchlist and the right side (Analyzer, News, AI Assistant). The sizes are remembered, and a double-click resets them.",
    "AI Assistant chats are now saved on your computer with the day, date and time of every message, and a History list lets you open, continue or delete past chats."
   ],
   "ar": [
    "اسحب الخطّين على جانبي الرسم البياني لتغيير عرض قائمة المتابعة واللوحة الجانبية (المحلّل والأخبار والمساعد الذكي)، ويُحفظ العرض الذي تختاره، وبالنقر المزدوج يعود إلى وضعه الأصلي.",
    "أصبحت محادثات المساعد الذكي تُحفظ على حاسوبك مع اليوم والتاريخ والوقت لكل رسالة، وتتيح قائمة History فتح المحادثات السابقة أو متابعتها أو حذفها."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.1.0",
   "date": "2026-11-18",
   "en": [
    "New News tab: headlines in English or Arabic for the selected market, with a summary of the price move over the last 15 minutes to 4 hours.",
    "New AI Assistant tab: ask Claude about any market; it sees the prices, the analyzer, the moves and the headlines. Uses your own Anthropic API key, saved only on your computer. Not financial advice.",
    "Available for Windows and Mac (Apple Silicon and Intel)."
   ],
   "ar": [
    "تبويب جديد للأخبار (News): عناوين الأخبار بالعربية أو الإنجليزية للسوق المختار، مع ملخّص لحركة السعر خلال فترة من 15 دقيقة إلى 4 ساعات.",
    "تبويب جديد للمساعد الذكي (AI Assistant): اسأل Claude عن أي سوق، فهو يطّلع على الأسعار والمحلّل والحركات وعناوين الأخبار. ويستخدم مفتاح Anthropic API الخاص بك المحفوظ على حاسوبك فقط. ولا يُعدّ نصيحة مالية.",
    "متاح لنظامي Windows وMac (بمعالجات Apple Silicon وIntel)."
   ]
  },
  {
   "product": "KankonMarkets",
   "version": "1.0.0",
   "date": "2026-11-18",
   "en": [
    "New app: Kankon Markets, for Windows and Mac. Live prices, charts from 1 day to 5 years and a rise/fall analyzer in English or Arabic for 20 markets (gold, silver, oil including Kuwait crude, crypto, currencies and indices), plus the price of a gram of gold in Kuwaiti dinar. Not financial advice."
   ],
   "ar": [
    "برنامج جديد: Kankon Markets لنظامي Windows وMac. أسعار مباشرة، ورسوم بيانية من يوم إلى 5 سنوات، ومحلّل للصعود والهبوط بالعربية أو الإنجليزية لـ 20 سوقًا (الذهب والفضة والنفط ومنه نفط الكويت، والعملات الرقمية، والعملات، والمؤشرات)، إضافةً إلى سعر غرام الذهب بالدينار الكويتي. ولا يُعدّ نصيحة مالية."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.13.1",
   "date": "2026-11-18",
   "en": [
    "New El Niño card: the current status, the ONI index and a chart of the last two years.",
    "New sea surface temperature anomaly layer on the map (how much warmer or cooler the sea is than average), with a colour legend."
   ],
   "ar": [
    "بطاقة جديدة لظاهرة El Niño (النينيو): حالتها الحالية، ومؤشّر ONI، ورسم بياني لآخر سنتين.",
    "طبقة جديدة على الخريطة لفرق درجة حرارة سطح البحر عن المعدل، مع مفتاح للألوان."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.12.1",
   "date": "2026-11-18",
   "en": [
    "Where's the rain now draws an arrow on the map from the selected city to the nearest rain, with a marker on the rain."
   ],
   "ar": [
    "أصبحت ميزة Where's the rain (أين المطر) ترسم على الخريطة سهمًا من المدينة المختارة إلى أقرب مطر، مع علامة على موضع المطر."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.12.0",
   "date": "2026-11-17",
   "en": [
    "New \"Where's the rain\" button (water drop): finds the nearest rain to the selected city and shows its distance, its direction and whether it is coming closer."
   ],
   "ar": [
    "زرّ جديد Where's the rain (أين المطر) على شكل قطرة ماء: يحدّد أقرب مطر إلى المدينة المختارة، ويعرض بُعده واتجاهه وما إذا كان يقترب منها."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.11.2",
   "date": "2026-11-17",
   "en": [
    "Country borders and coastlines now show over the whole world map.",
    "Clouds and rain from the forecast model look softer outside the Arab region."
   ],
   "ar": [
    "أصبحت حدود الدول والسواحل تظهر على خريطة العالم كلها.",
    "أصبحت السحب والأمطار المأخوذة من نموذج التوقّعات تُعرض بسلاسة أكبر خارج المنطقة العربية."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.3.1",
   "date": "2026-11-17",
   "en": [
    "Fixed the daily usage alert box showing the speed limit text.",
    "Arabic wording reviewed."
   ],
   "ar": [
    "إصلاح ظهور نصّ حدود السرعة في نافذة تنبيه الاستهلاك اليومي.",
    "مراجعة الصياغة العربية."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.3.0",
   "date": "2026-11-17",
   "en": [
    "New Speed limits window: set a maximum download speed for each port of a managed switch (NETGEAR S350: GS308T, GS324T, GS324TP) over SNMP. The limit stays on the switch when the app is closed, and the window shows which devices are on each port.",
    "New Auto Detect: finds the router and managed switches by itself, with their model and whether speed limits are supported.",
    "Automatic router mode now ignores an old router address that is no longer on the network."
   ],
   "ar": [
    "نافذة جديدة لحدود السرعة: حدّد سرعة تنزيل قصوى لكل منفذ في المحوّل المُدار (NETGEAR S350: GS308T وGS324T وGS324TP) عبر بروتوكول SNMP. ويبقى الحدّ محفوظًا في المحوّل بعد إغلاق البرنامج، وتعرض النافذة الأجهزة الموصولة بكل منفذ.",
    "ميزة جديدة للاكتشاف التلقائي (Auto Detect): تعثر على جهاز التوجيه والمحوّلات المُدارة تلقائيًا، مع طرازها وما إذا كانت تدعم حدود السرعة.",
    "أصبح الوضع التلقائي (Auto) لجهاز التوجيه يتجاهل عنوانه القديم إذا لم يعد موجودًا على الشبكة."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.11.1",
   "date": "2026-11-16",
   "en": [
    "The whole world: a world map with temperature, wind, clouds and rain, and a search for any city to open its 10-day forecast.",
    "New map layers: air pressure (isobars with H and L) and live tropical cyclones with their tracks.",
    "Satellite clouds now cover the whole world.",
    "A season banner shows the current season and the days left, with the dates of every season."
   ],
   "ar": [
    "العالم كله: خريطة للعالم بالحرارة والرياح والسحب والأمطار، وبحث عن أي مدينة لفتح توقّعاتها لعشرة أيام.",
    "طبقات جديدة على الخريطة: الضغط الجوي (خطوط الضغط المتساوي مع H وL)، والأعاصير المدارية النشطة ومساراتها.",
    "أصبحت صور السحب بالأقمار الصناعية تغطّي العالم كله.",
    "شريط للمواسم يعرض الموسم الحالي والأيام المتبقّية منه، مع تواريخ جميع المواسم."
   ]
  },
  {
   "product": "launcher",
   "version": "2.15.3",
   "date": "2026-11-16",
   "en": [
    "Removed the Edit app list button; the app list is managed for you."
   ],
   "ar": [
    "إزالة زرّ Edit app list، إذ تُدار قائمة البرامج تلقائيًا."
   ]
  },
  {
   "product": "launcher",
   "version": "2.15.2",
   "date": "2026-11-16",
   "en": [
    "Mac: fixed the update marker, so an app no longer shows Update after it has been updated."
   ],
   "ar": [
    "على Mac: إصلاح علامة التحديث، فلا يظهر زرّ Update لبرنامج بعد تحديثه."
   ]
  },
  {
   "product": "launcher",
   "version": "2.15.1",
   "date": "2026-11-16",
   "en": [
    "Downloads no longer stall: a stuck download retries and resumes where it stopped."
   ],
   "ar": [
    "لم تعد التنزيلات تتوقّف: إذا تعثّر التنزيل تُعاد المحاولة ويُستأنف من حيث توقّف."
   ]
  },
  {
   "product": "launcher",
   "version": "2.15.0",
   "date": "2026-11-16",
   "en": [
    "Mac: Kankon Launcher now updates itself, like on Windows."
   ],
   "ar": [
    "على Mac: أصبح Kankon Launcher يحدّث نفسه تلقائيًا، كما في Windows."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.2.0",
   "date": "2026-11-16",
   "en": [
    "New: Boys and Girls sizes for ages 2 to 15, with kids shoes (EU 20 to 36) and kids thobe and abaya.",
    "Fixed the app closing when pressing ft/lb, Men/Women, the clothing type or the body shape.",
    "Smoother sliders."
   ],
   "ar": [
    "جديد: مقاسات الأولاد والبنات من سنتين إلى 15 سنة، مع أحذية الأطفال (من EU 20 إلى 36) والثوب والعباءة للأطفال.",
    "إصلاح توقّف البرنامج المفاجئ عند النقر على ft/lb أو Men/Women أو نوع الملابس أو شكل الجسم.",
    "حركة أكثر سلاسة لأشرطة الطول والوزن."
   ]
  },
  {
   "product": "launcher",
   "version": "2.14.0",
   "date": "2026-11-15",
   "en": [
    "Size Finder is now available under Apps (Windows and Mac)."
   ],
   "ar": [
    "أصبح Size Finder متاحًا في قسم Apps (البرامج) على Windows وMac."
   ]
  },
  {
   "product": "launcher",
   "version": "2.13.0",
   "date": "2026-11-15",
   "en": [
    "New Uninstall button in each app's details."
   ],
   "ar": [
    "زرّ Uninstall جديد في صفحة تفاصيل كل برنامج لإزالته."
   ]
  },
  {
   "product": "launcher",
   "version": "2.12.0",
   "date": "2026-11-15",
   "en": [
    "Noor is now available under Apps (Windows and Mac)."
   ],
   "ar": [
    "أصبح Noor متاحًا في قسم Apps (البرامج) على Windows وMac."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.4",
   "date": "2026-11-15",
   "en": [
    "Download a surah (the ⬇ button on the Quran page) or the whole Quran for any reciter, to listen offline.",
    "Delete saved recitations per reciter or all at once (Settings > Quran recitation)."
   ],
   "ar": [
    "تحميل تلاوة سورة (بزرّ ⬇ في صفحة Quran) أو تلاوة القرآن الكريم كاملًا بصوت أي قارئ، للاستماع دون اتصال بالإنترنت.",
    "حذف التلاوات المحفوظة لكل قارئ أو جميعها دفعةً واحدة (Settings > Quran recitation)."
   ]
  },
  {
   "product": "SizeFinder",
   "version": "1.1.0",
   "date": "2026-11-15",
   "en": [
    "New app: Size Finder, for Windows and Mac. It gives your clothing size (XS to 5XL) from height, weight and body shape for men and women (trousers, shirts and tops, thobe and abaya, jackets), and your shoe size from foot length, with EU, US, UK and Asian sizes, saved people and an editable size chart."
   ],
   "ar": [
    "برنامج جديد: Size Finder لنظامي Windows وMac. يحدّد مقاس ملابسك (من XS إلى 5XL) من الطول والوزن وشكل الجسم للرجال والنساء (البنطال، والقميص والتوب، والثوب والعباءة، والجاكيت)، ومقاس حذائك من طول القدم، مع المقاسات الأوروبية والأمريكية والبريطانية والآسيوية، وحفظ الأشخاص، وجدول مقاسات قابل للتعديل."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.8.0",
   "date": "2026-11-15",
   "en": [
    "New map layers: real moving cloud images from the Meteosat satellite (EUMETSAT, every 15 minutes) and satellite rain for the whole region. The rain radar is now on by default.",
    "A more compact top bar, so the language button fits on small screens."
   ],
   "ar": [
    "طبقات جديدة على الخريطة: صور حقيقية متحركة للسحب من القمر الصناعي Meteosat (التابع لمنظمة EUMETSAT، كل 15 دقيقة)، والأمطار المرصودة بالأقمار الصناعية للمنطقة كلها. وأصبح رادار الأمطار مفعّلًا افتراضيًا.",
    "أصبح الشريط العلوي أصغر حتى يظهر زر اللغة على الشاشات الصغيرة."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.7.4",
   "date": "2026-11-15",
   "en": [
    "The map now shows a dark rain cloud, falling rain and lightning over rainy and stormy places.",
    "3D scene: thicker clouds with rain, stronger lightning with several bolts in thunderstorms, and a grey sky when it rains."
   ],
   "ar": [
    "أصبحت الخريطة تُظهر سحابة ممطرة داكنة، ومطرًا متساقطًا، وبرقًا فوق الأماكن الممطرة والعاصفة.",
    "المشهد ثلاثي الأبعاد: سحب أكثف مع المطر، وبرق أقوى بعدّة ومضات في العواصف الرعدية، وسماء رمادية عند هطول المطر."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.6.1",
   "date": "2026-11-15",
   "en": [
    "Arabic wording of the Pick the years section refined."
   ],
   "ar": [
    "تحسين الصياغة العربية لقسم اختيار السنوات (Pick the years)."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.6.0",
   "date": "2026-11-15",
   "en": [
    "Past and present: new Pick the years section. Choose any From and To year (for example 2020 to 2026) to get a year table, month-by-month temperature and rain tables, records (hottest and coldest day, wettest day, longest run of 45° days) and a daily chart.",
    "The current year is marked as unfinished. Days of 50° can read low because the archive comes from a weather model (ERA5)."
   ],
   "ar": [
    "الماضي والحاضر: قسم جديد باسم Pick the years (اختيار السنوات)، تختار فيه سنة البداية وسنة النهاية (مثل 2020 إلى 2026)، فتحصل على جدول للسنوات، وجداول شهرية لدرجات الحرارة والأمطار، والأرقام القياسية (أشدّ الأيام حرارةً وبرودةً، وأكثرها مطرًا، وأطول فترة متواصلة بحرارة 45° فأكثر)، ورسم بياني يومي.",
    "يُشار إلى العام الحالي بأنه لم يكتمل بعد. وقد يظهر عدد أيام 50° أقلّ من الواقع، لأن الأرشيف مستمدّ من نموذج للطقس (ERA5)."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.5.1",
   "date": "2026-11-15",
   "en": [
    "Arabic wording of the Past and present page, the camping outlook and the description refined."
   ],
   "ar": [
    "تحسين الصياغة العربية لصفحة الماضي والحاضر، وتوقّعات الرحلات البرية (الكشتة)، ووصف البرنامج."
   ]
  },
  {
   "product": "website",
   "version": "1.19.0",
   "date": "2026-11-15",
   "en": [
    "Gulf Weather 1.4.0 and 1.5.0 added to Updates and to its page."
   ],
   "ar": [
    "أُضيف الإصداران 1.4.0 و1.5.0 من Gulf Weather إلى التحديثات وإلى صفحته."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.5.0",
   "date": "2026-11-15",
   "en": [
    "New Past and present page: this year so far against the 1991–2020 average, the last 10 years or any other year; year-by-year charts with trend and 10-year average lines; a month-by-month profile; a temperature map of every year and month; records; a decade table; and a year against year table."
   ],
   "ar": [
    "صفحة جديدة باسم Past and present (الماضي والحاضر): مقارنة العام الحالي حتى اليوم بمعدّل الفترة 1991–2020، أو بالسنوات العشر الأخيرة، أو بأي عام آخر؛ مع رسوم بيانية عامًا بعام تتضمّن خط الاتجاه العام ومتوسط كل عشر سنوات، ومنحنى شهري (شهرًا بشهر)، وخريطة لونية لدرجات الحرارة في كل عام وشهر، والأرقام القياسية، وجدول لكل عقد، وجدول للمقارنة بين عامين."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.4.0",
   "date": "2026-11-15",
   "en": [
    "Camping outlook (kashta) upgraded: 8 desert areas (new: Subiya, Mutlaa, Kabd and Shaqaya, also on the Kuwait panel), the coldest night temperature with what to wear, the best calm hours to pitch the tent and light the fire, and a Thursday to Saturday weekend verdict.",
    "Fewer requests to the free weather service: history is fetched only when the climate view is opened and kept on the device for 30 days, forecasts refresh every 2 hours, and a clear message appears if the daily limit is reached."
   ],
   "ar": [
    "تطوير توقّعات الرحلات البرية (الكشتة): 8 مناطق صحراوية (الجديد منها: الصبية والمطلاع وكبد والشقايا، وتظهر أيضًا في لوحة الكويت)، وأدنى درجة حرارة ليلًا مع ما يناسبها من ملابس، وأنسب الساعات الهادئة لنصب الخيمة وإشعال النار، وتقييم لعطلة نهاية الأسبوع من الخميس إلى السبت.",
    "طلبات أقل إلى خدمة الطقس المجانية: لا تُجلب البيانات التاريخية إلا عند فتح قسم المناخ، وتُحفظ على الجهاز 30 يومًا، وتُحدَّث التوقّعات كل ساعتين، وتظهر رسالة واضحة عند بلوغ الحدّ اليومي."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.3.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording of the Climate over the years section and the description refined."
   ],
   "ar": [
    "تحسين الصياغة العربية لقسم المناخ عبر السنين ولوصف البرنامج."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.3",
   "date": "2026-11-14",
   "en": [
    "Arabic wording of the recitation feature and the description refined."
   ],
   "ar": [
    "تحسين الصياغة العربية لخاصية التلاوة ولوصف البرنامج."
   ]
  },
  {
   "product": "website",
   "version": "1.18.0",
   "date": "2026-11-14",
   "en": [
    "Noor 1.0.2 added to Updates and to its page, with a new Quran screenshot."
   ],
   "ar": [
    "أُضيف الإصدار 1.0.2 من Noor إلى التحديثات وإلى صفحته، مع لقطة شاشة جديدة لصفحة القرآن الكريم."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.2",
   "date": "2026-11-14",
   "en": [
    "Quran recitation with 15 reciters, ayah by ayah with the current ayah highlighted.",
    "Pause and resume, listen from any ayah, repeat each ayah, and continue to the next surah automatically.",
    "Each ayah works offline once it has played, and recitation pauses for the adhan."
   ],
   "ar": [
    "تلاوة القرآن الكريم بأصوات 15 قارئًا، آيةً آية مع تمييز الآية التي تُتلى.",
    "الإيقاف المؤقت والاستئناف، والاستماع من أي آية، وتكرار كل آية، والانتقال إلى السورة التالية تلقائيًا.",
    "تعمل التلاوة دون اتصال بالإنترنت بعد تشغيل كل آية أول مرة، وتتوقّف عند رفع الأذان."
   ]
  },
  {
   "product": "website",
   "version": "1.17.0",
   "date": "2026-11-14",
   "en": [
    "Gulf Weather 1.3.0 added to Updates and to its page."
   ],
   "ar": [
    "أُضيف الإصدار 1.3.0 من Gulf Weather إلى التحديثات وإلى صفحته."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.3.0",
   "date": "2026-11-14",
   "en": [
    "Climate over the years: compare any period (the autumn rains season, summer, winter or your own months) with the same period in every year since 1950 for the chosen place: average temperature, total rain, rainy days, days of 45° or more and of 50° or more, and stormy days, with trend lines, a short summary and a table for each decade. Free data from the Open-Meteo archive (ERA5).",
    "The Insights panel keeps its scroll position."
   ],
   "ar": [
    "المناخ عبر السنين (Climate over the years): مقارنة أي فترة (موسم أمطار الخريف «السرايات»، أو الصيف، أو الشتاء، أو أشهر تختارها) بالفترة نفسها في كل عام منذ 1950 للمكان المختار: متوسط درجة الحرارة، ومجموع الأمطار، وعدد الأيام الممطرة، والأيام التي تبلغ فيها الحرارة 45° فأكثر و50° فأكثر، والأيام العاصفة، مع خطوط للاتجاه العام، وملخّص قصير، وجدول لكل عقد. والبيانات مجانية من أرشيف Open-Meteo (ERA5).",
    "تحتفظ لوحة المعلومات (Insights) بموضع التمرير."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.2.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording and plural forms corrected in the interface.",
    "Clearer spoken weather summary."
   ],
   "ar": [
    "تصحيح الصياغة العربية وصيغ الجمع في واجهة البرنامج.",
    "تحسين وضوح الملخّص الصوتي للطقس."
   ]
  },
  {
   "product": "website",
   "version": "1.16.0",
   "date": "2026-11-14",
   "en": [
    "Gulf Weather 1.2.0 added to Updates and to its page."
   ],
   "ar": [
    "أُضيف الإصدار 1.2.0 من Gulf Weather إلى التحديثات وإلى صفحته."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.2.0",
   "date": "2026-11-14",
   "en": [
    "New Insights panel: prayer times for the chosen place, today compared with yesterday, air quality with simple advice, sea and waves, and a camping (kashta) outlook for Al Salmi, Al Wafra, Al Abdali and Al Jahra.",
    "Rain radar on the map (the last two hours, animated).",
    "Favourite places (the star next to the city button).",
    "My location: a blue dot on the map and the nearest city’s weather.",
    "Spoken weather summary in Arabic or English.",
    "Alerts for your places: heavy rain, dust storms, extreme heat and strong wind."
   ],
   "ar": [
    "لوحة معلومات جديدة (Insights): مواقيت الصلاة للمكان المختار، ومقارنة طقس اليوم بطقس الأمس، وجودة الهواء مع نصائح مبسّطة، وحالة البحر والأمواج، وتوقّعات مناسبة للرحلات البرية (الكشتة) في السالمي والوفرة والعبدلي والجهراء.",
    "رادار الأمطار على الخريطة (آخر ساعتين بصورة متحركة).",
    "الأماكن المفضّلة (النجمة بجانب زر المدينة).",
    "خاصية My location: نقطة زرقاء على الخريطة مع طقس أقرب مدينة.",
    "ملخّص صوتي للطقس بالعربية أو الإنجليزية.",
    "تنبيهات خاصة بأماكنك: الأمطار الغزيرة، والعواصف الغبارية، والحرّ الشديد، والرياح القوية."
   ]
  },
  {
   "product": "website",
   "version": "1.15.0",
   "date": "2026-11-14",
   "en": [
    "New app: Noor, under Apps, with full details, guides and screenshots."
   ],
   "ar": [
    "برنامج جديد: Noor في قسم Apps (البرامج)، مع تفاصيله الكاملة وأدلّة استخدامه وصوره."
   ]
  },
  {
   "product": "Noor",
   "version": "1.0.1",
   "date": "2026-11-14",
   "en": [
    "First release for Windows and Mac: prayer times with the adhan, hadith reminders, the complete Holy Quran, adhkar, Qibla, tasbih and the Hijri date."
   ],
   "ar": [
    "الإصدار الأول لنظام Windows ولأجهزة Mac: مواقيت الصلاة مع الأذان، والتذكير بالأحاديث، والقرآن الكريم كاملًا، والأذكار، واتجاه القبلة، والمسبحة، والتاريخ الهجري."
   ]
  },
  {
   "product": "website",
   "version": "1.14.0",
   "date": "2026-11-14",
   "en": [
    "Gulf Weather 1.1.0: page updated with the Arab world coverage, the real map, Mac support and new screenshots."
   ],
   "ar": [
    "Gulf Weather 1.1.0: حُدِّثت صفحته بتغطية العالم العربي، والخريطة الحقيقية، ودعم أجهزة Mac، ولقطات شاشة جديدة."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.1.0",
   "date": "2026-11-14",
   "en": [
    "The whole Arab world: 47 cities in 21 countries.",
    "A real map underneath (street, satellite or dark), with deep zoom down to the streets. Needs internet.",
    "Kuwait panel with all 6 governorates plus Abdali, Al Salmi, Al Wafra and Nuwaiseeb, with their temperatures.",
    "More realistic weather: heavy rain, an animated sea, dust and thunder.",
    "Now also available for Mac (Apple Silicon and Intel)."
   ],
   "ar": [
    "تغطية العالم العربي كله: 47 مدينة في 21 دولة.",
    "خريطة حقيقية في الخلفية (الشوارع، أو صور الأقمار الصناعية، أو النمط الداكن)، مع إمكانية التكبير حتى مستوى الشوارع، وتحتاج إلى اتصال بالإنترنت.",
    "لوحة خاصة بالكويت تشمل المحافظات الست، إضافةً إلى العبدلي والسالمي والوفرة والنويصيب، مع درجات حرارتها.",
    "طقس أكثر واقعية: أمطار غزيرة، وبحر متحرك، وغبار، ورعد.",
    "أصبح متاحًا أيضًا لأجهزة Mac (بمعالجات Apple Silicon وIntel)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.11.0",
   "date": "2026-11-14",
   "en": [
    "Windows: Gulf Weather is now available under Apps."
   ],
   "ar": [
    "على Windows: أصبح Gulf Weather متاحًا في قسم Apps (البرامج)."
   ]
  },
  {
   "product": "website",
   "version": "1.13.0",
   "date": "2026-11-14",
   "en": [
    "New app: Gulf Weather, under Apps, with full details, guides and screenshots."
   ],
   "ar": [
    "برنامج جديد: Gulf Weather في قسم Apps (البرامج)، مع تفاصيله الكاملة وأدلّته وصوره."
   ]
  },
  {
   "product": "GulfWeather",
   "version": "1.0.0",
   "date": "2026-11-14",
   "en": [
    "First release: weather for Kuwait and the Gulf (15 cities in 6 countries) on an animated map and in a 3D scene, a 10-day forecast, and alerts for heat, dust and storms."
   ],
   "ar": [
    "الإصدار الأول: طقس الكويت ودول الخليج (15 مدينة في 6 دول) على خريطة متحركة وفي مشهد ثلاثي الأبعاد، مع توقّعات لعشرة أيام وتنبيهات للحرّ والغبار والعواصف."
   ]
  },
  {
   "product": "website",
   "version": "1.12.0",
   "date": "2026-11-14",
   "en": [
    "System Info: disk details and disk speed test added to its page; Updates: System Info 1.1.0."
   ],
   "ar": [
    "System Info: أُضيفت تفاصيل الأقراص واختبار سرعتها إلى صفحته، وأُضيف الإصدار 1.1.0 إلى التحديثات."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.1.0",
   "date": "2026-11-14",
   "en": [
    "Every disk now shows its brand and model, SSD or HDD, form factor, connection and the most it can carry, health, spin speed for hard disks, and which drives are on it.",
    "New Test speed button for each disk: measures real read and write speed in MB/s and shows what is normal for that kind of disk.",
    "Copy my specs now includes the disk details and the measured speed."
   ],
   "ar": [
    "أصبح كل قرص يُظهر علامته التجارية وطرازه، ونوعه (SSD أو HDD)، وشكله، وطريقة توصيله وأقصى سرعة يدعمها، وحالته الصحية، وسرعة دوران الأقراص الصلبة (HDD)، والأقسام الموجودة عليه.",
    "زر جديد باسم Test speed لكل قرص، يقيس سرعته الفعلية في القراءة والكتابة بالميغابايت في الثانية (MB/s)، ويُبيّن السرعة المعتادة لهذا النوع من الأقراص.",
    "أصبح Copy my specs يتضمّن تفاصيل الأقراص وسرعتها المقيسة."
   ]
  },
  {
   "product": "website",
   "version": "1.11.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher for Mac now runs on Intel Macs too; the Mac button, requirements and guide are updated.",
    "Updates: Kankon Launcher 2.10.0 added."
   ],
   "ar": [
    "أصبح Kankon Launcher لأجهزة Mac يعمل أيضًا على الأجهزة ذات معالجات Intel، وحُدِّث زر التنزيل والمتطلبات ودليل التثبيت تبعًا لذلك.",
    "التحديثات: أُضيف الإصدار 2.10.0 من Kankon Launcher."
   ]
  },
  {
   "product": "launcher",
   "version": "2.10.0",
   "date": "2026-11-14",
   "en": [
    "Mac: one app for every Mac, with Apple Silicon or Intel.",
    "New apps: System Info (Tools) and Network Tools (Networking).",
    "\"My Device\" card on the Home page.",
    "Checks for updates in the background and shows a notification when one is available.",
    "Send report button, to tell Kankon about a problem in a few clicks.",
    "Counts app installs anonymously (no personal data) to show which apps are used most."
   ],
   "ar": [
    "على أجهزة Mac: تطبيق واحد يعمل على جميع الأجهزة، بمعالجات Apple Silicon أو Intel.",
    "برنامجان جديدان: System Info في قسم Tools (الأدوات)، وNetwork Tools في قسم Networking (الشبكات).",
    "بطاقة My Device (جهازي) في الصفحة الرئيسية.",
    "يتحقّق من التحديثات في الخلفية، ويُظهر إشعارًا عند توفّر تحديث.",
    "زر Send report لإبلاغ Kankon بأي مشكلة ببضع نقرات.",
    "يُحصي عمليات تثبيت البرامج دون تحديد هوية المستخدم (أعداد فقط، دون أي بيانات شخصية)، لمعرفة أكثر البرامج استخدامًا."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.1.1",
   "date": "2026-11-14",
   "en": [
    "Fixed a problem that closed the app on Macs with Intel processors."
   ],
   "ar": [
    "إصلاح خلل كان يؤدي إلى إغلاق البرنامج على أجهزة Mac ذات معالجات Intel."
   ]
  },
  {
   "product": "website",
   "version": "1.10.0",
   "date": "2026-11-14",
   "en": [
    "New app: System Info, under Tools, with full details and guides."
   ],
   "ar": [
    "برنامج جديد: System Info في قسم Tools (الأدوات)، مع تفاصيله الكاملة وأدلّته."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.0.0",
   "date": "2026-11-14",
   "en": [
    "First release for Windows and Mac: processor, graphics card and video memory, RAM, storage, screen, operating system, battery and computer model on one page, with Copy my specs and Save as file."
   ],
   "ar": [
    "الإصدار الأول لنظام Windows ولأجهزة Mac: المعالج، وبطاقة الرسوميات وذاكرتها، والذاكرة (RAM)، والتخزين، والشاشة، ونظام التشغيل، والبطارية، وطراز الجهاز في صفحة واحدة، مع زرّي Copy my specs وSave as file."
   ]
  },
  {
   "product": "website",
   "version": "1.9.3",
   "date": "2026-11-14",
   "en": [
    "Updates: Auto Create IP Config for Mac 1.1.0 added."
   ],
   "ar": [
    "التحديثات: أُضيف الإصدار 1.1.0 من Auto Create IP Config لأجهزة Mac."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.1.0",
   "date": "2026-11-14",
   "en": [
    "The Mac version is now one app for every Mac, with Apple Silicon (M1 and newer) or Intel.",
    "English by default, with an Arabic button, as on Windows."
   ],
   "ar": [
    "أصبحت نسخة Mac تطبيقًا واحدًا يعمل على جميع أجهزة Mac، سواء أكانت بمعالجات Apple Silicon (M1 أو أحدث) أم Intel.",
    "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية، كما في نسخة Windows."
   ]
  },
  {
   "product": "website",
   "version": "1.9.1",
   "date": "2026-11-14",
   "en": [
    "Network Tools: updated Arabic screenshots."
   ],
   "ar": [
    "Network Tools: تحديث لقطات الشاشة العربية."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.0.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording of the interface refined."
   ],
   "ar": [
    "تحسين الصياغة العربية في واجهة البرنامج."
   ]
  },
  {
   "product": "website",
   "version": "1.9.0",
   "date": "2026-11-14",
   "en": [
    "New app: Network Tools, under Networking, with full details, guides and screenshots."
   ],
   "ar": [
    "برنامج جديد: Network Tools في قسم Networking (الشبكات)، مع تفاصيله الكاملة وأدلّته وصوره."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.0.0",
   "date": "2026-11-14",
   "en": [
    "First release: Overview, Speed Test, Ping with live chart, Traceroute, DNS lookup and DNS benchmark, Port Check with presets, and Subnet Calculator."
   ],
   "ar": [
    "الإصدار الأول: نظرة عامة، واختبار السرعة، وPing مع رسم بياني مباشر، وتتبّع المسار، واستعلام DNS ومقارنة خوادمه، وفحص المنافذ بقوائم جاهزة، وحاسبة الشبكات الفرعية."
   ]
  },
  {
   "product": "website",
   "version": "1.8.0",
   "date": "2026-11-14",
   "en": [
    "Anonymous download counting for Windows and Mac (counts only, no personal data)."
   ],
   "ar": [
    "إحصاء عدد مرات التنزيل لنظام Windows ولأجهزة Mac دون تحديد هوية الزائر (أعداد فقط، دون أي بيانات شخصية)."
   ]
  },
  {
   "product": "website",
   "version": "1.7.4",
   "date": "2026-11-14",
   "en": [
    "Updates: Kankon Launcher 2.5 and 2.6 (the Mac version) added."
   ],
   "ar": [
    "التحديثات: أُضيف الإصداران 2.5 و2.6 من Kankon Launcher (نسخة Mac)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.6.0",
   "date": "2026-11-14",
   "en": [
    "Mac: Network Monitor is now available under Networking."
   ],
   "ar": [
    "على أجهزة Mac: أصبح Network Monitor متاحًا في قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.5.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher is now available for Mac (Apple Silicon), with its own download button on this site.",
    "Mac (2.5.1): Auto Create IP Config is available under Networking."
   ],
   "ar": [
    "أصبح Kankon Launcher متاحًا لأجهزة Mac (بمعالجات Apple Silicon)، وله زر تنزيل خاص في هذا الموقع.",
    "على أجهزة Mac (الإصدار 2.5.1): أصبح Auto Create IP Config متاحًا في قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "website",
   "version": "1.7.3",
   "date": "2026-11-14",
   "en": [
    "Network Monitor requirements for Mac added; Arabic wording refined."
   ],
   "ar": [
    "أُضيفت متطلبات Network Monitor على أجهزة Mac، وحُسِّنت الصياغة العربية."
   ]
  },
  {
   "product": "website",
   "version": "1.7.2",
   "date": "2026-11-14",
   "en": [
    "Network Monitor is now marked as available for Windows and Mac."
   ],
   "ar": [
    "أصبحت صفحة Network Monitor تُبيّن توفّره لنظام Windows ولأجهزة Mac."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.2.0",
   "date": "2026-11-14",
   "en": [
    "Now also available for Mac (Apple Silicon and Intel, macOS 12 or newer), with the same features as on Windows.",
    "On the Mac, Setup > Startup offers \"Start when I log in\" instead of \"Start with Windows\"."
   ],
   "ar": [
    "أصبح متاحًا أيضًا لأجهزة Mac (بمعالجات Apple Silicon وIntel، بنظام macOS 12 أو أحدث)، بالمزايا نفسها المتوفّرة على Windows.",
    "على أجهزة Mac، تعرض صفحة Setup > Startup خيار «Start when I log in» بدلًا من «Start with Windows»."
   ]
  },
  {
   "product": "website",
   "version": "1.7.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording refined."
   ],
   "ar": [
    "تحسين الصياغة العربية."
   ]
  },
  {
   "product": "website",
   "version": "1.7.0",
   "date": "2026-11-14",
   "en": [
    "Separate download buttons for Windows and Mac, each with its logo; the button for your own system is highlighted.",
    "Every app page shows which systems it runs on (Windows, Mac)."
   ],
   "ar": [
    "زرّا تنزيل منفصلان لنظام Windows ولأجهزة Mac، يحمل كلٌّ منهما شعاره، ويُبرَز الزر الخاص بنظام جهازك.",
    "تُبيّن صفحة كل برنامج الأنظمة التي يعمل عليها (Windows وMac)."
   ]
  },
  {
   "product": "website",
   "version": "1.6.1",
   "date": "2026-11-14",
   "en": [
    "Wording of the Mac section and requirements refined."
   ],
   "ar": [
    "تحسين صياغة قسم Mac والمتطلبات."
   ]
  },
  {
   "product": "website",
   "version": "1.6.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher for Mac: a new download button, always pointing to the latest Mac version, and an installation guide for Mac."
   ],
   "ar": [
    "Kankon Launcher لأجهزة Mac: زر تنزيل جديد يشير دائمًا إلى أحدث إصدار لأجهزة Mac، مع دليل لتثبيته عليها."
   ]
  },
  {
   "product": "website",
   "version": "1.5.1",
   "date": "2026-11-14",
   "en": [
    "Wording of the installation guide refined."
   ],
   "ar": [
    "تحسين صياغة دليل التثبيت."
   ]
  },
  {
   "product": "website",
   "version": "1.5.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher is now downloaded as a zip file (AppsLauncher-Setup.zip), which avoids the browser warning; the installation guide is updated accordingly.",
    "Updates: Kankon Launcher 2.4.0 added."
   ],
   "ar": [
    "أصبح Kankon Launcher يُنزَّل في ملف مضغوط (AppsLauncher-Setup.zip) تفاديًا لتحذير المتصفّح، وحُدِّث دليل التثبيت وفقًا لذلك.",
    "التحديثات: أُضيف الإصدار 2.4.0 من Kankon Launcher."
   ]
  },
  {
   "product": "launcher",
   "version": "2.4.0",
   "date": "2026-11-14",
   "en": [
    "New Home page: a welcome banner, stat cards, quick access to your apps, section cards and a tip of the day.",
    "A more modern design throughout the window.",
    "New kankon.net button in the side menu."
   ],
   "ar": [
    "صفحة رئيسية جديدة تضمّ: لافتة ترحيب، وبطاقات إحصائية، ووصولًا سريعًا إلى برامجك، وبطاقات للأقسام، ونصيحة اليوم.",
    "تصميم أحدث في أرجاء النافذة كلّها.",
    "زر جديد باسم kankon.net في القائمة الجانبية."
   ]
  },
  {
   "product": "website",
   "version": "1.4.0",
   "date": "2026-11-14",
   "en": [
    "Games: a new list of the best MMORPG, Action RPG and Strategy games, with official links.",
    "The site now updates itself on the server within minutes of each new version."
   ],
   "ar": [
    "الألعاب: قائمة جديدة بأفضل ألعاب الأدوار الجماعية، والأدوار والحركة، والاستراتيجية، مع روابطها الرسمية.",
    "أصبح الموقع يُحدَّث تلقائيًا على الخادم خلال دقائق من صدور كل إصدار جديد."
   ]
  },
  {
   "product": "website",
   "version": "1.3.0",
   "date": "2026-11-14",
   "en": [
    "New AI section: the most important AI programs with official links and a short description of each.",
    "kankon.net is now online."
   ],
   "ar": [
    "قسم جديد للذكاء الاصطناعي: أهم برامج الذكاء الاصطناعي مع روابطها الرسمية ووصف موجز لكل منها.",
    "أصبح موقع kankon.net متاحًا على الإنترنت."
   ]
  },
  {
   "product": "launcher",
   "version": "2.1.0",
   "date": "2026-11-13",
   "en": [
    "New name: Kankon Launcher (window, side menu, setup and shortcuts). Your existing install updates as usual.",
    "A \"by Kankon · kankon.net\" line in the footer and in every app's Details page."
   ],
   "ar": [
    "الاسم الجديد: Kankon Launcher (في النافذة والقائمة الجانبية وملف التثبيت والاختصارات)، ويستمر التحديث التلقائي للنسخ المثبّتة كالمعتاد.",
    "سطر «من Kankon · kankon.net» في أسفل النافذة وفي صفحة تفاصيل كل برنامج."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.1.0",
   "date": "2026-11-13",
   "en": [
    "Find the switch: Setup can now look for managed switches on the network.",
    "Daily usage limit per device, with an alert and a phone notice when it is passed.",
    "Internet outages: checked every 15 seconds and logged with their duration, with an alert when the connection is back.",
    "Weekly summary every Friday (top devices, home internet, outages), with a \"Send one now\" button.",
    "\"by Kankon · kankon.net\" in the window footer and Setup."
   ],
   "ar": [
    "البحث عن المحوّل: أصبح بإمكان صفحة الإعدادات البحث عن المحوّلات المُدارة في الشبكة.",
    "حد يومي للاستهلاك لكل جهاز، مع تنبيه وإشعار على الهاتف عند تجاوزه.",
    "انقطاعات الإنترنت: فحص كل 15 ثانية وتسجيل كل انقطاع ومدته، مع تنبيه عند عودة الاتصال.",
    "ملخص أسبوعي كل يوم جمعة (أكثر الأجهزة استهلاكًا، والإنترنت المنزلي، والانقطاعات)، مع زر «إرسال الآن».",
    "سطر «من Kankon · kankon.net» أسفل النافذة وفي الإعدادات."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.6.0",
   "date": "2026-11-13",
   "en": [
    "\"by Kankon · kankon.net\" line at the bottom of the window.",
    "Improved Arabic wording across the app."
   ],
   "ar": [
    "سطر «من Kankon · kankon.net» أسفل النافذة.",
    "تحسين الصياغة العربية في البرنامج كله."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.2.0",
   "date": "2026-11-13",
   "en": [
    "\"by Kankon · kankon.net\" line at the bottom of the window; clicking it opens kankon.net."
   ],
   "ar": [
    "سطر «من Kankon · kankon.net» أسفل النافذة، ويفتح الموقع عند النقر عليه."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.7",
   "date": "2026-11-13",
   "en": [
    "Network Monitor added under Networking."
   ],
   "ar": [
    "إضافة Network Monitor إلى قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.3",
   "date": "2026-11-13",
   "en": [
    "Setup warns when the switch address typed is this PC instead of the switch."
   ],
   "ar": [
    "تنبيه في الإعدادات عند إدخال عنوان هذا الجهاز بدلًا من عنوان المحوّل."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.2",
   "date": "2026-11-13",
   "en": [
    "Setup shows which address to allow in the switch's SNMP settings, so the app works from any PC."
   ],
   "ar": [
    "تعرض الإعدادات العنوان الواجب السماح له في إعدادات SNMP بالمحوّل، ليعمل البرنامج من أي جهاز."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.1",
   "date": "2026-11-13",
   "en": [
    "Setup shows \"Connecting…\" during the first switch reading, and the reason when it fails.",
    "Improved Arabic wording."
   ],
   "ar": [
    "تعرض الإعدادات عبارة «جارٍ الاتصال…» أثناء القراءة الأولى من المحوّل، وسبب الفشل إن حدث.",
    "تحسين الصياغة العربية."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.0",
   "date": "2026-11-13",
   "en": [
    "Network Monitor is now an installed Windows app that opens from Kankon Launcher (Networking), in its own window.",
    "Everything it needs is built in: nothing else to install.",
    "New Setup page: Router, Switch, Phone alerts, Password and Start with Windows.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "أصبح Network Monitor برنامجًا مثبّتًا على Windows يُفتح من Kankon Launcher (قسم Networking «الشبكات») في نافذة مستقلة.",
    "كل ما يحتاجه مدمج فيه، فلا حاجة إلى تثبيت أي شيء آخر.",
    "صفحة إعدادات جديدة: جهاز التوجيه، والمحوّل، وتنبيهات الهاتف، وكلمة المرور، والتشغيل مع Windows.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتبديل إلى العربية."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.6",
   "date": "2026-11-13",
   "en": [
    "New game: Dana (Games). Install downloads the Dana Launcher, checks it and installs it; Update appears when a newer one is out."
   ],
   "ar": [
    "لعبة جديدة: «الدانة» في قسم Games (الألعاب). يُنزّل زر Install برنامج Dana Launcher ويتحقق منه ثم يثبّته، ويظهر زر Update عند صدور إصدار أحدث."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.5",
   "date": "2026-11-13",
   "en": [
    "Translation improvements in the launcher."
   ],
   "ar": [
    "تحسين الترجمة العربية في واجهة المشغّل."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.5.2",
   "date": "2026-11-13",
   "en": [
    "On Wi-Fi, the network name is suggested as the name of a new saved profile."
   ],
   "ar": [
    "عند الاتصال بشبكة Wi-Fi، يُقترح اسم الشبكة اسمًا للإعداد المحفوظ الجديد."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.1.2",
   "date": "2026-11-13",
   "en": [
    "Arabic wording aligned with the other Kankon apps."
   ],
   "ar": [
    "توحيد الصياغة العربية مع برامج Kankon الأخرى."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.1.1",
   "date": "2026-11-13",
   "en": [
    "Hide drivers you do not want, with a button to show them again.",
    "Automatic backup of the current drivers before installing updates.",
    "Keeps only the last 3 backups of this PC.",
    "Fix: the app now opens correctly from the launcher."
   ],
   "ar": [
    "إخفاء التعريفات غير المرغوب فيها، مع زر لإظهارها مجددًا.",
    "نسخ احتياطي تلقائي للتعريفات الحالية قبل تثبيت التحديثات.",
    "الاحتفاظ بآخر 3 نسخ احتياطية فقط لهذا الجهاز.",
    "إصلاح: أصبح البرنامج يُفتح من المشغّل بشكل صحيح."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.4",
   "date": "2026-11-13",
   "en": [
    "Every app has a Details page with a full description in English and Arabic."
   ],
   "ar": [
    "صفحة تفاصيل لكل برنامج، تتضمن وصفًا كاملًا بالعربية والإنجليزية."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.5.0",
   "date": "2026-11-13",
   "en": [
    "Saves the previous settings and reverts automatically if the gateway does not reply.",
    "Connection test after every change, quick DNS buttons and Copy settings.",
    "Export and import of saved profiles."
   ],
   "ar": [
    "حفظ الإعدادات السابقة والعودة إليها تلقائيًا إذا لم تستجب البوابة.",
    "اختبار للاتصال بعد كل تغيير، وأزرار DNS سريعة، وزر لنسخ الإعدادات.",
    "تصدير الإعدادات المحفوظة واستيرادها."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.0.0",
   "date": "2026-11-13",
   "en": [
    "First release as an installed app in Kankon Launcher (Tools).",
    "Backup & Restore as the main screen, restore straight from a ZIP file.",
    "Driver updates from Windows Update with a restore point, installed drivers list with CSV export.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "الإصدار الأول برنامجًا مثبّتًا ضمن Kankon Launcher (قسم Tools «الأدوات»).",
    "النسخ الاحتياطي والاستعادة في الشاشة الرئيسية، مع الاستعادة مباشرة من ملف ZIP.",
    "تحديث التعريفات من Windows Update مع نقطة استعادة، وقائمة التعريفات المثبّتة مع التصدير إلى CSV.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتبديل إلى العربية."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.4.0",
   "date": "2026-11-13",
   "en": [
    "Network scan: free and used IP addresses with device names, and the closest free address picked for you."
   ],
   "ar": [
    "فحص الشبكة: العناوين المتاحة والمستخدمة مع أسماء الأجهزة، واقتراح أقرب عنوان متاح."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.3",
   "date": "2026-11-13",
   "en": [
    "Driver Manager added under Tools.",
    "Fix for the side menu colours."
   ],
   "ar": [
    "إضافة Driver Manager إلى قسم Tools (الأدوات).",
    "إصلاح ألوان القائمة الجانبية."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.2",
   "date": "2026-11-13",
   "en": [
    "New side menu with Apps, Games, Tools and Networking.",
    "Auto Create IP Config built in under Networking.",
    "New launcher icon."
   ],
   "ar": [
    "قائمة جانبية جديدة تضم: البرامج، والألعاب، والأدوات، والشبكات.",
    "دمج Auto Create IP Config في قسم Networking (الشبكات).",
    "أيقونة جديدة للمشغّل."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.0",
   "date": "2026-11-13",
   "en": [
    "A new desktop app with a small setup file, Start menu and desktop shortcuts, and an uninstaller.",
    "Updates itself and installs and updates your apps, with every file verified first.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "برنامج سطح مكتب جديد بملف تثبيت صغير، مع اختصارات في قائمة «ابدأ» وعلى سطح المكتب، وأداة لإزالة التثبيت.",
    "يحدّث نفسه ويثبّت برامجك ويحدّثها، مع التحقق من كل ملف قبل تثبيته.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتبديل إلى العربية."
   ]
  }
 ],
 "ai": [
  {
   "id": "chatgpt",
   "name": "ChatGPT",
   "by": "OpenAI",
   "color": "#10a37f",
   "url": "https://chatgpt.com",
   "dl": "https://openai.com/chatgpt/download/",
   "en": "The best-known AI assistant. Ask questions, write and improve texts, translate, summarize files and create images. Has a Windows app.",
   "ar": "أشهر مساعد ذكاء اصطناعي؛ يجيب عن الأسئلة، ويكتب النصوص ويحسّنها، ويترجم، ويلخّص الملفات، وينشئ الصور. ويتوفّر له تطبيق لنظام Windows."
  },
  {
   "id": "claude",
   "name": "Claude",
   "by": "Anthropic",
   "color": "#d97757",
   "url": "https://claude.ai",
   "dl": "https://claude.ai/download",
   "en": "A careful assistant for writing, analysis and programming. Reads long documents and helps with code. Has a Windows app.",
   "ar": "مساعد دقيق في الكتابة والتحليل والبرمجة، يقرأ المستندات الطويلة ويلخّصها ويحلّلها. ويتوفّر له تطبيق لنظام Windows."
  },
  {
   "id": "gemini",
   "name": "Gemini",
   "by": "Google",
   "color": "#4285f4",
   "url": "https://gemini.google.com",
   "en": "Google's AI assistant, connected to Google search, Gmail, Drive and YouTube. Works in the browser.",
   "ar": "مساعد Google للذكاء الاصطناعي، يرتبط بمحرّك بحث Google وبخدمات Gmail وDrive وYouTube، ويعمل من المتصفح."
  },
  {
   "id": "copilot",
   "name": "Microsoft Copilot",
   "by": "Microsoft",
   "color": "#2b88d8",
   "url": "https://copilot.microsoft.com",
   "en": "Microsoft's AI assistant, built into Windows 11, Edge and Microsoft 365 (Word, Excel, Outlook).",
   "ar": "مساعد Microsoft للذكاء الاصطناعي، مدمج في Windows 11 ومتصفح Edge وتطبيقات Microsoft 365 (Word وExcel وOutlook)."
  },
  {
   "id": "perplexity",
   "name": "Perplexity",
   "by": "Perplexity AI",
   "color": "#20808d",
   "url": "https://www.perplexity.ai",
   "en": "An AI search engine: ask anything and get a short answer with links to its sources.",
   "ar": "محرّك بحث بالذكاء الاصطناعي: اطرح أي سؤال، واحصل على إجابة موجزة مع روابط مصادرها."
  },
  {
   "id": "githubcopilot",
   "name": "GitHub Copilot",
   "by": "GitHub",
   "color": "#8957e5",
   "url": "https://github.com/features/copilot",
   "en": "An AI helper for programmers inside Visual Studio and VS Code: suggests code, explains it and fixes errors.",
   "ar": "مساعد للمبرمجين داخل Visual Studio وVS Code؛ يقترح الشيفرة البرمجية ويشرحها ويصلح أخطاءها."
  },
  {
   "id": "ollama",
   "name": "Ollama",
   "by": "Ollama",
   "color": "#9ca3af",
   "url": "https://ollama.com",
   "dl": "https://ollama.com/download",
   "en": "Run open AI models (such as Llama and Gemma) on your own PC, without internet and without sending your data anywhere.",
   "ar": "يشغّل نماذج الذكاء الاصطناعي المفتوحة (مثل Llama وGemma) على جهازك، دون اتصال بالإنترنت ودون إرسال بياناتك إلى أي جهة."
  },
  {
   "id": "lmstudio",
   "name": "LM Studio",
   "by": "LM Studio",
   "color": "#6366f1",
   "url": "https://lmstudio.ai",
   "dl": "https://lmstudio.ai",
   "en": "An easy desktop app to download and chat with open AI models on your PC, fully offline.",
   "ar": "تطبيق سهل لسطح المكتب لتنزيل نماذج الذكاء الاصطناعي المفتوحة والمحادثة معها على جهازك، دون الحاجة إلى الإنترنت."
  }
 ],
 "gameGroups": [
  {
   "id": "mmo",
   "en": "MMORPG",
   "ar": "ألعاب الأدوار الجماعية (MMORPG)"
  },
  {
   "id": "arpg",
   "en": "Action RPG",
   "ar": "ألعاب الأدوار والحركة (Action RPG)"
  },
  {
   "id": "strategy",
   "en": "Strategy",
   "ar": "ألعاب الاستراتيجية (Strategy)"
  }
 ],
 "games": [
  {
   "group": "mmo",
   "name": "World of Warcraft",
   "by": "Blizzard",
   "color": "#f8b700",
   "url": "https://worldofwarcraft.blizzard.com",
   "free": false,
   "en": "The most famous MMORPG: a huge fantasy world, raids, dungeons and battles between the Alliance and the Horde.",
   "ar": "أشهر لعبة أدوار جماعية: عالم خيالي ضخم، وغارات وزنزانات، ومعارك بين التحالف (Alliance) والحشد (Horde).",
   "mono": "WoW"
  },
  {
   "group": "mmo",
   "name": "Final Fantasy XIV",
   "by": "Square Enix",
   "color": "#3b6fd8",
   "url": "https://www.finalfantasyxiv.com",
   "free": false,
   "en": "A story-rich MMORPG with a large, friendly community. The free trial covers a big part of the game.",
   "ar": "لعبة أدوار جماعية غنية بالقصة، ومجتمعها كبير وودود، وتغطي النسخة التجريبية المجانية جزءًا كبيرًا منها.",
   "mono": "FF"
  },
  {
   "group": "mmo",
   "name": "Guild Wars 2",
   "by": "ArenaNet",
   "color": "#c0392b",
   "url": "https://www.guildwars2.com",
   "free": true,
   "en": "Fast action combat and big world events, with no monthly fee. The core game is free.",
   "ar": "قتال سريع وأحداث جماعية كبيرة في العالم، دون اشتراك شهري، واللعبة الأساسية مجانية.",
   "mono": "GW2"
  },
  {
   "group": "mmo",
   "name": "Black Desert",
   "by": "Pearl Abyss",
   "color": "#8e44ad",
   "url": "https://www.playblackdesert.com",
   "free": false,
   "en": "Beautiful graphics and fast action combat, with trading, crafting and sailing.",
   "ar": "رسوميات جميلة وقتال حركي سريع، مع التجارة والحِرف والإبحار.",
   "mono": "BD"
  },
  {
   "group": "mmo",
   "name": "The Elder Scrolls Online",
   "by": "ZeniMax Online",
   "color": "#b08d57",
   "url": "https://www.elderscrollsonline.com",
   "free": false,
   "en": "Explore the world of Skyrim and Tamriel with friends, with a full story for solo players too.",
   "ar": "استكشف عالم Skyrim وTamriel مع أصدقائك، مع قصة كاملة لمن يفضّل اللعب منفردًا.",
   "mono": "ESO"
  },
  {
   "group": "mmo",
   "name": "ArcheAge Chronicles",
   "by": "XLGAMES",
   "color": "#c58b2a",
   "url": "https://store.steampowered.com/search/?term=ArcheAge%20Chronicles",
   "free": false,
   "mono": "AC",
   "en": "The new ArcheAge, rebuilt in Unreal Engine 5: a fantasy MMORPG with open-world exploration, four classes and many weapons. On PC through Steam Early Access since November 2026.",
   "ar": "الجزء الجديد من ArcheAge، أُعيد بناؤه بمحرّك Unreal Engine 5: لعبة أدوار جماعية خيالية تقوم على استكشاف عالم مفتوح، وفيها أربع فئات وأسلحة متعدّدة. متاحة على الحاسوب عبر الوصول المبكر في Steam منذ نوفمبر 2026."
  },
  {
   "group": "mmo",
   "name": "AION 2",
   "by": "NCSOFT",
   "color": "#7c5cff",
   "url": "https://store.steampowered.com/search/?term=AION%202",
   "free": true,
   "mono": "A2",
   "en": "The sequel to the classic AION, made in Unreal Engine 5: winged flight, a large fantasy world and battles between two factions. The global PC version comes through Steam.",
   "ar": "الجزء الثاني من لعبة AION الشهيرة، مصنوع بمحرّك Unreal Engine 5: طيران بالأجنحة، وعالم خيالي واسع، ومعارك بين فصيلين. وتصدر النسخة العالمية للحاسوب عبر Steam."
  },
  {
   "group": "mmo",
   "name": "Silkroad Online",
   "by": "Joymax",
   "color": "#d9a441",
   "url": "https://www.joymax.com",
   "free": true,
   "mono": "SR",
   "en": "A classic free MMORPG set on the old Silk Road between China, Central Asia and Europe, famous for its trader, hunter and thief jobs that guard or raid trade caravans.",
   "ar": "لعبة أدوار جماعية مجانية عريقة، تدور أحداثها على طريق الحرير القديم بين الصين وآسيا الوسطى وأوروبا، وتشتهر بمهن التاجر والصيّاد واللص التي تحمي قوافل التجارة أو تُغير عليها."
  },
  {
   "group": "arpg",
   "name": "Path of Exile 2",
   "by": "Grinding Gear Games",
   "color": "#c9a227",
   "url": "https://pathofexile2.com",
   "free": true,
   "en": "Dark action RPG with deep character builds and endless loot. Free to play.",
   "ar": "لعبة أدوار وحركة ذات أجواء قاتمة، تتيح بناء الشخصيات بعمق، وغنائمها لا تنتهي، وهي مجانية.",
   "mono": "PoE"
  },
  {
   "group": "arpg",
   "name": "Diablo IV",
   "by": "Blizzard",
   "color": "#a31515",
   "url": "https://diablo4.blizzard.com",
   "free": false,
   "en": "Fight the forces of hell alone or with friends in a dark open world.",
   "ar": "قاتل قوى الجحيم وحدك أو مع أصدقائك في عالم مفتوح مظلم.",
   "mono": "D4"
  },
  {
   "group": "arpg",
   "name": "Elden Ring",
   "by": "FromSoftware",
   "color": "#c8a951",
   "url": "https://en.bandainamcoent.eu/elden-ring",
   "free": false,
   "en": "A challenging open world full of secrets, huge bosses and freedom to explore.",
   "ar": "عالم مفتوح مليء بالتحدي والأسرار والزعماء العمالقة، مع حرية كاملة في الاستكشاف.",
   "mono": "ER"
  },
  {
   "group": "arpg",
   "name": "Monster Hunter Wilds",
   "by": "Capcom",
   "color": "#2e8b57",
   "url": "https://www.monsterhunter.com/wilds/",
   "free": false,
   "en": "Hunt giant monsters alone or with up to three friends, and craft gear from what you hunt.",
   "ar": "اصطد وحوشًا عملاقة وحدك أو مع ما يصل إلى ثلاثة أصدقاء، واصنع عتادك مما تصطاده.",
   "mono": "MH"
  },
  {
   "group": "arpg",
   "name": "Genshin Impact",
   "by": "HoYoverse",
   "color": "#4fa3e0",
   "url": "https://genshin.hoyoverse.com",
   "free": true,
   "en": "A colorful open world with elemental combat and many characters. Free to play.",
   "ar": "عالم مفتوح ملوّن، وقتال يعتمد على العناصر، وشخصيات كثيرة، وهي مجانية.",
   "mono": "GI"
  },
  {
   "group": "strategy",
   "name": "Age of Empires IV",
   "by": "Microsoft",
   "color": "#c97c2b",
   "url": "https://www.ageofempires.com",
   "free": false,
   "en": "Classic real-time strategy: build your empire, gather resources and lead armies through history.",
   "ar": "استراتيجية كلاسيكية في الوقت الحقيقي: ابنِ إمبراطوريتك، واجمع الموارد، وقُد الجيوش عبر التاريخ.",
   "mono": "AoE"
  },
  {
   "group": "strategy",
   "name": "Civilization VII",
   "by": "Firaxis / 2K",
   "color": "#2c6e9b",
   "url": "https://civilization.2k.com",
   "free": false,
   "en": "Turn-based strategy: guide a civilization from the first city to the modern age.",
   "ar": "استراتيجية بنظام الأدوار: قُد حضارة من أول مدينة حتى العصر الحديث.",
   "mono": "Civ"
  },
  {
   "group": "strategy",
   "name": "StarCraft II",
   "by": "Blizzard",
   "color": "#1f6fd1",
   "url": "https://starcraft2.blizzard.com",
   "free": true,
   "en": "Fast competitive sci-fi strategy. The multiplayer and first campaign are free.",
   "ar": "استراتيجية خيال علمي سريعة وتنافسية، واللعب الجماعي والحملة الأولى مجانيان.",
   "mono": "SC2"
  },
  {
   "group": "strategy",
   "name": "Total War: Warhammer III",
   "by": "Creative Assembly",
   "color": "#8b1e1e",
   "url": "https://www.totalwar.com",
   "free": false,
   "en": "Huge real-time battles with fantasy armies, plus a turn-based campaign map.",
   "ar": "معارك ضخمة في الوقت الحقيقي بجيوش خيالية، مع خريطة حملة بنظام الأدوار.",
   "mono": "TW"
  },
  {
   "group": "strategy",
   "name": "Age of Empires II: Definitive Edition",
   "by": "Microsoft",
   "color": "#a0522d",
   "url": "https://www.ageofempires.com",
   "free": false,
   "en": "The legendary medieval strategy game, remastered with new graphics and online play.",
   "ar": "لعبة الاستراتيجية الأسطورية في العصور الوسطى، بنسخة محسّنة ورسوميات جديدة ولعب عبر الإنترنت.",
   "mono": "AoE2"
  }
 ],
 "help": {
  "launcher": {
   "version": "2.21.0"
  },
  "NetworkMonitor": {
   "version": "1.6.14"
  },
  "SystemInfo": {
   "version": "1.4.2"
  },
  "Noor": {
   "version": "1.1.0"
  },
  "AutoIpConfig": {
   "version": "1.9.0"
  },
  "KankonMarkets": {
   "version": "1.5.0"
  },
  "DriverManager": {
   "version": "1.5.0"
  },
  "NetworkTools": {
   "version": "1.2.8"
  },
  "SizeFinder": {
   "version": "1.4.2"
  },
  "GulfWeather": {
   "version": "1.17.3"
  },
  "ForceUninstaller": {
   "version": "1.0.6"
  },
  "GameRater": {
   "version": "1.0.2"
  },
  "FileRecovery": {
   "version": "1.1.1"
  },
  "KankonPhotoAI": {
   "version": "1.0.0"
  }
 },
 "legal": {
  "updated": "2026-11-20",
  "contact": "admin@kankon.net",
  "terms": [
   {
    "h": {
     "en": "Who we are",
     "ar": "من نحن"
    },
    "p": [
     {
      "en": "Kankon Launcher, the Kankon apps and the website kankon.net are made by Kankon in the State of Kuwait. By downloading, installing or using any of them, you agree to these terms. If you do not agree, do not use them.",
      "ar": "يُطوِّر Kankon في دولة الكويت برنامجَ Kankon Launcher وبرامجَ Kankon وموقعَ kankon.net. وبتنزيلك أيًّا منها أو تثبيته أو استخدامه فإنك توافق على هذه الشروط، فإن لم توافق عليها فلا تستخدمها."
     }
    ]
   },
   {
    "h": {
     "en": "Free to use",
     "ar": "الاستخدام مجاني"
    },
    "p": [
     {
      "en": "All Kankon apps on this site are free. There are no accounts, no ads and no in-app payments. iReport AI and the game Dana have their own terms on their store pages and websites.",
      "ar": "جميع برامج Kankon في هذا الموقع مجانية، فلا حسابات ولا إعلانات ولا مدفوعات داخل البرامج. أما iReport AI ولعبة Dana فلكلٍّ منهما شروطه الخاصة في صفحات المتاجر وفي موقعه."
     }
    ]
   },
   {
    "h": {
     "en": "Provided \"as is\"",
     "ar": "تُقدَّم البرامج «كما هي»"
    },
    "p": [
     {
      "en": "The apps and this website are provided \"as is\" and \"as available\", without any warranty, express or implied, including any warranty that they are accurate, error-free, uninterrupted or fit for a particular purpose.",
      "ar": "تُقدَّم البرامج وهذا الموقع «كما هي» و«حسب توفّرها»، دون أي ضمان صريح أو ضمني، بما في ذلك أي ضمان بدقتها أو خلوّها من الأخطاء أو استمرار عملها دون انقطاع أو ملاءمتها لغرض معيّن."
     }
    ]
   },
   {
    "h": {
     "en": "No liability",
     "ar": "حدود المسؤولية"
    },
    "p": [
     {
      "en": "To the fullest extent the law allows, Kankon is not liable for any damage or loss that comes from using the apps or from not being able to use them. This includes data loss, damage to devices or systems, network problems, lost time or lost profit.",
      "ar": "إلى أقصى حدّ يسمح به القانون، لا يتحمّل Kankon أي مسؤولية عن أي ضرر أو خسارة تنتج عن استخدام البرامج أو عن تعذّر استخدامها، ويشمل ذلك فقدان البيانات، والأضرار التي تلحق بالأجهزة أو الأنظمة، ومشكلات الشبكة، وضياع الوقت أو الأرباح."
     },
     {
      "en": "Some apps change your computer: Driver Manager installs drivers, Force Uninstaller removes programs and files, Auto IP Config changes network settings, and Network Monitor can limit speeds on a managed switch. Back up your data and make sure you understand an action before you confirm it.",
      "ar": "تُجري بعض البرامج تغييرات على حاسوبك: فبرنامج Driver Manager يثبّت التعريفات، وForce Uninstaller يحذف البرامج والملفات، وAuto IP Config يغيّر إعدادات الشبكة، ويستطيع Network Monitor تحديد السرعات في المحوّل المُدار. لذا احتفظ بنسخة احتياطية من بياناتك، وتأكّد من فهمك لأي إجراء قبل تأكيده."
     }
    ]
   },
   {
    "h": {
     "en": "Lawful use of the network tools",
     "ar": "الاستخدام المشروع لأدوات الشبكات"
    },
    "p": [
     {
      "en": "Use Network Monitor, Network Tools and Auto IP Config only on networks and devices that you own, or that you manage with the owner's permission. Scanning, monitoring, limiting or accessing other people's networks or devices without permission can be a crime under Kuwait Law No. 63 of 2015 on Combating Information Technology Crimes, and under similar laws in other countries. You alone are responsible for how you use these tools.",
      "ar": "لا تستخدم Network Monitor وNetwork Tools وAuto IP Config إلا على الشبكات والأجهزة التي تملكها أو تديرها بإذن من مالكها. فقد يُعدّ فحص شبكات الآخرين أو أجهزتهم أو مراقبتها أو تقييدها أو الدخول إليها دون إذن جريمةً بموجب القانون الكويتي رقم 63 لسنة 2015 في شأن مكافحة جرائم تقنية المعلومات، وبموجب قوانين مماثلة في دول أخرى. وأنت وحدك المسؤول عن طريقة استخدامك لهذه الأدوات."
     }
    ]
   },
   {
    "h": {
     "en": "Information only, not advice",
     "ar": "للاطلاع فقط، وليست نصيحة"
    },
    "p": [
     {
      "en": "Kankon Markets: prices, charts, analysis, news and AI answers are for information only and are not investment, financial or trading advice. Prices can be delayed or wrong. Make your own decisions, or ask a licensed adviser.",
      "ar": "Kankon Markets: الأسعار والرسوم البيانية والتحليلات والأخبار وإجابات الذكاء الاصطناعي للاطلاع فقط، وليست نصيحة استثمارية أو مالية أو تداولية. وقد تتأخر الأسعار أو تكون غير دقيقة، فاتخذ قراراتك بنفسك أو استشر مستشارًا مرخّصًا."
     },
     {
      "en": "Gulf Weather: forecasts and maps are for information only. For warnings and safety, follow the official meteorological authorities in your country.",
      "ar": "Gulf Weather: التوقعات والخرائط للاطلاع فقط، وفي ما يخص التحذيرات والسلامة اتّبع جهات الأرصاد الجوية الرسمية في بلدك."
     },
     {
      "en": "Noor: prayer times are calculated on your computer. Check them against your local mosque or official authority.",
      "ar": "Noor: تُحسب مواقيت الصلاة على حاسوبك، فقارِنها بمواقيت مسجدك أو الجهة الرسمية في بلدك."
     },
     {
      "en": "Size Finder: sizes are estimates. Brands and shops differ, so check each shop's own size chart.",
      "ar": "Size Finder: المقاسات تقديرية، وتختلف من علامة تجارية ومتجر إلى آخر، فراجع جدول المقاسات الخاص بكل متجر."
     }
    ]
   },
   {
    "h": {
     "en": "Other services",
     "ar": "الخدمات الأخرى"
    },
    "p": [
     {
      "en": "Some features use services run by others, such as price, news, weather and map providers, CallMeBot for WhatsApp alerts, and Anthropic for the AI assistant with your own key. Their own terms apply, they can change or stop at any time, and Kankon is not responsible for their content. The full list is on the Third-party notices page.",
      "ar": "تعتمد بعض الميزات على خدمات تديرها جهات أخرى، مثل مزوّدي الأسعار والأخبار والطقس والخرائط، وCallMeBot لتنبيهات WhatsApp، وAnthropic للمساعد الذكي الذي يعمل بمفتاحك الخاص. وتسري على هذه الخدمات شروطها الخاصة، وقد تتغيّر أو تتوقف في أي وقت، ولا يتحمّل Kankon مسؤولية محتواها. وتجد القائمة الكاملة في صفحة إشعارات الأطراف الثالثة."
     },
     {
      "en": "If you use your own API key or WhatsApp number, you are responsible for their use and for any costs from those services.",
      "ar": "إذا استخدمت مفتاح API خاصًا بك أو رقم WhatsApp الخاص بك، فأنت المسؤول عن استخدامهما وعن أي تكاليف تفرضها تلك الخدمات."
     }
    ]
   },
   {
    "h": {
     "en": "Names and trademarks",
     "ar": "الأسماء والعلامات التجارية"
    },
    "p": [
     {
      "en": "The Kankon name, the app names and their icons belong to Kankon. Third-party parts keep their own licenses. Windows is a trademark of Microsoft Corporation. Mac and macOS are trademarks of Apple Inc. Other names belong to their owners. Kankon is not affiliated with or endorsed by Microsoft, Apple or any other company named on this site.",
      "ar": "اسم Kankon وأسماء البرامج وأيقوناتها مملوكة لـKankon، وتحتفظ مكوّنات الأطراف الثالثة بتراخيصها الخاصة. Windows علامة تجارية لشركة Microsoft Corporation، وMac وmacOS علامتان تجاريتان لشركة Apple Inc.، وتعود الأسماء الأخرى إلى أصحابها. ولا يرتبط Kankon بشركة Microsoft أو Apple أو أي شركة أخرى مذكورة في هذا الموقع، ولا يحظى باعتمادها."
     }
    ]
   },
   {
    "h": {
     "en": "Changes",
     "ar": "التعديلات"
    },
    "p": [
     {
      "en": "Kankon can update the apps and these terms at any time. The date at the top shows the latest version. Using the apps after a change means you accept it.",
      "ar": "يجوز لـKankon تحديث البرامج وهذه الشروط في أي وقت، ويُبيّن التاريخ في أعلى الصفحة آخر إصدار منها. ويُعدّ استمرارك في استخدام البرامج بعد أي تعديل قبولًا له."
     }
    ]
   },
   {
    "h": {
     "en": "Governing law",
     "ar": "القانون الواجب التطبيق"
    },
    "p": [
     {
      "en": "These terms are governed by the laws of the State of Kuwait.",
      "ar": "تخضع هذه الشروط لقوانين دولة الكويت."
     }
    ]
   }
  ],
  "privacyIntro": [
   {
    "en": "Kankon does not collect, sell or share your personal data. The apps have no accounts, ads or tracking, and your settings stay on your device. Below is everything each app sends over the internet, and why.",
    "ar": "لا يجمع Kankon بياناتك الشخصية ولا يبيعها ولا يشاركها. فلا حسابات في البرامج ولا إعلانات ولا تتبّع، وتبقى إعداداتك على جهازك. وفيما يلي كل ما يرسله كل برنامج عبر الإنترنت، وسبب ذلك."
   }
  ],
  "privacyApps": [
   {
    "id": "launcher",
    "en": "Checks for updates and downloads apps from GitHub (Dana from Amazon S3). These requests include only the file names and versions, plus the normal connection data that every download sends.",
    "ar": "يتحقّق من التحديثات وينزّل البرامج من GitHub (ولعبة Dana من Amazon S3). ولا تتضمّن هذه الطلبات إلا أسماء الملفات وأرقام الإصدارات، إضافةً إلى بيانات الاتصال المعتادة التي يرسلها أي تنزيل."
   },
   {
    "id": "KankonMarkets",
    "en": "Asks Yahoo Finance for prices and charts, and Google News and Bing News for headlines. The AI assistant sends your question and the market data on screen to Anthropic (Claude), only when you use it, with your own API key.",
    "ar": "يطلب الأسعار والرسوم البيانية من Yahoo Finance، والعناوين الإخبارية من Google News وBing News. ولا يرسل المساعد الذكي سؤالك وبيانات السوق المعروضة إلى Anthropic (Claude) إلا عند استخدامه، وبمفتاح API الخاص بك."
   },
   {
    "id": "GulfWeather",
    "en": "Sends the coordinates of the city you pick to Open-Meteo for the forecast, and loads map and satellite pictures from NASA GIBS, EUMETSAT and Esri, and alerts from GDACS and NOAA.",
    "ar": "يرسل إحداثيات المدينة التي تختارها إلى Open-Meteo للحصول على التوقعات، ويحمّل صور الخرائط والأقمار الصناعية من NASA GIBS وEUMETSAT وEsri، والتنبيهات من GDACS وNOAA."
   },
   {
    "id": "Noor",
    "en": "Works offline. Only if you use automatic location, it asks ip-api.com or ipwho.is for your approximate city based on your IP address. Quran recitation audio streams from everyayah.com when you press play.",
    "ar": "يعمل دون اتصال بالإنترنت. ولا يطلب مدينتك التقريبية بناءً على عنوان IP من ip-api.com أو ipwho.is إلا إذا استخدمت تحديد الموقع التلقائي. وتُشغَّل تلاوات القرآن من everyayah.com عند الضغط على زر التشغيل."
   },
   {
    "id": "NetworkTools",
    "en": "The speed test uses Cloudflare. Your public IP address and provider come from Cloudflare and ipinfo.io. Ping, traceroute, DNS and port checks go only to the addresses you type.",
    "ar": "يستخدم اختبار السرعة خدمة Cloudflare، ويُجلب عنوان IP العام واسم مزوّد الخدمة من Cloudflare وipinfo.io. أما Ping وتتبّع المسار وDNS وفحص المنافذ فلا تتصل إلا بالعناوين التي تكتبها."
   },
   {
    "id": "NetworkMonitor",
    "en": "Scans only your own local network, router and switch. If you turn on WhatsApp alerts, it sends your WhatsApp number, your CallMeBot key and the alert text to CallMeBot.",
    "ar": "لا يفحص إلا شبكتك المحلية والراوتر والمحوّل الخاصَّين بك. وإذا فعّلت تنبيهات WhatsApp، فإنه يرسل رقمك في WhatsApp ومفتاح CallMeBot ونص التنبيه إلى CallMeBot."
   },
   {
    "id": "DriverManager",
    "en": "Searches Windows Update (Microsoft) for drivers. Manufacturer links open in your browser.",
    "ar": "يبحث عن التعريفات في Windows Update (Microsoft)، وتُفتح روابط الشركات المصنّعة في متصفحك."
   },
   {
    "id": "AutoIpConfig",
    "en": "Does not use the internet. It only checks your own network (the gateway and free addresses) on your local network.",
    "ar": "لا يستخدم الإنترنت، ولا يفحص إلا شبكتك المحلية (البوابة والعناوين المتاحة)."
   },
   {
    "id": "SystemInfo",
    "en": "Does not use the internet. Copy my specs and Save as file stay on your computer until you share them yourself.",
    "ar": "لا يستخدم الإنترنت. وتبقى بيانات «نسخ المواصفات» و«الحفظ كملف» على حاسوبك إلى أن تشاركها بنفسك."
   },
   {
    "id": "ForceUninstaller",
    "en": "Does not use the internet.",
    "ar": "لا يستخدم الإنترنت."
   },
   {
    "id": "FileRecovery",
    "en": "Does not use the internet. It only reads the drives you choose, and recovered files and the CSV report stay on your computer.",
    "ar": "لا يستخدم الإنترنت. يقرأ الأقراص التي تختارها فقط، وتبقى الملفات المستعادة وتقرير CSV على حاسوبك."
   },
   {
    "id": "KankonPhotoAI",
    "en": "Reads the photo folders you choose; everything about your library, albums and basic edits stays on this computer. A photo is sent only when you run an AI action, and only to the AI provider you chose (OpenAI, Gemini or Claude) with your own API key. Your key is stored encrypted on this computer. Faces are never recognised.",
    "ar": "يقرأ مجلدات الصور التي تختارها، ويبقى كل ما يخص مكتبتك وألبوماتك والتعديلات الأساسية على هذا الحاسوب. ولا تُرسل صورة إلا عند تشغيل إجراء ذكاء اصطناعي، وإلى المزوّد الذي اخترته فقط (OpenAI أو Gemini أو Claude) بمفتاحك الخاص. ويُحفظ مفتاحك مشفّرًا على هذا الحاسوب. ولا يتعرّف البرنامج على الوجوه أبدًا."
   },
   {
    "id": "SizeFinder",
    "en": "Does not use the internet.",
    "ar": "لا يستخدم الإنترنت."
   },
   {
    "id": "iReportAI",
    "en": "A store app with its own privacy policy, linked on its page.",
    "ar": "تطبيق متاجر له سياسة خصوصية خاصة به، تجد رابطها في صفحته."
   },
   {
    "id": "GameRater",
    "en": "Does not use the internet. It reads your graphics card and processor names and looks for games only in the drives and folders you choose; nothing leaves your computer.",
    "ar": "لا يستخدم الإنترنت. يقرأ اسمَي بطاقة الرسومات والمعالج، ولا يبحث عن الألعاب إلا في الأقراص والمجلدات التي تختارها، ولا يغادر أي شيء حاسوبك."
   },
   {
    "id": "Dana",
    "en": "A game with its own privacy policy on playdana.net.",
    "ar": "لعبة لها سياسة خصوصية خاصة بها في موقع playdana.net."
   }
  ],
  "libs": [
   {
    "name": ".NET",
    "lic": "MIT",
    "url": "https://github.com/dotnet/runtime",
    "apps": "Launcher, all desktop apps"
   },
   {
    "name": "Avalonia UI",
    "lic": "MIT",
    "url": "https://github.com/AvaloniaUI/Avalonia",
    "apps": "Launcher, Size Finder, Auto IP Config (Mac) and other apps"
   },
   {
    "name": "SkiaSharp / HarfBuzzSharp",
    "lic": "MIT",
    "url": "https://github.com/mono/SkiaSharp",
    "apps": "Apps built with Avalonia"
   },
   {
    "name": "Microsoft Edge WebView2",
    "lic": "Microsoft WebView2 SDK license",
    "url": "https://www.nuget.org/packages/Microsoft.Web.WebView2",
    "apps": "Gulf Weather, Kankon Markets (Windows)"
   },
   {
    "name": "System.Management",
    "lic": "MIT",
    "url": "https://github.com/dotnet/runtime",
    "apps": "Force Uninstaller"
   },
   {
    "name": "three.js",
    "lic": "MIT",
    "url": "https://github.com/mrdoob/three.js",
    "apps": "Gulf Weather"
   },
   {
    "name": "Chart.js",
    "lic": "MIT",
    "url": "https://github.com/chartjs/Chart.js",
    "apps": "Network Monitor"
   },
   {
    "name": "Amiri, Amiri Quran fonts",
    "lic": "SIL Open Font License 1.1",
    "url": "https://github.com/aliftype/amiri",
    "apps": "Noor"
   },
   {
    "name": "System.Drawing.Common",
    "lic": "MIT",
    "url": "https://github.com/dotnet/winforms",
    "apps": "Launcher (Windows)"
   },
   {
    "name": "NSIS",
    "lic": "zlib/libpng",
    "url": "https://nsis.sourceforge.io/License",
    "apps": "Windows setup programs"
   }
  ],
  "sources": [
   {
    "name": "GitHub",
    "use": {
     "en": "App downloads and update checks",
     "ar": "تنزيل البرامج والتحقق من التحديثات"
    },
    "url": "https://docs.github.com/site-policy",
    "apps": "Launcher, website"
   },
   {
    "name": "Amazon S3",
    "use": {
     "en": "Dana game downloads",
     "ar": "تنزيلات لعبة Dana"
    },
    "url": "https://aws.amazon.com/privacy/",
    "apps": "Launcher"
   },
   {
    "name": "Yahoo Finance",
    "use": {
     "en": "Market prices and charts",
     "ar": "أسعار الأسواق والرسوم البيانية"
    },
    "url": "https://legal.yahoo.com/",
    "apps": "Kankon Markets"
   },
   {
    "name": "Google News",
    "use": {
     "en": "News headlines",
     "ar": "العناوين الإخبارية"
    },
    "url": "https://policies.google.com/terms",
    "apps": "Kankon Markets"
   },
   {
    "name": "Bing News",
    "use": {
     "en": "News headlines",
     "ar": "العناوين الإخبارية"
    },
    "url": "https://www.microsoft.com/servicesagreement",
    "apps": "Kankon Markets"
   },
   {
    "name": "Anthropic (Claude)",
    "use": {
     "en": "AI assistant, with your own key",
     "ar": "المساعد الذكي، بمفتاحك الخاص"
    },
    "url": "https://www.anthropic.com/legal",
    "apps": "Kankon Markets"
   },
   {
    "name": "Open-Meteo",
    "use": {
     "en": "Weather, marine and air-quality data (CC BY 4.0)",
     "ar": "بيانات الطقس والبحر وجودة الهواء (CC BY 4.0)"
    },
    "url": "https://open-meteo.com/en/terms",
    "apps": "Gulf Weather"
   },
   {
    "name": "NASA GIBS",
    "use": {
     "en": "Satellite imagery",
     "ar": "صور الأقمار الصناعية"
    },
    "url": "https://earthdata.nasa.gov/",
    "apps": "Gulf Weather"
   },
   {
    "name": "EUMETSAT",
    "use": {
     "en": "Satellite imagery",
     "ar": "صور الأقمار الصناعية"
    },
    "url": "https://www.eumetsat.int/",
    "apps": "Gulf Weather"
   },
   {
    "name": "Esri",
    "use": {
     "en": "Map imagery",
     "ar": "صور الخرائط"
    },
    "url": "https://www.esri.com/legal",
    "apps": "Gulf Weather"
   },
   {
    "name": "GDACS",
    "use": {
     "en": "Disaster alerts",
     "ar": "تنبيهات الكوارث"
    },
    "url": "https://www.gdacs.org/",
    "apps": "Gulf Weather"
   },
   {
    "name": "NOAA CPC",
    "use": {
     "en": "Climate outlooks",
     "ar": "التوقعات المناخية"
    },
    "url": "https://www.cpc.ncep.noaa.gov/",
    "apps": "Gulf Weather"
   },
   {
    "name": "King Fahd Glorious Quran Printing Complex",
    "use": {
     "en": "Quran text (Madinah Mushaf, Hafs)",
     "ar": "نص القرآن الكريم (مصحف المدينة، رواية حفص)"
    },
    "url": "https://qurancomplex.gov.sa/",
    "apps": "Noor"
   },
   {
    "name": "Tanzil / Marmaduke Pickthall (1930, public domain)",
    "use": {
     "en": "English translation of the meanings of the Quran",
     "ar": "الترجمة الإنجليزية لمعاني القرآن"
    },
    "url": "https://tanzil.net/",
    "apps": "Noor"
   },
   {
    "name": "sunnah.com",
    "use": {
     "en": "Hadith from Sahih al-Bukhari and Sahih Muslim (Arabic text, with a link to each hadith)",
     "ar": "الأحاديث من صحيح البخاري وصحيح مسلم (النص العربي، مع رابط لكل حديث)"
    },
    "url": "https://sunnah.com/",
    "apps": "Noor"
   },
   {
    "name": "EveryAyah",
    "use": {
     "en": "Quran recitation audio",
     "ar": "تلاوات القرآن الصوتية"
    },
    "url": "https://everyayah.com/",
    "apps": "Noor"
   },
   {
    "name": "ip-api.com, ipwho.is",
    "use": {
     "en": "Approximate city for automatic location",
     "ar": "المدينة التقريبية لتحديد الموقع التلقائي"
    },
    "url": "https://ip-api.com/docs/legal",
    "apps": "Noor"
   },
   {
    "name": "Cloudflare",
    "use": {
     "en": "Speed test and public IP",
     "ar": "اختبار السرعة وعنوان IP العام"
    },
    "url": "https://www.cloudflare.com/website-terms/",
    "apps": "Network Tools"
   },
   {
    "name": "ipinfo.io",
    "use": {
     "en": "Internet provider and location of your public IP",
     "ar": "مزوّد الخدمة وموقع عنوان IP العام"
    },
    "url": "https://ipinfo.io/terms-of-service",
    "apps": "Network Tools"
   },
   {
    "name": "CallMeBot",
    "use": {
     "en": "WhatsApp alerts (personal use)",
     "ar": "تنبيهات WhatsApp (للاستخدام الشخصي)"
    },
    "url": "https://www.callmebot.com/",
    "apps": "Network Monitor"
   },
   {
    "name": "Windows Update (Microsoft)",
    "use": {
     "en": "Driver updates",
     "ar": "تحديثات التعريفات"
    },
    "url": "https://www.microsoft.com/servicesagreement",
    "apps": "Driver Manager"
   },
   {
    "name": "GeoNames",
    "use": {
     "en": "Offline place names for photo locations (CC BY 4.0)",
     "ar": "أسماء الأماكن لمواقع الصور دون اتصال بالإنترنت (بترخيص CC BY 4.0)"
    },
    "url": "https://www.geonames.org/",
    "apps": "File Recovery"
   },
   {
    "name": "Unicode CLDR",
    "use": {
     "en": "Country and place names in English and Arabic",
     "ar": "أسماء الدول والأماكن بالإنجليزية والعربية"
    },
    "url": "https://cldr.unicode.org/",
    "apps": "File Recovery"
   }
  ]
 }
};
