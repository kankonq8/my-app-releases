/* kankon.net site content (English + Modern Standard Arabic).
   App/launcher text: English from description.json, Arabic from translator/website/descriptions-ar-msa.json.
   On every app or launcher release: add an entry at the top of "updates", update the app text, and raise the site version (VERSION + SITE_VERSION in index.html). */
window.KANKON = {
 "launcher": {
  "name": "Kankon Launcher",
  "icon": "img/launcher.png",
  "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/app/version.json",
  "download": "https://github.com/kankonq8/my-app-releases/raw/main/AppsLauncher-Setup.zip",
  "macVersionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/app/mac/version.json",
  "macDownload": "https://github.com/kankonq8/my-app-releases/raw/main/app/mac/2.5.0/Kankon-Launcher-2.5.0-mac.zip",
  "summary": {
   "en": "Kankon Launcher is one place to install, open and update all Kankon apps and games on Windows. Install it once, and every app stays on its latest version.",
   "ar": "Kankon Launcher هو المشغّل الموحّد لجميع البرامج: من خلاله تُثبَّت البرامج وتُفتح وتُحدَّث، دون الحاجة إلى البحث عن كل برنامج على حدة."
  },
  "features": {
   "en": [
    "A modern Home page: welcome banner, stat cards, quick access to your apps, section cards and a tip of the day.",
    "Apps are grouped in a side menu: Apps, Games, Tools and Networking, with a kankon.net button.",
    "Install any app with one click, then open it from the launcher. Apps that need administrator rights are started with them.",
    "Checks for new versions automatically and shows an Update button next to the app.",
    "Every download is verified (SHA-256) before it is installed, so only the original, unchanged file runs on your PC.",
    "Updates itself: when a new launcher version is released, it downloads it and restarts on its own.",
    "Every app has a Details page with a full description in English and Arabic.",
    "English by default, with an Arabic button that switches the whole window to right-to-left."
   ],
   "ar": [
    "صفحة رئيسية حديثة تضمّ: لافتة ترحيب، وبطاقات إحصائية، ووصولًا سريعًا إلى برامجك، وبطاقات للأقسام، ونصيحة اليوم.",
    "تُعرض البرامج في القائمة الجانبية مصنّفةً في أقسام: Apps (البرامج) وGames (الألعاب) وTools (الأدوات) وNetworking (الشبكات)، إلى جانب زر kankon.net.",
    "تثبيت أي برنامج بنقرة واحدة، ثم فتحه من المشغّل مباشرةً. ولا تعمل البرامج إلا من خلال المشغّل، وبصلاحيات المسؤول عند الحاجة إليها.",
    "يتحقّق تلقائيًا من توفّر إصدارات جديدة ويُظهر زر Update، ويتحقّق من سلامة كل ملف قبل تثبيته.",
    "يحدّث نفسه تلقائيًا؛ فإذا صدر إصدار جديد من المشغّل نزّله وأعاد التشغيل.",
    "لكل برنامج وصف مفصّل باللغتين العربية والإنجليزية.",
    "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
   ]
  },
  "how": {
   "en": [
    "Download Kankon Launcher and run the setup file. It installs for your Windows user and adds Start menu and desktop shortcuts.",
    "Open Kankon Launcher and pick a section from the side menu.",
    "Press Install next to an app, then Open.",
    "When Update appears next to an app, press it to get the new version."
   ],
   "ar": [
    "اختر القسم المطلوب من القائمة الجانبية.",
    "انقر Install بجانب البرنامج، ثم Open.",
    "عند ظهور زر Update انقره للحصول على الإصدار الجديد."
   ]
  },
  "req": {
   "en": [
    "Windows 10 or 11.",
    "Or a Mac with Apple Silicon (M1 or newer) or Intel.",
    "An internet connection for installs and updates.",
    "No administrator rights needed to install the launcher."
   ],
   "ar": [
    "نظام Windows 10 أو Windows 11.",
    "أو جهاز Mac بمعالج Apple Silicon (M1 أو أحدث) أو Intel.",
    "اتصال بالإنترنت لتثبيت البرامج وتحديثها.",
    "لا يحتاج تثبيت المشغّل إلى صلاحيات المسؤول."
   ]
  },
  "guides": [
   {
    "t": {
     "en": "Install Kankon Launcher",
     "ar": "تثبيت Kankon Launcher"
    },
    "en": [
     "Click Download for Windows at the top of this page. A zip file is downloaded.",
     "Open the downloaded file AppsLauncher-Setup.zip and extract it (right-click, Extract All).",
     "Run Kankon-Launcher-Setup.exe from the extracted folder.",
     "If Windows SmartScreen appears, click More info, then Run anyway.",
     "Wait a few seconds. Kankon Launcher opens by itself and adds shortcuts to the Start menu and the desktop."
    ],
    "ar": [
     "انقر «تنزيل لنظام Windows» في أعلى هذه الصفحة، فيُنزَّل ملف مضغوط (zip).",
     "انقر بزر الفأرة الأيمن على الملف المضغوط الذي نُزِّل (AppsLauncher-Setup.zip)، ثم اختر Extract All لاستخراج محتواه.",
     "شغّل الملف Kankon-Launcher-Setup.exe من المجلد المستخرَج.",
     "إذا ظهرت نافذة Windows SmartScreen، فانقر More info ثم Run anyway.",
     "انتظر بضع ثوانٍ؛ إذ يفتح Kankon Launcher تلقائيًا، ويضيف اختصارًا في قائمة «ابدأ» وعلى سطح المكتب."
    ]
   },
   {
    "t": {
     "en": "Install Kankon Launcher on a Mac",
     "ar": "تثبيت Kankon Launcher على جهاز Mac"
    },
    "en": [
     "Click Download for Mac at the top of this page. It works on every Mac, with Apple Silicon (M1 or newer) or Intel.",
     "Open the downloaded zip file; macOS extracts Kankon Launcher automatically.",
     "Drag Kankon Launcher into the Applications folder.",
     "The first time only: right-click Kankon Launcher, choose Open, then click Open again to confirm. After that it opens normally."
    ],
    "ar": [
     "انقر «تنزيل لأجهزة Mac» في أعلى هذه الصفحة. وتعمل هذه النسخة على جميع أجهزة Mac، بمعالجات Apple Silicon (M1 أو أحدث) أو Intel.",
     "افتح الملف المضغوط الذي نُزِّل، فيستخرج نظام macOS برنامج Kankon Launcher تلقائيًا.",
     "اسحب Kankon Launcher إلى مجلد التطبيقات (Applications).",
     "في المرة الأولى فقط: انقر بزر الفأرة الأيمن على Kankon Launcher، واختر Open، ثم انقر Open مرة أخرى للتأكيد. وبعد ذلك يُفتح بالطريقة المعتادة."
    ]
   },
   {
    "t": {
     "en": "Install and open an app",
     "ar": "تثبيت برنامج وتشغيله"
    },
    "en": [
     "Pick a section from the side menu: Apps, Games, Tools or Networking.",
     "Click Install next to the app you want. The file is downloaded and verified before it is installed.",
     "When the button changes to Open, click it to start the app.",
     "If Windows asks for administrator rights, click Yes. Some apps need them to change system settings."
    ],
    "ar": [
     "اختر القسم المطلوب من القائمة الجانبية: Apps أو Games أو Tools أو Networking.",
     "انقر Install بجانب البرنامج المطلوب؛ فيُنزَّل الملف ويُتحقَّق من سلامته قبل تثبيته.",
     "عندما يتحوّل الزر إلى Open، انقره لتشغيل البرنامج.",
     "إذا طلب Windows صلاحيات المسؤول، فانقر Yes؛ إذ تحتاج بعض البرامج إليها لتعديل إعدادات النظام."
    ]
   },
   {
    "t": {
     "en": "Update the apps and the launcher",
     "ar": "تحديث البرامج والمشغّل"
    },
    "en": [
     "Open Kankon Launcher. It checks for new versions every time it starts.",
     "When Update appears next to an app, click it. The app closes, updates and is ready again in seconds.",
     "When a new version of the launcher itself is out, it downloads it and restarts on its own. You do not need to do anything."
    ],
    "ar": [
     "افتح Kankon Launcher؛ إذ يتحقّق من توفّر إصدارات جديدة في كل مرة يبدأ فيها.",
     "عند ظهور زر Update بجانب أي برنامج، انقره؛ فيُغلَق البرنامج ويُحدَّث، ويصبح جاهزًا خلال ثوانٍ.",
     "عند صدور إصدار جديد من المشغّل نفسه، ينزّله ويعيد التشغيل تلقائيًا، دون أي إجراء منك."
    ]
   },
   {
    "t": {
     "en": "Switch the language",
     "ar": "تغيير اللغة"
    },
    "en": [
     "Click العربية in the top corner to show the launcher in Arabic, from right to left.",
     "Click English to go back. The launcher always starts in English."
    ],
    "ar": [
     "انقر زر «العربية» في الزاوية العلوية لعرض المشغّل باللغة العربية ومن اليمين إلى اليسار.",
     "انقر English للعودة إلى الإنجليزية. ويبدأ المشغّل دائمًا باللغة الإنجليزية."
    ]
   }
  ],
  "shots": [
   {
    "ar": "img/shots/launcher/ar-01-networking.jpg",
    "cap": {
     "en": "Every app in one place, grouped by category: Apps, Games, Tools and Networking.",
     "ar": "جميع البرامج في مكان واحد، مصنّفة في أقسام، وبواجهة عربية من اليمين إلى اليسار."
    },
    "en": "img/shots/launcher/en-01-networking.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-02-games.jpg",
    "cap": {
     "en": "Games sit in their own section, ready to install and open with one click.",
     "ar": "قسم الألعاب: كل لعبة جاهزة للتثبيت والتشغيل بنقرة واحدة."
    },
    "en": "img/shots/launcher/en-02-games.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-03-tools.jpg",
    "cap": {
     "en": "Handy tools, such as Driver Manager, installed and kept current by the launcher.",
     "ar": "قسم الأدوات: أدوات مثل Driver Manager يثبّتها المشغّل ويُبقيها محدّثة."
    },
    "en": "img/shots/launcher/en-03-tools.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-04-details.jpg",
    "cap": {
     "en": "A full description of every app, with its main features and how to use it.",
     "ar": "وصف كامل لكل برنامج بالعربية، مع أبرز المزايا وطريقة الاستخدام."
    },
    "en": "img/shots/launcher/en-04-details.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-05-update-available.jpg",
    "cap": {
     "en": "Updates are spotted automatically, and one click installs them.",
     "ar": "يكتشف المشغّل التحديثات تلقائيًا، وتُثبَّت بنقرة واحدة."
    },
    "en": "img/shots/launcher/en-05-update-available.jpg"
   },
   {
    "ar": "img/shots/launcher/ar-06-installer.jpg",
    "cap": {
     "en": "A small installer with no administrator rights needed.",
     "ar": "ملف تثبيت صغير لا يحتاج إلى صلاحيات المسؤول."
    },
    "en": "img/shots/launcher/en-06-installer.jpg"
   }
  ]
 },
 "categories": [
  {
   "id": "apps",
   "en": "Apps",
   "ar": "البرامج"
  },
  {
   "id": "games",
   "en": "Games",
   "ar": "الألعاب"
  },
  {
   "id": "tools",
   "en": "Tools",
   "ar": "الأدوات"
  },
  {
   "id": "networking",
   "en": "Networking",
   "ar": "الشبكات"
  }
 ],
 "apps": [
  {
   "id": "AutoIpConfig",
   "name": "Auto Create IP Config",
   "os": [
    "win",
    "mac"
   ],
   "cat": "networking",
   "icon": "img/auto-ip-config.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/AutoIpConfig/version.json",
   "summary": {
    "en": "Auto Create IP Config sets a static IP address on any network adapter in one click, or switches it back to automatic (DHCP).",
    "ar": "يضبط برنامج Auto Create IP Config عنوان IP ثابتًا لأي بطاقة شبكة بنقرة واحدة، أو يعيدها إلى الإعداد التلقائي (DHCP)."
   },
   "features": {
    "en": [
     "Shows every enabled network adapter with its current IP, gateway and mode (Static or DHCP).",
     "Enter the IP address, Subnet Mask, gateway and DNS, then press Apply.",
     "Checks before applying: warns if another device already uses the IP, and if the gateway is not in the same network.",
     "Network scan: lists free and used IP addresses with device names, and picks the closest free address for you.",
     "Saved profiles (Office, Home, ...) fill all fields with one click. On Wi-Fi, the network name is suggested as the profile name. Profiles can be exported and imported between PCs.",
     "Quick DNS buttons: Google, Cloudflare, Quad9 and OpenDNS.",
     "Safety first: the previous settings are saved before any change. If the gateway does not reply after a change, the app reverts automatically unless you press Keep, and Restore previous is always available.",
     "A connection test after every change (gateway and internet), and a button to copy the settings."
    ],
    "ar": [
     "يعرض جميع بطاقات الشبكة المفعّلة مع عنوان IP الحالي والبوابة (Gateway) ونوع الإعداد (ثابت أو DHCP).",
     "تُدخل عنوان IP وقناع الشبكة (Subnet Mask) والبوابة وخوادم DNS، ثم تنقر Apply.",
     "يتحقّق قبل التطبيق: ينبّهك إذا كان جهاز آخر يستخدم العنوان نفسه، أو إذا كانت البوابة خارج نطاق الشبكة.",
     "فحص الشبكة: يعرض العناوين المتاحة والمستخدمة مع أسماء الأجهزة، ويقترح أقرب عنوان متاح.",
     "الإعدادات المحفوظة (العمل، المنزل...): تملأ جميع الحقول بنقرة واحدة. وعند الاتصال عبر Wi-Fi يُقترح اسم الشبكة اسمًا للإعداد. ويمكن تصديرها واستيرادها لنقلها إلى جهاز آخر.",
     "أزرار DNS سريعة: Google وCloudflare وQuad9 وOpenDNS.",
     "الأمان: يحفظ الإعدادات السابقة أولًا، وإذا لم تستجب البوابة بعد التغيير يعود إليها تلقائيًا ما لم تختر Keep. ويمكنك الرجوع إليها في أي وقت عبر Restore previous.",
     "اختبار الاتصال بعد كل تغيير (البوابة والإنترنت)، وزر لنسخ الإعدادات."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and press Open on Auto Create IP Config.",
     "Pick the network adapter.",
     "Type the IP you want, or press Scan network and choose a free one.",
     "Press Apply. To go back to automatic settings, press Switch to DHCP."
    ],
    "ar": [
     "اختر بطاقة الشبكة.",
     "اكتب عنوان IP المطلوب (أو انقر Scan network واختر عنوانًا متاحًا).",
     "انقر Apply. وللعودة إلى الإعداد التلقائي انقر Switch to DHCP."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11.",
     "Or a Mac (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "Administrator rights (Windows requires them to change IP settings). The launcher requests them when it opens the app.",
     "Opens from Kankon Launcher only.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11.",
     "أو جهاز Mac (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "صلاحيات المسؤول (يشترطها Windows لتغيير إعدادات IP)، ويطلبها المشغّل عند فتح البرنامج.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/autoipconfig/ar-01-main.jpg",
     "cap": {
      "en": "Pick an adapter and set a static IP, subnet mask, gateway and DNS, with a live check that the address is free.",
      "ar": "اختر بطاقة الشبكة وحدّد عنوان IP ثابتًا وقناع الشبكة والبوابة وخوادم DNS، مع فحص مباشر لتوفّر العنوان."
     },
     "en": "img/shots/autoipconfig/en-01-main.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-02-scan.jpg",
     "cap": {
      "en": "Scan the network to see which addresses are free or used, with device names, and pick the closest free one.",
      "ar": "افحص الشبكة لمعرفة العناوين المتاحة والمستخدمة مع أسماء الأجهزة، ثم اختر أقرب عنوان متاح بنقرة واحدة."
     },
     "en": "img/shots/autoipconfig/en-02-scan.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-03-profiles.jpg",
     "cap": {
      "en": "Save your settings as named profiles (Office, Home, Lab) and switch between them in one click. Export and import are supported.",
      "ar": "احفظ إعداداتك بأسماء (العمل، المنزل، المختبر) وبدّل بينها بنقرة واحدة، مع إمكانية التصدير والاستيراد."
     },
     "en": "img/shots/autoipconfig/en-03-profiles.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-04-keep-revert.jpg",
     "cap": {
      "en": "After applying, the app tests the connection and automatically reverts if the gateway does not reply.",
      "ar": "بعد التطبيق يختبر البرنامج الاتصال، ويعيد الإعدادات السابقة تلقائيًا إذا لم تستجب البوابة."
     },
     "en": "img/shots/autoipconfig/en-04-keep-revert.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-05-quick-dns.jpg",
     "cap": {
      "en": "One-click DNS presets (Google, Cloudflare, Quad9, OpenDNS) and a connection test after applying.",
      "ar": "إعدادات DNS جاهزة بنقرة واحدة (Google وCloudflare وQuad9 وOpenDNS) مع اختبار الاتصال بعد التطبيق."
     },
     "en": "img/shots/autoipconfig/en-05-quick-dns.jpg"
    },
    {
     "ar": "img/shots/autoipconfig/ar-06-dhcp.jpg",
     "cap": {
      "en": "Switch back to automatic addressing (DHCP) at any time.",
      "ar": "ارجع إلى الإعداد التلقائي (DHCP) في أي وقت."
     },
     "en": "img/shots/autoipconfig/en-06-dhcp.jpg"
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Set a static IP address",
      "ar": "تعيين عنوان IP ثابت"
     },
     "en": [
      "Open Auto Create IP Config from Kankon Launcher (Networking).",
      "Pick the network adapter from the list at the top.",
      "Type the IP address, Subnet Mask, gateway and DNS.",
      "Click Apply. The app checks the address first and warns you if another device already uses it.",
      "After the change, the app tests the gateway and the internet. If everything works, click Keep."
     ],
     "ar": [
      "افتح Auto Create IP Config من Kankon Launcher (قسم Networking «الشبكات»).",
      "اختر بطاقة الشبكة من القائمة في الأعلى.",
      "أدخل عنوان IP وقناع الشبكة (Subnet Mask) والبوابة وخوادم DNS.",
      "انقر Apply؛ فيتحقّق البرنامج من العنوان أولًا، وينبّهك إذا كان جهاز آخر يستخدمه.",
      "بعد التغيير، يختبر البرنامج الاتصال بالبوابة والإنترنت، فإذا كان كل شيء سليمًا، انقر Keep."
     ]
    },
    {
     "t": {
      "en": "Find a free IP address",
      "ar": "العثور على عنوان IP متاح"
     },
     "en": [
      "Click Scan network.",
      "Wait a few seconds while the app checks every address in your network.",
      "The list shows used addresses with device names, and free ones.",
      "Click the suggested closest free address, or any free one, and it is filled in for you. Then click Apply."
     ],
     "ar": [
      "انقر Scan network.",
      "انتظر بضع ثوانٍ بينما يفحص البرنامج جميع عناوين الشبكة.",
      "تعرض القائمة العناوين المستخدمة مع أسماء الأجهزة، والعناوين المتاحة.",
      "انقر أقرب عنوان متاح يقترحه البرنامج، أو أي عنوان متاح آخر، فيُملأ تلقائيًا، ثم انقر Apply."
     ]
    },
    {
     "t": {
      "en": "Save and reuse a profile",
      "ar": "حفظ إعداد واستخدامه لاحقًا"
     },
     "en": [
      "Fill in the IP settings you use in a place (for example Office).",
      "Save them as a profile. On Wi-Fi, the network name is suggested as the profile name.",
      "Next time, pick the profile and click Apply: all fields are filled with one click.",
      "Use Export and Import to move your profiles to another PC."
     ],
     "ar": [
      "أدخل إعدادات IP التي تستخدمها في مكان معيّن (العمل مثلًا).",
      "احفظها إعدادًا محفوظًا، وعند الاتصال عبر Wi-Fi يُقترح اسم الشبكة اسمًا له.",
      "في المرة التالية، اختر الإعداد وانقر Apply، فتُملأ جميع الحقول بنقرة واحدة.",
      "استخدم Export وImport لنقل إعداداتك إلى جهاز آخر."
     ]
    },
    {
     "t": {
      "en": "Go back to automatic settings",
      "ar": "العودة إلى الإعداد التلقائي"
     },
     "en": [
      "Pick the network adapter.",
      "Click Switch to DHCP. The adapter gets its address from the router again.",
      "If something goes wrong after any change, click Restore previous to return to the settings you had before."
     ],
     "ar": [
      "اختر بطاقة الشبكة.",
      "انقر Switch to DHCP؛ فتحصل البطاقة على عنوانها من جهاز التوجيه مجددًا.",
      "إذا حدث خلل بعد أي تغيير، فانقر Restore previous للعودة إلى الإعدادات السابقة."
     ]
    }
   ]
  },
  {
   "id": "NetworkMonitor",
   "name": "Network Monitor",
   "os": [
    "win",
    "mac"
   ],
   "cat": "networking",
   "icon": "img/network-monitor.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/NetworkMonitor/version.json",
   "summary": {
    "en": "Network Monitor shows every device on your network, how much each one uses, and your whole home internet usage, live, in its own window.",
    "ar": "يعرض برنامج Network Monitor جميع الأجهزة المتصلة بشبكتك، واستهلاك كل جهاز، واستهلاك إنترنت المنزل بالكامل، بصورة مباشرة وفي نافذة مستقلة."
   },
   "features": {
    "en": [
     "Devices: scans the network every minute and lists every device with its name, IP, MAC, maker, online status, response time and how often it is online. Rename devices and mark important ones.",
     "Router: whole-home internet download and upload, now, today and this month (Huawei home routers, read without a password).",
     "Switch: how much each device on a managed switch uses, today and over the last 30 days (SNMP, read only). Setup can find the switch on the network for you.",
     "Daily limit: set a daily usage limit for any device and get an alert when it is passed.",
     "Internet outages: checks the internet every 15 seconds, logs every outage and how long it lasted, and tells you when the connection is back.",
     "Weekly summary: every Friday, a short summary to your phone with the top devices, home internet usage and outages.",
     "This PC: download and upload speed, the programs using the internet and how many MB each one used, and the services (ports) on this PC.",
     "Free IPs: the addresses in each network that no device uses, ready for a new device.",
     "Alerts when a new device joins or an important device goes offline, plus a monthly report. Alerts can also reach your phone (ntfy app).",
     "Open it from other devices on the network in a browser, protected by a password.",
     "Export the device list to Excel (CSV).",
     "Start with Windows: keeps running in the background so alerts and history never stop."
    ],
    "ar": [
     "الأجهزة: يفحص الشبكة كل دقيقة ويعرض كل جهاز باسمه وعنوان IP وعنوان MAC والشركة المصنّعة، وحالة اتصاله، وزمن استجابته، ونسبة وجوده على الشبكة. ويمكنك تسمية الأجهزة وتمييز المهم منها.",
     "جهاز التوجيه (Router): معدّل التنزيل والرفع لإنترنت المنزل كله الآن، واستهلاك اليوم والشهر الحالي (لأجهزة Huawei المنزلية، دون كلمة مرور).",
     "المحوّل (Switch): استهلاك كل جهاز متصل بمحوّل مُدار، لليوم ولآخر 30 يومًا (عبر SNMP للقراءة فقط).",
     "This PC: سرعة التنزيل والرفع، والبرامج التي تستخدم الإنترنت وحجم ما استهلكه كل منها بالميغابايت، والخدمات (المنافذ) العاملة على الجهاز.",
     "العناوين المتاحة: عناوين IP غير المستخدمة في كل شبكة، الجاهزة لجهاز جديد.",
     "التنبيهات: عند انضمام جهاز جديد إلى الشبكة، وعند انقطاع جهاز مهم، إضافةً إلى تقرير شهري. ويمكن إرسالها إلى هاتفك (عبر تطبيق ntfy).",
     "يمكن فتحه من أي جهاز آخر على الشبكة عبر المتصفح، مع حمايته بكلمة مرور.",
     "تصدير قائمة الأجهزة إلى Excel (بصيغة CSV).",
     "التشغيل مع Windows: يواصل العمل في الخلفية حتى لا تتوقّف التنبيهات والسجل."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and press Open on Network Monitor.",
     "Wait a few seconds for the first scan, then click any device to see its details.",
     "Press Setup and fill in Router (type and address) and Switch (the switch's own address and SNMP community, or press Find the switch). The steps to turn on SNMP are shown there.",
     "Optional: in Setup, turn on phone alerts, a password for other devices, and Start with Windows."
    ],
    "ar": [
     "افتح Kankon Launcher، ثم انتقل إلى قسم Networking (الشبكات) وانقر Open بجانب Network Monitor.",
     "انتظر بضع ثوانٍ حتى يكتمل الفحص الأول، ثم انقر أي جهاز لعرض تفاصيله.",
     "انقر Setup وأدخل بيانات Router (النوع والعنوان) وSwitch (العنوان واسم SNMP Community). وتجد هناك خطوات تفعيل SNMP.",
     "اختياري: من Setup فعّل تنبيهات الهاتف، وكلمة المرور للأجهزة الأخرى، والتشغيل مع Windows."
    ]
   },
   "req": {
    "en": [
     "Windows 10, Windows 11 or Windows Server.",
     "Or a Mac (Apple Silicon or Intel) with macOS 12 or newer.",
     "On Windows: administrator rights (to measure each program and to start with Windows).",
     "Opens from Kankon Launcher only (Networking).",
     "English by default, with an Arabic button.",
     "Router and switch settings are saved on each PC only and are never shared."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 أو Windows Server.",
     "أو جهاز Mac (بمعالج Apple Silicon أو Intel) بنظام macOS 12 أو أحدث.",
     "على Windows: صلاحيات المسؤول (لقياس استهلاك كل برنامج وللتشغيل مع Windows).",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية.",
     "تُحفظ إعدادات جهاز التوجيه والمحوّل على الجهاز نفسه فقط، ولا تُشارك مع أي جهة."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/networkmonitor/ar-01-dashboard.jpg",
     "cap": {
      "en": "Every device on your network, with the whole home internet, outages and top devices at a glance.",
      "ar": "جميع الأجهزة المتصلة بشبكتك، مع استهلاك إنترنت المنزل والانقطاعات وأكثر الأجهزة استهلاكًا في نظرة واحدة."
     },
     "en": "img/shots/networkmonitor/en-01-dashboard.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-02-device-details.jpg",
     "cap": {
      "en": "Device details: rename it, mark it important, and set a daily usage limit.",
      "ar": "تفاصيل الجهاز: إعادة تسميته، وتمييزه بوصفه جهازًا مهمًا، وتحديد حدٍّ يومي للاستهلاك."
     },
     "en": "img/shots/networkmonitor/en-02-device-details.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-03-alerts.jpg",
     "cap": {
      "en": "Alerts for new devices, devices going offline, internet outages, daily limits and the weekly summary.",
      "ar": "تنبيهات عند انضمام جهاز جديد، أو انقطاع جهاز، أو انقطاع الإنترنت، أو تجاوز الحد اليومي، إضافةً إلى الملخص الأسبوعي."
     },
     "en": "img/shots/networkmonitor/en-03-alerts.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-04-monthly-report.jpg",
     "cap": {
      "en": "Monthly report: which devices and programs used the most data.",
      "ar": "التقرير الشهري: الأجهزة والبرامج الأكثر استهلاكًا للبيانات."
     },
     "en": "img/shots/networkmonitor/en-04-monthly-report.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-05-setup-switch.jpg",
     "cap": {
      "en": "Setup: find your managed switch on the network and connect it with SNMP (read only).",
      "ar": "الإعدادات: البحث عن المحوّل المُدار في الشبكة وربطه عبر بروتوكول SNMP للقراءة فقط."
     },
     "en": "img/shots/networkmonitor/en-05-setup-switch.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-06-setup-phone-weekly.jpg",
     "cap": {
      "en": "Phone alerts and a weekly summary every Friday.",
      "ar": "تنبيهات على الهاتف وملخص أسبوعي كل يوم جمعة."
     },
     "en": "img/shots/networkmonitor/en-06-setup-phone-weekly.jpg"
    },
    {
     "ar": "img/shots/networkmonitor/ar-07-free-ips.jpg",
     "cap": {
      "en": "Free IPs: addresses no device uses, ready for a new device.",
      "ar": "العناوين المتاحة: عناوين IP غير المستخدمة والجاهزة لجهاز جديد."
     },
     "en": "img/shots/networkmonitor/en-07-free-ips.jpg"
    }
   ],
   "guides": [
    {
     "t": {
      "en": "First start",
      "ar": "التشغيل الأول"
     },
     "en": [
      "Open Network Monitor from Kankon Launcher (Networking).",
      "Wait a few seconds for the first scan of your network.",
      "Every device appears in the list with its name, maker and status. Click a device to see its details, rename it or mark it as important."
     ],
     "ar": [
      "افتح Network Monitor من Kankon Launcher (قسم Networking «الشبكات»).",
      "انتظر بضع ثوانٍ حتى يكتمل الفحص الأول للشبكة.",
      "يظهر كل جهاز في القائمة باسمه والشركة المصنّعة وحالته. انقر أي جهاز لعرض تفاصيله، أو إعادة تسميته، أو تمييزه جهازًا مهمًا."
     ]
    },
    {
     "t": {
      "en": "Connect your router",
      "ar": "ربط جهاز التوجيه (Router)"
     },
     "en": [
      "Click Setup, then Router.",
      "Choose the router type and type its address.",
      "Click Save. The Router card now shows your whole home internet usage: now, today and this month."
     ],
     "ar": [
      "انقر Setup ثم Router.",
      "اختر نوع جهاز التوجيه وأدخل عنوانه.",
      "انقر Save؛ فتعرض بطاقة Router استهلاك الإنترنت المنزلي بالكامل: الآن، واليوم، وهذا الشهر."
     ]
    },
    {
     "t": {
      "en": "Measure each device through the switch",
      "ar": "قياس استهلاك كل جهاز عبر المحوّل (Switch)"
     },
     "en": [
      "Turn on SNMP (read only) in your managed switch. The steps are shown in Setup > Switch.",
      "In Setup > Switch, click Find the switch, or type the switch's own address.",
      "Type the SNMP community and click Save.",
      "After a few minutes, each device shows how much it used today and over the last 30 days."
     ],
     "ar": [
      "فعّل SNMP (للقراءة فقط) في المحوّل المُدار، وستجد الخطوات في Setup ثم Switch.",
      "من Setup ثم Switch، انقر Find the switch، أو أدخل عنوان المحوّل نفسه.",
      "أدخل اسم SNMP Community وانقر Save.",
      "بعد بضع دقائق، يعرض كل جهاز استهلاكه اليومي واستهلاكه خلال آخر 30 يومًا."
     ]
    },
    {
     "t": {
      "en": "Get alerts on your phone",
      "ar": "استقبال التنبيهات على الهاتف"
     },
     "en": [
      "Install the free ntfy app on your phone.",
      "In Network Monitor, open Setup > Phone alerts and turn them on.",
      "Subscribe to the topic shown there in the ntfy app.",
      "Click Send one now to test. You will get alerts for new devices, outages, daily limits and the weekly summary."
     ],
     "ar": [
      "ثبّت تطبيق ntfy المجاني على هاتفك.",
      "في Network Monitor، افتح Setup ثم Phone alerts وفعّلها.",
      "اشترك في الموضوع (Topic) الظاهر هناك من داخل تطبيق ntfy.",
      "انقر Send one now للتجربة؛ وستصلك التنبيهات عن الأجهزة الجديدة والانقطاعات والحد اليومي والملخص الأسبوعي."
     ]
    },
    {
     "t": {
      "en": "Set a daily limit for a device",
      "ar": "تحديد حد يومي لجهاز"
     },
     "en": [
      "Click the device in the list.",
      "In its details, set the daily limit in MB or GB.",
      "When the device passes the limit, you get an alert in the app and on your phone."
     ],
     "ar": [
      "انقر الجهاز في القائمة.",
      "حدّد الحد اليومي بالميغابايت أو الغيغابايت من صفحة تفاصيله.",
      "عند تجاوز الجهاز هذا الحد، يصلك تنبيه في البرنامج وعلى هاتفك."
     ]
    }
   ]
  },
  {
   "id": "NetworkTools",
   "name": "Network Tools",
   "os": [
    "win"
   ],
   "cat": "networking",
   "icon": "img/network-tools.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/NetworkTools/version.json",
   "summary": {
    "en": "Network Tools brings the network checks you need every day into one app: internet speed test, ping, traceroute, DNS, port check and a subnet calculator.",
    "ar": "يجمع برنامج Network Tools في تطبيق واحد فحوصات الشبكة التي تحتاج إليها يوميًا: اختبار سرعة الإنترنت، وPing، وتتبّع المسار، وDNS، وفحص المنافذ، وحاسبة الشبكات الفرعية."
   },
   "features": {
    "en": [
     "Overview: this computer's name and system, every connected network adapter (IP address, subnet mask, router, DNS servers, MAC address, link speed, DHCP or static), your public IP, internet provider and location, and live ping to your router and the internet. Copy everything with one click.",
     "Speed Test: download and upload speed, ping and jitter, measured against the nearest Cloudflare server, with a live speedometer and chart. Every result is saved in a history on this computer.",
     "Ping: ping any device or website, continuously or a fixed number of times. Shows sent, received, lost %, minimum, average and maximum time and jitter, with a live chart that marks lost packets in red and slow replies in amber.",
     "Traceroute: every router (hop) between you and the destination, with three timings per hop and the host names, to see where a connection slows down.",
     "DNS lookup: ask any DNS server (this computer's, Cloudflare, Google, Quad9, OpenDNS, AdGuard or your own) for A, AAAA, CNAME, MX, NS, TXT, PTR or SOA records. Type an IP address to get its name.",
     "DNS benchmark: tests all the DNS servers with 10 popular sites and shows the fastest one for your connection.",
     "Port Check: checks which TCP ports are open on any device, with ready lists for web, remote access, file sharing, Synology NAS, mail and common ports.",
     "Subnet Calculator: type 192.168.1.10/24 (or an IP address and a mask) to get the network, broadcast, first and last host, number of hosts, mask and wildcard.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظرة عامة (Overview): اسم الجهاز ونظام تشغيله، وكل بطاقة شبكة متصلة (عنوان IP، وقناع الشبكة الفرعية، وجهاز التوجيه، وخوادم DNS، وعنوان MAC، وسرعة الاتصال، ونوع الإعداد: تلقائي DHCP أو ثابت)، إلى جانب عنوان IP العام، ومزوّد خدمة الإنترنت، والموقع، وقياس Ping مباشر لجهاز التوجيه وللإنترنت. ويمكن نسخ هذه المعلومات كلّها بنقرة واحدة.",
     "اختبار السرعة (Speed Test): يقيس سرعة التنزيل والرفع، وزمن الاستجابة (Ping)، وتذبذبه (Jitter)، عبر أقرب خادم من خوادم Cloudflare، مع عدّاد سرعة ورسم بياني مباشرين. وتُحفظ كل نتيجة في سجلّ على هذا الجهاز.",
     "Ping: لاختبار الاتصال بأي جهاز أو موقع، باستمرار أو لعدد محدّد من المرات. ويعرض عدد الحزم المرسلة والمستلمة، ونسبة المفقود منها، وأقلّ زمن ومتوسّطه وأعلاه، والتذبذب، مع رسم بياني مباشر يُظهر الحزم المفقودة باللون الأحمر والردود البطيئة باللون البرتقالي.",
     "تتبّع المسار (Traceroute): يعرض كل جهاز توجيه (قفزة) بينك وبين الوجهة، مع ثلاثة قياسات زمنية لكل قفزة وأسماء الأجهزة، لمعرفة الموضع الذي يحدث فيه البطء.",
     "استعلام DNS: يستعلم من أي خادم DNS (خادم الجهاز، أو Cloudflare، أو Google، أو Quad9، أو OpenDNS، أو AdGuard، أو خادم تحدّده بنفسك) عن السجلات A وAAAA وCNAME وMX وNS وTXT وPTR وSOA. وعند إدخال عنوان IP يُظهر الاسم المرتبط به.",
     "مقارنة سرعة خوادم DNS: يختبر جميع الخوادم على 10 مواقع شائعة، ويُبيّن أسرعها لاتصالك.",
     "فحص المنافذ (Port Check): يتحقّق من منافذ TCP المفتوحة على أي جهاز، مع قوائم جاهزة لخدمات الويب، والتحكّم عن بُعد، ومشاركة الملفات، وأجهزة Synology NAS، والبريد، والمنافذ الشائعة.",
     "حاسبة الشبكات الفرعية (Subnet Calculator): أدخل 192.168.1.10/24 (أو عنوان IP وقناعًا) لتحصل على عنوان الشبكة، وعنوان البثّ (Broadcast)، وأول عنوان وآخره، وعدد الأجهزة الممكنة، والقناع، والقناع المعكوس (Wildcard).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Networking and click Install next to Network Tools, then Open.",
     "Pick a tool from the menu on the left.",
     "Speed Test: click Start test and wait about 25 seconds.",
     "Ping and Traceroute: type an address or click a quick button (Router, Google DNS, Cloudflare), then click Start.",
     "Port Check: type the device address, pick a preset or type the ports (for example 80, 443 or 1-1024), then click Start."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Networking (الشبكات)، ثم انقر Install بجانب Network Tools، ثم Open.",
     "اختر الأداة المطلوبة من القائمة الجانبية.",
     "اختبار السرعة: انقر Start test وانتظر نحو 25 ثانية.",
     "Ping وتتبّع المسار: أدخل العنوان أو انقر أحد الأزرار السريعة (Router، أو Google DNS، أو Cloudflare)، ثم انقر Start.",
     "فحص المنافذ: أدخل عنوان الجهاز، واختر قائمة جاهزة أو اكتب المنافذ (مثل 80 و443، أو النطاق 1-1024)، ثم انقر Start."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "No administrator rights needed.",
     "An internet connection for the speed test, the public IP and the DNS benchmark.",
     "Opens from Kankon Launcher only (Networking)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "لا يحتاج إلى صلاحيات المسؤول.",
     "اتصال بالإنترنت لاختبار السرعة، ومعرفة عنوان IP العام، ومقارنة خوادم DNS.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Networking (الشبكات)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Test your internet speed",
      "ar": "اختبار سرعة الإنترنت"
     },
     "en": [
      "Open Network Tools and click Speed Test.",
      "Click Start test and wait about 25 seconds without heavy downloads on the network.",
      "Read the download, upload, ping and jitter results. Earlier results are listed in the history below."
     ],
     "ar": [
      "افتح Network Tools وانقر Speed Test.",
      "انقر Start test وانتظر نحو 25 ثانية، مع تجنّب التنزيلات الكبيرة على الشبكة في أثناء الاختبار.",
      "اطّلع على نتائج سرعة التنزيل والرفع وزمن الاستجابة والتذبذب، وتجد النتائج السابقة في السجلّ أسفل الصفحة."
     ]
    },
    {
     "t": {
      "en": "Find where a connection slows down",
      "ar": "تحديد موضع البطء في الاتصال"
     },
     "en": [
      "Click Ping, type the address (or click Router or Google DNS) and click Start. Red marks on the chart are lost packets.",
      "If replies are slow or lost, click Traceroute, type the same address and click Start.",
      "The first hop with high times shows where the delay starts: your router, your provider or beyond."
     ],
     "ar": [
      "انقر Ping، وأدخل العنوان (أو انقر Router أو Google DNS)، ثم انقر Start. وتدلّ العلامات الحمراء في الرسم البياني على الحزم المفقودة.",
      "إذا كانت الردود بطيئة أو مفقودة، فانقر Traceroute، وأدخل العنوان نفسه، ثم انقر Start.",
      "أول قفزة يرتفع عندها الزمن تُبيّن موضع بدء التأخير: جهاز التوجيه، أو مزوّد الخدمة، أو ما بعدهما."
     ]
    },
    {
     "t": {
      "en": "Choose the fastest DNS",
      "ar": "اختيار أسرع خادم DNS"
     },
     "en": [
      "Click DNS, then open the benchmark.",
      "Click Start. Every DNS server is tested with 10 popular sites.",
      "The fastest server for your connection is shown at the top; you can set it on your router or network adapter."
     ],
     "ar": [
      "انقر DNS، ثم افتح أداة المقارنة.",
      "انقر Start، فيُختبر كل خادم DNS على 10 مواقع شائعة.",
      "يظهر أسرع خادم لاتصالك في أعلى القائمة، ويمكنك اعتماده في إعدادات جهاز التوجيه أو بطاقة الشبكة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/networktools/en-01-overview.jpg",
     "ar": "img/shots/networktools/ar-01-overview.jpg",
     "cap": {
      "en": "Overview: this computer, every network adapter, your public IP and provider at a glance.",
      "ar": "نظرة عامة: معلومات الجهاز، وكل بطاقة شبكة، وعنوان IP العام ومزوّد الخدمة في نظرة واحدة."
     }
    },
    {
     "en": "img/shots/networktools/en-02-speed-test.jpg",
     "ar": "img/shots/networktools/ar-02-speed-test.jpg",
     "cap": {
      "en": "Speed Test: download, upload, ping and jitter, with a history of every test.",
      "ar": "اختبار السرعة: التنزيل والرفع وزمن الاستجابة والتذبذب، مع سجلّ لكل اختبار."
     }
    },
    {
     "en": "img/shots/networktools/en-03-ping.jpg",
     "ar": "img/shots/networktools/ar-03-ping.jpg",
     "cap": {
      "en": "Ping with a live chart: lost packets in red, slow replies in amber.",
      "ar": "Ping مع رسم بياني مباشر: الحزم المفقودة باللون الأحمر، والردود البطيئة باللون البرتقالي."
     }
    },
    {
     "en": "img/shots/networktools/en-04-traceroute.jpg",
     "ar": "img/shots/networktools/ar-04-traceroute.jpg",
     "cap": {
      "en": "Traceroute: every hop to the destination, with three timings each.",
      "ar": "تتبّع المسار: كل قفزة حتى الوجهة، مع ثلاثة قياسات زمنية لكلٍّ منها."
     }
    },
    {
     "en": "img/shots/networktools/en-05-dns.jpg",
     "ar": "img/shots/networktools/ar-05-dns.jpg",
     "cap": {
      "en": "DNS lookup on any server, and a benchmark to find the fastest one.",
      "ar": "استعلام DNS من أي خادم، ومقارنة لمعرفة أسرع الخوادم."
     }
    },
    {
     "en": "img/shots/networktools/en-06-port-check.jpg",
     "ar": "img/shots/networktools/ar-06-port-check.jpg",
     "cap": {
      "en": "Port Check with ready presets, including Synology NAS.",
      "ar": "فحص المنافذ بقوائم جاهزة، منها قائمة لأجهزة Synology NAS."
     }
    },
    {
     "en": "img/shots/networktools/en-07-subnet.jpg",
     "ar": "img/shots/networktools/ar-07-subnet.jpg",
     "cap": {
      "en": "Subnet Calculator: network, broadcast, host range and mask from one entry.",
      "ar": "حاسبة الشبكات الفرعية: عنوان الشبكة والبثّ ونطاق العناوين والقناع من إدخال واحد."
     }
    }
   ]
  },
  {
   "id": "DriverManager",
   "name": "Driver Manager",
   "cat": "tools",
   "icon": "img/driver-manager.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/DriverManager/version.json",
   "summary": {
    "en": "Driver Manager keeps the drivers of your PC safe and up to date. Its main job is to back up all drivers and put them back after a clean Windows install, without internet.",
    "ar": "يحافظ برنامج Driver Manager على برامج تشغيل الأجهزة (التعريفات) في حاسوبك ويُبقيها محدّثة. ووظيفته الأساسية حفظ نسخة احتياطية من جميع التعريفات واستعادتها بعد إعادة تثبيت Windows، دون الحاجة إلى الإنترنت."
   },
   "features": {
    "en": [
     "Backup & Restore (main screen): save all third-party drivers of this PC in one click, as a folder or one ZIP file. Restore them later from the list, from any folder, or straight from a ZIP file.",
     "Backups are kept outside Windows: on a second drive if there is one, otherwise in Documents with a reminder to copy them to a USB drive. You can change the folder at any time.",
     "Each backup remembers which PC it came from, and the app asks before restoring a backup from a different PC.",
     "Driver Updates: finds new drivers from Windows Update (the official Microsoft source) and installs the ones you choose, after creating a system restore point.",
     "Hide drivers you do not want, so they no longer appear in update searches.",
     "Backs up the current drivers automatically before installing updates, and keeps only the last 3 backups of this PC (both can be turned off).",
     "This PC: shows the PC specifications, devices that need a driver, available updates and the last backup.",
     "Installed Drivers: search the list and export it as a CSV report.",
     "Automatic check every 4 weeks, with a notice when new drivers are found.",
     "Log: every action is shown in the app and saved to a log file."
    ],
    "ar": [
     "النسخ الاحتياطي والاستعادة (الشاشة الرئيسية): حفظ جميع تعريفات الجهاز بنقرة واحدة، في مجلد أو في ملف ZIP واحد، ثم استعادتها لاحقًا من القائمة أو من أي مجلد أو من ملف ZIP مباشرةً.",
     "تُحفظ النسخ خارج قرص Windows: على قرص ثانٍ إن وُجد، وإلا ففي مجلد المستندات مع تنبيه بنسخها إلى ذاكرة USB. ويمكن تغيير المجلد في أي وقت.",
     "تحتفظ كل نسخة باسم الجهاز الذي أُخذت منه، ويطلب البرنامج التأكيد قبل استعادة نسخة من جهاز آخر.",
     "تحديث التعريفات: يبحث عن تعريفات جديدة في Windows Update (المصدر الرسمي من Microsoft) ويثبّت ما تختاره منها، بعد إنشاء نقطة استعادة للنظام.",
     "إخفاء التعريفات غير المرغوب فيها حتى لا تظهر في نتائج البحث عن التحديثات.",
     "نسخة احتياطية تلقائية من التعريفات الحالية قبل تثبيت التحديثات، مع الاحتفاظ بآخر ثلاث نسخ فقط لهذا الجهاز (ويمكن إيقاف الخيارين).",
     "صفحة This PC: تعرض مواصفات الجهاز، والأجهزة التي تحتاج إلى تعريف، والتحديثات المتاحة، وتاريخ آخر نسخة احتياطية.",
     "التعريفات المثبّتة: البحث في القائمة وتصديرها تقريرًا بصيغة CSV.",
     "فحص تلقائي كل أربعة أسابيع، مع تنبيه عند توفّر تعريفات جديدة.",
     "السجل: تُعرض كل عملية في البرنامج وتُحفظ في ملف."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Tools and press Open on Driver Manager.",
     "Before formatting the PC, open Backup & Restore and press Back up now (a USB drive or a second drive is best).",
     "After installing Windows, open the app, pick the backup and press Restore selected.",
     "Restart the PC if the app asks."
    ],
    "ar": [
     "قبل إعادة تثبيت Windows، افتح Backup & Restore وانقر Back up now (ويُفضَّل الحفظ على ذاكرة USB أو قرص ثانٍ).",
     "بعد تثبيت Windows، افتح البرنامج واختر النسخة ثم انقر Restore selected.",
     "أعد تشغيل الجهاز إذا طلب البرنامج ذلك."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11.",
     "Administrator rights (needed to back up and install drivers).",
     "Opens from Kankon Launcher only (Tools).",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11.",
     "صلاحيات المسؤول (لازمة لحفظ التعريفات وتثبيتها).",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات).",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "shots": [
    {
     "ar": "img/shots/drivermanager/ar-01-backup.jpg",
     "cap": {
      "en": "Backup & Restore: save every driver on the PC and restore them offline after a clean install.",
      "ar": "النسخ الاحتياطي والاستعادة: احفظ جميع تعريفات الجهاز واستعدها دون اتصال بالإنترنت بعد إعادة تثبيت Windows."
     },
     "en": "img/shots/drivermanager/en-01-backup.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-02-backing.jpg",
     "cap": {
      "en": "One click backs up all drivers and compresses them into a single ZIP file.",
      "ar": "بنقرة واحدة تُحفَظ جميع التعريفات وتُضغَط في ملف ZIP واحد."
     },
     "en": "img/shots/drivermanager/en-02-backing.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-03-otherpc.jpg",
     "cap": {
      "en": "Each backup records the PC it came from, so you are warned before restoring drivers from a different PC.",
      "ar": "تحمل كل نسخة اسم الجهاز الذي أُخذت منه، فيُنبّهك البرنامج قبل استعادة تعريفات جهاز آخر."
     },
     "en": "img/shots/drivermanager/en-03-otherpc.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-04-home.jpg",
     "cap": {
      "en": "This PC: device health, available updates, last backup and the PC specifications at a glance.",
      "ar": "هذا الجهاز: حالة الأجهزة والتحديثات المتاحة وآخر نسخة احتياطية ومواصفات الجهاز في لمحة واحدة."
     },
     "en": "img/shots/drivermanager/en-04-home.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-05-updates.jpg",
     "cap": {
      "en": "Driver updates from Windows Update, with an automatic backup and a restore point before installing.",
      "ar": "تحديث التعريفات من Windows Update، مع نسخة احتياطية تلقائية ونقطة استعادة قبل التثبيت."
     },
     "en": "img/shots/drivermanager/en-05-updates.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-06-installed.jpg",
     "cap": {
      "en": "Installed drivers with search and CSV export.",
      "ar": "قائمة التعريفات المثبتة مع البحث والتصدير إلى ملف CSV."
     },
     "en": "img/shots/drivermanager/en-06-installed.jpg"
    },
    {
     "ar": "img/shots/drivermanager/ar-07-log.jpg",
     "cap": {
      "en": "A clear log of every action, also saved to a file.",
      "ar": "سجل واضح لكل عملية، يُحفَظ أيضًا في ملف."
     },
     "en": "img/shots/drivermanager/en-07-log.jpg"
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Back up your drivers before formatting",
      "ar": "نسخ التعريفات احتياطيًا قبل إعادة تثبيت Windows"
     },
     "en": [
      "Open Driver Manager from Kankon Launcher (Tools).",
      "Backup & Restore is the main screen. Check the backup folder: a USB drive or a second drive is best.",
      "Click Back up now. All third-party drivers are saved in a folder, or in one ZIP file if you choose.",
      "Wait until the app says the backup is done, then keep the USB drive safe."
     ],
     "ar": [
      "افتح Driver Manager من Kankon Launcher (قسم Tools «الأدوات»).",
      "شاشة Backup & Restore هي الشاشة الرئيسية؛ تحقّق من مجلد النسخ الاحتياطي، ويُفضَّل أن يكون على ذاكرة USB أو قرص ثانٍ.",
      "انقر Back up now؛ فتُحفظ جميع تعريفات الشركات المصنّعة في مجلد، أو في ملف ZIP واحد إن اخترت ذلك.",
      "انتظر حتى يُعلمك البرنامج باكتمال النسخ، ثم احتفظ بذاكرة USB في مكان آمن."
     ]
    },
    {
     "t": {
      "en": "Restore your drivers after installing Windows",
      "ar": "استعادة التعريفات بعد تثبيت Windows"
     },
     "en": [
      "Install Kankon Launcher, then Driver Manager (Tools). No internet is needed for the restore itself.",
      "Open Backup & Restore and pick your backup from the list, or click to choose a folder or a ZIP file.",
      "Click Restore selected. If the backup is from a different PC, the app asks you first.",
      "Restart the PC when the app asks."
     ],
     "ar": [
      "ثبّت Kankon Launcher، ثم Driver Manager من قسم Tools (الأدوات)؛ ولا تحتاج عملية الاستعادة نفسها إلى الإنترنت.",
      "افتح Backup & Restore واختر نسختك من القائمة، أو اختر مجلدًا أو ملف ZIP.",
      "انقر Restore selected، وإذا كانت النسخة من جهاز آخر، فسيطلب البرنامج تأكيدك أولًا.",
      "أعد تشغيل الجهاز عندما يطلب البرنامج ذلك."
     ]
    },
    {
     "t": {
      "en": "Update your drivers safely",
      "ar": "تحديث التعريفات بأمان"
     },
     "en": [
      "Open Driver Updates and click Check for updates. The app searches Windows Update, the official Microsoft source.",
      "Tick the drivers you want.",
      "Click Install. The app creates a restore point and backs up your current drivers first.",
      "If you do not want a driver offered again, select it and click Hide."
     ],
     "ar": [
      "افتح Driver Updates وانقر Check for updates؛ فيبحث البرنامج في Windows Update، المصدر الرسمي من Microsoft.",
      "حدّد التعريفات التي تريدها.",
      "انقر Install؛ فينشئ البرنامج نقطة استعادة، وينسخ تعريفاتك الحالية احتياطيًا أولًا.",
      "إذا لم تكن تريد ظهور تعريف معيّن مجددًا، فحدّده وانقر Hide."
     ]
    }
   ]
  },
  {
   "id": "SystemInfo",
   "name": "System Info",
   "os": [
    "win",
    "mac"
   ],
   "cat": "tools",
   "icon": "img/system-info.png",
   "versionUrl": "https://raw.githubusercontent.com/kankonq8/my-app-releases/main/apps/SystemInfo/version.json",
   "summary": {
    "en": "System Info shows everything about your computer on one clear page, so you can answer \"what's in my computer?\" in seconds, and copy your specs to send to anyone.",
    "ar": "يعرض برنامج System Info جميع مواصفات جهازك في صفحة واحدة واضحة، لتعرف مكوّنات حاسوبك في ثوانٍ، وتنسخ مواصفاته لترسلها إلى من يسألك عنها."
   },
   "features": {
    "en": [
     "Graphics card: model and video memory (VRAM) in GB, shown big at the top: the same number games show in their settings. Built-in graphics are marked \"Shared with RAM\"; on Apple Silicon it shows the unified memory and GPU cores.",
     "Processor (CPU): full name, cores and threads (performance and efficiency cores on Apple Silicon), maximum speed and architecture.",
     "Memory (RAM): total size, type (DDR4, DDR5, LPDDR5 and others), speed, used slots and each installed module.",
     "Storage: every disk with its brand and model, size, type (SSD or HDD), form factor (M.2 NVMe, 2.5-inch SATA, or built-in on Macs), connection (for example PCIe 4.0 x4 or SATA 6 Gb/s) and the most it can carry, health, spin speed for hard disks, and which drives (C:, D:) are on it, plus the free space on each drive.",
     "Test speed: a button for each disk measures its real read and write speed in MB/s (using a 1 GB temporary file that is deleted afterwards) and shows what is normal for that kind of disk, for example 1,500 to 3,500 MB/s for a PCIe 3.0 NVMe disk.",
     "Screen: resolution, refresh rate (Hz), size in inches and scaling for every screen.",
     "Operating system: Windows or macOS name, version and build, and how long the computer has been running.",
     "Battery (laptops): charge, health %, charge cycles and condition.",
     "Computer: maker and model (for example \"MacBook Air (M2, 2022)\"), motherboard, BIOS and serial number, plus the Wi-Fi and Ethernet adapters.",
     "Copy my specs: one button copies a short, tidy summary, including the disk details and measured speed, to paste in WhatsApp or anywhere. The serial number and MAC addresses are left out.",
     "Save as file: saves the same summary as a text file on the Desktop.",
     "Short plain-language notes explain each part, for example how much RAM is good for games.",
     "English by default, with an Arabic button."
    ],
    "ar": [
     "بطاقة الرسوميات: طرازها وذاكرة الفيديو (VRAM) بالغيغابايت، معروضةً بخطّ كبير في أعلى الصفحة، وهي القيمة نفسها التي تُظهرها الألعاب في إعداداتها. وتُوسَم الرسوميات المدمجة بعبارة Shared with RAM (مشتركة مع الذاكرة)، ويُعرض في أجهزة Apple Silicon حجم الذاكرة الموحّدة وعدد أنوية معالج الرسوميات.",
     "المعالج (CPU): اسمه الكامل، وعدد الأنوية والمسارات (أنوية الأداء والكفاءة في أجهزة Apple Silicon)، وأقصى سرعة له، ومعماريته.",
     "الذاكرة (RAM): حجمها الإجمالي، ونوعها (DDR4 أو DDR5 أو LPDDR5 وغيرها)، وسرعتها، والفتحات المستخدمة، وكل شريحة مركّبة.",
     "التخزين: كل قرص بعلامته التجارية وطرازه وسعته ونوعه (SSD أو HDD)، وشكله (M.2 NVMe، أو SATA بقياس 2.5 بوصة، أو مدمج في أجهزة Mac)، وطريقة توصيله (مثل PCIe 4.0 x4 أو SATA 6 Gb/s) وأقصى سرعة يدعمها، وحالته الصحية، وسرعة دوران الأقراص الصلبة (HDD)، والأقسام (C: وD:) الموجودة عليه، مع المساحة الفارغة في كل قسم.",
     "اختبار السرعة (Test speed): زرّ لكل قرص يقيس سرعته الفعلية في القراءة والكتابة بالميغابايت في الثانية (MB/s)، باستخدام ملف مؤقت حجمه 1 GB يُحذف بعد الاختبار، ويُبيّن السرعة المعتادة لهذا النوع من الأقراص، مثل 1,500 إلى 3,500 MB/s لأقراص PCIe 3.0 NVMe.",
     "الشاشة: الدقّة، ومعدّل التحديث (Hz)، والحجم بالبوصة، ونسبة التكبير لكل شاشة.",
     "نظام التشغيل: اسم Windows أو macOS وإصداره ورقم بنائه، والمدة التي مضت على تشغيل الجهاز.",
     "البطارية (للحواسيب المحمولة): نسبة الشحن، ونسبة صحّة البطارية، وعدد دورات الشحن، وحالتها.",
     "الجهاز: الشركة المصنّعة والطراز (مثل «MacBook Air (M2, 2022)»)، واللوحة الأم، وBIOS، والرقم التسلسلي، إضافةً إلى بطاقات Wi-Fi وEthernet.",
     "نسخ المواصفات (Copy my specs): زر واحد ينسخ ملخّصًا قصيرًا ومرتّبًا يمكنك لصقه في WhatsApp أو في أي مكان، ويتضمّن تفاصيل الأقراص وسرعتها المقيسة، دون الرقم التسلسلي وعناوين MAC.",
     "الحفظ في ملف (Save as file): يحفظ الملخّص نفسه في ملف نصي على سطح المكتب.",
     "ملاحظات قصيرة بلغة مبسّطة تشرح كل مكوّن، مثل مقدار الذاكرة المناسب للألعاب.",
     "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Tools and click Install next to System Info, then Open.",
     "Wait a few seconds while it reads the computer.",
     "Read the four big numbers at the top: processor, graphics memory, RAM and storage. Scroll down for the details.",
     "Click Copy my specs and paste it to the person who asked, or click Save as file.",
     "Click Refresh after changing hardware or connecting a screen."
    ],
    "ar": [
     "افتح Kankon Launcher، وانتقل إلى قسم Tools (الأدوات)، ثم انقر Install بجانب System Info، ثم Open.",
     "انتظر بضع ثوانٍ ريثما يقرأ البرنامج مواصفات الجهاز.",
     "اطّلع على القيم الأربع الكبيرة في الأعلى: المعالج، وذاكرة الرسوميات، والذاكرة (RAM)، والتخزين، ثم مرّر الصفحة للاطّلاع على التفاصيل.",
     "انقر Copy my specs والصق الملخّص لمن سألك عن مواصفات جهازك، أو انقر Save as file.",
     "انقر Refresh بعد تغيير أي قطعة في الجهاز أو توصيل شاشة."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "Or a Mac with macOS 11 Big Sur or newer (Apple Silicon or Intel), through Kankon Launcher for Mac.",
     "No administrator rights and no internet connection needed; nothing is sent anywhere.",
     "Opens from Kankon Launcher only (Tools)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "أو جهاز Mac بنظام macOS 11 Big Sur أو أحدث (بمعالج Apple Silicon أو Intel)، من خلال نسخة Kankon Launcher لأجهزة Mac.",
     "لا يحتاج إلى صلاحيات المسؤول ولا إلى اتصال بالإنترنت، ولا يُرسل أي بيانات إلى أي جهة.",
     "يُفتح من خلال Kankon Launcher فقط، من قسم Tools (الأدوات)."
    ]
   },
   "guides": [
    {
     "t": {
      "en": "Send your specs to a friend",
      "ar": "إرسال مواصفات جهازك إلى صديق"
     },
     "en": [
      "Open System Info from Kankon Launcher (Tools).",
      "Click Copy my specs at the top.",
      "Open WhatsApp (or any chat), paste the message and send it. The serial number and MAC addresses are not included."
     ],
     "ar": [
      "افتح System Info من Kankon Launcher (قسم Tools «الأدوات»).",
      "انقر Copy my specs في أعلى النافذة.",
      "افتح WhatsApp (أو أي تطبيق محادثة)، والصق الرسالة ثم أرسلها. ولا يتضمّن الملخّص الرقم التسلسلي ولا عناوين MAC."
     ]
    },
    {
     "t": {
      "en": "Check if a game will run",
      "ar": "معرفة ما إذا كانت لعبة ما ستعمل على جهازك"
     },
     "en": [
      "Open the game's page and find its minimum and recommended requirements.",
      "In System Info, compare the four big numbers at the top: processor, graphics memory (VRAM), RAM and free storage.",
      "If your graphics memory and RAM are at or above the recommended values, the game should run well."
     ],
     "ar": [
      "افتح صفحة اللعبة واطّلع على متطلباتها الدنيا والموصى بها.",
      "قارن في System Info القيم الأربع الكبيرة في الأعلى: المعالج، وذاكرة الرسوميات (VRAM)، والذاكرة (RAM)، والمساحة الفارغة.",
      "إذا كانت ذاكرة الرسوميات والذاكرة (RAM) مساويتين للقيم الموصى بها أو أعلى منها، فمن المتوقّع أن تعمل اللعبة بصورة جيدة."
     ]
    }
   ],
   "shots": [
    {
     "en": "img/shots/systeminfo/mac-en-01-main.jpg",
     "ar": "img/shots/systeminfo/mac-ar-01-main.jpg",
     "cap": {
      "en": "Everything about a MacBook Pro (M1 Max) on one page: processor, graphics memory, RAM and storage at the top.",
      "ar": "جميع مواصفات جهاز MacBook Pro (M1 Max) في صفحة واحدة: المعالج، وذاكرة الرسوميات، والذاكرة (RAM)، والتخزين في الأعلى."
     }
    }
   ]
  },
  {
   "id": "Dana",
   "name": "Dana",
   "cat": "games",
   "icon": "img/dana.png",
   "site": "https://danakuwait.net",
   "summary": {
    "en": "Dana is an online action role-playing game (MMORPG) set in old Kuwait and the Gulf. Kankon Launcher installs the Dana Launcher, the game's own program that signs you in, downloads the game and keeps it up to date.",
    "ar": "الدانة لعبة أكشن وتقمّص أدوار جماعية عبر الإنترنت (MMORPG)، تدور أحداثها في الكويت والخليج قديمًا. ويثبّت Kankon Launcher برنامج Dana Launcher، وهو المشغّل الخاص باللعبة الذي يتولّى تسجيل الدخول وتنزيل اللعبة وتحديثها."
   },
   "features": {
    "en": [
     "Explore old Kuwait and the Gulf with other players online, on Dana's official server.",
     "Dana Launcher shows the latest game news and the server status.",
     "Sign in with your Dana account (or Google), or create a new account.",
     "Downloads and installs the game for you, and resumes the download if it stops.",
     "Updates the game and itself automatically, so you always play the newest version.",
     "Characters page: see your characters before you start the game.",
     "Starts the game already signed in.",
     "Can check and repair the game files if something is damaged."
    ],
    "ar": [
     "استكشاف الكويت والخليج قديمًا مع لاعبين آخرين عبر الإنترنت، على الخادم الرسمي للعبة.",
     "يعرض Dana Launcher آخر أخبار اللعبة وحالة الخادم.",
     "تسجيل الدخول بحساب الدانة (أو بحساب Google)، أو إنشاء حساب جديد.",
     "تنزيل اللعبة وتثبيتها تلقائيًا، مع استئناف التنزيل إذا توقّف.",
     "تحديث اللعبة والمشغّل تلقائيًا، لتلعب دائمًا بأحدث إصدار.",
     "صفحة الشخصيات: لعرض شخصياتك قبل بدء اللعب.",
     "تشغيل اللعبة مع تسجيل الدخول مسبقًا.",
     "فحص ملفات اللعبة وإصلاحها عند تلف أي منها."
    ]
   },
   "how": {
    "en": [
     "Open Kankon Launcher, go to Games and press Install next to Dana.",
     "Press Open to start the Dana Launcher.",
     "Sign in (or create an account) and let it download the game the first time.",
     "Press Play. Next time just press Open: updates arrive on their own."
    ],
    "ar": [
     "افتح Kankon Launcher، ثم انتقل إلى قسم Games (الألعاب) وانقر Install بجانب Dana.",
     "انقر Open لتشغيل Dana Launcher.",
     "سجّل الدخول (أو أنشئ حسابًا)، واترك المشغّل ينزّل اللعبة في المرة الأولى.",
     "انقر Play. وفي المرات التالية يكفي النقر على Open، إذ تصل التحديثات تلقائيًا."
    ]
   },
   "req": {
    "en": [
     "Windows 10 or 11 (64-bit).",
     "An internet connection and a Dana account.",
     "No administrator rights needed (installs to your Windows user folder).",
     "Arabic and English (switch the language in the Dana Launcher)."
    ],
    "ar": [
     "نظام Windows 10 أو Windows 11 (64-bit).",
     "اتصال بالإنترنت وحساب في الدانة.",
     "لا يحتاج إلى صلاحيات المسؤول (يُثبَّت في مجلد المستخدم).",
     "يدعم العربية والإنجليزية (يُغيَّر من داخل Dana Launcher).",
     "الموقع الرسمي: danakuwait.net"
    ]
   },
   "shots": [
    {
     "src": "img/shots/dana-hero.jpg",
     "cap": {
      "en": "Old Kuwait",
      "ar": "الكويت قديمًا"
     }
    },
    {
     "src": "img/shots/dana-town.jpg",
     "cap": {
      "en": "The town",
      "ar": "الحيّ القديم (الفريج)"
     }
    },
    {
     "src": "img/shots/dana-map.jpg",
     "cap": {
      "en": "The map",
      "ar": "الخريطة"
     }
    },
    {
     "src": "img/shots/dana-underwater.jpg",
     "cap": {
      "en": "Pearl diving",
      "ar": "الغوص على اللؤلؤ"
     }
    },
    {
     "src": "img/shots/dana-caravan.jpg",
     "cap": {
      "en": "Caravans",
      "ar": "القوافل"
     }
    },
    {
     "src": "img/shots/dana-bridge.jpg",
     "cap": {
      "en": "Across the Gulf",
      "ar": "عبر الخليج"
     }
    },
    {
     "src": "img/shots/dana-house.jpg",
     "cap": {
      "en": "Old Kuwaiti houses",
      "ar": "البيوت الكويتية القديمة"
     }
    }
   ],
   "guides": [
    {
     "t": {
      "en": "Install Dana",
      "ar": "تثبيت الدانة"
     },
     "en": [
      "Open Kankon Launcher and go to Games.",
      "Click Install next to Dana. The Dana Launcher is downloaded, verified and installed.",
      "Click Open to start the Dana Launcher."
     ],
     "ar": [
      "افتح Kankon Launcher وانتقل إلى قسم Games (الألعاب).",
      "انقر Install بجانب Dana؛ فيُنزَّل Dana Launcher ويُتحقَّق منه ثم يُثبَّت.",
      "انقر Open لتشغيل Dana Launcher."
     ]
    },
    {
     "t": {
      "en": "Create an account and start playing",
      "ar": "إنشاء حساب وبدء اللعب"
     },
     "en": [
      "In the Dana Launcher, sign in with your Dana account or Google, or create a new account.",
      "The first time, let it download the game. If the download stops, it continues from where it stopped.",
      "Open the Characters page to see your characters.",
      "Click Play. The game starts already signed in."
     ],
     "ar": [
      "في Dana Launcher، سجّل الدخول بحساب الدانة أو بحساب Google، أو أنشئ حسابًا جديدًا.",
      "في المرة الأولى، اتركه ينزّل اللعبة، وإذا انقطع التنزيل فإنه يُستأنف من حيث توقّف.",
      "افتح صفحة الشخصيات لاستعراض شخصياتك.",
      "انقر Play؛ فتبدأ اللعبة وأنت مسجّل الدخول."
     ]
    },
    {
     "t": {
      "en": "Fix a game that does not start",
      "ar": "إصلاح اللعبة إذا لم تعمل"
     },
     "en": [
      "Open the Dana Launcher.",
      "Use the option to check and repair the game files.",
      "Wait until it finishes, then click Play again."
     ],
     "ar": [
      "افتح Dana Launcher.",
      "استخدم خيار فحص ملفات اللعبة وإصلاحها.",
      "انتظر حتى ينتهي، ثم انقر Play مجددًا."
     ]
    }
   ]
  }
 ],
 "updates": [
  {
   "product": "website",
   "version": "1.12.0",
   "date": "2026-11-14",
   "en": ["System Info: disk details and disk speed test added to its page; Updates: System Info 1.1.0."],
   "ar": ["System Info: أُضيفت تفاصيل الأقراص واختبار سرعتها إلى صفحته، وأُضيف الإصدار 1.1.0 إلى التحديثات."]
  },
  {
   "product": "SystemInfo",
   "version": "1.1.0",
   "date": "2026-11-14",
   "en": [
    "Every disk now shows its brand and model, SSD or HDD, form factor, connection and the most it can carry, health, spin speed for hard disks, and which drives are on it.",
    "New Test speed button for each disk: measures real read and write speed in MB/s and shows what is normal for that kind of disk.",
    "Copy my specs now includes the disk details and the measured speed."
   ],
   "ar": [
    "أصبح كل قرص يُظهر علامته التجارية وطرازه، ونوعه (SSD أو HDD)، وشكله، وطريقة توصيله وأقصى سرعة يدعمها، وحالته الصحية، وسرعة دوران الأقراص الصلبة (HDD)، والأقسام الموجودة عليه.",
    "زر جديد باسم Test speed لكل قرص، يقيس سرعته الفعلية في القراءة والكتابة بالميغابايت في الثانية (MB/s)، ويُبيّن السرعة المعتادة لهذا النوع من الأقراص.",
    "أصبح Copy my specs يتضمّن تفاصيل الأقراص وسرعتها المقيسة."
   ]
  },
  {
   "product": "website",
   "version": "1.11.0",
   "date": "2026-11-14",
   "en": ["Kankon Launcher for Mac now runs on Intel Macs too; the Mac button, requirements and guide are updated.", "Updates: Kankon Launcher 2.10.0 added."],
   "ar": ["أصبح Kankon Launcher لأجهزة Mac يعمل أيضًا على الأجهزة ذات معالجات Intel، وحُدِّث زر التنزيل والمتطلبات ودليل التثبيت تبعًا لذلك.", "التحديثات: أُضيف الإصدار 2.10.0 من Kankon Launcher."]
  },
  {
   "product": "launcher",
   "version": "2.10.0",
   "date": "2026-11-14",
   "en": [
    "Mac: one app for every Mac, with Apple Silicon or Intel.",
    "New apps: System Info (Tools) and Network Tools (Networking).",
    "\"My Device\" card on the Home page.",
    "Checks for updates in the background and shows a notification when one is available.",
    "Send report button, to tell Kankon about a problem in a few clicks.",
    "Counts app installs anonymously (no personal data) to show which apps are used most."
   ],
   "ar": [
    "على أجهزة Mac: تطبيق واحد يعمل على جميع الأجهزة، بمعالجات Apple Silicon أو Intel.",
    "برنامجان جديدان: System Info في قسم Tools (الأدوات)، وNetwork Tools في قسم Networking (الشبكات).",
    "بطاقة My Device (جهازي) في الصفحة الرئيسية.",
    "يتحقّق من التحديثات في الخلفية، ويُظهر إشعارًا عند توفّر تحديث.",
    "زر Send report لإبلاغ Kankon بأي مشكلة ببضع نقرات.",
    "يُحصي عمليات تثبيت البرامج دون تحديد هوية المستخدم (أعداد فقط، دون أي بيانات شخصية)، لمعرفة أكثر البرامج استخدامًا."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.1.1",
   "date": "2026-11-14",
   "en": ["Fixed a problem that closed the app on Macs with Intel processors."],
   "ar": ["إصلاح خلل كان يؤدي إلى إغلاق البرنامج على أجهزة Mac ذات معالجات Intel."]
  },
  {
   "product": "website",
   "version": "1.10.0",
   "date": "2026-11-14",
   "en": [
    "New app: System Info, under Tools, with full details and guides."
   ],
   "ar": [
    "برنامج جديد: System Info في قسم Tools (الأدوات)، مع تفاصيله الكاملة وأدلّته."
   ]
  },
  {
   "product": "SystemInfo",
   "version": "1.0.0",
   "date": "2026-11-14",
   "en": [
    "First release for Windows and Mac: processor, graphics card and video memory, RAM, storage, screen, operating system, battery and computer model on one page, with Copy my specs and Save as file."
   ],
   "ar": [
    "الإصدار الأول لنظام Windows ولأجهزة Mac: المعالج، وبطاقة الرسوميات وذاكرتها، والذاكرة (RAM)، والتخزين، والشاشة، ونظام التشغيل، والبطارية، وطراز الجهاز في صفحة واحدة، مع زرّي Copy my specs وSave as file."
   ]
  },
  {
   "product": "website",
   "version": "1.9.3",
   "date": "2026-11-14",
   "en": [
    "Updates: Auto Create IP Config for Mac 1.1.0 added."
   ],
   "ar": [
    "التحديثات: أُضيف الإصدار 1.1.0 من Auto Create IP Config لأجهزة Mac."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "Mac 1.1.0",
   "date": "2026-11-14",
   "en": [
    "The Mac version is now one app for every Mac, with Apple Silicon (M1 and newer) or Intel.",
    "English by default, with an Arabic button, as on Windows."
   ],
   "ar": [
    "أصبحت نسخة Mac تطبيقًا واحدًا يعمل على جميع أجهزة Mac، سواء أكانت بمعالجات Apple Silicon (M1 أو أحدث) أم Intel.",
    "الواجهة باللغة الإنجليزية افتراضيًا، مع زر للتبديل إلى العربية، كما في نسخة Windows."
   ]
  },
  {
   "product": "website",
   "version": "1.9.1",
   "date": "2026-11-14",
   "en": [
    "Network Tools: updated Arabic screenshots."
   ],
   "ar": [
    "Network Tools: تحديث لقطات الشاشة العربية."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.0.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording of the interface refined."
   ],
   "ar": [
    "تحسين الصياغة العربية في واجهة البرنامج."
   ]
  },
  {
   "product": "website",
   "version": "1.9.0",
   "date": "2026-11-14",
   "en": [
    "New app: Network Tools, under Networking, with full details, guides and screenshots."
   ],
   "ar": [
    "برنامج جديد: Network Tools في قسم Networking (الشبكات)، مع تفاصيله الكاملة وأدلّته وصوره."
   ]
  },
  {
   "product": "NetworkTools",
   "version": "1.0.0",
   "date": "2026-11-14",
   "en": [
    "First release: Overview, Speed Test, Ping with live chart, Traceroute, DNS lookup and DNS benchmark, Port Check with presets, and Subnet Calculator."
   ],
   "ar": [
    "الإصدار الأول: نظرة عامة، واختبار السرعة، وPing مع رسم بياني مباشر، وتتبّع المسار، واستعلام DNS ومقارنة خوادمه، وفحص المنافذ بقوائم جاهزة، وحاسبة الشبكات الفرعية."
   ]
  },
  {
   "product": "website",
   "version": "1.8.0",
   "date": "2026-11-14",
   "en": [
    "Anonymous download counting for Windows and Mac (counts only, no personal data)."
   ],
   "ar": [
    "إحصاء عدد مرات التنزيل لنظام Windows ولأجهزة Mac دون تحديد هوية الزائر (أعداد فقط، دون أي بيانات شخصية)."
   ]
  },
  {
   "product": "website",
   "version": "1.7.4",
   "date": "2026-11-14",
   "en": [
    "Updates: Kankon Launcher 2.5 and 2.6 (the Mac version) added."
   ],
   "ar": [
    "التحديثات: أُضيف الإصداران 2.5 و2.6 من Kankon Launcher (نسخة Mac)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.6.0",
   "date": "2026-11-14",
   "en": [
    "Mac: Network Monitor is now available under Networking."
   ],
   "ar": [
    "على أجهزة Mac: أصبح Network Monitor متاحًا في قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "launcher",
   "version": "2.5.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher is now available for Mac (Apple Silicon), with its own download button on this site.",
    "Mac (2.5.1): Auto Create IP Config is available under Networking."
   ],
   "ar": [
    "أصبح Kankon Launcher متاحًا لأجهزة Mac (بمعالجات Apple Silicon)، وله زر تنزيل خاص في هذا الموقع.",
    "على أجهزة Mac (الإصدار 2.5.1): أصبح Auto Create IP Config متاحًا في قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "website",
   "version": "1.7.3",
   "date": "2026-11-14",
   "en": [
    "Network Monitor requirements for Mac added; Arabic wording refined."
   ],
   "ar": [
    "أُضيفت متطلبات Network Monitor على أجهزة Mac، وحُسِّنت الصياغة العربية."
   ]
  },
  {
   "product": "website",
   "version": "1.7.2",
   "date": "2026-11-14",
   "en": [
    "Network Monitor is now marked as available for Windows and Mac."
   ],
   "ar": [
    "أصبحت صفحة Network Monitor تُبيّن توفّره لنظام Windows ولأجهزة Mac."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.2.0",
   "date": "2026-11-14",
   "en": [
    "Now also available for Mac (Apple Silicon and Intel, macOS 12 or newer), with the same features as on Windows.",
    "On the Mac, Setup > Startup offers \"Start when I log in\" instead of \"Start with Windows\"."
   ],
   "ar": [
    "أصبح متاحًا أيضًا لأجهزة Mac (بمعالجات Apple Silicon وIntel، بنظام macOS 12 أو أحدث)، بالمزايا نفسها المتوفّرة على Windows.",
    "على أجهزة Mac، تعرض صفحة Setup > Startup خيار «Start when I log in» بدلًا من «Start with Windows»."
   ]
  },
  {
   "product": "website",
   "version": "1.7.1",
   "date": "2026-11-14",
   "en": [
    "Arabic wording refined."
   ],
   "ar": [
    "تحسين الصياغة العربية."
   ]
  },
  {
   "product": "website",
   "version": "1.7.0",
   "date": "2026-11-14",
   "en": [
    "Separate download buttons for Windows and Mac, each with its logo; the button for your own system is highlighted.",
    "Every app page shows which systems it runs on (Windows, Mac)."
   ],
   "ar": [
    "زرّا تنزيل منفصلان لنظام Windows ولأجهزة Mac، يحمل كلٌّ منهما شعاره، ويُبرَز الزر الخاص بنظام جهازك.",
    "تُبيّن صفحة كل برنامج الأنظمة التي يعمل عليها (Windows وMac)."
   ]
  },
  {
   "product": "website",
   "version": "1.6.1",
   "date": "2026-11-14",
   "en": [
    "Wording of the Mac section and requirements refined."
   ],
   "ar": [
    "تحسين صياغة قسم Mac والمتطلبات."
   ]
  },
  {
   "product": "website",
   "version": "1.6.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher for Mac: a new download button, always pointing to the latest Mac version, and an installation guide for Mac."
   ],
   "ar": [
    "Kankon Launcher لأجهزة Mac: زر تنزيل جديد يشير دائمًا إلى أحدث إصدار لأجهزة Mac، مع دليل لتثبيته عليها."
   ]
  },
  {
   "product": "website",
   "version": "1.5.1",
   "date": "2026-11-14",
   "en": [
    "Wording of the installation guide refined."
   ],
   "ar": [
    "تحسين صياغة دليل التثبيت."
   ]
  },
  {
   "product": "website",
   "version": "1.5.0",
   "date": "2026-11-14",
   "en": [
    "Kankon Launcher is now downloaded as a zip file (AppsLauncher-Setup.zip), which avoids the browser warning; the installation guide is updated accordingly.",
    "Updates: Kankon Launcher 2.4.0 added."
   ],
   "ar": [
    "أصبح Kankon Launcher يُنزَّل في ملف مضغوط (AppsLauncher-Setup.zip) تفاديًا لتحذير المتصفّح، وحُدِّث دليل التثبيت وفقًا لذلك.",
    "التحديثات: أُضيف الإصدار 2.4.0 من Kankon Launcher."
   ]
  },
  {
   "product": "launcher",
   "version": "2.4.0",
   "date": "2026-11-14",
   "en": [
    "New Home page: a welcome banner, stat cards, quick access to your apps, section cards and a tip of the day.",
    "A more modern design throughout the window.",
    "New kankon.net button in the side menu."
   ],
   "ar": [
    "صفحة رئيسية جديدة تضمّ: لافتة ترحيب، وبطاقات إحصائية، ووصولًا سريعًا إلى برامجك، وبطاقات للأقسام، ونصيحة اليوم.",
    "تصميم أحدث في أرجاء النافذة كلّها.",
    "زر جديد باسم kankon.net في القائمة الجانبية."
   ]
  },
  {
   "product": "website",
   "version": "1.4.0",
   "date": "2026-11-14",
   "en": [
    "Games: a new list of the best MMORPG, Action RPG and Strategy games, with official links.",
    "The site now updates itself on the server within minutes of each new version."
   ],
   "ar": [
    "الألعاب: قائمة جديدة بأفضل ألعاب الأدوار الجماعية، والأدوار والحركة، والاستراتيجية، مع روابطها الرسمية.",
    "أصبح الموقع يُحدَّث تلقائيًا على الخادم خلال دقائق من صدور كل إصدار جديد."
   ]
  },
  {
   "product": "website",
   "version": "1.3.0",
   "date": "2026-11-14",
   "en": [
    "New AI section: the most important AI programs with official links and a short description of each.",
    "kankon.net is now online."
   ],
   "ar": [
    "قسم جديد للذكاء الاصطناعي: أهم برامج الذكاء الاصطناعي مع روابطها الرسمية ووصف موجز لكل منها.",
    "أصبح موقع kankon.net متاحًا على الإنترنت."
   ]
  },
  {
   "product": "launcher",
   "version": "2.1.0",
   "date": "2026-11-13",
   "en": [
    "New name: Kankon Launcher (window, side menu, setup and shortcuts). Your existing install updates as usual.",
    "A \"by Kankon · kankon.net\" line in the footer and in every app's Details page."
   ],
   "ar": [
    "الاسم الجديد: Kankon Launcher (في النافذة والقائمة الجانبية وملف التثبيت والاختصارات)، ويستمر التحديث التلقائي للنسخ المثبّتة كالمعتاد.",
    "سطر «من Kankon · kankon.net» في أسفل النافذة وفي صفحة تفاصيل كل برنامج."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.1.0",
   "date": "2026-11-13",
   "en": [
    "Find the switch: Setup can now look for managed switches on the network.",
    "Daily usage limit per device, with an alert and a phone notice when it is passed.",
    "Internet outages: checked every 15 seconds and logged with their duration, with an alert when the connection is back.",
    "Weekly summary every Friday (top devices, home internet, outages), with a \"Send one now\" button.",
    "\"by Kankon · kankon.net\" in the window footer and Setup."
   ],
   "ar": [
    "البحث عن المحوّل: أصبح بإمكان صفحة الإعدادات البحث عن المحوّلات المُدارة في الشبكة.",
    "حد يومي للاستهلاك لكل جهاز، مع تنبيه وإشعار على الهاتف عند تجاوزه.",
    "انقطاعات الإنترنت: فحص كل 15 ثانية وتسجيل كل انقطاع ومدته، مع تنبيه عند عودة الاتصال.",
    "ملخص أسبوعي كل يوم جمعة (أكثر الأجهزة استهلاكًا، والإنترنت المنزلي، والانقطاعات)، مع زر «إرسال الآن».",
    "سطر «من Kankon · kankon.net» أسفل النافذة وفي الإعدادات."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.6.0",
   "date": "2026-11-13",
   "en": [
    "\"by Kankon · kankon.net\" line at the bottom of the window.",
    "Improved Arabic wording across the app."
   ],
   "ar": [
    "سطر «من Kankon · kankon.net» أسفل النافذة.",
    "تحسين الصياغة العربية في البرنامج كله."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.2.0",
   "date": "2026-11-13",
   "en": [
    "\"by Kankon · kankon.net\" line at the bottom of the window; clicking it opens kankon.net."
   ],
   "ar": [
    "سطر «من Kankon · kankon.net» أسفل النافذة، ويفتح الموقع عند النقر عليه."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.7",
   "date": "2026-11-13",
   "en": [
    "Network Monitor added under Networking."
   ],
   "ar": [
    "إضافة Network Monitor إلى قسم Networking (الشبكات)."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.3",
   "date": "2026-11-13",
   "en": [
    "Setup warns when the switch address typed is this PC instead of the switch."
   ],
   "ar": [
    "تنبيه في الإعدادات عند إدخال عنوان هذا الجهاز بدلًا من عنوان المحوّل."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.2",
   "date": "2026-11-13",
   "en": [
    "Setup shows which address to allow in the switch's SNMP settings, so the app works from any PC."
   ],
   "ar": [
    "تعرض الإعدادات العنوان الواجب السماح له في إعدادات SNMP بالمحوّل، ليعمل البرنامج من أي جهاز."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.1",
   "date": "2026-11-13",
   "en": [
    "Setup shows \"Connecting…\" during the first switch reading, and the reason when it fails.",
    "Improved Arabic wording."
   ],
   "ar": [
    "تعرض الإعدادات عبارة «جارٍ الاتصال…» أثناء القراءة الأولى من المحوّل، وسبب الفشل إن حدث.",
    "تحسين الصياغة العربية."
   ]
  },
  {
   "product": "NetworkMonitor",
   "version": "1.0.0",
   "date": "2026-11-13",
   "en": [
    "Network Monitor is now an installed Windows app that opens from Kankon Launcher (Networking), in its own window.",
    "Everything it needs is built in: nothing else to install.",
    "New Setup page: Router, Switch, Phone alerts, Password and Start with Windows.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "أصبح Network Monitor برنامجًا مثبّتًا على Windows يُفتح من Kankon Launcher (قسم Networking «الشبكات») في نافذة مستقلة.",
    "كل ما يحتاجه مدمج فيه، فلا حاجة إلى تثبيت أي شيء آخر.",
    "صفحة إعدادات جديدة: جهاز التوجيه، والمحوّل، وتنبيهات الهاتف، وكلمة المرور، والتشغيل مع Windows.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتحويل إلى العربية."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.6",
   "date": "2026-11-13",
   "en": [
    "New game: Dana (Games). Install downloads the Dana Launcher, checks it and installs it; Update appears when a newer one is out."
   ],
   "ar": [
    "لعبة جديدة: «الدانة» في قسم Games (الألعاب). يُنزّل زر Install برنامج Dana Launcher ويتحقق منه ثم يثبّته، ويظهر زر Update عند صدور إصدار أحدث."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.5",
   "date": "2026-11-13",
   "en": [
    "Translation improvements in the launcher."
   ],
   "ar": [
    "تحسين الترجمة العربية في واجهة المشغّل."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.5.2",
   "date": "2026-11-13",
   "en": [
    "On Wi-Fi, the network name is suggested as the name of a new saved profile."
   ],
   "ar": [
    "عند الاتصال بشبكة Wi-Fi، يُقترح اسم الشبكة اسمًا للإعداد المحفوظ الجديد."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.1.2",
   "date": "2026-11-13",
   "en": [
    "Arabic wording aligned with the other Kankon apps."
   ],
   "ar": [
    "توحيد الصياغة العربية مع برامج Kankon الأخرى."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.1.1",
   "date": "2026-11-13",
   "en": [
    "Hide drivers you do not want, with a button to show them again.",
    "Automatic backup of the current drivers before installing updates.",
    "Keeps only the last 3 backups of this PC.",
    "Fix: the app now opens correctly from the launcher."
   ],
   "ar": [
    "إخفاء التعريفات غير المرغوب فيها، مع زر لإظهارها مجددًا.",
    "نسخ احتياطي تلقائي للتعريفات الحالية قبل تثبيت التحديثات.",
    "الاحتفاظ بآخر 3 نسخ احتياطية فقط لهذا الجهاز.",
    "إصلاح: أصبح البرنامج يُفتح من المشغّل بشكل صحيح."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.4",
   "date": "2026-11-13",
   "en": [
    "Every app has a Details page with a full description in English and Arabic."
   ],
   "ar": [
    "صفحة تفاصيل لكل برنامج، تتضمن وصفًا كاملًا بالعربية والإنجليزية."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.5.0",
   "date": "2026-11-13",
   "en": [
    "Saves the previous settings and reverts automatically if the gateway does not reply.",
    "Connection test after every change, quick DNS buttons and Copy settings.",
    "Export and import of saved profiles."
   ],
   "ar": [
    "حفظ الإعدادات السابقة والعودة إليها تلقائيًا إذا لم تستجب البوابة.",
    "اختبار للاتصال بعد كل تغيير، وأزرار DNS سريعة، وزر لنسخ الإعدادات.",
    "تصدير الإعدادات المحفوظة واستيرادها."
   ]
  },
  {
   "product": "DriverManager",
   "version": "1.0.0",
   "date": "2026-11-13",
   "en": [
    "First release as an installed app in Kankon Launcher (Tools).",
    "Backup & Restore as the main screen, restore straight from a ZIP file.",
    "Driver updates from Windows Update with a restore point, installed drivers list with CSV export.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "الإصدار الأول برنامجًا مثبّتًا ضمن Kankon Launcher (قسم Tools «الأدوات»).",
    "النسخ الاحتياطي والاستعادة في الشاشة الرئيسية، مع الاستعادة مباشرة من ملف ZIP.",
    "تحديث التعريفات من Windows Update مع نقطة استعادة، وقائمة التعريفات المثبّتة مع التصدير إلى CSV.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتحويل إلى العربية."
   ]
  },
  {
   "product": "AutoIpConfig",
   "version": "1.4.0",
   "date": "2026-11-13",
   "en": [
    "Network scan: free and used IP addresses with device names, and the closest free address picked for you."
   ],
   "ar": [
    "فحص الشبكة: العناوين المتاحة والمستخدمة مع أسماء الأجهزة، واقتراح أقرب عنوان متاح."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.3",
   "date": "2026-11-13",
   "en": [
    "Driver Manager added under Tools.",
    "Fix for the side menu colours."
   ],
   "ar": [
    "إضافة Driver Manager إلى قسم Tools (الأدوات).",
    "إصلاح ألوان القائمة الجانبية."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.2",
   "date": "2026-11-13",
   "en": [
    "New side menu with Apps, Games, Tools and Networking.",
    "Auto Create IP Config built in under Networking.",
    "New launcher icon."
   ],
   "ar": [
    "قائمة جانبية جديدة تضم: البرامج، والألعاب، والأدوات، والشبكات.",
    "دمج Auto Create IP Config في قسم Networking (الشبكات).",
    "أيقونة جديدة للمشغّل."
   ]
  },
  {
   "product": "launcher",
   "version": "2.0.0",
   "date": "2026-11-13",
   "en": [
    "A new desktop app with a small setup file, Start menu and desktop shortcuts, and an uninstaller.",
    "Updates itself and installs and updates your apps, with every file verified first.",
    "English by default with an Arabic button."
   ],
   "ar": [
    "برنامج سطح مكتب جديد بملف تثبيت صغير، مع اختصارات في قائمة «ابدأ» وعلى سطح المكتب، وأداة لإزالة التثبيت.",
    "يحدّث نفسه ويثبّت برامجك ويحدّثها، مع التحقق من كل ملف قبل تثبيته.",
    "الواجهة بالإنجليزية افتراضيًا مع زر للتحويل إلى العربية."
   ]
  }
 ],
 "ai": [
  {
   "id": "chatgpt",
   "name": "ChatGPT",
   "by": "OpenAI",
   "color": "#10a37f",
   "url": "https://chatgpt.com",
   "dl": "https://openai.com/chatgpt/download/",
   "en": "The best-known AI assistant. Ask questions, write and improve texts, translate, summarize files and create images. Has a Windows app.",
   "ar": "أشهر مساعد ذكاء اصطناعي؛ يجيب عن الأسئلة، ويكتب النصوص ويحسّنها، ويترجم، ويلخّص الملفات، وينشئ الصور. ويتوفّر له تطبيق لنظام Windows."
  },
  {
   "id": "claude",
   "name": "Claude",
   "by": "Anthropic",
   "color": "#d97757",
   "url": "https://claude.ai",
   "dl": "https://claude.ai/download",
   "en": "A careful assistant for writing, analysis and programming. Reads long documents and helps with code. Has a Windows app.",
   "ar": "مساعد دقيق في الكتابة والتحليل والبرمجة، يقرأ المستندات الطويلة ويلخّصها ويحلّلها. ويتوفّر له تطبيق لنظام Windows."
  },
  {
   "id": "gemini",
   "name": "Gemini",
   "by": "Google",
   "color": "#4285f4",
   "url": "https://gemini.google.com",
   "en": "Google's AI assistant, connected to Google search, Gmail, Drive and YouTube. Works in the browser.",
   "ar": "مساعد Google للذكاء الاصطناعي، يرتبط بمحرّك بحث Google وبخدمات Gmail وDrive وYouTube، ويعمل من المتصفح."
  },
  {
   "id": "copilot",
   "name": "Microsoft Copilot",
   "by": "Microsoft",
   "color": "#2b88d8",
   "url": "https://copilot.microsoft.com",
   "en": "Microsoft's AI assistant, built into Windows 11, Edge and Microsoft 365 (Word, Excel, Outlook).",
   "ar": "مساعد Microsoft للذكاء الاصطناعي، مدمج في Windows 11 ومتصفح Edge وتطبيقات Microsoft 365 (Word وExcel وOutlook)."
  },
  {
   "id": "perplexity",
   "name": "Perplexity",
   "by": "Perplexity AI",
   "color": "#20808d",
   "url": "https://www.perplexity.ai",
   "en": "An AI search engine: ask anything and get a short answer with links to its sources.",
   "ar": "محرّك بحث بالذكاء الاصطناعي: اطرح أي سؤال، واحصل على إجابة موجزة مع روابط مصادرها."
  },
  {
   "id": "githubcopilot",
   "name": "GitHub Copilot",
   "by": "GitHub",
   "color": "#8957e5",
   "url": "https://github.com/features/copilot",
   "en": "An AI helper for programmers inside Visual Studio and VS Code: suggests code, explains it and fixes errors.",
   "ar": "مساعد للمبرمجين داخل Visual Studio وVS Code؛ يقترح الشيفرة البرمجية ويشرحها ويصلح أخطاءها."
  },
  {
   "id": "ollama",
   "name": "Ollama",
   "by": "Ollama",
   "color": "#9ca3af",
   "url": "https://ollama.com",
   "dl": "https://ollama.com/download",
   "en": "Run open AI models (such as Llama and Gemma) on your own PC, without internet and without sending your data anywhere.",
   "ar": "يشغّل نماذج الذكاء الاصطناعي المفتوحة (مثل Llama وGemma) على جهازك، دون اتصال بالإنترنت ودون إرسال بياناتك إلى أي جهة."
  },
  {
   "id": "lmstudio",
   "name": "LM Studio",
   "by": "LM Studio",
   "color": "#6366f1",
   "url": "https://lmstudio.ai",
   "dl": "https://lmstudio.ai",
   "en": "An easy desktop app to download and chat with open AI models on your PC, fully offline.",
   "ar": "تطبيق سهل لسطح المكتب لتنزيل نماذج الذكاء الاصطناعي المفتوحة والمحادثة معها على جهازك، دون الحاجة إلى الإنترنت."
  }
 ],
 "gameGroups": [
  {
   "id": "mmo",
   "en": "MMORPG",
   "ar": "ألعاب الأدوار الجماعية (MMORPG)"
  },
  {
   "id": "arpg",
   "en": "Action RPG",
   "ar": "ألعاب الأدوار والحركة (Action RPG)"
  },
  {
   "id": "strategy",
   "en": "Strategy",
   "ar": "ألعاب الاستراتيجية (Strategy)"
  }
 ],
 "games": [
  {
   "group": "mmo",
   "name": "World of Warcraft",
   "by": "Blizzard",
   "color": "#f8b700",
   "url": "https://worldofwarcraft.blizzard.com",
   "free": false,
   "en": "The most famous MMORPG: a huge fantasy world, raids, dungeons and battles between the Alliance and the Horde.",
   "ar": "أشهر لعبة أدوار جماعية: عالم خيالي ضخم، وغارات وزنزانات، ومعارك بين التحالف (Alliance) والحشد (Horde).",
   "mono": "WoW"
  },
  {
   "group": "mmo",
   "name": "Final Fantasy XIV",
   "by": "Square Enix",
   "color": "#3b6fd8",
   "url": "https://www.finalfantasyxiv.com",
   "free": false,
   "en": "A story-rich MMORPG with a large, friendly community. The free trial covers a big part of the game.",
   "ar": "لعبة أدوار جماعية غنية بالقصة، ومجتمعها كبير وودود، وتغطي النسخة التجريبية المجانية جزءًا كبيرًا منها.",
   "mono": "FF"
  },
  {
   "group": "mmo",
   "name": "Guild Wars 2",
   "by": "ArenaNet",
   "color": "#c0392b",
   "url": "https://www.guildwars2.com",
   "free": true,
   "en": "Fast action combat and big world events, with no monthly fee. The core game is free.",
   "ar": "قتال سريع وأحداث جماعية كبيرة في العالم، دون اشتراك شهري، واللعبة الأساسية مجانية.",
   "mono": "GW2"
  },
  {
   "group": "mmo",
   "name": "Black Desert",
   "by": "Pearl Abyss",
   "color": "#8e44ad",
   "url": "https://www.playblackdesert.com",
   "free": false,
   "en": "Beautiful graphics and fast action combat, with trading, crafting and sailing.",
   "ar": "رسوميات جميلة وقتال حركي سريع، مع التجارة والحِرف والإبحار.",
   "mono": "BD"
  },
  {
   "group": "mmo",
   "name": "The Elder Scrolls Online",
   "by": "ZeniMax Online",
   "color": "#b08d57",
   "url": "https://www.elderscrollsonline.com",
   "free": false,
   "en": "Explore the world of Skyrim and Tamriel with friends, with a full story for solo players too.",
   "ar": "استكشف عالم Skyrim وTamriel مع أصدقائك، مع قصة كاملة لمن يفضّل اللعب منفردًا.",
   "mono": "ESO"
  },
  {
   "group": "arpg",
   "name": "Path of Exile 2",
   "by": "Grinding Gear Games",
   "color": "#c9a227",
   "url": "https://pathofexile2.com",
   "free": true,
   "en": "Dark action RPG with deep character builds and endless loot. Free to play.",
   "ar": "لعبة أدوار وحركة ذات أجواء قاتمة، تتيح بناء الشخصيات بعمق، وغنائمها لا تنتهي، وهي مجانية.",
   "mono": "PoE"
  },
  {
   "group": "arpg",
   "name": "Diablo IV",
   "by": "Blizzard",
   "color": "#a31515",
   "url": "https://diablo4.blizzard.com",
   "free": false,
   "en": "Fight the forces of hell alone or with friends in a dark open world.",
   "ar": "قاتل قوى الجحيم وحدك أو مع أصدقائك في عالم مفتوح مظلم.",
   "mono": "D4"
  },
  {
   "group": "arpg",
   "name": "Elden Ring",
   "by": "FromSoftware",
   "color": "#c8a951",
   "url": "https://en.bandainamcoent.eu/elden-ring",
   "free": false,
   "en": "A challenging open world full of secrets, huge bosses and freedom to explore.",
   "ar": "عالم مفتوح مليء بالتحدي والأسرار والزعماء العمالقة، مع حرية كاملة في الاستكشاف.",
   "mono": "ER"
  },
  {
   "group": "arpg",
   "name": "Monster Hunter Wilds",
   "by": "Capcom",
   "color": "#2e8b57",
   "url": "https://www.monsterhunter.com/wilds/",
   "free": false,
   "en": "Hunt giant monsters alone or with up to three friends, and craft gear from what you hunt.",
   "ar": "اصطد وحوشًا عملاقة وحدك أو مع ما يصل إلى ثلاثة أصدقاء، واصنع عتادك مما تصطاده.",
   "mono": "MH"
  },
  {
   "group": "arpg",
   "name": "Genshin Impact",
   "by": "HoYoverse",
   "color": "#4fa3e0",
   "url": "https://genshin.hoyoverse.com",
   "free": true,
   "en": "A colorful open world with elemental combat and many characters. Free to play.",
   "ar": "عالم مفتوح ملوّن، وقتال يعتمد على العناصر، وشخصيات كثيرة، وهي مجانية.",
   "mono": "GI"
  },
  {
   "group": "strategy",
   "name": "Age of Empires IV",
   "by": "Microsoft",
   "color": "#c97c2b",
   "url": "https://www.ageofempires.com",
   "free": false,
   "en": "Classic real-time strategy: build your empire, gather resources and lead armies through history.",
   "ar": "استراتيجية كلاسيكية في الوقت الحقيقي: ابنِ إمبراطوريتك، واجمع الموارد، وقُد الجيوش عبر التاريخ.",
   "mono": "AoE"
  },
  {
   "group": "strategy",
   "name": "Civilization VII",
   "by": "Firaxis / 2K",
   "color": "#2c6e9b",
   "url": "https://civilization.2k.com",
   "free": false,
   "en": "Turn-based strategy: guide a civilization from the first city to the modern age.",
   "ar": "استراتيجية بنظام الأدوار: قُد حضارة من أول مدينة حتى العصر الحديث.",
   "mono": "Civ"
  },
  {
   "group": "strategy",
   "name": "StarCraft II",
   "by": "Blizzard",
   "color": "#1f6fd1",
   "url": "https://starcraft2.blizzard.com",
   "free": true,
   "en": "Fast competitive sci-fi strategy. The multiplayer and first campaign are free.",
   "ar": "استراتيجية خيال علمي سريعة وتنافسية، واللعب الجماعي والحملة الأولى مجانيان.",
   "mono": "SC2"
  },
  {
   "group": "strategy",
   "name": "Total War: Warhammer III",
   "by": "Creative Assembly",
   "color": "#8b1e1e",
   "url": "https://www.totalwar.com",
   "free": false,
   "en": "Huge real-time battles with fantasy armies, plus a turn-based campaign map.",
   "ar": "معارك ضخمة في الوقت الحقيقي بجيوش خيالية، مع خريطة حملة بنظام الأدوار.",
   "mono": "TW"
  },
  {
   "group": "strategy",
   "name": "Age of Empires II: Definitive Edition",
   "by": "Microsoft",
   "color": "#a0522d",
   "url": "https://www.ageofempires.com",
   "free": false,
   "en": "The legendary medieval strategy game, remastered with new graphics and online play.",
   "ar": "لعبة الاستراتيجية الأسطورية في العصور الوسطى، بنسخة محسّنة ورسوميات جديدة ولعب عبر الإنترنت.",
   "mono": "AoE2"
  }
 ]
};
