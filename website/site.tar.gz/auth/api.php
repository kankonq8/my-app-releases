<?php
// Kankon accounts API: https://kankon.net/auth/api.php?a=<action>   (JSON in, JSON out)
require_once dirname(__DIR__) . '/auth-lib.php';
require_once dirname(__DIR__) . '/mail-lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out($code, $arr) { http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function clean($s, $max) { $s = is_string($s) ? preg_replace('/\p{C}+/u', ' ', $s) : ''; return substr(trim($s), 0, $max); }

$raw = file_get_contents('php://input', false, null, 0, 20000);
$in = json_decode($raw ?: '[]', true); if (!is_array($in)) $in = [];
$a = $_GET['a'] ?? '';
$ip = auth_ip();

try {
    $db = auth_db();
    $now = time();

    if ($a === 'request') {
        $email = strtolower(clean($in['email'] ?? '', 120));
        $lang = ($in['lang'] ?? 'en') === 'ar' ? 'ar' : 'en';
        if (!auth_valid_email($email)) out(400, ['ok' => false, 'error' => 'invalid_email']);
        if (!auth_rate('req-ip-' . $ip, 10, 3600) || !auth_rate('req-em-' . $email, 5, 3600)) out(429, ['ok' => false, 'error' => 'too_many']);
        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $db->prepare('REPLACE INTO codes(email,code_hash,expires,attempts) VALUES(?,?,?,0)')->execute([$email, auth_h($email . '|' . $code), $now + CODE_TTL]);
        if ($lang === 'ar') {
            $subj = 'رمز الدخول إلى Kankon: ' . $code;
            $body = '<p dir="rtl">رمز الدخول الخاص بك:</p><p style="font-size:32px;letter-spacing:6px;font-weight:700;direction:ltr;text-align:center">' . $code . '</p><p dir="rtl">الرمز صالح لمدة 10 دقائق. إذا لم تطلبه فتجاهل هذه الرسالة.</p>';
            $title = 'تسجيل الدخول';
        } else {
            $subj = 'Your Kankon sign-in code: ' . $code;
            $body = '<p>Your sign-in code:</p><p style="font-size:32px;letter-spacing:6px;font-weight:700;text-align:center">' . $code . '</p><p>The code is valid for 10 minutes. If you did not request it, ignore this email.</p>';
            $title = 'Sign in';
        }
        $sent = send_mail($email, $subj, kankon_mail_wrap($title, $body));
        out($sent ? 200 : 503, ['ok' => $sent, 'error' => $sent ? null : 'mail_failed']);
    }

    if ($a === 'verify') {
        $email = strtolower(clean($in['email'] ?? '', 120));
        $code = preg_replace('/\D/', '', (string)($in['code'] ?? ''));
        $dev = clean($in['device_id'] ?? '', 80);
        if (!auth_valid_email($email) || strlen($code) !== 6) out(400, ['ok' => false, 'error' => 'invalid']);
        if (!auth_rate('ver-ip-' . $ip, 30, 3600)) out(429, ['ok' => false, 'error' => 'too_many']);
        $st = $db->prepare('SELECT * FROM codes WHERE email=?'); $st->execute([$email]);
        $c = $st->fetch(PDO::FETCH_ASSOC);
        if (!$c || $c['expires'] < $now || $c['attempts'] >= 5) out(401, ['ok' => false, 'error' => 'expired']);
        $db->prepare('UPDATE codes SET attempts=attempts+1 WHERE email=?')->execute([$email]);
        if (!hash_equals($c['code_hash'], auth_h($email . '|' . $code))) out(401, ['ok' => false, 'error' => 'wrong_code']);
        $db->prepare('DELETE FROM codes WHERE email=?')->execute([$email]);
        $platform = clean($in['platform'] ?? '', 20); $lv = clean($in['launcher_version'] ?? '', 20); $lang = ($in['lang'] ?? '') === 'ar' ? 'ar' : 'en';
        $st = $db->prepare('SELECT id,status FROM users WHERE email=?'); $st->execute([$email]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if ($u && $u['status'] !== 'active') out(403, ['ok' => false, 'error' => 'suspended']);
        if (!$u) {
            $db->prepare('INSERT INTO users(email,created_at,last_login,lang,platform,launcher_version) VALUES(?,?,?,?,?,?)')->execute([$email, $now, $now, $lang, $platform, $lv]);
            $uid = (int)$db->lastInsertId();
        } else {
            $uid = (int)$u['id'];
            $db->prepare('UPDATE users SET last_login=?, lang=?, platform=?, launcher_version=? WHERE id=?')->execute([$now, $lang, $platform, $lv, $uid]);
        }
        $token = auth_rand(32);
        $exp = $now + SESSION_DAYS * 86400;
        $db->prepare('INSERT INTO sessions(user_id,token_hash,created_at,last_seen,expires,device_id) VALUES(?,?,?,?,?,?)')->execute([$uid, auth_h($token), $now, $now, $exp, $dev]);
        if ($dev !== '') $db->prepare('INSERT INTO devices(device_id,first_seen,last_seen,user_id) VALUES(?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET user_id=excluded.user_id,last_seen=excluded.last_seen')->execute([$dev, $now, $now, $uid]);
        out(200, ['ok' => true, 'token' => $token, 'email' => $email, 'expires_at' => $exp]);
    }

    if ($a === 'trial') {
        $dev = clean($in['device_id'] ?? '', 80);
        if (strlen($dev) < 16) out(400, ['ok' => false, 'error' => 'invalid_device']);
        if (!auth_rate('trial-ip-' . $ip, 60, 3600)) out(429, ['ok' => false, 'error' => 'too_many']);
        $st = $db->prepare('SELECT first_seen,user_id FROM devices WHERE device_id=?'); $st->execute([$dev]);
        $d = $st->fetch(PDO::FETCH_ASSOC);
        if (!$d) { $db->prepare('INSERT INTO devices(device_id,first_seen,last_seen) VALUES(?,?,?)')->execute([$dev, $now, $now]); $first = $now; $reg = false; }
        else { $db->prepare('UPDATE devices SET last_seen=? WHERE device_id=?')->execute([$now, $dev]); $first = (int)$d['first_seen']; $reg = !empty($d['user_id']); }
        $left = max(0, (int)ceil(($first + TRIAL_DAYS * 86400 - $now) / 86400));
        out(200, ['ok' => true, 'started_at' => $first, 'ends_at' => $first + TRIAL_DAYS * 86400, 'days_left' => $left, 'expired' => $left === 0, 'registered' => $reg, 'server_time' => $now]);
    }

    // everything below needs a session token
    $user = auth_verify(auth_bearer());
    if (!$user) out(401, ['ok' => false, 'error' => 'unauthorized']);

    if ($a === 'me') out(200, ['ok' => true, 'email' => $user['email'], 'status' => 'active', 'server_time' => $now]);

    if ($a === 'ping') {
        $apps = is_array($in['apps'] ?? null) ? array_slice($in['apps'], 0, 5) : [];
        foreach ($apps as $app) {
            $app = clean($app, 60); if ($app === '') continue;
            $db->prepare('INSERT INTO usage(user_id,app,last_used,n) VALUES(?,?,?,1) ON CONFLICT(user_id,app) DO UPDATE SET last_used=excluded.last_used,n=n+1')->execute([$user['uid'], $app, $now]);
        }
        $db->prepare('UPDATE users SET last_login=? WHERE id=?')->execute([$now, $user['uid']]);
        out(200, ['ok' => true]);
    }

    if ($a === 'logout') {
        $db->prepare('DELETE FROM sessions WHERE token_hash=?')->execute([auth_h(auth_bearer())]);
        out(200, ['ok' => true]);
    }

    out(404, ['ok' => false, 'error' => 'unknown_action']);
} catch (Throwable $e) {
    out(500, ['ok' => false, 'error' => 'server']);
}
