<?php
// Kankon problem-report relay (kankon.net/report.php).
// Receives a report from Kankon Launcher / Kankon apps and files it as a GitHub issue in the PRIVATE repo.
// The GitHub token lives ONLY in report-config.php on the NAS (never in the apps, never in the public site package):
//   <?php return ['token' => 'github_pat_...', 'repo' => 'kankonq8/my-app'];
// Protection: client header, honeypot, size limits, per-IP and global rate limits, duplicate check, strict validation.

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

const MAX_BODY   = 6 * 1024 * 1024;   // whole request
const MAX_SHOT   = 3 * 1024 * 1024;   // screenshot (decoded)
const MAX_LOG    = 150000;            // chars of log text
const PER_HOUR   = 5;                 // reports per IP per hour
const PER_DAY    = 15;                // reports per IP per day
const GLOBAL_DAY = 200;               // reports per day for everybody
const MIN_GAP    = 20;                // seconds between two reports from one IP
const KEEP_DAYS  = 60;                // screenshots/logs older than this are deleted

// Web Station PHP profiles may lack mbstring: small fallbacks so the relay still works
if (!function_exists('mb_strlen')) { function mb_strlen($s, $e = null) { return preg_match_all('/./su', $s); } }
if (!function_exists('mb_substr')) { function mb_substr($s, $st, $len = null, $e = null) { preg_match_all('/./su', $s, $m); return implode('', array_slice($m[0], $st, $len)); } }
function out($code, $arr) { http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function clean($s, $max, $multiline = false) {
    $s = is_string($s) ? $s : '';
    $s = str_replace("\0", '', $s);
    $s = $multiline ? preg_replace('/[^\P{C}\n\t]/u', '', str_replace("\r\n", "\n", $s)) : trim(preg_replace('/\s+/u', ' ', preg_replace('/\p{C}+/u', ' ', $s)));
    if (function_exists('mb_substr')) $s = mb_substr($s, 0, $max, 'UTF-8'); else $s = substr($s, 0, $max);
    return $s;
}
// stop @mentions and auto-links from pinging/cross-referencing people
function safe($s) { return str_replace(['@', '://'], ["@\u{200B}", ":/\u{200B}/"], $s); }
function fence($s) { $f = '~~~~~~'; while (strpos($s, $f) !== false) $f .= '~'; return $f . "\n" . $s . "\n" . $f; }

$cfgFile = __DIR__ . '/report-config.php';
$cfg = is_file($cfgFile) ? (include $cfgFile) : null;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {            // health check used by the launcher/diagnostics
    out(200, ['ok' => true, 'service' => 'kankon-report', 'configured' => is_array($cfg) && !empty($cfg['token']), 'curl' => function_exists('curl_init'), 'writable' => is_writable(__DIR__) && is_writable(sys_get_temp_dir()), 'php' => PHP_VERSION]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(405, ['ok' => false, 'error' => 'method']);
if (!is_array($cfg) || empty($cfg['token']) || empty($cfg['repo'])) out(503, ['ok' => false, 'error' => 'not_configured']);

$client = $_SERVER['HTTP_X_KANKON_CLIENT'] ?? '';
if (!preg_match('~^KankonLauncher/\d+\.\d+\.\d+ \((Windows|macOS|Linux)\)$~', $client)) out(403, ['ok' => false, 'error' => 'client']);
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > MAX_BODY) out(413, ['ok' => false, 'error' => 'too_large']);
$raw = file_get_contents('php://input', false, null, 0, MAX_BODY + 1);
if ($raw === false || strlen($raw) > MAX_BODY) out(413, ['ok' => false, 'error' => 'too_large']);
$in = json_decode($raw, true);
if (!is_array($in)) out(400, ['ok' => false, 'error' => 'json']);
if (!empty($in['website'])) out(200, ['ok' => true, 'ref' => 'KR-0']);   // honeypot: pretend success to bots

// ---------- rate limits (files in the system temp dir, no personal data: IP is hashed) ----------
$ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($_SERVER['REMOTE_ADDR'] ?? '0');
$dir = sys_get_temp_dir() . '/kankon-report';
if (!is_dir($dir)) @mkdir($dir, 0700, true);
$ipFile = $dir . '/ip-' . substr(hash('sha256', $ip . '|kankon'), 0, 24);
$now = time();
$fh = fopen($ipFile, 'c+');
if ($fh && flock($fh, LOCK_EX)) {
    $times = array_filter(array_map('intval', explode("\n", stream_get_contents($fh))), fn($t) => $t > $now - 86400);
    $hour = count(array_filter($times, fn($t) => $t > $now - 3600));
    $last = $times ? max($times) : 0;
    if ($now - $last < MIN_GAP || $hour >= PER_HOUR || count($times) >= PER_DAY) { flock($fh, LOCK_UN); fclose($fh); out(429, ['ok' => false, 'error' => 'rate_limited']); }
    $times[] = $now;
    ftruncate($fh, 0); rewind($fh); fwrite($fh, implode("\n", $times)); fflush($fh); flock($fh, LOCK_UN); fclose($fh);
}
$gFile = $dir . '/global-' . date('Ymd');
$g = (int)@file_get_contents($gFile);
if ($g >= GLOBAL_DAY) out(429, ['ok' => false, 'error' => 'busy']);
@file_put_contents($gFile, $g + 1);

// ---------- validate ----------
$app  = clean($in['app'] ?? '', 60);
$type = clean($in['type'] ?? '', 40);
$desc = clean($in['description'] ?? '', 4000, true);
$code = clean($in['code'] ?? '', 8000, true);
$mail = clean($in['email'] ?? '', 120);
$lang = in_array(($in['lang'] ?? ''), ['en', 'ar'], true) ? $in['lang'] : 'en';
$log  = clean($in['log'] ?? '', MAX_LOG, true);
$info = [];
foreach (is_array($in['info'] ?? null) ? array_slice($in['info'], 0, 20, true) : [] as $k => $v) {
    $k = clean((string)$k, 30); $v = clean(is_scalar($v) ? (string)$v : '', 120);
    if ($k !== '' && preg_match('/^[A-Za-z0-9 _.-]+$/', $k)) $info[$k] = $v;
}
if ($app === '' || mb_strlen($desc, 'UTF-8') < 10) out(400, ['ok' => false, 'error' => 'invalid']);
if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) out(400, ['ok' => false, 'error' => 'email']);
if (preg_match_all('~https?://~i', $desc) > 5) out(400, ['ok' => false, 'error' => 'spam']);   // link spam

$dupFile = $dir . '/dup-' . substr(hash('sha256', $app . '|' . $desc), 0, 24);
if (is_file($dupFile) && filemtime($dupFile) > $now - 600) out(200, ['ok' => true, 'ref' => 'KR-dup']);

// ---------- screenshot (kept on the NAS behind an unguessable link, deleted after KEEP_DAYS) ----------
$shotUrl = '';
$id = bin2hex(random_bytes(12));
if (!empty($in['screenshot'])) {
    $bin = base64_decode((string)$in['screenshot'], true);
    if ($bin === false || strlen($bin) > MAX_SHOT) out(400, ['ok' => false, 'error' => 'screenshot']);
    $im = @getimagesizefromstring($bin);
    $ext = $im ? ([IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg'][$im[2]] ?? '') : '';
    if ($ext === '') out(400, ['ok' => false, 'error' => 'screenshot']);
    $root = __DIR__ . '/report-files';
    @mkdir($root . '/' . $id, 0755, true);
    file_put_contents($root . '/' . $id . '/screenshot.' . $ext, $bin);
    file_put_contents($root . '/' . $id . '/index.html', '');   // no directory listing
    $shotUrl = 'https://kankon.net/report-files/' . $id . '/screenshot.' . $ext;
}
if (mt_rand(1, 20) === 1) {                                     // cheap cleanup of old attachments
    foreach (glob(__DIR__ . '/report-files/*', GLOB_ONLYDIR) ?: [] as $d) {
        if (filemtime($d) < $now - KEEP_DAYS * 86400) { foreach (glob($d . '/*') ?: [] as $f) @unlink($f); @rmdir($d); }
    }
}

// ---------- GitHub issue ----------
$slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($app)), '-');
$short = mb_substr(preg_replace('/\s+/u', ' ', $desc), 0, 70, 'UTF-8');
$title = '[Report] ' . safe($app) . ': ' . safe($short);
$body  = "**Program:** " . safe($app) . "\n**Type:** " . safe($type !== '' ? $type : '-') . "\n**Language:** " . $lang . "\n";
$body .= "**Contact email:** " . ($mail !== '' ? safe($mail) : '_none (anonymous)_') . "\n\n";
$body .= "### Description\n" . fence(safe($desc)) . "\n";
if ($code !== '') $body .= "\n### Error text / code from the user\n" . fence(safe($code)) . "\n";
if ($info) { $body .= "\n### Device and version info\n"; foreach ($info as $k => $v) $body .= "- **" . $k . ":** " . safe($v) . "\n"; }
if ($shotUrl !== '') $body .= "\n### Screenshot\n" . $shotUrl . " (kept " . KEEP_DAYS . " days)\n";
if ($log !== '') $body .= "\n<details><summary>Log (tail)</summary>\n\n" . fence(safe($log)) . "\n\n</details>\n";
$body .= "\n---\n_Sent from the in-app report form via kankon.net/report.php_";
if (strlen($body) > 60000) $body = substr($body, 0, 60000) . "\n...(cut)";

$payload = json_encode(['title' => $title, 'body' => $body, 'labels' => array_values(array_filter(['user-report', 'type:' . trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($type)), '-'), 'app:' . $slug], fn($l) => strlen($l) > 5 && strlen($l) < 50))], JSON_UNESCAPED_UNICODE);
$ch = curl_init('https://api.github.com/repos/' . $cfg['repo'] . '/issues');
curl_setopt_array($ch, [
    CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $cfg['token'], 'Accept: application/vnd.github+json', 'X-GitHub-Api-Version: 2022-11-28', 'User-Agent: kankon-report-relay', 'Content-Type: application/json'],
]);
$res = curl_exec($ch); $code2 = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
$j = is_string($res) ? json_decode($res, true) : null;
if ($code2 !== 201 || empty($j['number'])) { error_log('kankon-report: github ' . $code2); out(502, ['ok' => false, 'error' => 'upstream']); }
@touch($dupFile);
out(200, ['ok' => true, 'ref' => 'KR-' . $j['number']]);
