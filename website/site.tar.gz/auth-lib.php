<?php
// Kankon accounts: shared library (kankon.net). Used by auth/api.php, admin/index.php and report.php.
// Config: auth-config.php in the site folder (or one folder above). Never shipped in the website package.
//   <?php return ['resend_key'=>'re_...', 'admin_email'=>'...', 'pepper'=>'<random>', 'data_dir'=>'/volume1/kankon-data'];

const TRIAL_DAYS = 3;
const CODE_TTL = 600;
const SESSION_DAYS = 365;

function auth_cfg() {
    static $c = null;
    if ($c !== null) return $c;
    $c = [];
    foreach ([__DIR__ . '/auth-config.php', dirname(__DIR__) . '/auth-config.php'] as $f) {
        if (@is_file($f)) { $c = (include $f) ?: []; break; }
    }
    return $c;
}

function auth_db() {
    static $db = null;
    if ($db) return $db;
    $cfg = auth_cfg();
    $dirs = [];
    if (!empty($cfg['data_dir'])) $dirs[] = $cfg['data_dir'];
    $dirs[] = dirname(__DIR__) . '/kankon-data';
    // no fallback inside the web folder: the web server may serve it (nginx ignores .htaccess)
    $dir = null;
    foreach ($dirs as $d) {
        if (!is_dir($d)) @mkdir($d, 0700, true);
        if (is_dir($d) && is_writable($d)) { $dir = $d; break; }
    }
    if ($dir === null) throw new RuntimeException('no data dir');
    if (!is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');
    if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
    $name = 'kankon-' . substr(hash('sha256', ($cfg['pepper'] ?? 'x') . 'db'), 0, 16) . '.sqlite';
    $db = new PDO('sqlite:' . $dir . '/' . $name);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
    $db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, created_at INTEGER, last_login INTEGER, status TEXT DEFAULT 'active', lang TEXT, platform TEXT, launcher_version TEXT, note TEXT);
      CREATE TABLE IF NOT EXISTS codes(email TEXT PRIMARY KEY, code_hash TEXT, expires INTEGER, attempts INTEGER DEFAULT 0);
      CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY, user_id INTEGER, token_hash TEXT UNIQUE, created_at INTEGER, last_seen INTEGER, expires INTEGER, device_id TEXT);
      CREATE TABLE IF NOT EXISTS devices(device_id TEXT PRIMARY KEY, first_seen INTEGER, last_seen INTEGER, user_id INTEGER);
      CREATE TABLE IF NOT EXISTS usage(user_id INTEGER, app TEXT, last_used INTEGER, n INTEGER DEFAULT 0, PRIMARY KEY(user_id, app));
      CREATE TABLE IF NOT EXISTS rl(k TEXT, ts INTEGER);
      CREATE INDEX IF NOT EXISTS rl_k ON rl(k, ts);
      CREATE TABLE IF NOT EXISTS admin_sessions(token_hash TEXT PRIMARY KEY, expires INTEGER);");
    return $db;
}

function auth_h($s) { return hash('sha256', (auth_cfg()['pepper'] ?? '') . '|' . $s); }
function auth_rand($bytes = 32) { return bin2hex(random_bytes($bytes)); }
function auth_ip() { return $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '0'; }

// returns true when under the limit (and records the hit)
function auth_rate($key, $max, $window) {
    $db = auth_db(); $now = time();
    $db->prepare('DELETE FROM rl WHERE ts < ?')->execute([$now - 86400]);
    $st = $db->prepare('SELECT COUNT(*) FROM rl WHERE k=? AND ts>?'); $st->execute([$key, $now - $window]);
    if ((int)$st->fetchColumn() >= $max) return false;
    $db->prepare('INSERT INTO rl(k,ts) VALUES(?,?)')->execute([$key, $now]);
    return true;
}

function auth_bearer() {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($h === '' && function_exists('getallheaders')) { foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $h = $v; }
    return preg_match('/^Bearer\s+([a-f0-9]{64})$/i', trim($h), $m) ? strtolower($m[1]) : null;
}

// Shared with report.php: ['uid'=>int,'email'=>string] or null (invalid / expired / suspended)
function auth_verify($token) {
    if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) return null;
    try {
        $db = auth_db();
        $st = $db->prepare('SELECT s.id sid, u.id uid, u.email, u.status FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>?');
        $st->execute([auth_h($token), time()]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r || $r['status'] !== 'active') return null;
        $db->prepare('UPDATE sessions SET last_seen=?, expires=? WHERE id=?')->execute([time(), time() + SESSION_DAYS * 86400, $r['sid']]);
        return ['uid' => (int)$r['uid'], 'email' => $r['email']];
    } catch (Throwable $e) { return null; }
}

function auth_valid_email($e) { return is_string($e) && strlen($e) <= 120 && filter_var($e, FILTER_VALIDATE_EMAIL); }
