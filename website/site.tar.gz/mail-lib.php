<?php
// Kankon outgoing mail (kankon.net). send_mail($to,$subject,$html) -> bool. Quiet on failure.
// From no-reply@kankon.net, Reply-To support@kankon.net. Provider: Resend HTTPS API (key in auth-config.php).
require_once __DIR__ . '/auth-lib.php';

function kankon_mail_wrap($title, $bodyHtml) {
    return '<div style="font-family:Segoe UI,Arial,sans-serif;max-width:520px;margin:auto;border:1px solid #e3e6ee;border-radius:12px;overflow:hidden">'
        . '<div style="background:#0f1f3d;color:#fff;padding:16px 22px;font-size:18px;font-weight:600">Kankon</div>'
        . '<div style="padding:22px;color:#1a2233;line-height:1.6"><h2 style="margin:0 0 12px;font-size:18px">' . $title . '</h2>' . $bodyHtml . '</div>'
        . '<div style="background:#f5f7fb;color:#6b7690;padding:12px 22px;font-size:12px">Idea by Kankon · Built with Claude AI · kankon.net</div></div>';
}

function send_mail($to, $subject, $html) {
    try {
        $key = auth_cfg()['resend_key'] ?? '';
        if ($key === '' || !auth_valid_email($to) || !function_exists('curl_init')) return false;
        $ch = curl_init('https://api.resend.com/emails');
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key, 'Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode([
                'from' => 'Kankon <no-reply@kankon.net>', 'to' => [$to], 'reply_to' => 'support@kankon.net',
                'subject' => $subject, 'html' => $html,
            ], JSON_UNESCAPED_UNICODE),
        ]);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code >= 200 && $code < 300;
    } catch (Throwable $e) { return false; }
}
