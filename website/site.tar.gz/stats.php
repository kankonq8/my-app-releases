<?php
/* Kankon download statistics. Private: opens only from the home network (LAN), never from the internet. */
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');
function lan($ip) {
  if ($ip === '' || !filter_var($ip, FILTER_VALIDATE_IP)) return false;
  return !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}
$fw = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]) : '';
$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
if (!lan($ip) || ($fw !== '' && !lan($fw))) { http_response_code(403); echo 'Forbidden'; exit; }
$ar = isset($_GET['lang']) && $_GET['lang'] === 'ar';
$L = $ar ? array('t' => 'إحصاءات التنزيل', 'all' => 'إجمالي التنزيلات', 'win' => 'Windows', 'mac' => 'Mac', 'prod' => 'المنتج', 'ver' => 'الإصدار', 'os' => 'النظام', 'n' => 'العدد', 'days' => 'آخر 30 يومًا', 'bv' => 'حسب الإصدار', 'by' => 'حسب المنتج', 'none' => 'لا توجد تنزيلات مسجّلة بعد.', 'sw' => 'English', 'swl' => '?', 'priv' => 'هذه الصفحة خاصة، ولا تُفتح إلا من شبكتك المنزلية.')
            : array('t' => 'Download statistics', 'all' => 'Total downloads', 'win' => 'Windows', 'mac' => 'Mac', 'prod' => 'Product', 'ver' => 'Version', 'os' => 'System', 'n' => 'Count', 'days' => 'Last 30 days', 'bv' => 'By version', 'by' => 'By product', 'none' => 'No downloads recorded yet.', 'sw' => 'العربية', 'swl' => '?lang=ar', 'priv' => 'This page is private and opens only from your home network.');
$raw = @file_get_contents(__DIR__ . '/stats-data.php');
$nl = $raw === false ? false : strpos($raw, "\n");
$d = $nl === false ? null : json_decode(substr($raw, $nl + 1), true);
if (!is_array($d)) $d = array('c' => array(), 'day' => array());
$rows = array(); $tot = 0; $os = array('win' => 0, 'mac' => 0); $prod = array();
foreach ($d['c'] as $k => $n) {
  list($p, $o, $v) = array_pad(explode('|', $k), 3, '?');
  $rows[] = array($p, $o, $v, $n); $tot += $n;
  if (isset($os[$o])) $os[$o] += $n;
  if (!isset($prod[$p])) $prod[$p] = array('win' => 0, 'mac' => 0);
  $prod[$p][$o] = (isset($prod[$p][$o]) ? $prod[$p][$o] : 0) + $n;
}
usort($rows, function ($a, $b) { return strcmp($a[0], $b[0]) ?: version_compare($b[2], $a[2]) ?: strcmp($a[1], $b[1]); });
$names = array('launcher' => 'Kankon Launcher', 'AutoIpConfig' => 'Auto Create IP Config', 'NetworkMonitor' => 'Network Monitor', 'NetworkTools' => 'Network Tools', 'DriverManager' => 'Driver Manager', 'Dana' => 'Dana', 'SystemInfo' => 'System Info');
$h = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
$days = array(); for ($i = 29; $i >= 0; $i--) { $k = gmdate('Y-m-d', time() - 86400 * $i); $days[$k] = isset($d['day'][$k]) ? $d['day'][$k] : 0; }
$max = max(1, max($days));
?><!DOCTYPE html>
<html lang="<?= $ar ? 'ar' : 'en' ?>" dir="<?= $ar ? 'rtl' : 'ltr' ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex"><title><?= $h($L['t']) ?> · Kankon</title><link rel="icon" href="favicon.ico">
<style>
body{margin:0;background:#060914;color:#e8ecf8;font:16px/1.5 system-ui,"Segoe UI",Tahoma,sans-serif}
.w{max-width:960px;margin:0 auto;padding:32px 20px}
h1{margin:0 0 4px;font-size:30px}h2{margin:34px 0 12px;font-size:20px}
.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.sw{color:#e8ecf8;border:1px solid #2a3350;border-radius:10px;padding:8px 14px;text-decoration:none}
.muted{color:#93a0c0;font-size:14px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-top:22px}
.card{background:#0f1424;border:1px solid #1e2742;border-radius:16px;padding:18px}
.card b{display:block;font-size:34px;background:linear-gradient(90deg,#5b8cff,#22d3ee);-webkit-background-clip:text;background-clip:text;color:transparent}
table{width:100%;border-collapse:collapse;background:#0f1424;border:1px solid #1e2742;border-radius:16px;overflow:hidden}
th,td{padding:10px 14px;text-align:start;border-bottom:1px solid #1e2742}th{color:#93a0c0;font-weight:600;font-size:14px}
td.n{font-weight:700}tr:last-child td{border-bottom:0}
.bars{display:flex;align-items:flex-end;gap:4px;height:140px;background:#0f1424;border:1px solid #1e2742;border-radius:16px;padding:14px}
.bars div{flex:1;background:linear-gradient(#22d3ee,#5b8cff);border-radius:4px 4px 0 0;min-height:2px}
</style></head><body><div class="w">
<div class="top"><div><h1><?= $h($L['t']) ?></h1><div class="muted"><?= $h($L['priv']) ?></div></div><a class="sw" href="stats.php<?= $ar ? '' : '?lang=ar' ?>"><?= $h($L['sw']) ?></a></div>
<div class="cards"><div class="card"><b><?= $tot ?></b><?= $h($L['all']) ?></div><div class="card"><b><?= $os['win'] ?></b><?= $h($L['win']) ?></div><div class="card"><b><?= $os['mac'] ?></b><?= $h($L['mac']) ?></div></div>
<?php if (!$rows): ?><p class="muted" style="margin-top:28px"><?= $h($L['none']) ?></p><?php else: ?>
<h2><?= $h($L['days']) ?></h2>
<div class="bars"><?php foreach ($days as $k => $n): ?><div style="height:<?= round($n / $max * 100) ?>%" title="<?= $h($k) ?>: <?= $n ?>"></div><?php endforeach; ?></div>
<h2><?= $h($L['by']) ?></h2>
<table><tr><th><?= $h($L['prod']) ?></th><th>Windows</th><th>Mac</th></tr>
<?php foreach ($prod as $p => $c): ?><tr><td><?= $h(isset($names[$p]) ? $names[$p] : $p) ?></td><td class="n"><?= $c['win'] ?></td><td class="n"><?= $c['mac'] ?></td></tr><?php endforeach; ?></table>
<h2><?= $h($L['bv']) ?></h2>
<table><tr><th><?= $h($L['prod']) ?></th><th><?= $h($L['ver']) ?></th><th><?= $h($L['os']) ?></th><th><?= $h($L['n']) ?></th></tr>
<?php foreach ($rows as $r): ?><tr><td><?= $h(isset($names[$r[0]]) ? $names[$r[0]] : $r[0]) ?></td><td dir="ltr"><?= $h($r[2]) ?></td><td><?= $r[1] === 'mac' ? 'Mac' : 'Windows' ?></td><td class="n"><?= $r[3] ?></td></tr><?php endforeach; ?></table>
<?php endif; ?>
</div></body></html>
