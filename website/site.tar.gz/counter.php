<?php
/* Kankon visitor counter (kankon.net). Stores no IPs: only a random browser id and the time it was last seen.
   counter.php?id=<random>&n=1  ->  {"total":N,"online":M}   (n=1 counts a new visit, once per browser session) */
header('Cache-Control: no-store');
header('Content-Type: application/json');
if (isset($_GET['check'])) {
  $f = __DIR__ . '/counter-data.php';
  echo json_encode(array('php' => PHP_VERSION, 'dirWritable' => is_writable(__DIR__), 'fileExists' => file_exists($f),
    'fileWritable' => file_exists($f) ? is_writable($f) : null, 'tmpWritable' => is_writable(sys_get_temp_dir())));
  exit;
}
$id = isset($_GET['id']) ? (string)$_GET['id'] : '';
if (!preg_match('/^[a-z0-9]{8,32}$/', $id)) { http_response_code(400); echo '{}'; exit; }
$new = isset($_GET['n']) && $_GET['n'] === '1';
$file = __DIR__ . '/counter-data.php';
$fh = @fopen($file, 'c+');
if (!$fh) { $file = rtrim(sys_get_temp_dir(), '/') . '/kankon-counter-data.php'; $fh = @fopen($file, 'c+'); } /* fallback when the web folder is read-only for PHP */
if (!$fh) { http_response_code(500); echo '{"error":"cannot write data file"}'; exit; }
$out = array('total' => 0, 'online' => 1);
if (flock($fh, LOCK_EX)) {
  $raw = stream_get_contents($fh);
  $nl = strpos($raw, "\n");
  $d = $nl === false ? null : json_decode(substr($raw, $nl + 1), true);
  if (!is_array($d)) $d = array('total' => 0, 'on' => array());
  $now = time();
  if ($new) $d['total']++;
  $d['on'][$id] = $now;
  foreach ($d['on'] as $k => $t) if ($now - $t > 180) unset($d['on'][$k]);
  if (count($d['on']) > 5000) { asort($d['on']); $d['on'] = array_slice($d['on'], -5000, null, true); }
  ftruncate($fh, 0); rewind($fh);
  fwrite($fh, "<?php http_response_code(404); exit; ?>\n" . json_encode($d));
  fflush($fh); flock($fh, LOCK_UN);
  $out = array('total' => $d['total'], 'online' => max(1, count($d['on'])));
}
fclose($fh);
echo json_encode($out);
